import json
import os

from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KnowledgeGraphIndexConfig, QueryConfig, KBCreationConfig, \
    QueryResults, DeepThinkConfig
from kbx.splitter.types import SplitterConfig

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')


def setup(schema):
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    KBX.init(config=kbx_yaml_file)
    ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
    KBX.register_ai_models_from_conf(ai_models_yaml_file, overwrite=True, user_id=DEFAULT_USER_ID)
    # schema = json.load(open(schemapath, 'r'))
    kb_config = KBCreationConfig(
        name='新知识图谱测试知识库',
        description='',
        is_external_datastore=False,
        kg_config=KnowledgeGraphIndexConfig(
            index_strategy="DefaultGraphIndex",
            llm_model="doubao-1.5-pro-32k",
            embedding_model="doubao-embedding",
            schema_dict=schema,
            splitter_config=SplitterConfig(
                name="NaiveTextSplitter",
                delimiters=["\n\n"],
            ),
        ),
    )
    kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
    kb_name2id = dict([(item.name, item.kb_id) for item in kbs_info])
    existed_kb_id = kb_name2id.get(kb_config.name, None)
    if existed_kb_id:
        # 已经存在，尝试从DB中读取
        print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.get_existed_kb(kb_id=existed_kb_id)
    else:
        # 未存在，尝试创建
        print(f'Try to restore new kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
    return kb


def format_triplets(triplets: list[list]) -> str:
    """
    格式化三元组
    Args:
        triplets (list[list[str]]): 三元组列表

    Returns:
        str: 三元组str
    """
    return "\n".join(list(set([",".join(triplet) for triplet in triplets])))


if __name__ == '__main__':
    schema = json.load(open('tests/schema/schema.json', 'r'))
    kb = setup(schema)
    question = "万科高管有哪些？"
    # 使用知识库直接查询
    query = QueryConfig(
        text=question,
        top_k=5,
        score_threshold=0.1,
        deep_think=DeepThinkConfig()
    )
    query_result = kb.retrieve(query=query)
    print(query_result)
    assert isinstance(query_result, QueryResults), \
        f"Query result should be a QueryResults object, given {type(query_result)}"
    assert isinstance(query_result.results, list), \
        f"Retrieval results should be a list, given {type(query_result.results)}"
    assert len(query_result) > 0, "Failed to get query result"
