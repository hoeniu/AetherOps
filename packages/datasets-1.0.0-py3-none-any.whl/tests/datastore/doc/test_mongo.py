import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys

sys.path.insert(0, ROOT_DIR)
from pymongo import MongoClient


def main():
    from kbx.kbx import KBX
    KBX.init("conf/kbx_settings.yaml")
    config = KBX.config.doc_ds.connection_kwargs
    username = config["username"]
    password = config["password"]
    host = config["host"]
    port = config["port"]
    client = MongoClient(f"mongodb://{username}:{password}@{host}:{port}/")
    for db_name in client.list_database_names():
        if db_name not in ["admin", "config", "local"]:
            print(db_name)
            client.drop_database(db_name)


if __name__ == "__main__":
    main()
