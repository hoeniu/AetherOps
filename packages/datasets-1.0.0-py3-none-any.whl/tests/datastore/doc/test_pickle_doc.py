import pickle
import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
sys.path.insert(0, ROOT_DIR)
from typing import Dict, List
from kbx.datastore.doc.nano_doc import IndexType
from kbx.common.types import DocData, DocElement, Chunk


class DocTest:

    def __init__(self):
        self.index_type_list = list(IndexType)
        self.doc_file: str = "debug_data/doc_data.pickle"
        self.chunk_files: List[str] = [f"debug_data/{item}.pickle" for item in self.index_type_list]
        print(self.chunk_files)
        self.id_map_file = "debug_data/id_map.pickle"
        self.doc_data: Dict[str, DocData] = dict()  # {doc_id -> doc}
        self.chunk_data: Dict[str, Dict[str, Chunk]] = dict()  # {index_type -> {chunk_id -> chunk}}
        self.doc_id2chunk_id: Dict[str, Dict[str, List[str]]] = dict()  # {doc_id->{index_type->chunk_id_list}}
        self.doc_element: Dict[str, DocElement] = dict()  # {doc_element_id -> doc_element}

    def __fill_doc_element_item(self, doc_element_dict: Dict[str, DocElement], doc_data: DocData):
        for doc_element in doc_data.doc_elements:
            doc_element_dict[doc_element.doc_element_id] = doc_element

    def load(self):
        if os.path.exists(self.doc_file):
            with open(self.doc_file, 'rb') as file_handler:
                self.doc_data = pickle.load(file_handler)
                for doc_data in self.doc_data.values():
                    self.__fill_doc_element_item(self.doc_element, doc_data)
        for i in range(len(self.chunk_files)):
            if not os.path.exists(self.chunk_files[i]):
                self.chunk_data[self.index_type_list[i]] = dict()
            else:
                with open(self.chunk_files[i], 'rb') as file_handler:
                    self.chunk_data[self.index_type_list[i]] = pickle.load(file_handler)
        if os.path.exists(self.id_map_file):
            with open(self.id_map_file, 'rb') as file_handler:
                self.doc_id2chunk_id = pickle.load(file_handler)

    def show(self):
        for key in self.chunk_data.keys():
            print(key)
            chunk_data = self.chunk_data[key]
            for key2 in chunk_data.keys():
                print(key2, chunk_data[key2])

    def show_keys(self):
        print(self.chunk_data.keys())
        print("07a93708-e1a0-4f01-9240-1b56c900a8e1" in self.chunk_data["vector_keyword"].keys())
        print(self.chunk_files)


def main():

    doc_test = DocTest()
    doc_test.load()
    doc_test.show_keys()


if __name__ == "__main__":
    main()
