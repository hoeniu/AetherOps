import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
sys.path.insert(0, ROOT_DIR)
from kbx.common.types import Chunk, DocData, DocElement, DocElementType, DocElementCollection
from uuid import uuid4
import enum
from pydantic import BaseModel, Field, field_serializer


class Color(enum.Enum):
    RED = "red"
    BLUE = "blue"


class MyModel(BaseModel):
    color: Color = Field(default=Color.RED, description="颜色")

    @field_serializer('color')
    def serialize_color(self, color: Color, _info):
        return color.value  # 始终输出 Enum 的值作为字符串


def main():

    chunk: Chunk = Chunk()
    print(chunk)
    doc_data: DocData = DocData()
    doc_element: DocElement = DocElement(
        doc_element_id="xxx-a-b-xx",
        type=DocElementType.TEXT
    )
    print(doc_element.model_dump())

    doc_element_collection = DocElementCollection()
    for i in range(1):
        for j in range(3):
            de = DocElement(doc_element_id=str(uuid4()), text=f"doc_{i}_element{j}")
            print(de.model_dump())
            doc_element_collection.append(de)
        doc_data: DocData = DocData(doc_id=str(uuid4().hex), file_name=f"file{i}.txt",
                                    file_path=f"./files/file{i}.txt",
                                    doc_elements=doc_element_collection)
        print(doc_data.model_dump())

    model = MyModel()
    model_dict = model.model_dump()
    print(model)
    print(model_dict)
    model_dict["color"] = "blue"
    model = MyModel.model_validate(model_dict)
    print(model)
    print(model.model_dump())


if __name__ == "__main__":
    main()
