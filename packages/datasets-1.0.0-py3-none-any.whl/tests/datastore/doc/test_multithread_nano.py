import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
import threading
sys.path.insert(0, ROOT_DIR)
from kbx.kbx import KBX
from kbx.common.constants import DEFAULT_USER_ID
from tests.base_test_case import BaseTestCase
from kbx.knowledge_base.knowledge_base import KBCreationConfig
from tests.datastore.doc.test_nano import nano_doc_workflow


concur_num = 10

kb_config = KBCreationConfig(
    name="test_kb",
    description="用于测试的kb",
    is_external_datastore=False
)


class TestMultiThreadDoc(BaseTestCase):
    def test_multi_thread_doc(self):
        task_list = []

        kb_id: str = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID).kb_id
        print(kb_id)
        # 创建Thread实例
        for i in range(concur_num):
            thread = threading.Thread(target=nano_doc_workflow, args=(str(i), kb_id))
            task_list.append(thread)

        # 启动所有线程
        for i in range(concur_num):
            task_list[i].start()
            print(f"thread{i} start.")

        for i in range(concur_num):
            # 等待线程结束
            task_list[i].join()


if __name__ == "__main__":
    # 手动执行
    test_case = TestMultiThreadDoc()
    test_case.setup_class()
    test_case.test_multi_thread_doc()
