import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys

sys.path.insert(0, ROOT_DIR)
from uuid import uuid4
from kbx.datastore.doc.doc_base import BaseDocDS
from kbx.common.types import KBXError, DocData, DocElement, Chunk, IndexType, DocElementCollection
from kbx.common.constants import DEFAULT_TENANT_ID, DEFAULT_USER_ID
from kbx.knowledge_base.knowledge_base import KBCreationConfig
from kbx.datastore.ds_factory import get_fast_doc_ds

DOC_NUM = 10
DOC_ELEMENTS_NUM = 2
CHUNK_NUM = 3

kb_config = KBCreationConfig(
    name="test_kb",
    description="用于测试的kb",
    is_external_datastore=False
)


def fast_doc_workflow(thread_id: str):
    doc_ds: BaseDocDS = get_fast_doc_ds(DEFAULT_TENANT_ID, DEFAULT_USER_ID)
    with doc_ds:

        for i in range(DOC_NUM):
            doc_element_collection = DocElementCollection()
            for j in range(DOC_ELEMENTS_NUM):
                doc_element_collection.append(DocElement(doc_element_id=str(uuid4()), text=f"doc_{i}_element{j}"))
            doc_data: DocData = DocData(doc_id=str(uuid4().hex), file_name=f"file{i}.txt",
                                        file_path=f"./files/file{i}.txt",
                                        doc_elements=doc_element_collection)
            error: KBXError = doc_ds.save_doc_data(doc_data)
            if error.code != KBXError.Code.SUCCESS:
                print(error.msg)
        doc_ids, error = doc_ds.list_doc_ids()
        if error.code == KBXError.Code.SUCCESS:
            print("After save operation:", doc_ids)
        else:
            print("doc_ds.list_doc_ids() error happened: ", error.msg)

        for doc_id in doc_ids:
            doc_data, error = doc_ds.load_doc_data(doc_id)
            if error.code != KBXError.Code.SUCCESS:
                print(error.msg)
            # else:
            #     print(f"{thread_id} -> {doc_data}")

        for i in range(len(doc_ids)):
            if i % 3 == 0:
                print(f"delete doc {doc_ids[i]}")
                error = doc_ds.delete_doc_data(doc_ids[i])
                if error.code != KBXError.Code.SUCCESS:
                    print("doc_ds.delete_doc_data() error happened: ", error.msg)

        doc_ids, error = doc_ds.list_doc_ids()
        if error.code == KBXError.Code.SUCCESS:
            print("After deleted operation: ", doc_ids)
        else:
            print(KBXError.msg)

        for doc_id in doc_ids:
            for i in range(CHUNK_NUM):
                chunk: Chunk = Chunk(
                    text=f"a{i}b{i}c{i}d{i}",
                    chunk_id=str(uuid4().hex),
                    doc_id=doc_id,
                    doc_element_ids=[f"id1{i}", f"id2{i}", f"id3{i}"],
                    meta_data=dict()
                )
                error = doc_ds.save_chunk(chunk, index_type=IndexType.VECTOR_KEYWORD)
                if error.code != KBXError.Code.SUCCESS:
                    print(f"{thread_id} -> ERROR: {error.msg}")

        for doc_id in doc_ids:
            chunk_ids, error = doc_ds.list_chunk_ids_by_doc_id(doc_id=doc_id, index_type=IndexType.VECTOR_KEYWORD)
            print(doc_id, chunk_ids)
            if chunk_ids:
                doc_ds.delete_chunk(chunk_ids[0], index_type=IndexType.VECTOR_KEYWORD)
            chunk_ids, error = doc_ds.list_chunk_ids_by_doc_id(doc_id=doc_id, index_type=IndexType.VECTOR_KEYWORD)
            print(doc_id, chunk_ids)

        doc_ds.flush()
        # doc_ds.delete_ds()
        doc_ds.close()


if __name__ == "__main__":
    from kbx.kbx import KBX
    KBX.init("conf/kbx_settings.yaml")
    fast_doc_workflow("0")
