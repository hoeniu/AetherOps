import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
from typing import Dict, List, Tuple
import threading
sys.path.insert(0, ROOT_DIR)
import time
from kbx.common.types import StructuredDSConfig
from kbx.datastore.structured.structured_base import BaseStructuredDS
from kbx.datastore.structured.sqlite_structured import SqliteStructuredDS
from kbx.kbx import KBX
from kbx.common.constants import DEFAULT_USER_ID
from tests.base_test_case import BaseTestCase
from kbx.knowledge_base.knowledge_base import KBCreationConfig

concur_num = 10


def sqlite_workflow(thread_id: str, kb_id: str):
    structured_ds_config: StructuredDSConfig = StructuredDSConfig()
    structured_ds: BaseStructuredDS = SqliteStructuredDS(structured_ds_config, kb_id, "structured", "default")
    structured_ds.connect()
    print(structured_ds.get_type())

    table_name: str = "test_data"
    attr: Dict[str, Tuple[str, bool, str, str]] = dict()
    attr["name"] = ("varchar(20)", False, "", "name of this data.")
    attr["email"] = ("varchar(40)", False, "", "email of this data.")
    index_dict: Dict[str, List[str]] = dict()
    index_dict["index1"] = ["name"]
    index_dict["index2"] = ["email"]

    time.sleep(5)
    res, error = structured_ds.create_table(table_name, attr, key=None, index=index_dict)
    print("THREAD_ID: ", thread_id, ":", res, error)

    table_list, error = structured_ds.show_tables()
    print("THREAD_ID: ", thread_id, ":", table_list, error)

    for table_name in table_list:
        res, error = structured_ds.show_create_table(table_name)
        print("THREAD_ID: ", thread_id, ":", res, error)

    print("THREAD_ID: ", thread_id, ": SHOW CREATE TABLE FINISH.")

    item_list = list()
    item_list.append({"name": "name1", "email": "email1"})
    item_list.append({"name": "name2", "email": "email2"})
    res, error = structured_ds.batch_insert(item_list, table_name)
    print("THREAD_ID: ", thread_id, ":", res, error)

    time.sleep(5)
    # 测试select
    target_list = ["*"]
    table_name = "test_data"
    condition_list = []
    selected_list, error = structured_ds.select(target_list, table_name, condition_list)
    print("THREAD_ID: ", selected_list, error)

    # 测试batch_upsert
    for i in range(len(selected_list)):
        selected_list[i]["name"] = f"heihei{i}"
    error = structured_ds.batch_upsert(selected_list, table_name)
    print("THREAD_ID: ", thread_id, " Batch Upsert:", error)
    selected_list, error = structured_ds.select(target_list, table_name, condition_list)
    print("THREAD_ID: ", thread_id, " After batch upsert: ", selected_list, error)

    # 测试batch_update
    for i in range(len(selected_list)):
        selected_list[i]["email"] = f"a{i}@smartmore.com"
    error = structured_ds.batch_update(selected_list, table_name)
    print(error)
    selected_list, error = structured_ds.select(target_list, table_name, condition_list)
    print(selected_list, error)
    res, error = structured_ds.execute_sql("SELECT * FROM test_data;")
    print("THREAD_ID: ", thread_id, " Custom Execute SQL: ", res, error)
    item_id = selected_list[0]["id"]
    res, error = structured_ds.execute_sql(f"UPDATE test_data SET name = 'update_name' WHERE id = '{item_id}';")
    print("THREAD_ID: ", thread_id, " Custom Execute SQL: ", res, error)
    res, error = structured_ds.execute_sql(f"UPDATE test_data SET name = 'update_name' WHERE id = '{item_id}';")
    print("THREAD_ID: ", thread_id, " Custom Execute SQL: ", res, error)

    # 测试批量删除
    item_ids = list()
    for item in selected_list:
        item_ids.append(item["id"])
    res, error = structured_ds.batch_delete(item_ids, table_name)
    print(res, error)
    # 这里返回空list.
    selected_list, error = structured_ds.select(target_list, table_name, condition_list)
    print(selected_list, error)

    res, error = structured_ds.drop_table(table_name)
    print(res, error)

    structured_ds.flush()
    error = structured_ds.delete_ds()
    print(error)


kb_config = KBCreationConfig(
    name="test_kb",
    description="用于测试的kb",
    is_external_datastore=False
)


class TestMultiThreadSqlite(BaseTestCase):
    def test_multi_thread_sqlite(self):
        task_list = []

        kb_id: str = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID).kb_id
        print(kb_id)
        # 创建Thread实例
        for i in range(concur_num):
            thread = threading.Thread(target=sqlite_workflow, args=(str(i), kb_id))
            task_list.append(thread)

        # 启动所有线程
        for i in range(concur_num):
            task_list[i].start()

        for i in range(concur_num):
            # 等待线程结束
            task_list[i].join()


if __name__ == "__main__":
    # 手动执行
    test_case = TestMultiThreadSqlite()
    test_case.setup_class()
    test_case.test_multi_thread_sqlite()
