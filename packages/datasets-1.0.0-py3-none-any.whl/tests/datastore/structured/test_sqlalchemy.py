from sqlalchemy import create_engine, Engine, text


def main():
    engine: Engine = create_engine("mysql+pymysql://root:admin@211.93.18.51:3306/db_c902addb4a4743c08589e615907f89a8",
                                   echo=True)
    with engine.connect() as conn:
        result = conn.execute(text("SELECT 城市 FROM"
                                   "("
                                   "  SELECT 城市, 城市人口 FROM 中国部分城市人口数据表_china_cities_populat"
                                   "  UNION ALL SELECT 城市, 城市人口 FROM 中国部分城市人口信息表"
                                   ")"
                                   "combined ORDER BY 城市人口 DESC LIMIT 2;"))
        print(result.rowcount)
        rows_as_dicts = [dict(row) for row in result.mappings()]
        print(rows_as_dicts)


if __name__ == "__main__":
    main()
