import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys
sys.path.insert(0, ROOT_DIR)
from typing import Dict, List, Tuple
from kbx.datastore.structured.structured_base import BaseStructuredDS
from kbx.datastore.structured.sqlite_structured import SqliteStructuredDS
from kbx.common.types import StructuredDSConfig
from tests.datastore.tool import create_default_user_tenant_kb


def main():

    structured_ds_config: StructuredDSConfig = StructuredDSConfig()
    kb_id: str = create_default_user_tenant_kb()
    print(kb_id)
    base_ds: BaseStructuredDS = SqliteStructuredDS(structured_ds_config, kb_id)
    base_ds.connect()

    table_name: str = "info_table"
    attr: Dict[str, Tuple[str, bool, str, str]] = dict()
    attr["doc_id"] = ("varchar(255)", True, "", "name of this data.")
    attr["table_name"] = ("varchar(255)", True, "", "email of this data.")
    index_dict: Dict[str, List[str]] = dict()
    index_dict["index"] = ["doc_id", "table_name"]

    res, error = base_ds.create_table(table_name, attr, key=None, index=index_dict, comment="test comment")
    print(res, error)

    table_list, error = base_ds.show_tables()
    print(table_list, error)

    item_list = [{"doc_id": "xxx-1-xxx", "table_name": "city_data"}]
    error = base_ds.batch_insert(item_list, table_name)
    print(error)

    item_list = [{"doc_id": "xxx-1-xxx", "table_name": "city_data"}]
    error = base_ds.batch_insert(item_list, table_name)
    print(error)

    res, error = base_ds.select(target_list=["*"], table_name=table_name, condition_list=[])
    print(res, error)

    res = base_ds.delete_ds()
    print("deleted: ", res)


if __name__ == "__main__":
    main()
