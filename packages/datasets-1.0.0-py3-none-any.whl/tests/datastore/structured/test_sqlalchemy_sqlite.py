import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys
sys.path.insert(0, ROOT_DIR)
from typing import Dict, List, Tuple
from kbx.datastore.structured.structured_base import BaseStructuredDS
from kbx.datastore.structured.sqlalchemy_structured import SqlAlchemyStructuredDS
from tests.datastore.tool import create_default_user_tenant_kb


def main():

    from kbx.kbx import KBX
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    KBX.init(config=kbx_yaml_file)

    kb_id: str = create_default_user_tenant_kb()
    # kb_id = "c5cc7d59-60c8-4e9f-a343-111d1c8ff19c"
    print(kb_id)

    structured_ds: BaseStructuredDS = SqlAlchemyStructuredDS(KBX.config.structured_ds, kb_id, "structured", "default")
    structured_ds.connect()

    print(structured_ds.get_type())

    table_name: str = "test_data"
    attr: Dict[str, Tuple[str, bool, str, str]] = dict()
    attr["name"] = ("varchar(20)", False, "default_name", "name of this data.")
    attr["email"] = ("varchar(40)", False, "default_email", "email of this data.")
    index_dict: Dict[str, List[str]] = dict()
    index_dict["index1"] = ["name"]
    index_dict["index2"] = ["email"]

    res, error = structured_ds.create_table(table_name, attr, key=None, index=index_dict, comment="")
    print("CreateTable: ", res, error)

    table_list, error = structured_ds.show_tables()
    print("SHOW TABLES: ", table_list, error)

    for table_name in table_list:
        res, error = structured_ds.show_create_table(table_name)
        print("SHOW CREATE TABLE: ", res, error)

    print("SHOW CREATE TABLE FINISH.")

    item_list = list()
    item_list.append({"name": "name1", "email": "email1"})
    item_list.append({"name": "name2", "email": "email2"})
    # item_list.append({"name": "name1", "email": "email2"})
    res, error = structured_ds.batch_insert(item_list, table_name)
    print("Batch Insert: ", res, error)

    # 测试select
    target_list = ["*"]
    table_name = "test_data"
    condition_list = []
    selected_list, error = structured_ds.select(target_list, table_name, condition_list)
    print("After Batch Insert Operation: ", selected_list, error)

    # 测试batch_upsert
    for i in range(len(selected_list)):
        selected_list[i]["name"] = f"heihei{i}"
    error = structured_ds.batch_upsert(selected_list, table_name)
    print("Batch Upsert: ", error)
    selected_list, error = structured_ds.select(target_list, table_name, condition_list)
    print("After Batch Upsert Operation: ", selected_list, error)

    # 测试batch_update
    for i in range(len(selected_list)):
        selected_list[i]["email"] = f"a{i}@smartmore.com"
    error = structured_ds.batch_update(selected_list, table_name)
    print(error)
    selected_list, error = structured_ds.select(target_list, table_name, condition_list)
    print(selected_list, error)

    item_id = selected_list[0]["id"]
    res, error = structured_ds.execute_sql(f"UPDATE test_data SET name = 'update_name' WHERE id = '{item_id}';")
    print("Custom Execute Update SQL: ", res, error)
    res, error = structured_ds.execute_sql("SELECT * FROM test_data;")
    print("Custom Execute SELECT SQL: ", res, error)

    # 测试批量删除
    item_ids = list()
    for item in selected_list:
        item_ids.append(item["id"])
    res, error = structured_ds.batch_delete(item_ids, table_name)
    print("Batch Delete: ", res, error)
    # 这里返回空list.
    selected_list, error = structured_ds.select(target_list, table_name, condition_list)
    print("After Batch Delete Operation: ", selected_list, error)

    res, error = structured_ds.drop_table(table_name)
    print(res, error)

    # error = structured_ds.delete_ds()
    # print(error)

    os.system("rm -r volumes/*")


if __name__ == "__main__":
    main()
