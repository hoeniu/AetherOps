import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../..")
import sys
sys.path.insert(0, ROOT_DIR)
from kbx.kbx import KBX
from concurrent.futures import ThreadPoolExecutor
from kbx.common.constants import DEFAULT_USER_ID
from kbx.knowledge_base.knowledge_base import KnowledgeBase, KBCreationConfig

import pypdfium2


kb_config = KBCreationConfig(
    name="test_kb",
    description="用于测试的kb",
    is_external_datastore=False
)


def create_default_user_tenant_kb() -> str:
    kb: KnowledgeBase = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
    return kb.kb_id


def parse(file_path: str):
    print(file_path)
    with open(file_path, 'rb') as f:
        pdf_reader = pypdfium2.PdfDocument(f, autoclose=True)
        try:
            for page_number, page in enumerate(pdf_reader):
                text_page = page.get_textpage()
                content = text_page.get_text_range(force_this=True)
                text_page.close()
                page.close()
                print(content)
        except Exception as e:
            print(str(e))


def main():
    data_dir = "cache/kbx_test_data"
    file_list = [
        os.path.join(data_dir, "1.pdf"),
        os.path.join(data_dir, "2.pdf"),
        os.path.join(data_dir, "3.pdf"),
        os.path.join(data_dir, "4.pdf"),
        os.path.join(data_dir, "5.pdf"),
    ]
    with ThreadPoolExecutor(max_workers=5) as pool:
        pool.map(parse, file_list)
    print("Completed.")


if __name__ == "__main__":
    main()
