import os
import time

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys
sys.path.insert(0, ROOT_DIR)
from kbx.datastore.vector.chroma_vector import ChromaVectorDS
from kbx.common.types import VectorDSConfig
from typing import List, Tuple
from kbx.common.constants import DEFAULT_USER_ID
from kbx.knowledge_base.knowledge_base import KBCreationConfig

kb_config = KBCreationConfig(
    name="test_kb",
    description="用于测试的kb",
    is_external_datastore=False
)

chunk_embedding_list: List[Tuple[str, List[float]]] = list()
chunk_embedding_list.append(("id1", [0.01, 0.01, 0.01]))
chunk_embedding_list.append(("id2", [0.01, 0.01, -0.01]))
chunk_embedding_list.append(("id3", [0.01, -0.01, 0.01]))
chunk_embedding_list.append(("id4", [0.01, -0.01, -0.01]))
chunk_embedding_list.append(("id5", [-0.01, 0.01, 0.01]))
chunk_embedding_list.append(("id6", [-0.01, 0.01, -0.01]))
chunk_embedding_list.append(("id7", [-0.01, -0.01, 0.01]))
chunk_embedding_list.append(("id8", [-0.01, -0.01, -0.01]))


def chroma_single_thread_work_flow(thread_id: str, kb_id: str):

    vector_ds_config: VectorDSConfig = VectorDSConfig()
    vector_ds = ChromaVectorDS(vector_ds_config, kb_id, "vector", "default")

    with vector_ds:
        error = vector_ds.add(chunk_embedding_list)
        """ chroma 使用 upsert 方式添加，这里允许反复添加相同的id """
        print(f"thread_id: {thread_id} --> 测试添加向量的结果: {error}")
        id_list, error = vector_ds.search_by_vector([0.01, 0.01, 0.01])
        print(f"thread_id: {thread_id} --> 测试search_by_vector的结果: {id_list}, {error}")
        id_list, error = vector_ds.search_by_vector([0.005, 0.01, 0.01])
        print(str(id_list))
        print(str(error))

        print(vector_ds.if_chunk_id_exists("id8"))
        print(vector_ds.delete_by_chunk_ids(["id8"]))
        print(vector_ds.if_chunk_id_exists("id8"))


def chroma_delete_ds(kb_id: str, place_holder: str):

    vector_ds_config: VectorDSConfig = VectorDSConfig()
    vector_ds = ChromaVectorDS(vector_ds_config, kb_id, "vector", "default")
    with vector_ds:
        try:
            res = vector_ds.delete_ds()
            print(f"删除DS结果：{res}, {place_holder}")
        except Exception as e:
            print(f"删除DS结果：删除失败 {str(e)}")

    time.sleep(1)
    vector_ds2 = ChromaVectorDS(vector_ds_config, kb_id, "vector", "default")
    with vector_ds2:
        try:
            res = vector_ds2.delete_ds()
            print(f"删除DS结果：{res}, {place_holder}")
        except Exception as e:
            print(f"删除DS结果：删除失败 {str(e)}")


if __name__ == "__main__":
    from kbx.kbx import KBX
    KBX.init("conf/kbx_settings.yaml")
    local_kb_id: str = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID).kb_id
    chroma_single_thread_work_flow("0", local_kb_id)
    chroma_delete_ds(local_kb_id, "0")
