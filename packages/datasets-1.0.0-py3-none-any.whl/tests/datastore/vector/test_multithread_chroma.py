import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
import threading
sys.path.insert(0, ROOT_DIR)
from kbx.kbx import KBX
from kbx.common.constants import DEFAULT_USER_ID
from tests.datastore.vector.test_chroma import chroma_single_thread_work_flow, chroma_delete_ds
from tests.base_test_case import BaseTestCase
from kbx.knowledge_base.knowledge_base import KBCreationConfig

concur_num = 10


kb_config = KBCreationConfig(
    name="test_kb",
    description="用于测试的kb",
    is_external_datastore=False
)


class TestMultiThreadChroma(BaseTestCase):
    def test_multi_thread_chroma(self):
        task_list = []

        kb_id: str = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID).kb_id
        print("kb_id: ", kb_id)
        # 创建Thread实例
        for i in range(concur_num):
            thread = threading.Thread(target=chroma_single_thread_work_flow, args=(str(i), kb_id))
            task_list.append(thread)

        # 启动所有线程
        for i in range(concur_num):
            task_list[i].start()

        for i in range(concur_num):
            # 等待线程结束
            task_list[i].join()

        t = threading.Thread(target=chroma_delete_ds, args=(kb_id, ""))
        t.start()
        t.join()


if __name__ == "__main__":
    # 手动执行
    test_case = TestMultiThreadChroma()
    test_case.setup_class()
    test_case.test_multi_thread_chroma()
