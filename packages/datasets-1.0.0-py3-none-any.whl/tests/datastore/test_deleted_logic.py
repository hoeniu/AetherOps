import os
import shutil


def func(current_dir: str) -> None:

    for item in ["namespace", "index_type", "kb_id"]:
        parent_dir = os.path.dirname(current_dir)
        shutil.rmtree(current_dir)
        print("deleted dir: ", current_dir)
        # 上级文件夹不为空，直接跳出
        if len(os.listdir(parent_dir)) != 0:
            break
        else:
            current_dir = parent_dir


if __name__ == "__main__":

    base_path = "./aaa"

    path1 = "./aaa/bbb/ccc/ddd/eee/fff"
    os.makedirs(name=path1, exist_ok=True)
    func(path1)

    path2 = "./aaa/bbb/ccc/ddd/ggg/fff"
    os.makedirs(name=path1, exist_ok=True)
    os.makedirs(name=path2, exist_ok=True)
    func(path1)

    shutil.rmtree(base_path)
