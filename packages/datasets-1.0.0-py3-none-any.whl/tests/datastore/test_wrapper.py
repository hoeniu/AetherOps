from abc import ABC


def decorator(func):
    def wrapper(self, *args, **kwargs):
        if self.is_callable:
            return func(args, kwargs)
        else:
            print("Error")
    return wrapper


class BaseClass(ABC):

    def __init__(self):
        self.is_callable = False

    @decorator
    def func1(self):
        print("This is func1 of base class.")


class DerivedClass(BaseClass):

    def __init__(self):
        super().__init__()

    def func1(self):
        print("This is func1 of derived class.")


if __name__ == "__main__":
    b_ins: BaseClass = BaseClass()
    b_ins.func1()
    d_ins: BaseClass = DerivedClass()
    d_ins.func1()
