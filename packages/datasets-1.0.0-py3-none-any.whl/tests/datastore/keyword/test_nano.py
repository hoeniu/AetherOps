import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys

sys.path.insert(0, ROOT_DIR)
from typing import List, Tuple
from kbx.datastore.keyword.keyword_base import BaseKeywordDS
from kbx.datastore.ds_factory import get_keyword_datastore
from kbx.common.constants import DEFAULT_USER_ID
from kbx.common.types import KBXError
from kbx.knowledge_base.knowledge_base import KBCreationConfig


kb_config = KBCreationConfig(
    name="test_kb",
    description="用于测试的kb",
    is_external_datastore=False
)


def nano_keyword_workflow(thread_id: str, kb_id: str):

    keyword_ds: BaseKeywordDS = get_keyword_datastore(kb_id, "keyword", "default")
    with keyword_ds:
        item1: Tuple[List[str], str] = (["aaa", "bbb", "ccc"], "id1")
        item2: Tuple[List[str], str] = (["aaa", "ddd", "eee"], "id2")
        item3: Tuple[List[str], str] = (["bbb", "ddd", "fff"], "id3")
        item4: Tuple[List[str], str] = (["ccc", "eee", "ggg"], "id4")
        input_list = [item1, item2, item3, item4]
        error = keyword_ds.add(input_list)
        if error.code != KBXError.Code.SUCCESS:
            print(f"[{thread_id}] -> {error.msg}")
        else:
            print(f"[{thread_id}] -> 插入数据成功")

        res, error = keyword_ds.search(["aaa", "bbb", "ccc", "ddd"])
        if error.code != KBXError.Code.SUCCESS:
            print(f"[{thread_id}] -> {error.msg}")
        else:
            print(f"[{thread_id}] -> {res}")

        error = keyword_ds.delete_by_chunk_ids(["id1", "id2", "id5"])
        if error.code != KBXError.Code.SUCCESS:
            print(f"[{thread_id}] -> {error.msg}")
        else:
            print(f"[{thread_id}] -> 删除数据成功")

        res, error = keyword_ds.search(["aaa", "bbb", "ccc", "ddd"])
        if error.code != KBXError.Code.SUCCESS:
            print(error.msg)
        else:
            print(f"[{thread_id}] -> {res}")


if __name__ == "__main__":
    from kbx.kbx import KBX
    KBX.init("conf/kbx_settings.yaml")
    local_kb_id: str = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID).kb_id
    nano_keyword_workflow("0", local_kb_id)
