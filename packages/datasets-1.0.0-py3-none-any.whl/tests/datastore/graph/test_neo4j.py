import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys

sys.path.insert(0, ROOT_DIR)
from kbx.datastore.graph.graph_base import BaseGraphDS
from kbx.datastore.graph.neo4j_graph import Neo4jGraphDS

from tests.datastore.tool import create_default_user_tenant_kb


def main():
    from kbx.kbx import KBX
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    KBX.init(config=kbx_yaml_file)

    kb_id: str = create_default_user_tenant_kb()
    print(kb_id)

    graph_ds: BaseGraphDS = Neo4jGraphDS(KBX.config.graph_ds, kb_id, "test", "default")
    graph_ds.connect()

    template = {
        "ID": "",
        "名称": 0,
        "类型": ""
    }

    # 插入3个node.
    # node1 = template.copy()
    # node1["ID"] = "node_1"
    # node1["名称"] = 1
    # node1["类型"] = "公司"
    # vid: int = graph_ds.insert_node(node1)
    # print(vid)

    # node2 = template.copy()
    # node2["ID"] = "node_2"
    # node2["名称"] = 2
    # node2["类型"] = "法人"
    # graph_ds.insert_node(node2)

    # node3 = template.copy()
    # node3["ID"] = "node_3"
    # node3["名称"] = 3
    # node3["类型"] = "个人"
    # vid2: int = graph_ds.insert_node(node3)
    # print(vid2)

    # node3["ID"] = "node_33"
    # node3["名称"] = 33
    # node3["类型"] = "个人1"
    # graph_ds.update_node(vid2, node3)
    # print(graph_ds.nodes())
    # graph_ds.delete_node(vid)
    # print(graph_ds.nodes())
    # 插入1条edge
    edge: dict = template.copy()
    vid1: int = 16
    vid2: int = 17
    # print(graph_ds.insert_edge(vid1, vid2, edge))
    # print(graph_ds.search_edge_by_id(vid1, vid2))
    edge["ID"] = "123"
    graph_ds.update_edge(vid1, vid2, 2, edge)
    # graph_ds.delete_edge(vid1, vid2, 0)
    # graph_ds.search_edge_by_id(src, dst, rank)
    # print(graph_ds.search_edge_by_id(1, 2))

    print(graph_ds._find_successor(vid1))
    print(graph_ds._find_predecessor(vid2))

    graph_ds.close()


if __name__ == "__main__":
    main()
