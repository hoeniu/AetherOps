import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys

sys.path.insert(0, ROOT_DIR)
from typing import Any, Dict, List, Tuple


def build(node_list: List[Tuple[int, Dict[str, Any]]]) -> Dict:
    nodes = dict()
    index = dict()
    # 遍历所有节点和它们的属性
    for node_id, node in node_list:
        for attr, val in node.items():
            index.setdefault(attr, dict()).setdefault(val, set()).add(node_id)
        nodes[node_id] = node.copy()
    print(nodes, index)


node_list = [(1, {"name": "frank"})]
build(node_list)

from kbx.datastore.graph.graph_helper import sanitize_string
print(sanitize_string("奶龙:\"'我是暴暴龙'\"。"))
