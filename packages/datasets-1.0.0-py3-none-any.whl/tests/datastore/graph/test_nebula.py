import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys

sys.path.insert(0, ROOT_DIR)
from typing import Dict
from kbx.datastore.graph.graph_base import BaseGraphDS
from kbx.datastore.graph.nebula_graph import NebulaGraphDS

from tests.datastore.tool import create_default_user_tenant_kb

schema_info = {
    "实体": [
        {"名称": "企业", "说明": "企业、公司、企业单位、事业单位"},
        {"名称": "人", "说明": "个人、高管、员工"}
    ],
    "属性": [
        {"类型": "ID", "数据类型": "string", "属于": []},
        {"类型": "名称", "数据类型": "int", "必须": "是"},
        {"类型": "类型", "数据类型": "string", "必须": "是"}
    ],
    "关系": [
        {"类型": "任职", "说明": "xxx"},
        {"类型": "持股", "说明": "xxx"}
    ]
}


def main():
    from kbx.kbx import KBX
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    KBX.init(config=kbx_yaml_file)

    KBX.config.graph_ds.schema_info = schema_info
    kb_id: str = create_default_user_tenant_kb()
    print(kb_id)

    graph_ds: BaseGraphDS = NebulaGraphDS(KBX.config.graph_ds, kb_id, "test", "default")
    graph_ds.connect()

    template = {
        "ID": "",
        "名称": 0,
        "类型": ""
    }

    # 插入3个node.
    node1: Dict = template.copy()
    node1["ID"] = "node'\"_1"
    node1["名称"] = 1
    node1["类型"] = "公司"
    vid: int = graph_ds.insert_node(node1)
    print(vid)

    # node2 = template.copy()
    # node2["ID"] = "node_2"
    # node2["名称"] = 2
    # node2["类型"] = "法人"
    # graph_ds.insert_node(node2)

    # node3 = template.copy()
    # node3["ID"] = "node_3"
    # node3["名称"] = 3
    # node3["类型"] = "个人"
    # graph_ds.insert_node(node3)

    # node3["ID"] = "node_33"
    # node3["名称"] = 33
    # node3["类型"] = "个人1"
    # graph_ds.update_node(6, node3)
    # print(graph_ds.nodes())
    # graph_ds.delete_node(5)
    # 插入1条edge
    # edge: dict = template.copy()
    # graph_ds.insert_edge(1, 2, edge)
    # print(graph_ds.search_edge_by_id(1, 2))
    # edge["ID"] = "122"
    # graph_ds.update_edge(1, 2, 2, edge)
    # graph_ds.delete_edge(1, 2, 0)
    # graph_ds.search_edge_by_id(src, dst, rank)
    # print(graph_ds.search_edge_by_id(1, 2))

    graph_ds.close()


if __name__ == "__main__":
    main()
