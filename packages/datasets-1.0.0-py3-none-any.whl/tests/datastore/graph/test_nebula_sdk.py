import os
import time

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys

sys.path.insert(0, ROOT_DIR)
from typing import Any, Dict
from nebula3.gclient.net import ConnectionPool
from kbx.datastore.graph.nebula_graph import result_set_convert

# 配置连接信息
connection_pool = ConnectionPool()
connection_pool.init([('127.0.0.1', 9669)])  # 替换为你的 NebulaGraph 服务地址

# 获取会话
session = connection_pool.get_session('root', 'nebula')  # 替换为你的用户名和密码

space_name = "test"
space_name = "knowledge_graphdefaultfbb71d98b0f34be9a64b661f36b92c78"
# 创建图空间
# ddl = f"CREATE SPACE IF NOT EXISTS {space_name} (vid_type = INT64, partition_num = 10, replica_factor = 1)"
# res = session.execute(ddl)
# print(res.is_succeeded())
# print(f"succeed to create space {space_name}")
#
res = session.execute("SHOW SPACES;")
print(res)

res = session.execute(f"USE {space_name};")
if res.is_succeeded():
    print("USE succeed.")
else:
    print(res.error_msg())

res = session.execute("DESCRIBE TAG t_tag;")
if res.is_succeeded():
    print(res)
else:
    print(res.error_msg())

node_id = 1
query: str = f"MATCH (v) WHERE id(v) == {node_id} RETURN v;"
result = session.execute(query)
print(result_set_convert(result))

node_ids = [1, 6, 22]
str_id_list: str = ",".join([str(node_id) for node_id in node_ids])
print(str_id_list)
query: str = f"MATCH (v) WHERE id(v) IN [{str_id_list}] RETURN v;"
result = session.execute(query)
print(result_set_convert(result))

# res = session.execute("MATCH ()-[e]->() RETURN e;")
# if not res.is_succeeded():
#     print(res.error_msg())
# else:
#     print(res)

# n_gql: str = "MATCH (m)-->(n) WHERE id(n) == 2 WITH DISTINCT m AS m RETURN m;"
# result_set = session.execute(n_gql)
# print(result_set)
# node_list = result_set_convert(result_set, "m")
# print(dict(node_list))

# n_gql: str = "MATCH (n)-->(m) WHERE id(n) == 1 WITH DISTINCT m AS m RETURN m;"
# result_set = session.execute(n_gql)
# print(result_set)
# node_list = result_set_convert(result_set, "m")
# print(dict(node_list))

# space_name_list = []
# for item in space_name_list:
#     res = session.execute(f"DROP SPACE IF EXISTS {item[0]};")
#     print(res.is_succeeded())


def get_value_from_wrapper(value_wrapper):
    if value_wrapper.is_list():
        return value_wrapper.as_list()
    elif value_wrapper.is_map():
        return value_wrapper.as_map()
    else:
        if value_wrapper.is_int():
            return value_wrapper.as_int()
        elif value_wrapper.is_double():
            return value_wrapper.as_double()
        elif value_wrapper.is_string():
            return value_wrapper.as_string()
        else:
            return ""


n_gql: str = "CREATE EDGE INDEX IF NOT EXISTS t_edge_index ON t_edge()"
res = session.execute(n_gql)
if res.is_succeeded():
    print("Succeed.")
else:
    print(f"Failed. {res.error_msg()}")


def search_edge_by_id(src: int, dst: int) -> Dict[int, Dict]:
    edge_dict: Dict[int, Dict] = dict()
    # 一组src-dst中间可能有具有不同rank的多条边: -> (rank, edge_attrs)
    search_query: str = f"MATCH (v1)-[e:t_edge]->(v2) WHERE id(v1) == {src} AND id(v2) == {dst} RETURN e;"
    # search_query: str = f"MATCH (e) WHERE id(e) == {src} RETURN e;"
    # n_gql = f"LOOKUP ON t_edge WHERE t_edge.src == {src} AND t_edge.dst == {dst} YIELD edge AS e;"
    t1 = time.time()
    res = session.execute(search_query)
    t2 = time.time()
    if res.is_succeeded():
        result_list = res.column_values("e")
        for edge in result_list:
            flag: bool = edge.is_edge()
            if flag:
                edge_data = edge.as_relationship()
                rank = edge_data.ranking()
                prop = edge_data.properties()
                edge_dict[rank] = {k: get_value_from_wrapper(v) for k, v in prop.items()}
        t3 = time.time()
        print("ngql: ", t2 - t1, "post process: ", t3 - t2)
        return edge_dict
    else:
        print(f"search edge {src}->{dst} failed. {res.error_msg()}")


def insert_edge(src: int, dst: int, edge: Dict[str, Any]):
    edge_dict: Dict[int, Dict] = search_edge_by_id(src, dst)
    # nebula中rank需要由业务逻辑维护
    if len(edge_dict.keys()) == 0:
        rank = 0
    else:
        rank = max(edge_dict.keys()) + 1
    attr_list: str = ", ".join(f"`{attr}`" for attr in edge.keys())
    val_list: str = ", ".join([f"{val}" if isinstance(val, (int, float))
                               else f"'{val}'" for val in edge.values()])
    n_gql: str = f"INSERT EDGE t_edge ({attr_list})" \
                 f" VALUES {src} -> {dst}@{rank}: ({val_list});"
    res = session.execute(n_gql)
    if not res.is_succeeded():
        print(f"INSERT EDGE FAILED: {src}->{dst}@{rank}. {res.error_msg()}")
    return rank


vid1 = 9
vid2 = 10
t1 = 0
t2 = 0
for i in range(1):
    # print(search_edge_by_id(vid1, vid2))
    # t3 = time.time()
    search_edge_by_id(vid1, vid2)
    # t4 = time.time()
    # print(insert_edge(vid1, vid2, dict()))
    # insert_edge(vid1, vid2, dict())
    # t5 = time.time()
    # t2 += t5 - t4
    # t1 += t4 - t3
# print(t1 + t2)  # 18.5
# print("t1: ", t1)  # 7.3    ~ 0.07ms
# print("t2: ", t2)  # 11.2   ~ 0.04ms
