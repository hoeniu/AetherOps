import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../..")
import sys
sys.path.insert(0, ROOT_DIR)
from kbx.datastore.file.file_base import BaseFileDS
from kbx.datastore.file.nano_file import NanoFileDS
from kbx.common.constants import DEFAULT_USER_ID
from kbx.common.types import FileDSConfig, KBXError, FileInfo
from kbx.knowledge_base.types import KBCreationConfig
from typing import List, Tuple, Optional


kb_config = KBCreationConfig(
    name="test_kb",
    description="用于测试的kb",
    is_external_datastore=False
)


def main(thread_id: str, kb_id: str):

    file_ds_config: FileDSConfig = FileDSConfig()
    # kb_id: str = str(uuid4())
    # kb_id: str = "92b6e06e-d326-4804-b972-43687d68d6e5"
    print(kb_id)

    file_ds: BaseFileDS = NanoFileDS(file_ds_config, kb_id)
    print(file_ds.get_type())

    file_ds.connect()

    res: List[Tuple[KBXError, Optional[FileInfo]]] = file_ds.upload_files([
        os.path.join("..", "..", "workplace", "files", "files1.txt"),
        os.path.join("..", "..", "workplace", "files", "files2.txt"),
        os.path.join("..", "..", "workplace", "files", "files3.txt")], "")
    # logger.info(str(res))
    print(str(res))

    file_list: List[FileInfo] = file_ds.list_files("")
    print(str(file_list))

    res_list: List[KBXError] = file_ds.download_files(["files1.txt", "files2.txt", "files3.txt"],
                                                      os.path.join("..", "..", "workplace", "files2/"))
    print(str(res_list))

    flag: bool = file_ds.delete_file("files1.txt")
    print("删除结果：", flag)

    f = file_ds.open("files2.txt", "r", encoding="utf-8")
    f.close()

    f = file_ds.open("files3.txt", "rb", encoding="utf-8")

    print(file_ds.get_raw_path("files3.txt"))
    f.close()

    file_ds.delete_ds()
    file_ds.close()


if __name__ == "__main__":
    from kbx.kbx import KBX
    KBX.init("conf/kbx_settings.yaml")
    local_kb_id: str = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID).kb_id
    main("0", local_kb_id)
