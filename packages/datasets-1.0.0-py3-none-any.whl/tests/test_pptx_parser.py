import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys

sys.path.insert(0, ROOT_DIR)

import pytest
import base64

from tests.base_test_case import BaseTestCase
from kbx.common.types import DocElementType
from kbx.common.utils import generate_new_id
from kbx.parser.pptx.default_pptx_parser import DefaultPptxParser, safe_get_attr
from kbx.parser.types import DocParseConfig
from kbx.parser.parser_factory import get_parser


class TestPptxParser(BaseTestCase):
    """PPTX解析器专项测试"""

    def setup_method(self):
        """初始化测试环境"""
        # 设置测试文件路径
        self.test_pptx_file = os.path.join(self.test_data_dir, "parser_data/test2.pptx")

        # 创建解析器
        self._doc_parser_config = DocParseConfig()
        self.parser = DefaultPptxParser(self._doc_parser_config)

    def test_constructor(self):
        """测试构造函数"""
        config = DocParseConfig()
        parser = get_parser("DefaultPptxParser", config)
        assert parser._config.save_external_data is False

    def test_file_extensions(self):
        """测试文件扩展名支持"""
        assert self.parser.file_extensions() == ['.pptx']

    def test_safe_get_attr(self):
        """测试safe_get_attr辅助函数"""

        # 创建一个简单的嵌套对象
        class InnerClass:

            def __init__(self):
                self.value = "inner_value"

        class OuterClass:

            def __init__(self):
                self.inner = InnerClass()
                self.simple = "simple_value"

        obj = OuterClass()

        # 测试正常路径
        assert safe_get_attr(obj, "simple") == "simple_value"
        assert safe_get_attr(obj, "inner.value") == "inner_value"

        # 测试不存在的属性
        assert safe_get_attr(obj, "non_existent") is None
        assert safe_get_attr(obj, "inner.non_existent") is None
        assert safe_get_attr(obj, "non_existent", "default") == "default"

        # 测试None值
        obj.nullable = None
        assert safe_get_attr(obj, "nullable.some_attr") is None

    def test_parse_pptx_file(self):
        """测试解析PPTX文件"""
        # 跳过测试，如果测试文件不存在
        if not os.path.exists(self.test_pptx_file):
            pytest.skip(f"测试文件不存在: {self.test_pptx_file}")

        doc_id = generate_new_id()
        doc_data = self.parser.parse(self.test_pptx_file, doc_id)

        # 测试基本属性
        assert doc_data.doc_id == doc_id
        assert doc_data.file_name == os.path.basename(self.test_pptx_file)
        assert doc_data.file_path == self.test_pptx_file

        # 检查是否有文档元素
        assert len(doc_data.doc_elements) > 0

        # 对提取的各类型元素进行计数
        element_count = {
            "text": 0,
            "title": 0,
            "figure": 0,
            "table": 0,
            "notes": 0,
            "chart": 0,
            "smartart": 0,
            "shape": 0
        }

        for elem in doc_data.doc_elements:
            if elem.type == DocElementType.TEXT:
                element_count["text"] += 1
            elif elem.type == DocElementType.TITLE:
                element_count["title"] += 1
            elif elem.type == DocElementType.FIGURE:
                element_count["figure"] += 1
            elif elem.type == DocElementType.TABLE:
                if elem.meta_data.get("content_type") == "chart":
                    element_count["chart"] += 1
                else:
                    element_count["table"] += 1

            # 根据元数据内容区分特殊类型
            content_type = elem.meta_data.get("content_type", "")
            if content_type == "note":
                element_count["notes"] += 1
            elif content_type == "smartart":
                element_count["smartart"] += 1
            elif content_type == "shape":
                element_count["shape"] += 1

        # 输出统计信息
        print("\n解析结果统计:")
        print(f"文本元素: {element_count['text']}个")
        print(f"标题元素: {element_count['title']}个")
        print(f"图像元素: {element_count['figure']}个")
        print(f"表格元素: {element_count['table']}个")
        print(f"笔记元素: {element_count['notes']}个")
        print(f"图表元素: {element_count['chart']}个")
        print(f"SmartArt元素: {element_count['smartart']}个")
        print(f"形状元素: {element_count['shape']}个")

        # 验证文档元素结构
        for elem in doc_data.doc_elements:
            # 所有元素应该都有ID
            assert elem.doc_element_id is not None

            # 所有元素应该有slide_number元数据
            if "slide_number" in elem.meta_data:
                assert isinstance(elem.meta_data["slide_number"], int)

            # 检查表格结构
            if elem.type == DocElementType.TABLE:
                if elem.table:
                    # 表格数据应该是二维列表
                    assert isinstance(elem.table, list)
                    if len(elem.table) > 0:
                        assert isinstance(elem.table[0], list)

            # 检查图片数据
            if elem.type == DocElementType.FIGURE:
                assert elem.image_b64 is not None
                assert len(elem.image_b64) > 0

            # 检查位置信息
            if "position" in elem.meta_data:
                position = elem.meta_data["position"]
                assert "left" in position
                assert "top" in position
                assert "width" in position
                assert "height" in position

    def test_extract_text(self):
        """测试文本提取功能"""
        # 跳过测试，如果测试文件不存在
        if not os.path.exists(self.test_pptx_file):
            pytest.skip(f"测试文件不存在: {self.test_pptx_file}")

        # 打开PPTX文件
        with open(self.test_pptx_file, 'rb') as f:
            from pptx import Presentation
            presentation = Presentation(f)

            text_elements = []
            # 遍历所有幻灯片，提取文本
            for i, slide in enumerate(presentation.slides, 1):
                slide_text = self.parser._extract_text_from_slide(slide, i)
                text_elements.extend(slide_text)

                # 输出每个幻灯片的文本内容
                print(f"\n幻灯片 {i} 的文本内容:")
                for elem in slide_text:
                    print(f"  - {elem.text}")

            # 验证提取结果
            assert len(text_elements) > 0, "应该至少提取到一些文本"
            for elem in text_elements:
                assert elem.type == DocElementType.TEXT
                assert "slide_number" in elem.meta_data
                # 有些文本可能是空的，只检查非空文本
                if elem.text:
                    assert len(elem.text) > 0

    def test_extract_tables(self):
        """测试表格提取功能"""
        # 跳过测试，如果测试文件不存在
        if not os.path.exists(self.test_pptx_file):
            pytest.skip(f"测试文件不存在: {self.test_pptx_file}")

        # 打开PPTX文件
        with open(self.test_pptx_file, 'rb') as f:
            from pptx import Presentation
            presentation = Presentation(f)

            table_count = 0
            # 遍历所有幻灯片，提取表格
            for i, slide in enumerate(presentation.slides, 1):
                tables = self.parser._extract_tables_from_slide(slide, i)
                table_count += len(tables)

                # 输出表格内容
                for table_idx, table_elem in enumerate(tables):
                    print(f"\n幻灯片 {i} 的表格 {table_idx + 1}:")
                    if table_elem.table:
                        for row_idx, row in enumerate(table_elem.table):
                            print(f"  行 {row_idx + 1}: {row}")

            print(f"\n总共发现 {table_count} 个表格")

            # 验证：我们知道测试文件中至少有一个表格
            assert table_count >= 1, "应该至少提取到一个表格"

    def test_extract_images(self):
        """测试图像提取功能"""
        # 跳过测试，如果测试文件不存在
        if not os.path.exists(self.test_pptx_file):
            pytest.skip(f"测试文件不存在: {self.test_pptx_file}")

        # 打开PPTX文件
        with open(self.test_pptx_file, 'rb') as f:
            from pptx import Presentation
            presentation = Presentation(f)

            image_count = 0
            # 遍历所有幻灯片，提取图像
            for i, slide in enumerate(presentation.slides, 1):
                images = self.parser._extract_images_from_slide(slide, i)
                image_count += len(images)

                # 输出图像信息
                for img_idx, img in enumerate(images):
                    print(f"\n幻灯片 {i} 中的图像 {img_idx + 1}:")
                    # 验证图像确实是base64编码的
                    try:
                        # 尝试解码前100个字符，确认它是有效的base64
                        base64_sample = img.image_b64[:100] if len(
                            img.image_b64) > 100 else img.image_b64
                        base64.b64decode(base64_sample)
                        print(f"  - 有效的Base64编码图像，长度: {len(img.image_b64)} 字符")
                    except Exception as e:
                        print(f"  - 无效的Base64编码: {e}")
                        pytest.fail(f"图像包含无效的Base64编码: {e}")

            print(f"\n总共发现 {image_count} 个图像")
            # 注意：测试演示文稿可能没有图像，所以不做硬性断言

    def test_extract_notes(self):
        """测试笔记提取功能"""
        # 跳过测试，如果测试文件不存在
        if not os.path.exists(self.test_pptx_file):
            pytest.skip(f"测试文件不存在: {self.test_pptx_file}")

        # 打开PPTX文件
        with open(self.test_pptx_file, 'rb') as f:
            from pptx import Presentation
            presentation = Presentation(f)

            notes_count = 0
            # 遍历所有幻灯片，提取笔记
            for i, slide in enumerate(presentation.slides, 1):
                notes = self.parser._extract_notes_from_slide(slide, i)
                notes_count += len(notes)

                # 输出笔记内容
                if notes:
                    for note in notes:
                        print(f"\n幻灯片 {i} 的笔记: {note.text}")

            print(f"\n总共发现 {notes_count} 个笔记")

            # 验证：我们知道测试文件中至少有一个笔记
            assert notes_count >= 1, "应该至少提取到一个笔记"

    def test_extract_charts(self):
        """测试图表提取功能"""
        # 跳过测试，如果测试文件不存在
        if not os.path.exists(self.test_pptx_file):
            pytest.skip(f"测试文件不存在: {self.test_pptx_file}")

        # 打开PPTX文件
        with open(self.test_pptx_file, 'rb') as f:
            from pptx import Presentation
            presentation = Presentation(f)

            chart_count = 0
            # 遍历所有幻灯片，提取图表
            for i, slide in enumerate(presentation.slides, 1):
                charts = self.parser._extract_charts_from_slide(slide, i)
                chart_count += len(charts)

                # 输出图表内容
                for chart in charts:
                    print(f"\n幻灯片 {i} 的图表: {chart.table_caption}")
                    if chart.table:
                        # 打印前3行数据
                        for row_idx, row in enumerate(chart.table[:3]):
                            print(f"  行 {row_idx + 1}: {row}")
                        if len(chart.table) > 3:
                            print("  ...")

            print(f"\n总共发现 {chart_count} 个图表")

            # 验证：我们知道测试文件中至少有一个图表
            assert chart_count >= 1, "应该至少提取到一个图表"

    def test_extract_shapes(self):
        """测试形状提取功能"""
        # 跳过测试，如果测试文件不存在
        if not os.path.exists(self.test_pptx_file):
            pytest.skip(f"测试文件不存在: {self.test_pptx_file}")

        # 打开PPTX文件
        with open(self.test_pptx_file, 'rb') as f:
            from pptx import Presentation
            presentation = Presentation(f)

            shape_count = 0
            # 遍历所有幻灯片，提取形状
            for i, slide in enumerate(presentation.slides, 1):
                shapes = self.parser._extract_shapes_from_slide(slide, i)
                shape_count += len(shapes)

                # 输出形状内容
                for shape_idx, shape in enumerate(shapes):
                    print(f"\n幻灯片 {i} 的形状 {shape_idx + 1}:")
                    print(f"  - 内容: {shape.text}")
                    if "content_type" in shape.meta_data:
                        print(f"  - 类型: {shape.meta_data['content_type']}")
                    if "shape_type" in shape.meta_data:
                        print(f"  - 形状类型: {shape.meta_data['shape_type']}")

            print(f"\n总共发现 {shape_count} 个形状/SmartArt元素")
            # 注意：测试中应该有一个形状，但形状提取可能受到很多因素影响
            # 所以这里不做硬性断言

    def test_extract_titles(self):
        """测试标题提取功能"""
        # 跳过测试，如果测试文件不存在
        if not os.path.exists(self.test_pptx_file):
            pytest.skip(f"测试文件不存在: {self.test_pptx_file}")

        # 打开PPTX文件
        with open(self.test_pptx_file, 'rb') as f:
            from pptx import Presentation
            presentation = Presentation(f)

            title_count = 0
            subtitle_count = 0

            # 遍历所有幻灯片，提取文本
            for i, slide in enumerate(presentation.slides, 1):
                text_elements = self.parser._extract_text_from_slide(slide, i)

                # 筛选标题元素
                slide_titles = [
                    elem for elem in text_elements
                    if elem.type == DocElementType.TITLE
                ]
                title_count += len(slide_titles)

                # 统计主标题和副标题
                for title in slide_titles:
                    if title.meta_data.get("title_level") == 1:
                        print(f"\n幻灯片 {i} 的主标题: {title.text}")
                    elif title.meta_data.get("title_level") == 2:
                        subtitle_count += 1
                        print(f"\n幻灯片 {i} 的副标题: {title.text}")

                    # 验证标题元素的元数据
                    assert title.meta_data.get("title_level") in [
                        1, 2
                    ], f"标题级别错误: {title.meta_data.get('title_level')}"
                    # 不再检查content_type字段
                    assert title.type == DocElementType.TITLE, "元素类型应为TITLE"

            print(
                f"\n总共发现 {title_count} 个标题元素（主标题: {title_count - subtitle_count}, 副标题: {subtitle_count}）"
            )

            # 验证：测试文件中应该至少有一个标题
            assert title_count > 0, "应该至少提取到一个标题元素"

            # 测试整个解析过程中的标题提取
            doc_id = generate_new_id()
            doc_data = self.parser.parse(self.test_pptx_file, doc_id)

            # 统计整个文档中的标题元素
            all_titles = [
                elem for elem in doc_data.doc_elements
                if elem.type == DocElementType.TITLE
            ]

            print(f"完整解析过程中提取到 {len(all_titles)} 个标题元素")
            error_msg = f"完整解析与逐幻灯片提取的标题数量不一致: {len(all_titles)} vs {title_count}"
            assert len(all_titles) == title_count, error_msg

    def test_validate_file(self):
        """测试文件验证功能"""
        # 测试有效文件
        if os.path.exists(self.test_pptx_file):
            self.parser.validate_file(self.test_pptx_file)

        # 测试无效文件
        invalid_file = os.path.join(self.test_data_dir,
                                    "parser_data/non_existent_file.pptx")
        with pytest.raises(Exception):
            self.parser.validate_file(invalid_file)


if __name__ == "__main__":
    # 手动执行测试
    test_case = TestPptxParser()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_constructor()
    test_case.test_file_extensions()
    test_case.test_safe_get_attr()
    test_case.test_parse_pptx_file()
    test_case.test_extract_text()
    test_case.test_extract_tables()
    test_case.test_extract_images()
    test_case.test_extract_notes()
    test_case.test_extract_charts()
    test_case.test_extract_shapes()
    test_case.test_extract_titles()
    test_case.test_validate_file()
