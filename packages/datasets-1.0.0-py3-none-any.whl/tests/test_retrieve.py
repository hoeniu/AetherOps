import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
from tests.base_test_case import BaseTestCase
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, DeepThinkConfig, \
    QueryConfig, VectorKeywordIndexConfig, QueryResults
from kbx.splitter.types import SplitterConfig


class TestRetrieve(BaseTestCase):
    def setup_method(self):
        self._kb_name = "测试知识库（多模态）"
        self._kb_description = "这是一个测试知识库（多模态）"

    def test_nonstream_retrieve_case(self):
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model='BAAI/bge-m3',
                splitter_config=SplitterConfig(name='NaiveTextSplitter')
            ),
        )
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass

        # 尝试创建
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

        kb.insert_docs(file_list=[os.path.join(self.test_data_dir, 'parser_data', 'KBX_README.md')])

        # 使用知识库直接查询
        query = QueryConfig(
            text="KBX是什么？",
            stream=False,
            deep_think=DeepThinkConfig(llm_model="doubao-1.5-pro-256k"),
            top_k=3,
            score_threshold=0.1,
        )
        query_results = kb.retrieve(query=query)
        print(query_results)
        assert isinstance(query_results, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_results)}"
        assert isinstance(query_results.results, list), \
            f"Retrieval results should be a list, given {type(query_results.results)}"
        assert len(query_results) > 0, "Failed to get query result"
        if query.top_k > 0:
            assert query.top_k >= len(query_results), f"Query result should be no more than top_k, " \
                                                      f"given {query.top_k} and {len(query_results)}"

        # 使用KBX在顶层进行查询
        query_results = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
        print(query_results)
        assert isinstance(query_results, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_results)}"
        assert isinstance(query_results.results, list), \
            f"Retrieval results should be a list, given {type(query_results.results)}"
        assert len(query_results) > 0, "Failed to get query result"
        if query.top_k > 0:
            assert query.top_k >= len(query_results), f"Query result should be no more than top_k, " \
                                                      f"given {query.top_k} and {len(query_results)}"

    def test_stream_retrieve_case(self):
        try:
            kb = KBX.get_existed_kb(kb_name=self._kb_name, user_id=DEFAULT_USER_ID)
        except RuntimeError:
            pass

        # 使用知识库直接查询
        query = QueryConfig(
            text="KBX是什么？",
            stream=True,
            deep_think=DeepThinkConfig(llm_model="doubao-1.5-pro-256k"),
            top_k=3,
            score_threshold=0.1,
        )
        for query_result in kb.retrieve(query=query):
            assert isinstance(query_result, QueryResults), \
                f"Query result should be a QueryResults object, given {type(query_result)}"
            if query_result.is_final:
                print(f'检索的最终结果： {query_result.results}')
                query_results = query_result.results
            elif query_result.step_messages:
                print(f'检索过程中的中间结果：{query_result.step_messages}')
        assert len(query_results) > 0, "Failed to get query result"
        if query.top_k > 0:
            assert query.top_k >= len(query_results), f"Query result should be no more than top_k, " \
                                                      f"given {query.top_k} and {len(query_results)}"

        # 使用KBX在顶层进行查询
        for query_result in KBX.retrieve(query=query, kb_ids=[kb.kb_id]):
            assert isinstance(query_result, QueryResults), \
                f"Query result should be a QueryResults object, given {type(query_result)}"
            if query_result.is_final:
                print(f'检索的最终结果： {query_result.results}')
                query_results = query_result.results
            elif query_result.step_messages:
                print(f'检索过程中的中间结果：{query_result.step_messages}')
        print(query_results)
        assert len(query_results) > 0, "Failed to get query result"
        if query.top_k > 0:
            assert query.top_k >= len(query_results), f"Query result should be no more than top_k, " \
                                                      f"given {query.top_k} and {len(query_results)}"


if __name__ == '__main__':
    test_case = TestRetrieve()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_nonstream_retrieve_case()
    test_case.test_stream_retrieve_case()
