import json
import requests
from typing import List, Optional, Any, Dict
from tests.helper import gen_test_auth_token


server_address = 'http://localhost:30018'
api_key = gen_test_auth_token()


def test_list_kbs(user_id: str):
    response = requests.get(
        url=f"{server_address}/list_kbs",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        params={'user_id': user_id}
    )
    if response.status_code == 200:
        kbs_list = response.json()
        print("获取知识库列表成功:", kbs_list)
    else:
        print(f"获取知识库列表失败，状态码: {response.status_code}")
        print("错误信息:", response.text)


def test_get_kb_detail(kb_id: str, user_id: str):
    data = {
        'kb_id': kb_id,
        'user_id': user_id
    }
    response = requests.get(
        url=f"{server_address}/kb_detail",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        params=data
    )
    if response.status_code == 200:
        kb_info = response.json()
        kb_info_str = json.dumps(kb_info, ensure_ascii=False)
        print("获取知识库详情成功:", kb_info_str)
    else:
        print(f"获取知识库详情失败，状态码: {response.status_code}")
        print("错误信息:", response.text)


def test_list_doc_ids(kb_id: str, user_id: str):
    data = {
        'kb_id': kb_id,
        'user_id': user_id
    }
    response = requests.get(
        url=f"{server_address}/doc_ids",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        params=data
    )
    if response.status_code == 200:
        doc_ids = response.json()
        print("获取文档ID列表成功:", doc_ids)
    else:
        print(f"获取文档ID列表失败，状态码: {response.status_code}")
        print("错误信息:", response.text)


def test_list_docs_info(kb_id: str, user_id: str):
    data = {
        'kb_id': kb_id,
        'user_id': user_id
    }
    response = requests.get(
        url=f"{server_address}/docs_info",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        params=data
    )
    if response.status_code == 200:
        docs_list = response.json()
        docs_list_str = json.dumps(docs_list, ensure_ascii=False)
        print("获取文档列表成功:", docs_list_str)
    else:
        print(f"获取文档列表失败，状态码: {response.status_code}")
        print("错误信息:", response.text)


def test_get_doc_info(kb_id: str, user_id: str, doc_id: str):
    data = {
        'kb_id': kb_id,
        'user_id': user_id,
        'doc_id': doc_id
    }
    response = requests.get(
        url=f"{server_address}/doc_info",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        params=data
    )
    if response.status_code == 200:
        doc_info = response.json()
        doc_data_str = json.dumps(doc_info, ensure_ascii=False)
        print("获取文档详情成功:", doc_data_str)
    else:
        print(f"获取文档详情失败，状态码: {response.status_code}")
        print("错误信息:", response.text)


def test_get_doc_data(kb_id: str, user_id: str, doc_id: str):
    data = {
        'kb_id': kb_id,
        'user_id': user_id,
        'doc_id': doc_id
    }
    response = requests.get(
        url=f"{server_address}/doc_data",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        params=data
    )
    if response.status_code == 200:
        doc_data = response.json()
        qr_res_list_str = json.dumps(doc_data, ensure_ascii=False)
        print("获取文档切片内容对应数据详情成功:", qr_res_list_str)
    else:
        print(f"获取文档切片内容对应数据详情失败，状态码: {response.status_code}")
        print("错误信息:", response.text)


def test_retrieval(
        text: Optional[str],
        messages: Optional[List[Dict[str, Any]]],
        top_k: int,
        score_threshold: float,
        deep_think: Optional[Dict[str, Any]],
        kb_ids: List[str],
        enable_index_types: Optional[List[str]],
        user_id: str):
    data = {
        'text': text,
        'messages': messages,
        'top_k': top_k,
        'score_threshold': score_threshold,
        'deep_think': deep_think,
        'enable_index_types': enable_index_types
    }
    print(data)
    response = requests.post(
        url=f"{server_address}/retrieval",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        json=data,
        params={"kb_ids": kb_ids, "user_id": user_id}
    )
    if response.status_code == 200:
        qr_res_list = response.json()
        qr_res_list_str = json.dumps(qr_res_list, ensure_ascii=False)
        print("检索成功:", qr_res_list_str)
        return qr_res_list
    else:
        print(f"检索失败，状态码: {response.status_code}")
        print("错误信息:", response.text)


def test_insert_doc_async(file_path: str, kb_id: str, user_id: str):
    with open(file_path, 'rb') as file:
        response = requests.post(
            url=f"{server_address}/insert_doc_async",
            headers={"Authorization": f"Bearer {api_key}"},
            params={
                "user_id": user_id,
                "kb_id": kb_id,
            },
            files={"file": file}
        )
        assert response.status_code == 200, f"上传失败：{response.text}"
        file_id = response.json().get("id") or response.json().get("doc_id")
        assert file_id, "接口未返回 file_id"
        print("文件上传成功，返回 file_id:", file_id)
        return file_id


def test_insert_doc(file_path: str, kb_id: str, user_id: str):
    response = requests.post(
        url=f"{server_address}/insert_doc",
        headers={"Authorization": f"Bearer {api_key}"},
        params={
            "user_id": user_id,
            "kb_id": kb_id,
            "save_dir": ""
        },
        files={"file": open(file_path, 'rb')}
    )
    assert response.status_code == 200, f"上传失败：{response.text}"
    file_id = response.json().get("id") or response.json().get("doc_id")
    assert file_id, "接口未返回 file_id"
    print("文件上传成功，返回 file_id:", file_id)
    return file_id


if __name__ == '__main__':
    test_list_kbs(user_id='3a7a1250-d043-41c8-bf2a-af8fbc48bb85')

    # 请替换为实际的知识库 ID
    test_insert_doc_async(
        file_path='./cache/kbx_test_data/中国平安.txt',
        kb_id='KDM4mpc2',
        user_id='5YZsMzEB'
    )
    test_insert_doc(
        file_path='./cache/kbx_test_data/中国平安.txt',
        kb_id='KDM4mpc2',
        user_id='5YZsMzEB'
    )
    test_get_kb_detail(
        kb_id='0d5c1d1a-6f05-48c2-bc65-5d922a69e3e7',
        user_id='3a7a1250-d043-41c8-bf2a-af8fbc48bb85'
    )
    test_list_doc_ids(
        kb_id='0d5c1d1a-6f05-48c2-bc65-5d922a69e3e7',
        user_id='3a7a1250-d043-41c8-bf2a-af8fbc48bb85'
    )
    test_list_docs_info(
        kb_id='0d5c1d1a-6f05-48c2-bc65-5d922a69e3e7',
        user_id='3a7a1250-d043-41c8-bf2a-af8fbc48bb85'
    )
    test_get_doc_info(
        kb_id='0d5c1d1a-6f05-48c2-bc65-5d922a69e3e7',
        user_id='3a7a1250-d043-41c8-bf2a-af8fbc48bb85',
        doc_id='dc5800c6-3525-45c4-9574-45eed67e7660'
    )
    test_get_doc_data(
        kb_id='0d5c1d1a-6f05-48c2-bc65-5d922a69e3e7',
        user_id='3a7a1250-d043-41c8-bf2a-af8fbc48bb85',
        doc_id='dc5800c6-3525-45c4-9574-45eed67e7660'
    )

    qr_res_list = test_retrieval(
        text="我国制造业PMI在哪个月最低？",
        top_k=1,
        score_threshold=0,
        deep_think={},
        kb_ids=['5ebfd82c-210e-4265-ad92-872266d10fe2'],
        enable_index_types=['vector_keyword'],
        user_id='3a7a1250-d043-41c8-bf2a-af8fbc48bb85'
    )

    qr_res_list = test_retrieval(
        text="Llama3和Llama2的主要区别是什么？",
        top_k=1,
        score_threshold=0,
        kb_ids=['eb03f02c-d54d-4a46-bbd4-81bca146887b'],
        enable_index_types=None
    )
