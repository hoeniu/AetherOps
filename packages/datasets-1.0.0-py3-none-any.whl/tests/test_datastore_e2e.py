from typing import Any, Dict, List
import time
import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
import json
from tests.base_test_case import BaseTestCase
from kbx.common.types import DocFileType, KBXError
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX, KnowledgeBase
from kbx.knowledge_base.types import KBCreationConfig, DocParseConfig, QueryConfig, \
    SplitterConfig, DocStatus, QueryResults
from kbx.knowledge_base.types import KnowledgeGraphIndexConfig
from kbx.knowledge_base.types import VectorKeywordIndexConfig
from kbx.knowledge_base.types import StructuredIndexConfig
from kbx.common.logging import logger
import threading


schema_path = os.path.join(ROOT_DIR, "tests/schema/schema.json")
with open(schema_path, "r", encoding="utf-8") as f:
    schema_dict: Dict[str, List[Dict[str, Any]]] = json.load(f)


class TestDatastoreConcurrentE2E(BaseTestCase):

    def setup_method(self):
        self.concurrent_num = 4
        self.graph_lock = threading.Lock()
        self.sd_lock = threading.Lock()
        self.vk_lock = threading.Lock()
        self.wait_lock = threading.Lock()
        self.graph_dict: Dict[str, int] = dict()
        self.structured_dict: Dict[str, int] = dict()
        self.vk_dict: Dict[str, int] = dict()

    def wait(self, record: Dict[str, int], step) -> None:
        while True:
            self.wait_lock.acquire()
            flag = True
            for key in record.keys():
                if record[key] < step:
                    flag = False
                    break
            self.wait_lock.release()
            if flag is False:
                time.sleep(1)
            else:
                break

    def set(self, record: Dict[str, int], key) -> True:
        self.wait_lock.acquire()
        record[key] = record[key] + 1
        self.wait_lock.release()

    def test_datastore_concurrent(self):
        task_list = []
        # 创建Thread实例
        for i in range(self.concurrent_num):
            thread_id: str = str(i)
            # self.graph_dict[thread_id] = 0
            # thread = threading.Thread(target=self.test_graph_index, args=(thread_id))
            # task_list.append(thread)
            # self.structured_dict[thread_id] = 0
            # thread = threading.Thread(target=self.test_structured_index, args=(thread_id))
            # task_list.append(thread)
            self.vk_dict[thread_id] = 0
            thread = threading.Thread(target=self.test_vk_index, args=(thread_id))
            task_list.append(thread)
        # 启动所有线程
        for task in task_list:
            task.start()
        # 等待线程结束
        for task in task_list:
            task.join()

    def test_graph_index(self, thread_id: str = "0"):

        kb_name = "KB_GRAPH_INDEX_CONCURRENT_DS"
        kb_description = "用于并发测试DataStore, 使用GraphIndex的KB"

        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "DefaultPdfParser",
                    DocFileType.TXT: "DefaultTxtParser"
                }
            ),
            kg_config=KnowledgeGraphIndexConfig(
                index_strategy="DefaultGraphIndex",
                llm_model="doubao-1.5-pro-32k",
                embedding_model="doubao-embedding",
                schema_dict=schema_dict,
            ),
        )
        # logger.info(f"{thread_id} -> Start to create kb.")
        self.graph_lock.acquire()
        try:
            kb: KnowledgeBase = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            logger.info(f"知识库{kb_config.name}已存在，无需重新创建.")
        except RuntimeError:
            kb: KnowledgeBase = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
            logger.info(f"知识库{kb_config.name}不存在，创建新知识库.")
        self.graph_lock.release()
        # logger.info(f"{thread_id} -> set thread_id.")
        self.set(self.graph_dict, thread_id)
        logger.info(f"{thread_id} -> wait create kb.")
        self.wait(self.graph_dict, 1)
        # logger.info(f"{thread_id} -> wait create kb finish. {self.graph_dict}")

        self.graph_lock.acquire()
        logger.info(f"{thread_id} -> start insert docs.")
        results = kb.insert_docs(
            file_list=[
                os.path.join(self.test_data_dir, '中国平安.txt'),
                os.path.join(self.test_data_dir, '平安银行.txt'),
                os.path.join(self.test_data_dir, '全新好.txt'),
                os.path.join(self.test_data_dir, '神州高铁.txt'),
                os.path.join(self.test_data_dir, '万科A.txt'),
            ]
        )
        logger.info(f"{thread_id} -> end insert docs.")
        self.graph_lock.release()
        self.set(self.graph_dict, thread_id)
        logger.info(f"{thread_id} -> wait insert doc.")
        self.wait(self.graph_dict, 2)
        logger.info(f"{thread_id} -> wait insert finish. {self.graph_dict}")

        if len(results) == 0:
            logger.error("Failed to insert docs.")
            return
        # if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
        #     raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

        # 使用知识库直接查询
        query_text_list = ["万科高管有哪些？", "万科是一家什么公司？", "万科有多少员工？"]
        for query_text in query_text_list:
            query = QueryConfig(
                text=query_text,
                top_k=5,
                score_threshold=0.1,
            )
            query_result = kb.retrieve(query=query)
            assert isinstance(query_result, QueryResults), \
                f"Query result should be a QueryResults object, given {type(query_result)}"
            assert isinstance(query_result.results, list), \
                f"Retrieval results should be a list, given {type(query_result.results)}"
            assert len(query_result) > 0, "Failed to get query result"
            if query.top_k > 0:
                assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                                                         f"given {query.top_k} and {len(query_result)}"
            print(f'Get {len(query_result)} results from kb ("{kb.kb_config.name}")')
            for k, qr in enumerate(query_result):
                print(f'THREAD_ID: {thread_id}----------------------- #{k}, score={qr.score} -------------------------')
                print(qr.graph_triplets)
                print(qr.chunk)

            # 使用KBX在顶层进行查询
            query_result = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
            assert isinstance(query_result, QueryResults), \
                f"Query result should be a QueryResults object, given {type(query_result)}"
            assert isinstance(query_result.results, list), \
                f"Retrieval results should be a list, given {type(query_result.results)}"
            assert len(query_result) > 0, "Failed to get query result"
            if query.top_k > 0:
                assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                                                         f"given {query.top_k} and {len(query_result)}"
            print(f'Get {len(query_result)} results from kb ("{kb.kb_config.name}")')
            for k, qr in enumerate(query_result):
                print(f'THREAD_ID: {thread_id}----------------------- #{k}, score={qr.score} -------------------------')
                print(qr.graph_triplets)
                print(qr.chunk)

    def test_structured_index(self, thread_id: str = "0"):
        kb_name = "KB_STRUCTURED_INDEX_CONCURRENT_DS"
        kb_description = "用于并发测试DataStore, 使用StructuredIndex的KB"
        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.CSV: "DefaultCSVParser",
                    DocFileType.EXCEL: "DefaultExcelParser",
                }
            ),
            structured_config=StructuredIndexConfig(
                index_strategy="DefaultStructuredIndex",
                llm_model="doubao-1.5-pro-32k",
                sql_gen_llm_model="doubao-1.5-pro-32k",
            ),
        )
        self.sd_lock.acquire()
        try:
            kb: KnowledgeBase = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            logger.info(f"知识库{kb_config.name}已存在，无需重新创建.")
        except RuntimeError:
            kb: KnowledgeBase = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
            logger.info(f"知识库{kb_config.name}不存在，创建新知识库.")
        self.sd_lock.release()
        self.set(self.structured_dict, thread_id)
        logger.info(f"{thread_id} -> wait create kb.")
        self.wait(self.structured_dict, 1)

        self.sd_lock.acquire()
        results = kb.insert_docs(
            file_list=[
                os.path.join(self.test_data_dir, '北京GDP数据.csv'),
                os.path.join(self.test_data_dir, '上海GDP数据.csv'),
                os.path.join(self.test_data_dir, '广州GDP数据.csv'),
                os.path.join(self.test_data_dir, '深圳GDP数据.csv'),
            ]
        )
        logger.info(f"{thread_id} -> end insert docs.")
        self.sd_lock.release()
        self.set(self.structured_dict, thread_id)
        logger.info(f"{thread_id} -> wait insert docs.")
        self.wait(self.structured_dict, 2)
        # 任取其中一个文档的信息，检查是否可以正常获取
        for doc_info in results:
            # print(doc_info.err_info)
            if doc_info.err_info.code != KBXError.Code.SUCCESS:
                continue
            assert doc_info.doc_status == DocStatus.INDEX_SUCCESS
            doc_info_get = kb.get_doc_info(doc_id=doc_info.doc_id)
            assert doc_info == doc_info_get, f'Expect same doc_info, given\n{doc_info!r}\nand\n{doc_info_get!r}'
            doc_data = kb.get_doc_data(doc_id=doc_info.doc_id)
            assert doc_data is not None, f'Expect doc_data is not None, given {doc_data!r}'

        self.set(self.structured_dict, thread_id)
        self.wait(self.structured_dict, 3)

        # reindex_all
        self.sd_lock.acquire()
        kb.reindex_all(reparse=True)
        self.sd_lock.release()
        self.set(self.structured_dict, thread_id)
        self.wait(self.structured_dict, 4)

        # 使用知识库直接查询
        query = QueryConfig(
            text="上海2024年哪个月的GDP最高，数值是多少？",
            top_k=5,
            score_threshold=0.0,
        )
        query_results = kb.retrieve(query=query)
        assert isinstance(query_results, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_results)}"
        assert isinstance(query_results.results, list), \
            f"Retrieval results should be a list, given {type(query_results.results)}"
        assert len(query_results) > 0, f"Failed to get query result {query.text}"
        print(f"kb.retrieve: query = {query.text}")
        for k, qr in enumerate(query_results):
            print(f'THREAD_ID: {thread_id}--------------- # {k} ---------------')
            # print(f"SQL: {qr.structured_result.sql}")
            print(f"Result: {qr.try_get_content_as_str()}")

        # 使用KBX在顶层进行查询
        query_results = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
        assert isinstance(query_results, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_results)}"
        assert isinstance(query_results.results, list), \
            f"Retrieval results should be a list, given {type(query_results.results)}"
        assert len(query_results) > 0, f"Failed to get query result {query.text}"
        print(f"KBX.retrieve: query = {query.text}")
        for k, qr in enumerate(query_results):
            print(f'THREAD_ID: {thread_id}--------------- # {k} ---------------')
            # print(f"SQL: {qr.structured_result.sql}")
            print(f"Result: {qr.try_get_content_as_str()}")

    def test_vk_index(self, thread_id: str = "0"):
        kb_name = "KB_VK_INDEX_CONCURRENT_DS"
        kb_description = "用于并发测试DataStore, 使用VKIndex的KB"
        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "DefaultPdfParser",
                }
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                splitter_config=SplitterConfig(name="RecursiveTextSplitter", chunk_size=1024),
                keyword_extractor="jieba",
                max_keywords_per_chunk=100,
            ),
        )
        self.vk_lock.acquire()
        try:
            kb: KnowledgeBase = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            logger.info(f"THREAD: {thread_id}. 知识库{kb_config.name}已存在，无需重新创建.")
        except RuntimeError:
            kb: KnowledgeBase = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
            logger.info(f"THREAD: {thread_id}. 知识库{kb_config.name}不存在，创建新知识库.")
        self.vk_lock.release()
        logger.info(f"{thread_id} -> wait create kb.")
        self.set(self.vk_dict, thread_id)
        self.wait(self.vk_dict, 1)

        self.vk_lock.acquire()
        results = kb.insert_docs(
            file_list=[
                os.path.join(self.test_data_dir, '2023-04-10：海外宏观周报：美国经济喜忧交织.pdf'),
                os.path.join(self.test_data_dir, '2023-04-05：以史为鉴：从银行业危机到衰退和降息有多远？.pdf'),
                # os.path.join(self.test_data_dir, "1.txt"),
                # os.path.join(self.test_data_dir, "2.txt"),
                # os.path.join(self.test_data_dir, "3.txt")
            ]
        )
        self.vk_lock.release()
        logger.info(f"{thread_id} -> wait insert doc.")
        self.set(self.vk_dict, thread_id)
        self.wait(self.vk_dict, 2)
        if len(results) == 0:
            print("Failed.")
        # if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
        #    raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

        query_text_list = ["3月欧洲经济如何", "主要银行业危机是什么？", "大宗商品价格怎么变化？"]

        for query_text in query_text_list:
            query = QueryConfig(
                text=query_text,
                top_k=5,
                score_threshold=0.0,
                vector_dynamic_kwargs={
                    "keyword_similarity_weight": 0.2,
                }
            )

            # 使用知识库直接查询
            query_result = kb.retrieve(query=query)
            assert isinstance(query_result, QueryResults), \
                f"Query result should be a QueryResults object, given {type(query_result)}"
            assert isinstance(query_result.results, list), \
                f"Retrieval results should be a list, given {type(query_result.results)}"
            assert len(query_result) > 0, f"Failed to get query result {query}"
            if query.top_k > 0:
                assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                                                         f"given {query.top_k} and {len(query_result)}"
            print(f'Get {len(query_result)} results from kb ("{kb.kb_config.name}")')
            for k, qr in enumerate(query_result):
                print(f'THREAD: {thread_id}------------------------- #{k}, score={qr.score} -------------------------')
                print(qr.chunk.text)

            # # 使用KBX在顶层进行查询
            query_result = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
            assert isinstance(query_result, QueryResults), \
                f"Query result should be a QueryResults object, given {type(query_result)}"
            assert isinstance(query_result.results, list), \
                f"Retrieval results should be a list, given {type(query_result.results)}"
            assert len(query_result) > 0, f"Failed to get query result {query}"
            if query.top_k > 0:
                assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                                                         f"given {query.top_k} and {len(query_result)}"
            print(f'Get {len(query_result)} results from KBX ("{kb.kb_config.name}")')
            for k, qr in enumerate(query_result):
                print(f'THREAD: {thread_id}------------------------- #{k}, score={qr.score} -------------------------')
                print(qr.chunk.text)

        print("TEST END.")


if __name__ == "__main__":
    # 手动执行
    test_case = TestDatastoreConcurrentE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_datastore_concurrent()
