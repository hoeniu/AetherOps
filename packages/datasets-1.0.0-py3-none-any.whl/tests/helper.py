from kbx.common.utils import get_user_id_from_jwt_header
from kbx.common.constants import DEFAULT_USER_ID


def gen_test_auth_token(user_id: str = DEFAULT_USER_ID):
    """
    Generate a test authentication token for KBXClient.
    This function is used to create a mock authentication token for testing purposes.
    """
    # Generate a mock authentication token using the get_user_id_from_jwt_header function
    # The user ID is set to "test_user" and the expiration time is set to 10 hours (36000 seconds)
    api_token = get_user_id_from_jwt_header(user_id, expires_in=36000)
    return api_token
