from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
from opentelemetry.sdk.resources import Resource


service_name = "otel-create"
resource = Resource(attributes={
    "service.name": service_name
})


def main():
    tracer = trace.get_tracer(service_name)
    # NoRecordingSpan
    with tracer.start_as_current_span("test") as span:
        print(span)
    trace.set_tracer_provider(TracerProvider(resource=resource))
    span_exporter = ConsoleSpanExporter()
    span_processor = BatchSpanProcessor(span_exporter)
    trace.get_tracer_provider().add_span_processor(span_processor)


# 用于验证:
# 0. tracer先构建，然后setProvider，也能构建span
# 1. 使用同一个TraceProvider, 构建同名tracer: tracer是不同实例，但是span可以形成嵌套关系
# 2. 使用同一个TraceProvider, 构建异名tracer: span可以形成嵌套关系
    with tracer.start_as_current_span("test-0") as span:
        print(span, tracer)
        tracer1 = trace.get_tracer(service_name)
        # _Span
        with tracer1.start_as_current_span("test-1") as span1:
            print(span1, tracer1)
            tracer2 = trace.get_tracer(service_name)
            # _Span
            with tracer2.start_as_current_span("test-2") as span2:
                print(span2, tracer2)
                tracer3 = trace.get_tracer(service_name + ".extra")
                # _Span
                with tracer3.start_as_current_span("test-3") as span3:
                    print(span3, tracer3)


if __name__ == "__main__":
    main()
