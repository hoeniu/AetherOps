import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import yaml

from kbx.common.constants import DEFAULT_USER_ID
from kbx.cli.client import KBXClient
from tests.helper import gen_test_auth_token

DEFAULT_SERVER = "127.0.0.1:30018"


def register_model(auth_token: str, ai_model_file: str):

    kbx_client: KBXClient = KBXClient(server=DEFAULT_SERVER, auth_token=auth_token)
    with open(ai_model_file, 'r', encoding='utf-8') as f:
        ai_model_config_list = yaml.safe_load(f)
    print(ai_model_config_list)
    res = kbx_client.register_ai_models(ai_model_config_list, overwrite=True)
    print(res)
    res = kbx_client.list_ai_models()
    print(res)
    res = kbx_client.get_ai_model_detail("volcengine-deepseek-v3")
    print(res)


if __name__ == "__main__":
    auth_token = gen_test_auth_token(DEFAULT_USER_ID)
    register_model(auth_token, "conf/ai_models.yaml")
