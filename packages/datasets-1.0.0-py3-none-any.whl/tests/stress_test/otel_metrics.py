import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

from kbx.common.otel import record_func_metrics
import time
import random


@record_func_metrics
def function_example():
    t = random.uniform(0.1, 2.9)
    time.sleep(t)  # 模拟耗时操作
    print(f"sleep {t * 1000} milliseconds.")


if __name__ == "__main__":
    for _ in range(10000):
        function_example()
