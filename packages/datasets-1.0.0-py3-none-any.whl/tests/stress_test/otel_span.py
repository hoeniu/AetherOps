from opentelemetry import trace, context
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
import threading


service_name = "otel-test"
# current_span = trace.get_current_span()
# print("global span: ", current_span)
# current_context = context.get_current()
# print("global context: ", current_context)
# 初始化 TracerProvider 和 SpanProcessor
trace.set_tracer_provider(TracerProvider())
trace.get_tracer_provider().add_span_processor(
    BatchSpanProcessor(ConsoleSpanExporter())
)
# 获取 Tracer 对象
tracer = trace.get_tracer(service_name)


@tracer.start_as_current_span("main_function_impl")
def main_function_impl():
    current_span = trace.get_current_span()
    print("child span: ", current_span)
    current_context = context.get_current()
    print("child context: ", current_context)


# 定义子线程的函数
def thread_function_wrapper(current_span, current_context):
    # 使用当前上下文创建一个新的 Span
    token = context.attach(current_context)
    # tracer.use_span()
    thread_function_impl()
    context.detach(token)


@tracer.start_as_current_span("thread_function_impl")
def thread_function_impl():
    # span2.set_attribute("child_key", "child_value")
    current_span = trace.get_current_span()
    print("child span: ", current_span)
    current_context = context.get_current()
    print("child context: ", current_context)


@tracer.start_as_current_span("main")
def main():
    # 获取当前上下文
    current_span = trace.get_current_span()
    print("parent span: ", current_span)
    current_context = context.get_current()
    print("parent context: ", current_context)
    main_function_impl()
    # 创建并启动子线程
    thread = threading.Thread(target=thread_function_wrapper, args=(current_span, current_context))
    thread.start()
    thread.join()


if __name__ == "__main__":
    main()
