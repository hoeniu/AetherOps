import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import yaml
from typing import Any, Dict, List, Tuple
import threading

from kbx.common.constants import DEFAULT_USER_ID
from kbx.cli.client import KBXClient
from tests.helper import gen_test_auth_token
import time

ROUND = 100000
THREAD_NUM = 4
server = "127.0.0.1:30018"
user_id = DEFAULT_USER_ID
share_lock = threading.Lock()


def retrieve(kbx_client: KBXClient, kb_id: str, query: str, top_k: int) -> Tuple[List[Dict[str, Any]], float]:
    now = time.time()
    res = kbx_client.query_kb(kb_ids=[kb_id], query=query, top_k=top_k)
    cost = time.time() - now
    return res, cost


def print_thread(thread_id: str, content):
    print(f"THREAD_ID: {thread_id} -> ", content)


def kb_workflow_test(thread_id: int = 0, auth_token: str = ""):

    kbx_client: KBXClient = KBXClient(server=server, auth_token=auth_token)
    kb_id: str = None
    share_lock.acquire()
    res = kbx_client.list_kbs()
    len_kb_list = res["total"]
    kb_list = res["data"]
    print(kb_list)
    print_thread(thread_id=thread_id, content=kb_list)
    print_thread(thread_id=thread_id, content=len_kb_list)
    if len_kb_list <= thread_id:
        for i in range(len_kb_list, thread_id + 1):
            print_thread(thread_id=thread_id, content=f"try to create kb {i}, {thread_id + 1}")
            with open(f"{ROOT_DIR}/conf/kb_examples/vector_keyword_multi_modal.yaml",
                      'r', encoding="utf-8") as yaml_file:
                kb_creation_config = yaml.safe_load(yaml_file)
            kb_creation_config["name"] = kb_creation_config["name"] + f"_{i}"
            create_res = kbx_client.create_kb(config=kb_creation_config, desired_kb_id=None)
            if create_res:
                kb_id = create_res["kb_id"]
                print_thread(thread_id=thread_id, content=f"Create KB: {kb_id}")
            else:
                print_thread(thread_id=thread_id, content="Cannot get legal kb_id, exit")
                return
    else:
        kb_id = kb_list[thread_id]["kb_id"]

    # print_thread(thread_id=thread_id, content=f"Start to insert docs in to kb {kb_id}")
    kbx_client.insert_docs_folder(kb_id=kb_id, folder_path="cache/kbx_test_data",
                                  include_patterns=["2023*.pdf"])
    # print_thread(thread_id=thread_id, content=kbx_client.list_docs(kb_id))
    share_lock.release()

    query_list = ["美国经济如何", "世界经济如何", "中国经济如何"]
    for round in range(ROUND):
        for query in query_list:
            res, cost = retrieve(kbx_client=kbx_client, kb_id=kb_id, query=query, top_k=3)
            print_thread(thread_id=thread_id, content=(res, cost))


if __name__ == "__main__":

    task_list: List = list()
    auth_token = gen_test_auth_token(DEFAULT_USER_ID)
    print(auth_token)

    for i in range(THREAD_NUM):
        # args必须是一个元组，不能写(i), 必须写(i,)
        task = threading.Thread(target=kb_workflow_test, args=(i, auth_token))
        task_list.append(task)

    for i in range(THREAD_NUM):
        task_list[i].start()

    for i in range(THREAD_NUM):
        task_list[i].join()
