import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

from kbx.common.constants import DEFAULT_USER_ID
from kbx.cli.client import KBXClient
from typing import List, Tuple

# alias kbx=PYTHONPATH=.\ python\ kbx/cli/main.py
# export KBX_USER_ID=5YZsMzEB
# export KBX_API_KEY=kbx123456

DEFAULT_SERVER = "127.0.0.1:30018"
DEFAULT_API_KEY = "kbx123456"


def delete_all_kbs(user_id: str):

    kbx_client: KBXClient = KBXClient(server=DEFAULT_SERVER, api_key=DEFAULT_API_KEY, user_id=user_id)
    kb_id_list: List[Tuple[str, str]] = kbx_client.list_kbs()
    for t in kb_id_list:
        kb_id = t[0]
        if kb_id == "v6m88E10":
            continue
        kbx_client.remove_kb(kb_id)


if __name__ == "__main__":
    delete_all_kbs(DEFAULT_USER_ID)
