import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
from tests.ci.test_structured_e2e import TestStructuredIndexE2E


class TestStructuredIndexCeleryE2E(TestStructuredIndexE2E):
    @classmethod
    def setup_class(cls):
        cls.kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings_celery.yaml')
        super().setup_class()

    def setup_method(self):
        self._kb_name = "一线城市近几年GDP经济数据"
        self._kb_description = "目前主要包括北京、上海、广州、深圳的GDP经济数据"


if __name__ == "__main__":
    # 手动执行
    test_case = TestStructuredIndexCeleryE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_std_case()
