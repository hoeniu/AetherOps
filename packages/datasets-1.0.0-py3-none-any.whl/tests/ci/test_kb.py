import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import json
import pytest
from tests.base_test_case import BaseTestCase
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.common.types import KBXError, DocFileType
from kbx.datastore.types import FileType
from kbx.knowledge_base.types import KBCreationConfig, SplitterConfig, \
    VectorKeywordIndexConfig, KnowledgeGraphIndexConfig, StructuredIndexConfig, DocStatus, DocType


class TestKnowledgeBaseE2E(BaseTestCase):
    def setup_method(self):
        with open(os.path.join(ROOT_DIR, "tests/schema/schema.json"), 'r', encoding="utf-8") as fd:
            self._schema_dict = json.load(fd)

    def try_remove_previous_kb(self, kb_id: str = None, kb_name: str = None, user_id: str = DEFAULT_USER_ID):
        # 删除之前的知识库
        if KBX.if_kb_exists(kb_id=kb_id, kb_name=kb_name, user_id=user_id):
            previous_kb = KBX.get_existed_kb(kb_id=kb_id, kb_name=kb_name, user_id=user_id)
            previous_kb.remove_kb()

    @pytest.mark.mr_ci
    def test_create_new_kb(self):
        kb_name = '测试知识库new'
        kb_description = '这是一个测试知识库'

        self.try_remove_previous_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)

        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                    chunk_size=200,
                ),
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        print(f'Try to create new kb {kb_config.name} (id={kb._kb_id})')

        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description

        # 删除知识库
        kb.remove_kb()
        assert not KBX.if_kb_exists(kb_name=kb_name, user_id=DEFAULT_USER_ID)

    @pytest.mark.mr_ci
    def test_create_new_kb_with_id(self):
        kb_name = '测试知识库new'
        kb_description = '这是一个测试知识库'
        kb_id = "awesome-kb-id-abcdefgh"

        self.try_remove_previous_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)

        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                    chunk_size=200,
                ),
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID, desired_kb_id=kb_id)
        print(f'Try to create new kb {kb_config.name} (id={kb._kb_id})')

        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description
        assert kb.kb_id == kb_id

        # 修改部分配置参数
        kb_config.name = '测试知识库new2'
        kb_config.description = '这是一个测试知识库2'
        err = kb.modify_kb_config(kb_config)

        assert err.code == KBXError.Code.SUCCESS
        assert kb.kb_name == kb_config.name == kb_config.name
        assert kb.kb_config.description == kb_config.description

        # 删除知识库
        kb.remove_kb()
        assert not KBX.if_kb_exists(kb_id=kb_id, user_id=DEFAULT_USER_ID)
        assert not KBX.if_kb_exists(kb_name=kb_name, user_id=DEFAULT_USER_ID)

    @pytest.mark.mr_ci
    def test_create_new_kb_auto_gen_user_tenant(self):
        kb_name = '测试知识库【自动创建用户租户】'
        kb_description = '这是一个测试知识库'
        kb_id = "awesome-kb-id-abcdefghijkl"

        tenant_id = 'tenant_does_not_exists'
        user_id = 'user_does_not_exists'
        try:
            KBX.remove_tenant(tenant_id=tenant_id)
        except ValueError:
            pass

        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                    chunk_size=200,
                ),
            ),
        )
        with pytest.raises(ValueError):
            # 直接创建知识库，由于用户不存在，应该直接抛异常
            kb = KBX.create_new_kb(kb_config, user_id=user_id, desired_kb_id=kb_id)
        print(f'Try to create new kb {kb_config.name} with auto_create_user_tenant')
        # 设置auto_create_user_tenant，可以自动创建用户和租户
        kb = KBX.create_new_kb(
            kb_config,
            user_id=user_id,
            desired_kb_id=kb_id,
            auto_create_user_tenant=True,
            tenant_id=tenant_id
        )

        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description
        assert kb.kb_id == kb_id

        # 检查对应租户、用户是否成功自动创建
        tenant_info = KBX.get_tenant_info(tenant_id=tenant_id)
        assert tenant_info.id == tenant_id
        user_info = KBX.get_user_info(tenant_id=tenant_id, user_id=user_id)
        assert user_info.id == user_id

        KBX.remove_tenant(tenant_id=tenant_id)

    @pytest.mark.mr_ci
    def test_kb_insert_docs(self):
        kb_name = '测试知识库【插入文档】'
        kb_description = '这是一个测试知识库'

        self.try_remove_previous_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)

        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                    chunk_size=200,
                ),
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        print(f'Try to create new kb {kb_config.name} (id={kb._kb_id})')

        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description

        # 插入不存在的文档
        doc_info = kb.insert_single_doc(
            file_path=os.path.join(ROOT_DIR, '/不存在/的文件.docx'),
        )
        assert doc_info.err_info.code != KBXError.Code.SUCCESS
        assert doc_info.doc_status == DocStatus.UPLOAD_FAILED
        assert doc_info.doc_id is None
        assert doc_info.raw_file_info is None
        assert len(doc_info.extra_files_info) == 0
        doc_ids = kb.list_doc_ids(offset=0, limit=1000)[0]
        assert doc_ids == []

        # 插入存在但无法解析的文档
        file_path = os.path.join(
            self.test_data_dir, '中国平安.txt')
        doc_info = kb.insert_single_doc(
            file_path=file_path,
        )
        # assert doc_info.err_info.code != KBXError.Code.SUCCESS
        # assert doc_info.doc_status == DocStatus.PARSE_FAILED, \
        #     f"Expect parse error, given {doc_info}"
        assert doc_info.doc_id is not None
        assert doc_info.raw_file_info is not None
        assert doc_info.raw_file_info.file_path.endswith(os.path.basename(file_path))
        assert doc_info.raw_file_info.file_raw_path is not None
        expected_file_url = KBX.config.file_service_prefix + '/' + doc_info.raw_file_info.file_raw_path
        assert doc_info.raw_file_info.file_url == expected_file_url
        assert len(doc_info.extra_files_info) == 0
        # 虽然插入失败，但因为是解析出错，所以文档持久化入库，可以查询、reindex
        doc_info2 = kb.get_doc_info(doc_id=doc_info.doc_id)
        assert doc_info == doc_info2, f'Expect same doc_info, given\n{doc_info!r}\nand\n{doc_info2!r}'
        # 应该获取到内容空的DocData
        doc_data = kb.get_doc_data(doc_id=doc_info.doc_id)
        assert doc_data is not None
        # assert len(doc_data.doc_elements) == 0

        # reindex，依然解析失败
        doc_id_errors = kb.reindex(doc_info.doc_id, reparse=True)

        # reindex_all
        doc_id_errors2 = kb.reindex_all(reparse=True)
        assert doc_id_errors2 == doc_id_errors, \
            f'Expect same doc_id_errors, given\n{doc_id_errors!r}\nand\n{doc_id_errors2!r}'

        # 插入空文档路径
        file_list = [file_path, file_path, '']
        with pytest.raises(ValueError):
            _ = kb.insert_docs(file_list=file_list)

        # 一次插入重复的文档
        file_list = [file_path, file_path]
        with pytest.raises(ValueError):
            _ = kb.insert_docs(file_list=file_list)

        # 一次插入过多的文档
        file_list = [file_path.replace('.pdf', f'_{k}.pdf') for k in range(2000)]
        with pytest.raises(ValueError):
            _ = kb.insert_docs(file_list=file_list)

        # 插入一个符合预期的文档
        file_path = os.path.join(
            self.test_data_dir, '2023-04-10：海外宏观周报：美国经济喜忧交织.pdf')
        doc_info = kb.insert_single_doc(
            file_path=file_path,
        )
        assert doc_info.err_info.code == KBXError.Code.SUCCESS
        assert doc_info.doc_status == DocStatus.INDEX_SUCCESS
        assert doc_info.doc_id is not None
        assert doc_info.raw_file_info is not None
        assert doc_info.raw_file_info.file_path.endswith(os.path.basename(file_path))
        assert doc_info.raw_file_info.file_name == os.path.basename(file_path)
        assert doc_info.raw_file_info.file_raw_path is not None
        expected_file_url = KBX.config.file_service_prefix + '/' + doc_info.raw_file_info.file_raw_path
        assert doc_info.raw_file_info.file_url == expected_file_url
        doc_ids = kb.list_doc_ids(offset=0, limit=1000)[0]
        assert len(doc_ids) == 2, f'Expect 2 doc, given {len(doc_ids)}: {doc_ids!r}'
        doc_info2 = kb.get_doc_info(doc_id=doc_info.doc_id)
        assert doc_info == doc_info2, f'Expect same doc_info, given\n{doc_info!r}\nand\n{doc_info2!r}'
        assert doc_info2.raw_file_info.file_name == os.path.basename(file_path)
        doc_data = kb.get_doc_data(doc_id=doc_info.doc_id)
        assert doc_data is not None, f'Expect doc_data is not None, given {doc_data!r}'

        # 重复插入一个文档，不增加文档数量，覆盖写入
        doc_info = kb.insert_single_doc(
            file_path=file_path,
        )
        assert doc_info.err_info.code == KBXError.Code.SUCCESS
        assert doc_info.doc_status == DocStatus.INDEX_SUCCESS
        assert doc_info.doc_id is not None
        assert doc_info.raw_file_info is not None
        assert doc_info.raw_file_info.file_path.endswith(os.path.basename(file_path))
        new_doc_ids = kb.list_doc_ids()[0]
        assert len(kb.list_doc_ids()[0]) == 2
        assert new_doc_ids[0] == doc_ids[0]

        # 插入多个文档
        file_list = [
            os.path.join(self.test_data_dir, '中国平安.txt'),
            os.path.join(self.test_data_dir, 'dose-not-exist.pdf'),
            os.path.join(self.test_data_dir, '2023-04-05：以史为鉴：从银行业危机到衰退和降息有多远？.pdf'),
            os.path.join(self.test_data_dir, '2023-04-10：海外宏观周报：美国经济喜忧交织.pdf'),
            os.path.join(self.test_data_dir, '中医医院建设标准建标106-2008.pdf'),
        ]
        rets = kb.insert_docs(file_list=file_list)
        assert len(rets) == len(file_list)
        assert rets[0].doc_status == DocStatus.INDEX_SUCCESS
        assert rets[1].doc_status == DocStatus.UPLOAD_FAILED
        assert rets[2].err_info.code == KBXError.Code.SUCCESS
        assert rets[3].err_info.code == KBXError.Code.SUCCESS
        assert rets[4].err_info.code == KBXError.Code.SUCCESS
        doc_ids = kb.list_doc_ids()[0]
        assert len(doc_ids) == 4

        # reindex_all
        doc_id_errors2 = kb.reindex_all(reparse=True)
        assert doc_id_errors2 == doc_id_errors, \
            f'Expect same doc_id_errors, given\n{doc_id_errors!r}\nand\n{doc_id_errors2!r}'

        # 删除知识库
        kb.remove_kb()
        assert not KBX.if_kb_exists(kb_name=kb_name, user_id=DEFAULT_USER_ID)

    @pytest.mark.mr_ci
    def test_kb_insert_docs_folder(self):
        kb_name = '测试知识库【插入文档】'
        kb_description = '这是一个测试知识库'
        self.try_remove_previous_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)
        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        print(f'Try to create new kb {kb_config.name} (id={kb._kb_id})')

        import fnmatch
        # 插入一个文件夹，使用include_patterns指定要插入的文件类型
        folder_path = os.path.join(self.test_data_dir, 'parser_data')
        save_dir = 'parser_data'
        include_patterns = ['*.txt']
        print(f'Insert docs folder {folder_path} with include_patterns {include_patterns} and save_dir {save_dir}')
        rets = kb.insert_docs_folder(
            folder_path=folder_path,
            include_patterns=include_patterns,
            save_dir=save_dir,
            recursive=False
        )
        assert len(rets) >= 1
        for rel_path, doc_infos in rets.items():
            assert rel_path == '.'
            for doc_info in doc_infos:
                assert doc_info.err_info.code == KBXError.Code.SUCCESS, f"doc_info: {doc_info}"
                save_path = os.path.relpath(doc_info.raw_file_info.file_path, FileType.RAW_DOC_FILES)
                assert save_path.startswith(save_dir)
                assert doc_info.doc_id is not None
                assert doc_info.doc_status == DocStatus.INDEX_SUCCESS, f"doc_info: {doc_info}"
                assert doc_info.raw_file_info is not None
                ext = os.path.splitext(doc_info.raw_file_info.file_name)[1]
                assert any(fnmatch.fnmatch(ext, pattern) for pattern in include_patterns), \
                    f'Expect ext in {include_patterns}, given {ext}'

        kb.remove_docs(doc_ids=kb.list_doc_ids(limit=-1)[0])

        # 插入一个文件夹，使用exclude_patterns指定要排除的文件类型
        folder_path = os.path.join(self.test_data_dir, 'parser_data')
        save_dir = 'parser_data'
        exclude_patterns = ['*.pdf', '*.pptx', '*.jpg', '*.html', '*.md', '*.jpg', '*.xls', '*.docx', '*.xlsx', '*.rst']
        print(f'Insert docs folder {folder_path} with exclude_patterns {exclude_patterns} and save_dir {save_dir}')
        rets = kb.insert_docs_folder(
            folder_path=folder_path,
            exclude_patterns=exclude_patterns,
            save_dir=save_dir,
            recursive=False
        )
        assert len(rets) >= 1
        for rel_path, doc_infos in rets.items():
            assert rel_path == '.', f'Expect rel_path == ".", given {rel_path}'
            for doc_info in doc_infos:
                assert doc_info.err_info.code == KBXError.Code.SUCCESS, f"doc_info: {doc_info}"
                save_path = os.path.relpath(doc_info.raw_file_info.file_path, FileType.RAW_DOC_FILES)
                assert save_path.startswith(save_dir)
                assert doc_info.doc_id is not None
                assert doc_info.doc_status == DocStatus.INDEX_SUCCESS, f"doc_info: {doc_info}"
                assert doc_info.raw_file_info is not None
                ext = os.path.splitext(doc_info.raw_file_info.file_name)[1]
                assert not any(fnmatch.fnmatch(ext, pattern) for pattern in exclude_patterns), \
                    f'Expect ext not in {exclude_patterns}, given {ext}'

        # 删除知识库
        kb.remove_kb()

    @pytest.mark.mr_ci
    def test_kb_insert_docs_with_parse_config(self):
        kb_name = '测试知识库【插入文档】'
        kb_description = '这是一个测试知识库'
        self.try_remove_previous_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)
        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                    chunk_size=500,
                ),
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        print(f'Try to create new kb {kb_config.name} (id={kb._kb_id})')
        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description

        doc_parse_config2 = kb_config.doc_parse_config.model_copy(deep=True)
        # 指定parser插入一个md文档
        md_file = os.path.join(self.test_data_dir, 'parser_data/test.md')
        doc_info = kb.insert_single_doc(
            file_path=md_file,
            doc_parse_config=doc_parse_config2
        )
        assert doc_info.doc_parse_config is not None
        assert doc_info.doc_parse_config == doc_parse_config2

        doc_parse_config3 = doc_parse_config2.model_copy(deep=True)
        doc_parse_config3.file_parsers = {
            DocFileType.MARKDOWN: "DefaultMarkdownParser",
        }
        doc_info = kb.insert_single_doc(
            file_path=md_file,
            doc_parse_config=doc_parse_config3
        )
        assert doc_info.doc_parse_config is not None
        assert doc_info.doc_parse_config == doc_parse_config3

    @pytest.mark.mr_ci
    def test_remove_empty_kb(self):
        kb_name = '测试知识库【删除空知识库】'
        kb_description = '这是一个测试知识库'
        self.try_remove_previous_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)

        # ---------------------向量---------------------
        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                    chunk_size=200,
                ),
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description
        kb.remove_kb()

        with pytest.raises(RuntimeError):
            # 删除后应该无法正常获取到知识库
            KBX.get_existed_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)

        # ---------------------知识图谱---------------------
        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            kg_config=KnowledgeGraphIndexConfig(
                index_strategy="DefaultGraphIndex",
                llm_model="doubao-1.5-pro-32k",
                embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                ),
                schema_dict=self._schema_dict,
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description
        kb.remove_kb()

        with pytest.raises(RuntimeError):
            # 删除后应该无法正常获取到知识库
            KBX.get_existed_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)

        # ---------------------结构化数据库---------------------
        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            structured_config=StructuredIndexConfig(
                index_strategy="DefaultStructuredIndex",
                llm_model="doubao-1.5-pro-32k",
                sql_gen_llm_model="doubao-1.5-pro-32k",
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description
        kb.remove_kb()

        with pytest.raises(RuntimeError):
            # 删除后应该无法正常获取到知识库
            KBX.get_existed_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)

    @pytest.mark.mr_ci
    def test_kb_insert_resource_docs(self):
        kb_name = '测试知识库【插入文档】'
        kb_description = '这是一个测试知识库'

        self.try_remove_previous_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)

        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                    chunk_size=200,
                ),
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        print(f'Try to create new kb {kb_config.name} (id={kb._kb_id})')

        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description

        # 插入资源文件
        doc_info = kb.insert_single_doc(
            file_path=os.path.join(self.test_data_dir, 'parser_data/chess.jpg'),
            doc_type=DocType.RESOURCE,
        )
        assert doc_info.err_info.code == KBXError.Code.SUCCESS
        assert doc_info.doc_status == DocStatus.UPLOAD_SUCCESS
        assert doc_info.doc_id is not None
        assert doc_info.raw_file_info is not None
        assert len(doc_info.extra_files_info) == 0

        doc_infos = kb.insert_docs(
            file_list=[
                os.path.join(self.test_data_dir, 'parser_data/kbx_arch.jpg'),
                os.path.join(self.test_data_dir, 'parser_data/test.md'),
            ],
            doc_patterns=["*.md"]
        )
        assert len(doc_infos) == 2
        assert doc_infos[0].err_info.code == KBXError.Code.SUCCESS
        assert doc_infos[0].doc_type == DocType.RESOURCE
        assert doc_infos[0].doc_id is not None
        assert doc_infos[0].doc_status == DocStatus.UPLOAD_SUCCESS
        assert doc_infos[0].raw_file_info is not None
        assert doc_infos[0].raw_file_info.file_path.endswith('kbx_arch.jpg')
        assert doc_infos[0].extra_files_info is not None
        assert doc_infos[1].err_info.code == KBXError.Code.SUCCESS
        assert doc_infos[1].doc_type == DocType.NORMAL
        assert doc_infos[1].doc_id is not None
        assert doc_infos[1].doc_status == DocStatus.INDEX_SUCCESS
        assert doc_infos[1].raw_file_info is not None
        assert doc_infos[1].raw_file_info.file_path.endswith('test.md')
        assert doc_infos[1].extra_files_info is not None

        doc_infos, total_count = kb.list_docs_info(offset=0, limit=-1, doc_type_filter=[DocType.RESOURCE])
        assert len(doc_infos) == 2
        assert total_count == 2
        assert all(doc_info.doc_type == DocType.RESOURCE for doc_info in doc_infos)

        doc_infos, total_count = kb.list_docs_info(offset=0, limit=-1, doc_type_filter=[DocType.NORMAL])
        assert len(doc_infos) == 1
        assert total_count == 1
        assert all(doc_info.doc_type == DocType.NORMAL for doc_info in doc_infos)

    @pytest.mark.mr_ci
    def test_kb_insert_resource_docs_folder(self):
        kb_name = '测试知识库【插入文档】'
        kb_description = '这是一个测试知识库'

        self.try_remove_previous_kb(kb_name=kb_name, user_id=DEFAULT_USER_ID)

        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                    chunk_size=200,
                ),
            ),
        )
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        print(f'Try to create new kb {kb_config.name} (id={kb._kb_id})')

        assert kb.kb_name == kb_name
        assert kb.kb_config.description == kb_description

        doc_infos = kb.insert_docs_folder(
            folder_path=os.path.join(self.test_data_dir, 'parser_data'),
            recursive=True,
            include_patterns=["*.md", "*.jpg", "*.png"],
            doc_patterns=["*.md"],
        )
        for _, tmp_doc_infos in doc_infos.items():
            for doc_info in tmp_doc_infos:
                assert doc_info.doc_id is not None
                if doc_info.doc_type == DocType.RESOURCE:
                    assert doc_info.doc_status == DocStatus.UPLOAD_SUCCESS
                    assert doc_info.raw_file_info is not None
                else:
                    assert doc_info.doc_type == DocType.NORMAL
                    assert doc_info.doc_status == DocStatus.INDEX_SUCCESS
                    assert doc_info.raw_file_info is not None


if __name__ == '__main__':
    # 手动执行
    test_case = TestKnowledgeBaseE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_kb_insert_resource_docs()
    test_case.test_kb_insert_resource_docs_folder()
    test_case.test_create_new_kb()
    test_case.test_create_new_kb_with_id()
    test_case.test_remove_empty_kb()
    test_case.test_kb_insert_docs()
    test_case.test_kb_insert_docs_with_parse_config()
    test_case.test_create_new_kb_auto_gen_user_tenant()
    test_case.test_kb_insert_docs_folder()
