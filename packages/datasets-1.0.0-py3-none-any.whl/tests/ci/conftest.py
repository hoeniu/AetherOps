import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import pytest
from fastapi.testclient import TestClient
import taskiq_fastapi
from kbx.bin.launch_restful_svc import app
from tests.helper import gen_test_auth_token


@pytest.fixture(scope="session")
def anyio_backend() -> str:
    """
    Backend for anyio pytest plugin.

    :return: backend name.
    """
    return "asyncio"


@pytest.fixture(scope="session", autouse=True)
def mock_data():
    from unittest.mock import MagicMock

    mock = MagicMock()
    token = gen_test_auth_token()
    mock.headers = {"Authorization": f"Bearer {token}"}

    mock.client = TestClient(app)

    return mock


@pytest.fixture(autouse=True)
def init_taskiq_deps():
    # This is important part. Here we add dependency context,
    # this thing helps in resolving dependencies for tasks
    # for inmemory broker.
    from kbx.app.core.taskiq import broker

    taskiq_fastapi.populate_dependency_context(broker, app)

    yield

    broker.custom_dependency_context = {}
