import os
import pytest
import sys
from humanfriendly.text import random_string
import copy

# 根目录
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../..")
sys.path.insert(0, ROOT_DIR)
from tests.base_test_case import BaseTestCase


# 文档测试中使用的模型注册配置和知识库模板
kb_template = {
    "name": "test-kb-" + random_string(6),
    "description": "这是一个新的知识库",
    "doc_parse_config": {
        "autodetect_encoding": True,
        "save_external_data": False,
        "enable_layout_recognition": True,
        "image_strategy": {
            "type": "VLMTextEmbedding",
            "vision_model": "doubao-pro-vision-32k"
        },
        "video_strategy": None,
        "audio_strategy": None,
    },
    "vector_keyword_config": {
        "index_strategy": "DefaultVectorKeywordIndex",
        "splitter_config": {
            "name": "RecursiveTextSplitter",
            "chunk_size": 1024,
            "delimiters": ["\n\n", "\n", " "],
            "overlap_size": 0,
            "keep_delimiter": True,
        },
        "text_embedding_model": "doubao-embedding-large",
        "keyword_extractor": None,
        "max_keywords_per_chunk": 0
    },
}


class TestRetrievalAPI(BaseTestCase):
    @pytest.fixture(scope="class", autouse=True)
    def setup_and_teardown_class(self, mock_data):
        # 初始化客户端和请求头
        TestRetrievalAPI.client = mock_data.client
        TestRetrievalAPI.headers = mock_data.headers
        # 注册测试模型
        request_data = {
            "configs": [
                {
                    "name": "doubao-embedding-large",
                    "type": "text_embedding",
                    "backend": "volcengine",
                    "api_key": "8b52eb53-cc4f-44b4-a59b-73e179fc9e3a",
                    "base_url": "https://ark.cn-beijing.volces.com/api/v3",
                    "endpoint": "ep-20241108104331-4jfp9",
                    "max_context_len": 4096,
                    "max_tokens": 4096,
                    "rpm": 1000
                },
                {
                    "name": "doubao-1.5-pro-256k",
                    "type": "llm",
                    "backend": "volcengine",
                    "api_key": "8b52eb53-cc4f-44b4-a59b-73e179fc9e3a",
                    "base_url": "https://ark.cn-beijing.volces.com/api/v3",
                    "endpoint": "ep-20250122192253-khdzh",
                    "max_context_len": 4096,
                    "max_tokens": 4096,
                    "rpm": 1000
                },
                {
                    "name": "qwen-max",
                    "type": "llm",
                    "backend": "tongyi",
                    "api_key": "sk-05ee5d096cb34027af2d02593f102059",
                    "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
                    "max_context_len": 4096,
                    "max_tokens": 4096,
                    "rpm": 1000
                }
            ],
            "overwrite": True
        }
        reg_resp = TestRetrievalAPI.client.post(
            "/api/v1/register_ai_models",
            json=request_data,
            headers=TestRetrievalAPI.headers
        )
        assert reg_resp.status_code == 200
        # 创建测试知识库
        req = copy.deepcopy(kb_template)
        create_resp = TestRetrievalAPI.client.post(
            "/api/v1/create_kb",
            json=req,
            headers=TestRetrievalAPI.headers
        )
        assert create_resp.status_code == 200
        TestRetrievalAPI.kb_id = create_resp.json().get("kb_id")
        # 同步插入测试文档
        test_files = [
            os.path.join(ROOT_DIR, self.test_data_dir, '中国平安.txt'),
            os.path.join(ROOT_DIR, self.test_data_dir, '平安银行.txt')
        ]
        files = []
        for fp in test_files:
            with open(fp, 'rb') as f:
                content = f.read()
            files.append(('files', (os.path.basename(fp), content, 'text/plain')))
        insert_resp = TestRetrievalAPI.client.post(
            f"/api/v1/docs/{TestRetrievalAPI.kb_id}", headers=TestRetrievalAPI.headers, files=files
        )
        assert insert_resp.status_code == 200
        docs = insert_resp.json()
        assert isinstance(docs, list) and len(docs) >= 2
        TestRetrievalAPI.doc_ids = [d['doc_id'] for d in docs]
        yield
        # 删除测试知识库
        tear = TestRetrievalAPI.client.post(
            f"/api/v1/remove_kb?kb_id={TestRetrievalAPI.kb_id}",
            headers=TestRetrievalAPI.headers
        )
        assert tear.status_code == 200

    @pytest.mark.mr_ci
    def test_dify_retrieval_success(self):
        """测试 Dify 兼容检索接口，已插入文档返回记录"""
        # 检索关键字应能命中插入的文档内容
        payload = {
            "knowledge_id": TestRetrievalAPI.kb_id,
            "query": "平安银行",
            "retrieval_setting": {"top_k": 5, "score_threshold": 0.0}
        }
        response = self.client.post(
            "/api/v1/dify/retrieval",
            json=payload,
            headers=self.headers
        )
        assert response.status_code == 200
        body = response.json()
        records = body.get("records")
        assert isinstance(records, list)
        # 至少返回一个结果
        assert len(records) >= 1
        # 验证字段
        for rec in records:
            assert "content" in rec and isinstance(rec["content"], str)
            assert "score" in rec and isinstance(rec["score"], float)
            assert "title" in rec and isinstance(rec["title"], str)

    @pytest.mark.mr_ci
    def test_retrieval_success(self):
        """测试 KBX 原始检索接口，非流式调用返回 QueryResult 列表"""
        query = {"text": "中国平安", "top_k": 5, "score_threshold": 0.0, "stream": False}
        url = f"/api/v1/retrieval?kb_ids={TestRetrievalAPI.kb_id}"
        response = self.client.post(
            url,
            json=query,
            headers=self.headers
        )
        assert response.status_code == 200
        data = response.json()
        # API 返回可能为 dict 包含 results，或直接为列表
        assert isinstance(data, dict)
        entries = data.get('results', [])
        # 结果应为非空列表
        assert isinstance(entries, list)
        assert len(entries) >= 1
        # 验证返回元素包含必要字段
        for item in entries:
            assert 'doc_id' in item
            # chunk 字段可能在不同层级
            assert 'chunk' in item
            assert 'score' in item
        # 验证 step_messages 字段
        assert 'step_messages' in data
        step_messages = data['step_messages']
        assert isinstance(step_messages, list)
        assert len(step_messages) >= 0
        for msg in step_messages:
            assert 'step_name' in msg and isinstance(msg['step_name'], str)
            assert 'content' in msg and isinstance(msg['content'], str)
        # 验证 is_final 字段
        assert 'is_final' in data
        assert isinstance(data['is_final'], bool)

    @pytest.mark.mr_ci
    def test_retrieval_agent_success(self):
        """测试 KBX 原始检索接口，流式调用返回 QueryResult 列表"""
        query = {
            "text": "中国平安",
            "top_k": 5,
            "score_threshold": 0.0,
            "stream": False,
            "deep_think": {
                "llm_model": "doubao-1.5-pro-256k",
            }
        }
        url = f"/api/v1/retrieval?kb_ids={TestRetrievalAPI.kb_id}"
        response = self.client.post(
            url,
            json=query,
            headers=self.headers
        )
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, dict)
        entries = data.get('results', [])
        assert isinstance(entries, list)
        assert len(entries) >= 1
        for item in entries:
            assert 'doc_id' in item
            assert 'chunk' in item
            assert 'score' in item
        # 验证 step_messages 字段
        assert 'step_messages' in data
        step_messages = data['step_messages']
        assert isinstance(step_messages, list)
        assert len(step_messages) >= 0
        for msg in step_messages:
            assert 'step_name' in msg and isinstance(msg['step_name'], str)
            assert 'content' in msg and isinstance(msg['content'], str)
        # 验证 is_final 字段
        assert 'is_final' in data
        assert isinstance(data['is_final'], bool)

    @pytest.mark.mr_ci
    def test_retrieval_stream_success(self):
        """测试 KBX 原始检索接口，流式调用返回 QueryResult 列表"""
        query = {"text": "中国平安", "top_k": 5, "score_threshold": 0.0, "stream": True}
        url = f"/api/v1/retrieval?kb_ids={TestRetrievalAPI.kb_id}"
        response = self.client.post(
            url,
            json=query,
            headers=self.headers
        )
        assert response.status_code == 200
        # 解析 SSE 格式的响应，提取每个 data 事件
        raw = response.text
        assert raw
        # 每行以 'data: ' 开头是一个事件
        lines = [line for line in raw.splitlines() if line.startswith('data: ')]
        assert lines, f"No data lines in stream response: {raw}"
        import json
        events = [json.loads(line[len('data: '):]) for line in lines]
        # 首个事件包含 results
        first = events[0]
        assert 'results' in first and isinstance(first['results'], list)
        results = first['results']
        assert results, "Stream results list is empty"
        # 验证返回元素包含必要字段
        for item in results:
            assert 'doc_id' in item
            assert 'chunk' in item and isinstance(item['chunk'], dict)
            # 每个 chunk 内有 text 字段
            txt = item['chunk'].get('text')
            assert isinstance(txt, str) and txt
            assert 'score' in item
