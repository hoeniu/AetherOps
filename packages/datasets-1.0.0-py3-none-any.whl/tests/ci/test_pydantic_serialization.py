import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

import enum
import json
import random
import string
import pytest
from typing import Any, get_type_hints, Union, TypeVar, Literal, ClassVar
from pydantic import BaseModel
from pydantic_core import PydanticUndefined

from kbx.common.types import DocData, DocElement, Chunk, FileEncoding, KBXGlobalConfig, KBXError, FileInfo
from kbx.ai_model.types import BaseAIModelConfig, ChatMessage
from kbx.knowledge_base.types import QueryResult, QueryResults, QueryConfig, KBCreationConfig, DocInfo
from kbx.parser.types import DocParseConfig
from kbx.common.utils import get_pydantic_config_changes
from kbx.ai_model.openai import OpenAIModelConfig
from kbx.ai_model.tongyi import TongyiAIModelConfig
from kbx.ai_model.volcengine import VolcengineAIModelConfig
from tests.base_test_case import BaseTestCase


T = TypeVar('T', bound=BaseModel)
MAX_RECURSION_DEPTH = 5  # 设置最大递归深度


def mock_random_pydantic_data(base_model_cls: type[T], depth: int = 0) -> T:
    """生成一个 pydantic BaseModel 数据类的 mock 实例，包含随机数据。

    Args:
        base_model_cls (pydantic.BaseModel): pydantic BaseModel 的子类
        depth (int): 递归深度，用于控制递归的深度，防止无限递归。

    Returns:
        一个 base_model_cls 的实例，所有字段都被填充，
        要么是默认值，要么是随机生成的 mock 数据。
    """
    # 特殊处理 Table 类
    if base_model_cls.__name__ == "Table":
        # 生成一个简单的 2x2 表格数据
        data_2d = [
            ["字段1", "字段2"],
            ["值1", "值2"]
        ]
        return base_model_cls(
            data_2d=data_2d,
            has_header=True,
            original_format="2d_list"
        )

    if depth > MAX_RECURSION_DEPTH:
        return base_model_cls()

    def _generate_mock_value(field_type: type, current_depth: int = MAX_RECURSION_DEPTH) -> Any:
        # Handle nested BaseModel
        if isinstance(field_type, type) and issubclass(field_type, BaseModel):
            return mock_random_pydantic_data(field_type, current_depth + 1)

        # Handle enum types first to catch str/int enums
        if isinstance(field_type, type) and issubclass(field_type, enum.Enum):
            return random.choice(list(field_type))

        # Handle basic types
        if field_type is str:
            return ''.join(random.choices(string.ascii_letters, k=10))
        elif field_type is int:
            return random.randint(0, 100)
        elif field_type is float:
            return round(random.uniform(0, 100), 2)
        elif field_type is bool:
            return random.choice([True, False])
        elif field_type is list:
            return []
        elif field_type is dict:
            return {}

        # Handle Optional types
        if hasattr(field_type, "__origin__") and field_type.__origin__ is Union:
            # Get the non-None type from Optional[T]
            non_none_type = next(t for t in field_type.__args__ if t is not type(None))
            if non_none_type:
                return _generate_mock_value(non_none_type, current_depth + 1)
            return None

        # Handle List types
        if field_type is list:
            return []
        # Handle List[T] types
        if hasattr(field_type, "__origin__") and field_type.__origin__ is list:
            if hasattr(field_type, "__args__"):
                if field_type.__args__[0] == ChatMessage:
                    return []
                return [_generate_mock_value(field_type.__args__[0], current_depth + 1)]
            return []

        # Handle Dict[K, V] types
        if hasattr(field_type, "__origin__") and field_type.__origin__ is dict:
            key_type, value_type = field_type.__args__
            return {_generate_mock_value(key_type): _generate_mock_value(value_type)}

        # Handle Tuple types
        if field_type is tuple:
            return ()
        # Handle Tuple[T, ...] types
        if hasattr(field_type, "__origin__") and field_type.__origin__ is tuple:
            if hasattr(field_type, "__args__"):
                return tuple(_generate_mock_value(arg) for arg in field_type.__args__)
            return ()

        # Handle Set types
        if field_type is set:
            return set()
        # Handle Set[T] types
        if hasattr(field_type, "__origin__") and field_type.__origin__ is set:
            if hasattr(field_type, "__args__"):
                return {_generate_mock_value(field_type.__args__[0])}
            return set()

        # Handle enum types
        if isinstance(field_type, type) and issubclass(field_type, enum.Enum):
            return random.choice(list(field_type))

        # Handle Literal types
        if hasattr(field_type, "__origin__") and field_type.__origin__ is Literal:
            return random.choice(field_type.__args__)

        # Default to None for unknown types
        return None

    # Get field types from the model, excluding ClassVar fields
    field_types = {
        name: field_type
        for name, field_type in get_type_hints(base_model_cls).items()
        if not (hasattr(field_type, "__origin__") and field_type.__origin__ is ClassVar)
    }

    # Generate mock data for each field
    mock_data = {}
    for field_name, field_type in field_types.items():
        field_info = base_model_cls.model_fields[field_name]
        if field_info.default is not None and field_info.default != PydanticUndefined:
            mock_data[field_name] = field_info.default
        else:
            mock_data[field_name] = _generate_mock_value(field_type, depth)

    # Create instance and set user_ctx to None if exists
    instance = base_model_cls(**mock_data)
    if hasattr(instance, 'user_ctx'):
        instance.user_ctx = None
    return instance


class TestPydanticSerializationCase(BaseTestCase):
    def setup_method(self):
        self._base_model_cls_list = [
            QueryResult,
            QueryResults,
            DocParseConfig,
            KBCreationConfig,
            QueryConfig,
            DocElement,
            DocData,
            Chunk,
            FileEncoding,
            KBXGlobalConfig,
            KBXError,
            FileInfo,
            DocInfo,
            BaseAIModelConfig,
            OpenAIModelConfig,
            VolcengineAIModelConfig,
            TongyiAIModelConfig,
        ]

    @pytest.mark.mr_ci
    def test_pydantic_serialization(self):
        # 把所有待测试的pydantic数据类型挨个遍历进行mock数据的序列化和反序列化，
        # 并比较序列化前后的数据是否一致。
        for base_model_cls in self._base_model_cls_list:
            mock_data: BaseModel = mock_random_pydantic_data(base_model_cls)
            serialized_data_dict = mock_data.model_dump(mode='json')
            serialized_json_str = json.dumps(serialized_data_dict)

            deserialized_data: BaseModel = base_model_cls(**json.loads(serialized_json_str))

            # First compare model dict representation
            mock_dict = mock_data.model_dump()
            deserialized_dict = deserialized_data.model_dump()
            if mock_dict != deserialized_dict:
                diff = get_pydantic_config_changes(mock_data, deserialized_data, recursive=True)
                raise RuntimeError(
                    f'{base_model_cls} mock data serialization failed (dict comparison), expected: {mock_dict},'
                    f' got: {deserialized_dict}.\nDifference: {diff}'
                )

            # Then compare model instances directly
            if mock_data != deserialized_data:
                diff = get_pydantic_config_changes(mock_data, deserialized_data, recursive=True)
                raise RuntimeError(
                    f'{base_model_cls} mock data serialization failed (direct comparison), expected: {mock_data},'
                    f' got: {deserialized_data}.\nDifference: {diff}'
                )


if __name__ == '__main__':
    # 手动执行
    test_case = TestPydanticSerializationCase()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_pydantic_serialization()
