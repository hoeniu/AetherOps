import os

from kbx.common.utils import generate_new_id
from tests.base_test_case import BaseTestCase
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

import pytest


class TestUserAPI(BaseTestCase):
    @pytest.fixture(scope="class", autouse=True)
    def tenant_fixture(self, mock_data):
        TestUserAPI.client = mock_data.client
        TestUserAPI.tenant_id = generate_new_id()
        TestUserAPI.user_id = generate_new_id()
        # Create a tenant for the tests
        response = self.client.post(
            "/api/v1/tenants/",
            json={"name": "test_tenant", "desired_tenant_id": TestUserAPI.tenant_id}
        )
        assert response.status_code == 201
        TestUserAPI.tenant_id = response.json()
        assert isinstance(TestUserAPI.tenant_id, str)
        yield
        # Clean up the tenant after tests
        response = self.client.delete(
            f"/api/v1/tenants/{TestUserAPI.tenant_id}",
        )
        assert response.status_code == 204

    @pytest.mark.mr_ci
    def test_create_user(self):
        response = self.client.post(
            f"/api/v1/tenants/{TestUserAPI.tenant_id}/users/",
            json={"name": "test_user", "desired_user_id": "test_user_id"}
        )
        assert response.status_code == 201
        TestUserAPI.user_id = response.json()
        assert isinstance(TestUserAPI.user_id, str)

    @pytest.mark.mr_ci
    def test_get_user(self):
        response = self.client.get(
            f"/api/v1/tenants/{TestUserAPI.tenant_id}/users/{TestUserAPI.user_id}",
        )
        assert response.status_code == 200
        assert response.json() == {
            "id": TestUserAPI.user_id,
            "name": "test_user",
            "tenant_id": TestUserAPI.tenant_id
        }

    @pytest.mark.mr_ci
    def test_update_user(self):
        response = self.client.put(
            f"/api/v1/tenants/{TestUserAPI.tenant_id}/users/{TestUserAPI.user_id}",
            json={"name": "new_user"}
        )
        assert response.status_code == 200
        assert response.json() == {
            "id": TestUserAPI.user_id,
            "name": "new_user",
            "tenant_id": TestUserAPI.tenant_id
        }

    @pytest.mark.mr_ci
    def test_list_users(self):
        response = self.client.get(
            f"/api/v1/tenants/{TestUserAPI.tenant_id}/users/",
        )
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert any(u.get("id") == TestUserAPI.user_id for u in data)

    @pytest.mark.mr_ci
    def test_delete_user(self):
        response = self.client.delete(
            f"/api/v1/tenants/{TestUserAPI.tenant_id}/users/{TestUserAPI.user_id}",
        )
        assert response.status_code == 204

    @pytest.mark.mr_ci
    def test_get_user_not_found(self):
        response = self.client.get(
            f"/api/v1/tenants/{TestUserAPI.tenant_id}/users/nonexistent",
        )
        assert response.status_code == 404
        assert "details" in response.json()
