import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

import pytest
import time
from tests.base_test_case import BaseTestCase
from kbx.kbx import KBX
from kbx.ai_model.types import AIModelBundle, AIModelType
from kbx.common.constants import DEFAULT_USER_ID
from kbx.common.types import KBXError, DocData


class TestFastParser(BaseTestCase):
    def setup_method(self):
        self._ai_model_bundle = AIModelBundle(
            bundles={
                AIModelType.LLM: 'volcengine-deepseek-v3',
                AIModelType.VLM: 'doubao-1.5-vision-pro-32k',
                AIModelType.TEXT_EMBEDDING: 'jina-embeddings-v3',
                AIModelType.RERANK: 'BAAI/bge-reranker-v2-m3',
                # AIModelType.SPEECH2TEXT: 'FunAudioLLM/SenseVoiceSmall',
            }
        )
        self._user_id = DEFAULT_USER_ID

    @pytest.mark.mr_ci
    def test_fast_parser(self):
        file_path = os.path.join(self.test_data_dir, "parser_data/test.md")
        t0 = time.time()
        doc_id, err = KBX.parse_fast_doc(
            doc_file_path=file_path,
            model_bundle=self._ai_model_bundle,
            user_id=self._user_id,
        )
        t1 = time.time()
        print(f"parse_fast_doc cost: {t1 - t0} seconds")
        if err.code != KBXError.Code.SUCCESS:
            raise RuntimeError(f"fast_parse_doc failed for doc \"{file_path}\": {err.msg}")
        assert doc_id is not None and isinstance(doc_id, str)

        rets = KBX.get_fast_doc_data(doc_ids=[doc_id], user_id=self._user_id)
        t2 = time.time()
        print(f"get_fast_doc_data cost: {t2 - t1} seconds")
        assert len(rets) == 1
        doc_data, err = rets[0]
        assert doc_data is not None
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        assert doc_data.doc_id == doc_id
        assert err.code == KBXError.Code.SUCCESS

        # 测试非法user_id
        with pytest.raises(ValueError):
            _ = KBX.get_fast_doc_data(doc_ids=[doc_id], user_id="invalid_user_id")

        # 测试非法的doc_id
        rets = KBX.get_fast_doc_data(doc_ids=['invalid_doc_id'], user_id=self._user_id)
        t3 = time.time()
        print(f"get_fast_doc_data cost: {t3 - t2} seconds")
        assert len(rets) == 1
        assert rets[0][0] is None
        assert rets[0][1].code == KBXError.Code.RUNTIME_ERROR

        # 测试list文档列表
        doc_ids = KBX.list_fast_doc_ids(user_id=self._user_id)
        t4 = time.time()
        print(f"list_fast_doc_ids cost: {t4 - t3} seconds")
        assert len(doc_ids) >= 1
        assert doc_id in doc_ids

        # 测试删除文档
        errs = KBX.remove_fast_docs(doc_ids=[doc_id], user_id=self._user_id)
        t5 = time.time()
        print(f"remove_fast_docs cost: {t5 - t4} seconds")
        assert len(errs) == 1
        assert errs[0].code == KBXError.Code.SUCCESS

        # 测试删除非法的doc_id
        errs = KBX.remove_fast_docs(doc_ids=['invalid_doc_id'], user_id=self._user_id)
        t6 = time.time()
        print(f"remove_fast_docs cost: {t6 - t5} seconds")
        assert len(errs) == 1
        # NOTE(@dingdong): 目前删除不存在的文档也不会返回失败
        assert errs[0].code == KBXError.Code.SUCCESS


if __name__ == '__main__':
    # 手动执行
    test_case = TestFastParser()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_fast_parser()
