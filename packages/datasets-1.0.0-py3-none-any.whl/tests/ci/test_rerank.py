import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

import pytest
from tests.base_test_case import BaseTestCase
from kbx.common.constants import DEFAULT_USER_ID, DEFAULT_TENANT_ID
from kbx.rerank.rerank_factory import get_rerank
from kbx.rerank.types import RerankConfig, RerankWeights
from kbx.common.types import Chunk, UserContext
from kbx.knowledge_base.types import QueryConfig, QueryResult


class TestRerank(BaseTestCase):
    # 测试WeightRerank run 方法
    @pytest.mark.mr_ci
    def test_weight_rerank_run(self):
        # 创建测试用的 QueryConfig 和 QueryResult 对象
        query_config = QueryConfig(text="测试查询", score_threshold=0.5, top_k=10)
        query_result1 = QueryResult(chunk=Chunk(chunk_id='1', text="文档 1 测试查询"), score=0.8)
        query_result2 = QueryResult(chunk=Chunk(chunk_id='2', text="文档 2 内容"), score=0.6)

        # 创建 WeightRerank 对象
        config = RerankConfig(name='WeightRerank', kwargs={'weights': RerankWeights()})
        weight_rerank = get_rerank(config=config)

        # 执行 run 方法
        rerank_query_results = weight_rerank.rerank(query_config, [query_result1, query_result2])

        # 断言结果数量
        assert len(rerank_query_results) <= query_config.top_k

        # 断言每个文档元素的分数
        for query_result in rerank_query_results:
            assert query_result.score >= query_config.score_threshold

        # 断言排序顺序
        assert rerank_query_results[0].score >= rerank_query_results[-1].score

    # 测试ModelRerank run 方法
    @pytest.mark.mr_ci
    def test_model_rerank_run(self):
        # 模拟查询配置和查询结果
        query_config = QueryConfig(text="查询文本", score_threshold=0.0, top_k=10)
        query_results = [
            QueryResult(chunk=Chunk(chunk_id='1', text="查询文本 1")),
            QueryResult(chunk=Chunk(chunk_id='2', text="查询文本")),
            QueryResult(chunk=Chunk(chunk_id='1', text="文本 1"))
        ]

        # 创建 ModelRerank 对象
        config = RerankConfig(name='ModelRerank', kwargs={'model': 'BAAI/bge-reranker-v2-m3'})
        config.user_ctx = UserContext(user_id=DEFAULT_USER_ID, tenant_id=DEFAULT_TENANT_ID)
        model_rerank = get_rerank(config)

        rerank_query_results = model_rerank.rerank(query_config, query_results)
        assert len(rerank_query_results) > 0
        assert len(rerank_query_results) <= query_config.top_k

        # 断言结果
        for query_result in rerank_query_results:
            assert query_result.score >= query_config.score_threshold
        # 断言排序顺序
        assert rerank_query_results[0].score >= rerank_query_results[-1].score


if __name__ == '__main__':
    # 手动执行
    test_case = TestRerank()
    test_case.setup_class()
    test_case.test_model_rerank_run()
    test_case.test_weight_rerank_run()
