import pytest
from kbx.common.types import Table


@pytest.mark.mr_ci
def test_table_serialization_from_html():
    """测试从 HTML 创建表格并序列化"""
    # 创建一个只有 html 格式的表格
    html_table = """
    <table>
        <caption>测试表格</caption>
        <tr>
            <th>姓名</th>
            <th>年龄</th>
        </tr>
        <tr>
            <td>张三</td>
            <td>20</td>
        </tr>
        <tr>
            <td>李四</td>
            <td>25</td>
        </tr>
    </table>
    """
    table = Table.from_html(html_table)
    table.has_header = True  # 明确设置 has_header

    # 测试内部序列化（不填充其他格式）
    internal_dict = table.model_dump(context={"fill_all_formats": False})
    assert internal_dict["html"] == html_table
    assert internal_dict["data_2d"] is None
    assert internal_dict["md"] is None

    # 测试外部序列化（填充所有格式）
    external_dict = table.model_dump(context={"fill_all_formats": True})
    assert external_dict["html"] == html_table
    assert external_dict["data_2d"] is not None
    assert external_dict["md"] is not None

    # 验证填充的数据格式正确
    assert len(external_dict["data_2d"]) == 3  # 表头 + 两行数据
    assert len(external_dict["data_2d"][0]) == 2  # 两列
    assert external_dict["data_2d"][0] == ["姓名", "年龄"]  # 表头
    assert external_dict["data_2d"][1] == ["张三", "20"]  # 第一行
    assert external_dict["data_2d"][2] == ["李四", "25"]  # 第二行


def test_table_serialization_from_2d_list():
    """测试从二维列表创建表格并序列化"""
    # 创建一个只有二维列表格式的表格
    data = [
        ["姓名", "年龄"],
        ["张三", "20"],
        ["李四", "25"]
    ]
    table = Table.from_2d_list(data, has_header=True, caption="测试表格")

    # 测试内部序列化（不填充其他格式）
    internal_dict = table.model_dump(context={"fill_all_formats": False})
    assert internal_dict["data_2d"] == data
    assert internal_dict["html"] is None
    assert internal_dict["md"] is None

    # 测试外部序列化（填充所有格式）
    external_dict = table.model_dump(context={"fill_all_formats": True})
    assert external_dict["data_2d"] == data
    assert external_dict["html"] is not None
    assert external_dict["md"] is not None

    # 验证填充的格式正确
    assert "<table>" in external_dict["html"]
    assert "|姓名|年龄|" in external_dict["md"]


def test_table_serialization_from_md():
    """测试从 Markdown 创建表格并序列化"""
    # 创建一个只有 md 格式的表格
    md_table = """|姓名|年龄|
|---|---|
|张三|20|
|李四|25|"""
    table = Table.from_md(md_table, caption="测试表格")

    # 测试内部序列化（不填充其他格式）
    internal_dict = table.model_dump(context={"fill_all_formats": False})
    assert internal_dict["md"] == md_table
    assert internal_dict["html"] is None
    assert internal_dict["data_2d"] is None

    # 测试外部序列化（填充所有格式）
    external_dict = table.model_dump(context={"fill_all_formats": True})
    assert external_dict["md"] == md_table
    assert external_dict["html"] is not None
    assert external_dict["data_2d"] is not None

    # 验证填充的格式正确
    assert "<table>" in external_dict["html"]
    assert len(external_dict["data_2d"]) == 4  # 表头 + 分隔行 + 两行数据
    assert external_dict["data_2d"][0] == ["姓名", "年龄"]  # 表头
    assert external_dict["data_2d"][1] == ["---", "---"]  # 分隔行
    assert external_dict["data_2d"][2] == ["张三", "20"]  # 数据行
    assert external_dict["data_2d"][3] == ["李四", "25"]  # 数据行


def test_table_deserialization():
    """测试表格反序列化"""
    # 准备测试数据 - 从2d_list格式反序列化
    data_2d = {
        "data_2d": [["姓名", "年龄"], ["张三", "20"], ["李四", "25"]],
        "has_header": True,
        "caption": "测试表格",
        "original_format": "2d_list"
    }

    # 测试从2d_list格式反序列化
    table_2d = Table.model_validate(data_2d)
    assert table_2d.data_2d == data_2d["data_2d"]
    assert table_2d.md is not None
    assert table_2d.html is not None
    assert table_2d.has_header == data_2d["has_header"]
    assert table_2d.caption == data_2d["caption"]
    assert table_2d.original_format == data_2d["original_format"]

    # 准备测试数据 - 从md格式反序列化
    data_md = {
        "md": "|姓名|年龄|\n|---|---|\n|张三|20|\n|李四|25|",
        "has_header": True,
        "caption": "测试表格",
        "original_format": "md"
    }

    # 测试从md格式反序列化
    table_md = Table.model_validate(data_md)
    assert table_md.md == data_md["md"]
    assert table_md.data_2d is not None
    assert table_md.html is not None
    assert table_md.has_header == data_md["has_header"]
    assert table_md.caption == data_md["caption"]
    assert table_md.original_format == data_md["original_format"]

    # 准备测试数据 - 从html格式反序列化
    data_html = {
        "html": (
            "<table><tr><th>姓名</th><th>年龄</th></tr>"
            "<tr><td>张三</td><td>20</td></tr>"
            "<tr><td>李四</td><td>25</td></tr></table>"
        ),
        "has_header": True,
        "caption": "测试表格",
        "original_format": "html"
    }

    # 测试从html格式反序列化
    table_html = Table.model_validate(data_html)
    assert table_html.html == data_html["html"]
    assert table_html.data_2d is not None
    assert table_html.md is not None
    assert table_html.has_header == data_html["has_header"]
    assert table_html.caption == data_html["caption"]
    assert table_html.original_format == data_html["original_format"]

    # 测试错误处理 - 缺少必要字段
    with pytest.raises(ValueError):
        Table.model_validate({})

    # 测试错误处理 - 无效的original_format
    with pytest.raises(ValueError):
        Table.model_validate({
            "data_2d": [["姓名", "年龄"]],
            "original_format": "invalid_format"
        })


def test_table_creation_validation():
    """测试表格实例创建时的验证"""
    # 测试至少需要一个格式
    with pytest.raises(ValueError, match="'original_format' is '2d_list', must set 'data_2d' field!"):
        Table()

    # 测试使用别名创建实例
    table = Table(data_2d=[["姓名", "年龄"], ["张三", "20"]], has_header=True)
    assert table.data_2d == [["姓名", "年龄"], ["张三", "20"]]
    assert table.has_header is True

    # 测试使用内部字段名创建实例
    table = Table(data_2d=[["姓名", "年龄"], ["张三", "20"]], has_header=True)
    assert table.data_2d == [["姓名", "年龄"], ["张三", "20"]]
    assert table.has_header is True


def test_table_serialization_behavior():
    """测试表格序列化行为"""
    # 创建表格实例
    table = Table.from_2d_list([["姓名", "年龄"], ["张三", "20"]], has_header=True)

    # 测试内部序列化（不填充其他格式）
    internal_dict = table.model_dump(context={"fill_all_formats": False})
    assert internal_dict["data_2d"] == [["姓名", "年龄"], ["张三", "20"]]
    assert internal_dict["md"] is None
    assert internal_dict["html"] is None

    # 测试外部序列化（填充所有格式）
    external_dict = table.model_dump(context={"fill_all_formats": True})
    assert external_dict["data_2d"] == [["姓名", "年龄"], ["张三", "20"]]
    assert external_dict["md"] is not None
    assert external_dict["html"] is not None

    # 测试使用内部字段名序列化
    internal_dict = table.model_dump(context={"fill_all_formats": False})
    assert internal_dict["data_2d"] == [["姓名", "年龄"], ["张三", "20"]]


def test_table_format_conversion():
    """测试表格格式转换"""
    # 从 data_2d 创建
    table = Table.from_2d_list([["姓名", "年龄"], ["张三", "20"]], has_header=True)

    # 验证所有格式都被正确填充
    assert table.data_2d == [["姓名", "年龄"], ["张三", "20"]]
    assert table.md is not None
    assert "|姓名|年龄|" in table.md
    assert table.html is not None
    assert "<table>" in table.html

    # 从 md 创建
    md_table = """|姓名|年龄|
|---|---|
|张三|20|"""
    table = Table.from_md(md_table)

    # 验证所有格式都被正确填充
    assert table.md == md_table
    assert table.data_2d is not None
    assert len(table.data_2d) == 3  # 表头 + 分隔行 + 数据行
    assert table.data_2d[0] == ["姓名", "年龄"]  # 表头
    assert table.data_2d[1] == ["---", "---"]  # 分隔行
    assert table.data_2d[2] == ["张三", "20"]  # 数据行
    assert table.html is not None
    assert "<table>" in table.html


if __name__ == "__main__":
    pytest.main([__file__])
