import os
import copy
import time
import pytest

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../..")
import sys

sys.path.insert(0, ROOT_DIR)
from tests.base_test_case import BaseTestCase
from kbx.common.logging import logger
from humanfriendly.text import random_string


kb_template = {
    "name": "test-kb-" + random_string(6),
    "description": "这是一个新的知识库",
    "doc_parse_config": {
        "autodetect_encoding": True,
        "save_external_data": False,
        "enable_layout_recognition": True,
        "image_strategy": {
            "type": "VLMTextEmbedding",
            "vision_model": "doubao-1.5-vision-pro"
        },
        "video_strategy": None,
        "audio_strategy": None,
    },
    "vector_keyword_config": {
        "index_strategy": "DefaultVectorKeywordIndex",
        "splitter_config": {
            "name": "RecursiveTextSplitter",
            "chunk_size": 1024,
            "delimiters": [
                "\n\n",
                "\n",
                " "
            ],
            "overlap_size": 0,
            "keep_delimiter": True,
        },
        "text_embedding_model": "doubao-embedding-large",
        "keyword_extractor": None,
        "max_keywords_per_chunk": 0
    },
}


def get_content_type(file_path):
    ext = os.path.splitext(file_path)[1].lower()
    content_types = {
        '.txt': 'text/plain',
        '.md': 'text/markdown',
        '.html': 'text/html',
        '.pdf': 'application/pdf',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.doc': 'application/msword',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.xls': 'application/vnd.ms-excel',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.ppt': 'application/vnd.ms-powerpoint',
        '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    }
    return content_types.get(ext, 'application/octet-stream')


class TestDocsAPI(BaseTestCase):
    @pytest.fixture(scope="class", autouse=True)
    def setup_and_teardown_class(self, mock_data):
        TestDocsAPI.headers = mock_data.headers
        TestDocsAPI.client = mock_data.client
        # 注册测试模型
        request_data = {
            "configs": [
                {
                    "name": "doubao-embedding-large",
                    "type": "text_embedding",
                    "backend": "volcengine",
                    "api_key": "8b52eb53-cc4f-44b4-a59b-73e179fc9e3a",
                    "base_url": "https://ark.cn-beijing.volces.com/api/v3",
                    "endpoint": "ep-20241108104331-4jfp9",
                    "max_context_len": 4096,
                    "max_tokens": 4096,
                    "rpm": 1000
                },
                {
                    "name": "doubao-1.5-pro-256k",
                    "type": "llm",
                    "backend": "volcengine",
                    "api_key": "8b52eb53-cc4f-44b4-a59b-73e179fc9e3a",
                    "base_url": "https://ark.cn-beijing.volces.com/api/v3",
                    "endpoint": "ep-20250122192253-khdzh",
                    "max_context_len": 4096,
                    "max_tokens": 4096,
                    "rpm": 1000
                },
                {
                    "name": "qwen-max",
                    "type": "llm",
                    "backend": "tongyi",
                    "api_key": "sk-05ee5d096cb34027af2d02593f102059",
                    "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
                    "max_context_len": 4096,
                    "max_tokens": 4096,
                    "rpm": 1000
                }
            ],
            "overwrite": True
        }

        response = self.client.post("/api/v1/register_ai_models", json=request_data, headers=self.headers)

        assert response.status_code == 200

        # 使用接口创建测试知识库
        req = copy.deepcopy(kb_template)

        response = self.client.post("/api/v1/create_kb", json=req, headers=self.headers)

        assert response.status_code == 200
        logger.info(f"test_create_kb: {response.json()}")
        assert response.json()['kb_id']
        TestDocsAPI.test_kb_id = response.json()['kb_id']
        logger.info(TestDocsAPI.test_kb_id)

        yield
        # 删除测试知识库
        response = self.client.post(f"/api/v1/remove_kb?kb_id={TestDocsAPI.test_kb_id}", headers=self.headers)
        assert response.status_code == 200

    @pytest.mark.mr_ci
    def test_kbx_health(self):
        response = self.client.get("/api/v1/health", headers=self.headers)
        assert response.status_code == 200
        assert response.json()['status'] == "healthy"

    @pytest.mark.skip
    def test_insert_docs(self):
        # 准备多个测试文件
        test_files = [
            os.path.join(self.test_data_dir, '中国平安.txt'),
            os.path.join(self.test_data_dir, '平安银行.txt'),
            os.path.join(self.test_data_dir, 'parser_data/test.md'),
            os.path.join(self.test_data_dir, 'parser_data/kbx_arch.jpg'),
        ]

        # 使用multipart/form-data格式上传多个文件，读取文件内容
        files = []
        for file_path in test_files:
            # 如果测试文件不存在，则跳过测试
            if not os.path.exists(file_path):
                pytest.skip(f"测试文件未找到: {file_path}")
            with open(file_path, 'rb') as f:
                content = f.read()
            files.append(
                (
                    'files',
                    (
                        os.path.relpath(file_path, self.test_data_dir),
                        content,
                        get_content_type(file_path)
                    )
                )
            )

        # 设置InsertDocRequest参数
        request_data = {
            "save_dir": "test_docs",
            "doc_patterns": ["*.txt", "*.md"],
            "only_upload": False,
            "keep_rel_path": True
        }

        response = self.client.post(
            f"/api/v1/docs/{TestDocsAPI.test_kb_id}",
            headers=self.headers,
            files=files,
            data=request_data
        )

        logger.info(f"test_insert_docs: {response.json()}")
        assert response.status_code == 200
        assert response.json()
        assert len(response.json()) > 0

    @pytest.mark.mr_ci
    @pytest.mark.anyio
    @pytest.mark.order(1)
    async def test_insert_docs_async(self):
        # 准备多个测试文件
        test_files = [
            os.path.join(self.test_data_dir, '中国平安.txt'),
            os.path.join(self.test_data_dir, '平安银行.txt'),
            os.path.join(self.test_data_dir, 'parser_data/test.md'),
            os.path.join(self.test_data_dir, 'parser_data/kbx_arch.jpg'),
        ]

        # 使用multipart/form-data格式上传多个文件，读取文件内容
        files = []
        for file_path in test_files:
            if not os.path.exists(file_path):
                pytest.skip(f"测试文件未找到: {file_path}")
            with open(file_path, 'rb') as f:
                content = f.read()
            files.append(
                (
                    'files',
                    (
                        os.path.relpath(file_path, self.test_data_dir),
                        content,
                        get_content_type(file_path)
                    )
                )
            )

        # 设置InsertDocRequest参数
        request_data = {
            "save_dir": "test_docs",
            "doc_patterns": ["*.txt", "*.md"],
            "only_upload": False,
            "keep_rel_path": True
        }

        logger.info("test_insert_docs_async")
        response = self.client.post(
            f"/api/v1/docs/{TestDocsAPI.test_kb_id}/async",
            headers=self.headers,
            files=files,
            data=request_data
        )
        logger.info(f"test_insert_docs_async: {response.json()}")
        assert response.status_code == 200
        assert response.json()
        assert len(response.json()) > 0

    @pytest.mark.mr_ci
    @pytest.mark.order(2)
    def test_list_docs_info(self):
        # 轮询检查文档状态，最多尝试10次
        max_retries = 10
        retries = 0
        while True:
            response = self.client.get(
                "/api/v1/docs_info",
                params={
                    "kb_id": TestDocsAPI.test_kb_id,
                    "doc_type_filter": ["NORMAL"]  # 只获取普通文档
                },
                headers=self.headers
            )
            assert response.status_code == 200
            docs_info = response.json()
            logger.info(f"list_docs_info: {docs_info}")

            # 如果文档列表为空，等待1秒后重试
            if not docs_info['data']:
                logger.info("文档信息尚未在列表中")
                time.sleep(1)  # 等待1秒后再次请求
                retries += 1
                if retries >= max_retries:
                    logger.warning(f"Reached maximum polling attempts ({max_retries}), exiting loop")
                    break
                continue

            # 检查所有文档的状态
            all_complete = True
            for doc_info in docs_info['data']:
                doc_status = doc_info['doc_status']
                doc_type = doc_info['doc_type']
                assert doc_type == "NORMAL", f"Expected doc_type: NORMAL, but got: {doc_type}, doc_info: {doc_info}"
                logger.info(f"轮询获取文档信息中的doc_status: {doc_status}")
                logger.info(f"轮询获取文档信息中的doc_type: {doc_type}")

                if doc_status == "INDEX_SUCCESS":
                    continue
                elif doc_status == "UPLOAD_SUCCESS":
                    if doc_type == "RESOURCE":
                        continue
                elif doc_status in ["UPLOAD_FAILED", "PARSE_FAILED", "INDEX_FAILED"]:
                    logger.error(f"文档解析失败: {doc_info}")
                    raise Exception(f"文档解析失败: {doc_info}")
                else:
                    all_complete = False
                    logger.info(f"文档解析中, 当前状态: {doc_status}")
                    break

            # 如果所有文档都完成，退出循环
            if all_complete:
                break

            # 如果还有文档在处理中，等待1秒后重试
            time.sleep(1)
            retries += 1
            if retries >= max_retries:
                logger.warning(f"Reached maximum polling attempts ({max_retries}), exiting loop")
                break

        assert response.status_code == 200
        assert response.json()
        assert len(response.json()) > 0
        logger.info(f'list_docs_info: {response.json()}')
        assert len(response.json()['data']) >= 2  # 确保至少有两个文档
        TestDocsAPI.test_doc_ids = [doc['doc_id'] for doc in response.json()['data'] if doc['doc_type'] == 'NORMAL']

    @pytest.mark.mr_ci
    @pytest.mark.order(3)
    def test_get_doc_info(self):
        for doc_id in TestDocsAPI.test_doc_ids:
            response = self.client.get(f"/api/v1/doc_info?kb_id={TestDocsAPI.test_kb_id}&doc_id={doc_id}",
                                       headers=self.headers)

            assert response.status_code == 200
            logger.info(response.json())
            # 轮询获取文档信息中的doc_status,直到状态为INDEX_SUCCESS
            doc_status = response.json()['doc_status']
            while doc_status != "INDEX_SUCCESS":
                response = self.client.get(f"/api/v1/doc_info?kb_id={TestDocsAPI.test_kb_id}&doc_id={doc_id}",
                                           headers=self.headers)
                doc_info = response.json()
                doc_status = doc_info['doc_status']
                doc_type = doc_info['doc_type']
                logger.info(f"轮询获取文档信息中的doc_status: {doc_status}")
                logger.info(f"轮询获取文档信息中的doc_type: {doc_type}")
                if doc_status == "INDEX_SUCCESS":
                    break
                elif doc_status == "UPLOAD_SUCCESS":
                    if doc_type == "RESOURCE":
                        break
                # UPLOAD_FAILED or PARSE_FAILED or INDEX_FAILED
                elif doc_status == "UPLOAD_FAILED" or doc_status == "PARSE_FAILED" or doc_status == "INDEX_FAILED":
                    logger.error(f"文档解析失败: {response.json()}")
                    raise Exception(f"文档解析失败: {response.json()}")
                else:
                    logger.info(f"文档解析中, 当前状态: {doc_status}")
                    time.sleep(5)  # 等待5秒后再次请求
            assert response.status_code == 200

    @pytest.mark.mr_ci
    @pytest.mark.order(4)
    def test_get_doc_data(self):
        for doc_id in TestDocsAPI.test_doc_ids:
            response = self.client.get(
                "/api/v1/doc_data",
                params={
                    "kb_id": TestDocsAPI.test_kb_id,
                    "doc_id": doc_id
                },
                headers=self.headers
            )

            assert response.status_code == 200
            assert response.json()['doc_id'] == doc_id
            assert response.json()['doc_elements'] is not None

    @pytest.mark.mr_ci
    @pytest.mark.order(5)
    def test_list_chunks(self):
        response = self.client.get(
            "/api/v1/list_chunks",
            params={
                "kb_id": TestDocsAPI.test_kb_id,
                "doc_id": TestDocsAPI.test_doc_ids[0]
            },
            headers=self.headers
        )

        assert response.status_code == 200
        assert response.json()
        assert len(response.json()) > 0

    @pytest.mark.mr_ci
    @pytest.mark.order(6)
    def test_insert_docs_folder(self):
        response = self.client.post(
            "/api/v1/insert_docs_folder",
            headers=self.headers,
            json={
                "folder_path": os.path.join(ROOT_DIR, self.test_data_dir),
                "recursive": True,
                "save_dir": "test_docs_folder",
                "include_patterns": ["*.txt"],
                "kb_id": TestDocsAPI.test_kb_id
            }
        )

        assert response.status_code == 200
        assert response.json()
        assert len(response.json()) > 0

    @pytest.mark.mr_ci
    @pytest.mark.order(7)
    def test_remove_docs(self):
        response = self.client.post(
            "/api/v1/remove_docs",
            params={
                "kb_id": TestDocsAPI.test_kb_id,
                "doc_ids": TestDocsAPI.test_doc_ids,
            },
            headers=self.headers,
        )

        assert response.status_code == 200
        assert response.json()
        assert len(response.json()) > 0
