import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

import pytest
from typing import cast
from tests.base_test_case import BaseTestCase
from kbx.common.types import AudioEmbeddingStrategy, DocData, ImageEmbeddingStrategy, UserContext, DocElementType
from kbx.common.utils import generate_new_id, inject_user_ctx, toc_tree_to_string
from kbx.common.constants import DEFAULT_USER_ID, DEFAULT_TENANT_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, VectorKeywordIndexConfig
from kbx.parser.parser_factory import get_parser
from kbx.parser.types import AudioStrategyConfig, DocParseConfig, ImageStrategyConfig, CodeStrategyConfig
from kbx.agent.agent_factory import get_agent
from kbx.agent.types import TOCAgentConfig
from kbx.agent.toc.base_toc_agent import BaseTOCAgent
from kbx.common.toc_builder import TOCBuilder


class TestTOCAgent(BaseTestCase):
    def setup_method(self):
        self._kb_name = "文档测试"
        self._doc_parser_config = DocParseConfig(
            audio_strategy=AudioStrategyConfig(type=AudioEmbeddingStrategy.SPEECH2TEXT_TEXT_EMBEDDING,
                                               split_mode='size',
                                               voice_model='FunAudioLLM/SenseVoiceSmall',
                                               refinement_model='Qwen/Qwen2.5-7B-Instruct'),
            image_strategy=ImageStrategyConfig(type=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,
                                               vision_model='doubao-1.5-vision-pro-32k'),
            code_strategy=CodeStrategyConfig(
                code_summarizer='doubao-1.5-pro-32k'
            )
        )
        self.kb_config = KBCreationConfig(
            name=self._kb_name,
            description="这是一个文档测试知识库",
            is_external_datastore=False,
            doc_parse_config=self._doc_parser_config,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="BAAI/bge-m3",
            ),
        )
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=self.kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass

        # 尝试创建
        KBX.create_new_kb(self.kb_config, user_id=DEFAULT_USER_ID)

        # 创建TOC Agent
        self.toc_agent_config = TOCAgentConfig(
            agent_name='IterativeTOCAgent',
            llm_model='volcengine-deepseek-v3',
            # llm_model='volcengine-deepseek-r1',
            # llm_model='doubao-1.5-thinking-pro',
            max_iter=3,
            token_counter=self.kb_config.token_counter,
        )
        inject_user_ctx(
            self.toc_agent_config,
            user_ctx=UserContext(
                user_id=DEFAULT_USER_ID,
                tenant_id=DEFAULT_TENANT_ID,
            ),
            recursive=True,
        )
        self.toc_agent = cast(BaseTOCAgent, get_agent(self.toc_agent_config))
        assert self.toc_agent is not None
        assert isinstance(self.toc_agent, BaseTOCAgent)

    def _modify_title_to_text(self, doc_data: DocData) -> DocData:
        """将doc_data中的所有标题指令修改为文本指令"""
        for doc_element in doc_data.doc_elements:
            if doc_element.type == DocElementType.TITLE:
                doc_element.type = DocElementType.TEXT
                doc_element.meta_data.pop('title_level')
        return doc_data

    @pytest.mark.mr_ci
    def test_toc_agent_without_titled_doc(self):
        parser = get_parser("MarkdownItPyParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/KBX_README.md")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0

        # 故意把doc_data中的所有标题指令修改为正文段落，模拟parser没有正常解析标题格式的情况
        doc_data = self._modify_title_to_text(doc_data)

        '''
        for i, title_cmd in enumerate(self.toc_agent.generate_title_cmds(doc_data=doc_data)):
            assert isinstance(title_cmd, TitleCmd)
        '''

        # 使用TOCBuilder构建TOC树
        toc_builder = TOCBuilder(config=self._doc_parser_config)

        # 先使用传统模式构建，预期是无法获得有效的标题目录树
        doc_data = toc_builder.build_toc(doc_data)
        assert isinstance(doc_data, DocData)
        # assert len(doc_data.doc_toc.children) == 0
        print('-------------------- TOC TREE (传统模式) ----------------------')
        print(toc_tree_to_string(doc_data.doc_toc))
        print('--------------------------------')

        # 然后使用AI模式构建，预期可以获得有效的标题目录树
        doc_data = toc_builder.build_toc_by_ai(doc_data=doc_data, agent_config=self.toc_agent_config)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        assert len(doc_data.doc_toc.children) > 0
        print('-------------------- TOC TREE (AI模式) ----------------------')
        print(toc_tree_to_string(doc_data.doc_toc))
        print('--------------------------------')


if __name__ == "__main__":
    # 手动执行
    test_case = TestTOCAgent()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_toc_agent_without_titled_doc()
