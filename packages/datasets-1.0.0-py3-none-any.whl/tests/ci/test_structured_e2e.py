import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import pytest
from tests.base_test_case import BaseTestCase
from kbx.common.types import KBXError
from kbx.common.constants import DEFAULT_USER_ID
from kbx.common.utils import get_pydantic_config_changes
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, \
    QueryConfig, StructuredIndexConfig, DocStatus, QueryResults


class TestStructuredIndexE2E(BaseTestCase):
    def setup_method(self):
        self._kb_name = "一线城市近几年GDP经济数据"
        self._kb_description = "目前主要包括北京、上海、广州、深圳的GDP经济数据"

    @pytest.mark.daily_ci
    def test_std_case(self):
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            structured_config=StructuredIndexConfig(
                index_strategy="DefaultStructuredIndex",
                llm_model="doubao-1.5-pro-32k",
                sql_gen_llm_model="doubao-1.5-pro-32k",
            ),
        )
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

        results = kb.insert_docs(
            file_list=[
                os.path.join(self.test_data_dir, '北京GDP数据.csv'),
                os.path.join(self.test_data_dir, '上海GDP数据.csv'),
                os.path.join(self.test_data_dir, '广州GDP数据.csv'),
                os.path.join(self.test_data_dir, '深圳GDP数据.csv'),
            ]
        )
        if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
            raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

        # 任取其中一个文档的信息，检查是否可以正常获取
        doc_info = results[0]
        assert doc_info.doc_status == DocStatus.INDEX_SUCCESS
        doc_info2 = kb.get_doc_info(doc_id=doc_info.doc_id)
        assert doc_info == doc_info2, f'Expect same doc_info, given\n{doc_info!r}\nand\n{doc_info2!r}'
        doc_data = kb.get_doc_data(doc_id=doc_info.doc_id)
        assert doc_data is not None, f'Expect doc_data is not None, given {doc_data!r}'

        # 使用知识库直接查询
        query = QueryConfig(
            text="上海2024年哪个月的GDP最高，数值是多少？",
            top_k=5,
            score_threshold=0.0,
        )
        query_results = kb.retrieve(query=query)
        assert isinstance(query_results, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_results)}"
        assert isinstance(query_results.results, list), \
            f"Retrieval results should be a list, given {type(query_results.results)}"
        assert len(query_results) > 0, "Failed to get query result"

        # 使用KBX在顶层进行查询
        query_results = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
        assert isinstance(query_results, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_results)}"
        assert isinstance(query_results.results, list), \
            f"Retrieval results should be a list, given {type(query_results.results)}"
        assert len(query_results) > 0, "Failed to get query result"

        print(f"query = {query.text}")
        for k, qr in enumerate(query_results):
            print(f'--------------- # {k} ---------------')
            print(f"SQL: {qr.structured_result.sql}")
            print(f"Result: {qr.try_get_content_as_str()}")
            print(f"Score: {qr.score}")

    @pytest.mark.mr_ci
    def test_modify_config_case(self):
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            structured_config=StructuredIndexConfig(
                index_strategy="DefaultStructuredIndex",
                llm_model="doubao-1.5-pro-32k",
                sql_gen_llm_model="doubao-1.5-pro-32k",
            ),
        )
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

        kb_config_new_1 = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            structured_config=StructuredIndexConfig(
                index_strategy="DefaultStructuredIndex",
                llm_model="doubao-1.5-pro-256k",
                sql_gen_llm_model="doubao-1.5-pro-256k",
                tables=[],
                sql={},
                max_related_tables=10,
                generate_iters=10,

            ),
        )
        config_diff = get_pydantic_config_changes(kb.kb_config, kb_config_new_1, False)
        assert "structured_config" in config_diff
        kb_config_new_1_modify_res = kb.modify_kb_config(kb_config_new_1)
        assert kb_config_new_1_modify_res.code == KBXError.Code.SUCCESS
        assert kb.kb_config.structured_config.llm_model == "doubao-1.5-pro-256k"
        assert kb.kb_config.structured_config.sql_gen_llm_model == "doubao-1.5-pro-256k"
        assert kb.kb_config.structured_config.tables == []
        assert kb.kb_config.structured_config.sql == {}
        assert kb.kb_config.structured_config.max_related_tables == 10
        assert kb.kb_config.structured_config.generate_iters == 10

        kb_config_new_2 = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            structured_config=StructuredIndexConfig(
                index_strategy="DefaultStructuredIndex",
                llm_model="doubao-1.5-pro-256k",
                sql_gen_llm_model="doubao-1.5-pro-256k",
                tables=[],
                sql={},
                max_related_tables=-1,
                generate_iters=0,

            ),
        )
        config_diff = get_pydantic_config_changes(kb.kb_config, kb_config_new_2, False)
        assert "structured_config" in config_diff
        kb_config_new_2_modify_res = kb.modify_kb_config(kb_config_new_2)
        assert kb_config_new_2_modify_res.code != KBXError.Code.SUCCESS
        assert "max_related_tables" in kb_config_new_2_modify_res.msg
        assert "generate_iters" in kb_config_new_2_modify_res.msg


if __name__ == "__main__":
    # 手动执行
    test_case = TestStructuredIndexE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_std_case()
    test_case.test_modify_config_case()
