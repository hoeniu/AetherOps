import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

import pytest

from tests.base_test_case import BaseTestCase
from kbx.common.types import AudioEmbeddingStrategy, DocData, ImageEmbeddingStrategy
from kbx.common.utils import generate_new_id
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, VectorKeywordIndexConfig
from kbx.parser.parser_factory import get_parser
from kbx.parser.types import AudioStrategyConfig, DocParseConfig, ImageStrategyConfig, \
    CodeStrategyConfig, PdfOcrStrategyConfig
# from kbx.common.utils import doc_element_to_markdown


class TestParser(BaseTestCase):
    def setup_method(self):
        self._kb_name = "文档测试"
        self._doc_parser_config = DocParseConfig(
            audio_strategy=AudioStrategyConfig(type=AudioEmbeddingStrategy.SPEECH2TEXT_TEXT_EMBEDDING,
                                               split_mode='size',
                                               voice_model='FunAudioLLM/SenseVoiceSmall',
                                               refinement_model='Qwen/Qwen2.5-7B-Instruct'),
            image_strategy=ImageStrategyConfig(type=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,
                                               vision_model='doubao-1.5-vision-pro-32k'),
            code_strategy=CodeStrategyConfig(
                code_summarizer='doubao-1.5-pro-32k'
            ),
            pdf_ocr_strategy=PdfOcrStrategyConfig(
                parser_type='VLMPdfParser',
                vlm_model='Qwen2.5-VL-72B',
                use_consecutive_pages=False
            )
        )
        self.kb_config = KBCreationConfig(
            name=self._kb_name,
            description="这是一个文档测试知识库",
            is_external_datastore=False,
            doc_parse_config=self._doc_parser_config,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="BAAI/bge-m3",
            ),
        )
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=self.kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass

        # 尝试创建
        KBX.create_new_kb(self.kb_config, user_id=DEFAULT_USER_ID)

    @pytest.mark.mr_ci
    def test_constructor(self):
        config = DocParseConfig()
        parser = get_parser("DefaultTxtParser", config)
        assert parser._config.save_external_data is False

    # Test file_extensions method
    @pytest.mark.mr_ci
    def test_file_extensions(self):
        parser = get_parser("DefaultDocxParser", self._doc_parser_config)
        assert parser.file_extensions() == [".docx"]

        parser = get_parser("DefaultTxtParser", self._doc_parser_config)
        assert parser.file_extensions() == [".txt"]

        parser = get_parser("DefaultMarkdownParser", self._doc_parser_config)
        assert parser.file_extensions() == [".md", ".markdown"]

        parser = get_parser("DefaultPdfParser", self._doc_parser_config)
        assert parser.file_extensions() == [".pdf"]

        parser = get_parser("DefaultCsvParser", self._doc_parser_config)
        assert parser.file_extensions() == [".csv"]

        parser = get_parser("DefaultExcelParser", self._doc_parser_config)
        assert parser.file_extensions() == [".xlsx", ".xlsm", ".xls"]

        parser = get_parser("DefaultPptxParser", self._doc_parser_config)
        assert parser.file_extensions() == [".pptx"]

    # Test parse method with valid file
    @pytest.mark.mr_ci
    def test_parse_txt_valid_file(self):
        parser = get_parser("DefaultTxtParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test.txt")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        '''
        with open('data/txt_log.txt', 'w') as f:
            f.write(str(doc_data))
        '''

    @pytest.mark.mr_ci
    def test_parse_md_valid_file(self):
        parser = get_parser("DefaultMarkdownParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test.md")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        assert doc_data.doc_elements
        '''
        with open('data/md_log.txt', 'w') as f:
            f.write(str(doc_data))
        '''

    @pytest.mark.mr_ci
    def test_parse_md_valid_file2(self):
        parser = get_parser("MarkdownItPyParser", self._doc_parser_config)
        # file_path = '/media/lhy/Data/Data/RAG/思谋资料/SMP.md'
        file_path = os.path.join(self.test_data_dir, "parser_data/test2.md")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0

        # 测试line_range
        for doc_element in doc_data.doc_elements:
            # 确保每个doc_element都有line_range
            assert 'line_range' in doc_element.meta_data, f"doc_element {doc_element.doc_element_id} missing line_range"

        '''
        with open('data/md_log2.txt', 'w') as f:
            for doc_element in doc_data.doc_elements:
                f.write('============================================================\n')
                f.write(str(doc_element) + '\n')
                f.write(doc_element_to_markdown(doc_element=doc_element) + '\n')
        '''

    @pytest.mark.mr_ci
    def test_parse_docx_valid_file(self):
        parser = get_parser("DefaultDocxParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test.docx")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        '''
        with open(os.path.join(self.test_data_dir, 'parser_data/docx_log.txt'), 'w') as f:
            f.write(str(doc_data))
        '''

    @pytest.mark.mr_ci
    def test_parse_excel_valid_file(self):
        parser = get_parser("DefaultExcelParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test1.xlsx")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        '''
        with open('data/xlsx_log.txt', 'w') as f:
            f.write(str(doc_data))
        '''

        file_path = os.path.join(self.test_data_dir, "parser_data/test.xls")
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        '''
        with open('data/xls_log.txt', 'w') as f:
            f.write(str(doc_data))
        '''

    @pytest.mark.mr_ci
    def test_parse_csv_valid_file(self):
        parser = get_parser("DefaultCsvParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test.csv")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        '''
        with open('data/csv_log.txt', 'w') as f:
            f.write(str(doc_data))
        '''

    @pytest.mark.mr_ci
    def test_parse_pdf_valid_file(self):
        parser = get_parser("DefaultPdfParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test1.pdf")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        '''
        with open('data/pdf_log.txt', 'w') as f:
            f.write(str(doc_data))
        '''

    @pytest.mark.mr_ci
    def test_parse_pptx_valid_file(self):
        parser = get_parser("DefaultPptxParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test.pptx")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        '''
        with open('data/pptx_log.txt', 'w') as f:
            f.write(str(doc_data))
        '''

    # Test parse method with invalid file
    @pytest.mark.mr_ci
    def test_parse_invalid_file(self):
        config = DocParseConfig()
        parser = get_parser("DefaultTxtParser", config)
        file_path = os.path.join(self.test_data_dir, "parser_data/file-does-not-exist.txt")
        doc_id = generate_new_id()
        with pytest.raises(Exception):
            parser.parse(file_path, doc_id)

    # Test validate_file method with valid file
    @pytest.mark.mr_ci
    def test_validate_file_valid(self):
        parser = get_parser("DefaultTxtParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test.txt")
        parser.validate_file(file_path)

    # Test validate_file method with invalid file
    @pytest.mark.mr_ci
    def test_validate_file_invalid(self):
        file_path = os.path.join(self.test_data_dir, "parser_data/file-does-not-exist.txt")
        parser = get_parser("DefaultTxtParser", self._doc_parser_config)
        with pytest.raises(Exception):
            parser.validate_file(file_path)

    # Test parse method with valid file
    @pytest.mark.mr_ci
    def test_parse_html_valid_file(self):
        parser = get_parser("DefaultHTMLParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test1.html")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0

    @pytest.mark.mr_ci
    def test_parse_vlm_pdf_valid_file(self):
        parser = get_parser("VLMPdfParser", self._doc_parser_config)
        file_path = os.path.join(self.test_data_dir, "parser_data/test1.pdf")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        '''
        with open('data/pdf_log.txt', 'w') as f:
            f.write(str(doc_data))
        '''


if __name__ == '__main__':
    # 手动执行
    test_case = TestParser()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_parse_md_valid_file2()
    test_case.test_constructor()
    test_case.test_file_extensions()
    test_case.test_parse_txt_valid_file()
    test_case.test_parse_md_valid_file()
    test_case.test_parse_docx_valid_file()
    test_case.test_parse_excel_valid_file()
    test_case.test_parse_csv_valid_file()
    test_case.test_parse_pdf_valid_file()
    test_case.test_parse_pptx_valid_file()
    test_case.test_parse_invalid_file()
    test_case.test_validate_file_valid()
    test_case.test_validate_file_invalid()
    test_case.test_parse_html_valid_file()
    test_case.test_parse_vlm_pdf_valid_file()
