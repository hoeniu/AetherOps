import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import pytest
from tests.base_test_case import BaseTestCase
from kbx.common.types import KBXError
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, DeepThinkConfig, \
    QueryConfig, DynamicDocIndexConfig, DocStatus
from kbx.knowledge_base.types import QueryResults
from kbx.ai_model.types import AIModelBundle, AIModelType


class TestDynamicDocIndexE2E(BaseTestCase):
    def setup_method(self):
        self._kb_name = "【粗粒度文件索引】一线城市近几年GDP经济数据"
        self._kb_description = "目前主要包括北京、上海、广州、深圳的GDP经济数据"
        self._ai_model_bundle = AIModelBundle(
            bundles={
                AIModelType.LLM: 'volcengine-deepseek-v3',
            }
        )

    @pytest.mark.mr_ci
    def test_std_case_default_dynamic_doc_index(self):
        self._test_std_case(index_strategy='DefaultDynamicDocIndex')

    @pytest.mark.daily_ci
    def test_toc_docs_default_dynamic_doc_index(self):
        self._test_toc_docs(index_strategy='DefaultDynamicDocIndex')

    @pytest.mark.mr_ci
    def test_std_case_agentic_dynamic_doc_index(self):
        self._test_std_case(index_strategy='AgenticDynamicDocIndex')

    @pytest.mark.daily_ci
    def test_toc_docs_agentic_dynamic_doc_index(self):
        self._test_toc_docs(index_strategy='AgenticDynamicDocIndex')

    def _test_std_case(self, index_strategy: str):
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            dynamic_doc_config=DynamicDocIndexConfig(
                index_strategy=index_strategy,
            ),
            ai_model_bundle=self._ai_model_bundle,
        )
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

        '''
        # reindex
        doc_id_errors = kb.reindex(doc_info.doc_id, reparse=True)
        assert len(doc_id_errors) == 1, f'Expect len(doc_id_errors) == 1, given {len(doc_id_errors)}: {doc_id_errors!r}'
        assert doc_info.doc_id in doc_id_errors
        '''

        results = kb.insert_docs(
            file_list=[
                os.path.join(self.test_data_dir, '北京GDP数据.csv'),
                os.path.join(self.test_data_dir, '上海GDP数据.csv'),
                os.path.join(self.test_data_dir, '广州GDP数据.csv'),
                os.path.join(self.test_data_dir, '深圳GDP数据.csv'),
            ]
        )
        if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
            raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

        # 任取其中一个文档的信息，检查是否可以正常获取
        doc_info = results[0]
        assert doc_info.doc_status == DocStatus.INDEX_SUCCESS
        doc_info2 = kb.get_doc_info(doc_id=doc_info.doc_id)
        assert doc_info == doc_info2, f'Expect same doc_info, given\n{doc_info!r}\nand\n{doc_info2!r}'
        doc_data = kb.get_doc_data(doc_id=doc_info.doc_id)
        assert doc_data is not None, f'Expect doc_data is not None, given {doc_data!r}'

        '''
        # reindex_all
        doc_id_errors2 = kb.reindex_all(reparse=True)
        assert len(doc_id_errors2) == 1
        assert doc_id_errors2 == doc_id_errors, \
            f'Expect same doc_id_errors, given\n{doc_id_errors!r}\nand\n{doc_id_errors2!r}'
        '''

        # 使用知识库直接查询
        query = QueryConfig(
            text="上海2023年哪个月的GDP最高，数值是多少？",
            top_k=5,
            score_threshold=0.0,
            deep_think=DeepThinkConfig(
                llm_model="doubao-1.5-pro-256k",
            ),
        )
        query_results = kb.retrieve(query=query)
        assert isinstance(query_results, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_results)}"
        assert isinstance(query_results.results, list), \
            f"Retrieval results should be a list, given {type(query_results.results)}"
        if len(query_results) == 0:
            print("[ERROR] Failed to get query result")
        else:
            assert query_results[0].meta_data.get('doc_name') == '上海GDP数据.csv'

        # 使用KBX在顶层进行查询
        query_results = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
        self._print_query_results(query_results, query=query)
        assert isinstance(query_results, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_results)}"
        assert isinstance(query_results.results, list), \
            f"Retrieval results should be a list, given {type(query_results.results)}"
        # TODO: 容易在CI运行时失败，玄学问题，暂时跳过
        if len(query_results) == 0:
            print("[ERROR] Failed to get query result")
        else:
            assert query_results[0].meta_data.get('doc_name') == '上海GDP数据.csv'

    def _test_toc_docs(self, index_strategy: str):
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            dynamic_doc_config=DynamicDocIndexConfig(index_strategy=index_strategy),
        )
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

        results = kb.insert_docs(
            file_list=[
                os.path.join(self.test_data_dir, '北京GDP数据.csv'),
                os.path.join(self.test_data_dir, '上海GDP数据.csv'),
                os.path.join(self.test_data_dir, '广州GDP数据.csv'),
                os.path.join(self.test_data_dir, '深圳GDP数据.csv'),
                os.path.join(self.test_data_dir, 'parser_data/KBX_README.md'),
            ]
        )
        if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
            raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

        # 使用知识库直接查询
        query = QueryConfig(
            text="如何使用KBX命令行工具来创建一个知识库？",
            top_k=5,
            score_threshold=0.0,
            deep_think=DeepThinkConfig(
                llm_model="doubao-1.5-pro-256k",
            ),
            ai_model_bundle=self._ai_model_bundle,
        )
        query_results = kb.retrieve(query=query)
        self._print_query_results(query_results, query=query)
        assert isinstance(query_results, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_results)}"
        assert isinstance(query_results.results, list), \
            f"Retrieval results should be a list, given {type(query_results.results)}"
        # TODO: 容易在CI运行时失败，玄学问题，暂时跳过
        if len(query_results.results) == 0:
            print("[ERROR] Failed to get query result")

    def _print_query_results(self, query_results: QueryResults, query: QueryConfig):
        print(f"query = {query.text}")
        for k, qr in enumerate(query_results):
            print(f'--------------- # {k} ---------------')
            print(f"Text chunk:\n{qr.chunk.text}")


if __name__ == "__main__":
    # 手动执行
    test_case = TestDynamicDocIndexE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_std_case_default_dynamic_doc_index()
    test_case.test_toc_docs_default_dynamic_doc_index()
    test_case.test_std_case_agentic_dynamic_doc_index()
    test_case.test_toc_docs_agentic_dynamic_doc_index()
