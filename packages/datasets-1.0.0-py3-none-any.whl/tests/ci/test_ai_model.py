import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
from typing import Iterator, cast
from pydantic import ValidationError
import pytest
from tests.base_test_case import BaseTestCase
from kbx.kbx import KBX
from kbx.common.logging import logger
from kbx.ai_model.types import AIModelType, AIModelBundle, ChatResponse, ChatResponseChunk
from kbx.ai_model.openai import OpenAIModelConfig
from kbx.ai_model.tongyi import TongyiAIModelConfig
from kbx.ai_model.volcengine import VolcengineAIModelConfig


class TestAIModelE2E(BaseTestCase):
    def setup_method(self):
        self.queries = [
            "你知道太阳的直径是多少吗？",
            "地球和火星之间的距离是多少？",
            "太阳系有多少颗行星？",
            "太阳系的平均温度是多少？",
            "太阳系的自转周期是多少？",
            "太阳系的公转周期是多少？",
            "太阳系的平均密度是多少？",
            "普朗克常数是多少？",
            "爱因斯坦的相对论是哪一年提出的？",
            "量子计算是什么原理？",
            "什么是量子纠缠？",
            "什么是量子比特？",
            "什么是量子态？",
        ]
        self.text_list = [
            'abcd',
            '10km',
            '100km',
            '1000km',
        ]

    @pytest.mark.mr_ci
    def test_configs(self):
        config1_dict = {
            'name': 'qwen-max',
            'type': 'llm',
            'backend': 'tongyi',
            'api_key': 'abcdef-12345',
        }
        tongyi_config = TongyiAIModelConfig(**config1_dict)
        with pytest.raises(ValidationError):
            _ = VolcengineAIModelConfig(**config1_dict)
        with pytest.raises(ValidationError):
            openai_config = OpenAIModelConfig(**config1_dict)
        assert tongyi_config.name == 'qwen-max'
        assert tongyi_config.model == 'qwen-max'
        assert tongyi_config.backend == 'tongyi'
        assert tongyi_config.api_key == 'abcdef-12345'

        config2_dict = {
            'model': 'qwen-max',
            'type': 'llm',
            'backend': 'tongyi',
            'api_key': 'abcdef-12345',
        }
        tongyi_config = TongyiAIModelConfig(**config2_dict)
        assert tongyi_config.name == 'qwen-max'
        assert tongyi_config.model == 'qwen-max'
        assert tongyi_config.backend == 'tongyi'
        assert tongyi_config.api_key == 'abcdef-12345'

        config3_dict = {
            'name': 'tongyi-qwen-max',
            'model': 'qwen-max',
            'type': 'llm',
            'backend': 'tongyi',
            'api_key': 'abcdef-12345',
        }
        tongyi_config = TongyiAIModelConfig(**config3_dict)
        assert tongyi_config.name == 'tongyi-qwen-max'
        assert tongyi_config.model == 'qwen-max'
        assert tongyi_config.backend == 'tongyi'
        assert tongyi_config.api_key == 'abcdef-12345'

        config4_dict = {
            'name': 'deepseek-r1',
            'type': 'llm',
            'backend': 'openai',
            'api_key': 'abcdef-12345',
            'base_url': 'http://127.0.0.1:8000/'
        }
        openai_config = OpenAIModelConfig(**config4_dict)
        with pytest.raises(ValidationError):
            tongyi_config = TongyiAIModelConfig(**config4_dict)
        with pytest.raises(ValidationError):
            _ = VolcengineAIModelConfig(**config4_dict)
        assert openai_config.name == 'deepseek-r1'
        assert openai_config.model == 'deepseek-r1'
        assert openai_config.backend == 'openai'
        assert openai_config.api_key == 'abcdef-12345'

        config5_dict = {
            'name': 'Deepseek-R1-671B',
            'type': 'llm',
            'backend': 'openai',
            'api_key': '123456',
            'base_url': 'http://127.0.0.1:8000',
            'max_context_len': 32768,
            'max_tokens': 65536
        }
        openai_config = OpenAIModelConfig(**config5_dict)
        assert openai_config.name == 'Deepseek-R1-671B'
        assert openai_config.model == 'Deepseek-R1-671B'
        assert openai_config.backend == 'openai'
        assert openai_config.api_key == '123456'
        assert openai_config.base_url == 'http://127.0.0.1:8000'

    @pytest.mark.mr_ci
    def test_llm(self):
        llm_config, llm_client = KBX.get_ai_model_config_and_client('doubao-1.5-pro-32k')
        response = llm_client.chat(
            model_config=llm_config,
            messages=[
                {"role": "user", "content": self.queries[0]},
            ],
        ).choices[0].message.content
        assert response is not None
        logger.info(f'Got LLM response: {response}')

    @pytest.mark.mr_ci
    def test_llm_stream(self):
        llm_config, llm_client = KBX.get_ai_model_config_and_client('doubao-1.5-pro-32k')
        response = llm_client.chat(
            model_config=llm_config,
            messages=[
                {"role": "user", "content": self.queries[0]},
            ],
            stream=True,
        )
        assert isinstance(response, Iterator)
        chunks = []
        for chunk in response:
            chunk_msg = chunk.choices[0].delta.content
            print(chunk_msg, end='', flush=True)  # 实时打印内容
            chunks.append(chunk_msg)
        assert len(chunks) > 0
        all_msg = ''.join(chunks)
        assert len(all_msg) > 0

    def _test_reasoning_llm(self, llm_name: str, stream: bool = False) -> None:
        llm_config, llm_client = KBX.get_ai_model_config_and_client(llm_name)
        assert llm_config.type == AIModelType.REASONING_LLM, \
            f'Expect reasoning llm, but got {llm_config.type}'
        response = llm_client.chat(
            model_config=llm_config,
            messages=[{"role": "user", "content": self.queries[0]}],
            stream=stream,
        )
        assert response is not None
        content = ''
        reasoning_content = ''
        if stream:
            # 流式
            response = cast(Iterator[ChatResponseChunk], response)
            assert isinstance(response, Iterator)
            content_chunks = []
            reasoning_chunks = []
            for chunk in response:
                if getattr(chunk.choices[0].delta, 'reasoning_content', None):
                    reasoning_chunks.append(chunk.choices[0].delta.reasoning_content)
                if chunk.choices[0].delta.content:
                    content_chunks.append(chunk.choices[0].delta.content)
            assert len(content_chunks) > 0
            assert len(reasoning_chunks) > 0
            content = ''.join(content_chunks).strip()
            reasoning_content = ''.join(reasoning_chunks).strip()
            assert len(content) > 0
            assert len(reasoning_content) > 0
        else:
            # 非流式
            response = cast(ChatResponse, response)
            assert response is not None
            assert hasattr(response.choices[0].message, 'reasoning_content')
            assert response.choices[0].message.reasoning_content is not None
            assert response.choices[0].message.content is not None
            reasoning_content = response.choices[0].message.reasoning_content
            content = response.choices[0].message.content

        logger.info(
            f'Got reasoning content: "{reasoning_content}"\n'
            f'Got content: "{content}"'
        )

    @pytest.mark.daily_ci
    def test_reasoning_llm_v2(self):
        # reasoning_content</think>content
        self._test_reasoning_llm('SMore-Deepseek-R1-671B')

    @pytest.mark.daily_ci
    def test_reasoning_llm_v3(self):
        # 不涉及reasoning content特殊处理，服务端已经处理好
        self._test_reasoning_llm('volcengine-deepseek-r1')

    def _test_reasoning_vlm(self, vlm_name: str, stream: bool = False) -> None:
        vlm_config, vlm_client = KBX.get_ai_model_config_and_client(vlm_name)
        assert vlm_config.type == AIModelType.REASONING_VLM, \
            f'Expect reasoning vlm, but got {vlm_config.type}'
        image_file = os.path.join(self.test_data_dir, 'parser_data/kbx_arch.jpg')
        with open(image_file, 'rb') as f:
            import base64
            image_b64 = base64.b64encode(f.read()).decode('utf-8')
        response = vlm_client.chat(
            model_config=vlm_config,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {'type': 'text', 'text': '图片里有什么？'},
                        {'type': 'image_url', 'image_url': f'data:image/jpeg;base64,{image_b64}'},
                    ]
                }
            ],
            stream=stream,
        )
        content = ''
        reasoning_content = ''
        if stream:
            # 流式
            response = cast(Iterator[ChatResponseChunk], response)
            assert isinstance(response, Iterator)
            content_chunks = []
            reasoning_chunks = []
            for chunk in response:
                if getattr(chunk.choices[0].delta, 'reasoning_content', None):
                    reasoning_chunks.append(chunk.choices[0].delta.reasoning_content)
                if chunk.choices[0].delta.content:
                    content_chunks.append(chunk.choices[0].delta.content)
            assert len(content_chunks) > 0
            assert len(reasoning_chunks) > 0
            content = ''.join(content_chunks).strip()
            reasoning_content = ''.join(reasoning_chunks).strip()
            assert len(content) > 0
            assert len(reasoning_content) > 0
        else:
            # 非流式
            response = cast(ChatResponse, response)
            assert response is not None
            assert hasattr(response.choices[0].message, 'reasoning_content')
            assert response.choices[0].message.reasoning_content is not None
            assert response.choices[0].message.content is not None
            reasoning_content = response.choices[0].message.reasoning_content
            content = response.choices[0].message.content

        logger.info(
            f'Got reasoning content: "{reasoning_content}"\n'
            f'Got content: "{content}"'
        )

    @pytest.mark.daily_ci
    def test_reasoning_vlm(self):
        self._test_reasoning_vlm('doubao-1.5-thinking-pro-vision', stream=False)

    @pytest.mark.daily_ci
    def test_reasoning_vlm_stream(self):
        self._test_reasoning_vlm('doubao-1.5-thinking-pro-vision', stream=True)

    @pytest.mark.daily_ci
    def test_reasoning_llm_v2_stream(self):
        # reasoning_content</think>content
        self._test_reasoning_llm('SMore-Deepseek-R1-671B', stream=True)

    @pytest.mark.daily_ci
    def test_reasoning_llm_v3_stream(self):
        # 不涉及reasoning content特殊处理，服务端已经处理好
        self._test_reasoning_llm('volcengine-deepseek-r1', stream=True)

    @pytest.mark.mr_ci
    def test_llm_timeout_and_retry(self):
        import openai
        llm_config, llm_client = KBX.get_ai_model_config_and_client('doubao-1.5-pro-32k')
        # 特意把timeout设置得比较短，触发timeout错误
        llm_config.timeout = 0.01
        llm_config.retry_delay = 1
        llm_config.max_retries = 1
        with pytest.raises(openai.APITimeoutError):
            response = llm_client.chat(
                model_config=llm_config,
                messages=[
                    {"role": "user", "content": self.queries[0]},
                ],
            ).choices[0].message.content
            raise RuntimeError(f'LLM timeout test case failed, got unexpected response: {response}')

    @pytest.mark.mr_ci
    def test_llm_with_wrong_api_key(self):
        '''此用例请确保ai_models.yaml中提供了一个api-key不正确的LLM，配置如下：
            - name: llm-with-wrong-api-key
              type: llm
              backend: volcengine
              api_key: abcdef
              endpoint: xxxxx
              base_url: https://ark.cn-beijing.volces.com/api/v3
        '''
        import openai
        llm_config, llm_client = KBX.get_ai_model_config_and_client('llm-with-wrong-api-key')
        with pytest.raises(openai.AuthenticationError):
            response = llm_client.chat(
                model_config=llm_config,
                messages=[
                    {"role": "user", "content": self.queries[0]},
                ],
            ).choices[0].message.content
            raise RuntimeError(f'LLM call should crash, but got unexpected response: {response}')

    @pytest.mark.mr_ci
    def test_llm_does_not_exist(self):
        '''此用例请确保ai_models.yaml中提供了一个模型名称不正确的LLM，配置如下：
            - name: llm-does-not-exists
              type: llm
              backend: volcengine
              api_key: 8b52eb53-cc4f-44b4-a59b-73e179fc9e3a
              endpoint: wrong-endpoint
              base_url: https://ark.cn-beijing.volces.com/api/v3
        '''
        import openai
        llm_config, llm_client = KBX.get_ai_model_config_and_client('llm-does-not-exists')
        with pytest.raises((openai.BadRequestError, openai.InternalServerError, openai.NotFoundError)):
            response = llm_client.chat(
                model_config=llm_config,
                messages=[
                    {"role": "user", "content": self.queries[0]},
                ],
            ).choices[0].message.content
            raise RuntimeError(f'LLM call should crash, but got unexpected response: {response}')

    @pytest.mark.mr_ci
    def test_embedding(self):
        embedding_config, embedding_client = KBX.get_ai_model_config_and_client('doubao-embedding')
        embedding = embedding_client.text_embedding(model_config=embedding_config, text=self.queries[0])
        assert len(embedding) == 2560
        # logger.info(f'Got LLM embedding: {embedding}')

    @pytest.mark.mr_ci
    def test_embedding_batch(self):
        embedding_config, embedding_client = KBX.get_ai_model_config_and_client('doubao-embedding')
        embedding_batch = embedding_client.text_embedding_batch(model_config=embedding_config, texts=self.queries)
        assert len(embedding_batch) == len(self.queries)
        assert len(embedding_batch[0]) == 2560

    @pytest.mark.mr_ci
    def test_rerank(self):
        top_n = 2
        rerank_config, rerank_client = KBX.get_ai_model_config_and_client('BAAI/bge-reranker-v2-m3')
        rerank_results = rerank_client.rerank(
            model_config=rerank_config,
            query=self.queries[0],
            texts=self.text_list,
            top_n=top_n,
        )
        if len(rerank_results) > top_n:
            raise RuntimeError(f'Rerank results length should be less than or equal to {top_n}: {rerank_results}')
        for index, text, score in rerank_results:
            assert index < len(self.text_list)
            assert score >= 0
            assert text == self.text_list[index]

    @pytest.mark.mr_ci
    def test_rerank_timeout(self):
        top_n = 2
        rerank_config, rerank_client = KBX.get_ai_model_config_and_client('BAAI/bge-reranker-v2-m3')
        # 特意把timeout设置得比较短，触发timeout错误
        rerank_config.timeout = 0.01
        import requests
        with pytest.raises((requests.exceptions.ConnectTimeout, requests.exceptions.ReadTimeout)):
            _ = rerank_client.rerank(
                model_config=rerank_config,
                query=self.queries[0],
                texts=self.text_list,
                top_n=top_n,
            )
            raise RuntimeError('Expect to get rerank timeout error but nothing happened.')

    @pytest.mark.daily_ci
    def test_llm_limiter(self):
        # 测试LLM限流器，耗时较长，通过命名取消pytest自动执行
        import time
        from concurrent.futures import ThreadPoolExecutor

        logger.info('Start llm limiter testcase, it may takes a while ...')
        n_queries = 100
        logger.info(f'Init thread pool with {KBX.config.num_threads} threads')
        pool = ThreadPoolExecutor(max_workers=KBX.config.num_threads)

        queries = [self.queries[i % len(self.queries)] for i in range(n_queries)]

        embedding_config, embedding_client = KBX.get_ai_model_config_and_client('doubao-embedding')
        embedding_config.rpm = 50
        embedding_config.tpm = -1

        logger.info('======================================================================================')
        logger.info('Start single request test, use limiter and without limiter should take similar time.')

        n_test = 10

        old_user_id = embedding_config.user_id
        embedding_config.user_id = None
        t_start = time.time()
        for i in range(n_test):
            _ = embedding_client.text_embedding(model_config=embedding_config, text=self.queries[i])
        t_1_request = (time.time() - t_start) / n_test
        logger.info(f'Single request without limiter test finished in {t_1_request} seconds ({n_test} average)')
        embedding_config.user_id = old_user_id

        t_start = time.time()
        for i in range(n_test):
            _ = embedding_client.text_embedding(model_config=embedding_config, text=self.queries[i])
        t_1_request = (time.time() - t_start) / n_test
        logger.info(f'Single request without limiter test finished in {t_1_request} seconds ({n_test} average)')

        logger.info('======================================================================================')
        logger.info(f'Start {n_queries} requests test, use limiter and without limiter should take different time.')

        with pool:
            # 通过删除user_id来临时禁用限流器
            old_user_id = embedding_config.user_id
            embedding_config.user_id = None
            t_start = time.time()
            future_results = [
                pool.submit(
                    embedding_client.text_embedding,
                    embedding_config, text=query) for query in queries
            ]
            _ = [future.result() for future in future_results]
            t_no_limiter = time.time() - t_start
            logger.info(f'total time for concurrent {n_queries} queries without limiter: {t_no_limiter}')

            # 恢复user_id，重新启用限流器
            embedding_config.user_id = old_user_id
            t_start = time.time()
            future_results = [
                pool.submit(
                    embedding_client.text_embedding,
                    embedding_config, text=query) for query in queries
            ]
            _ = [future.result() for future in future_results]
            t_with_limiter = time.time() - t_start
            logger.info(f'total time for concurrent {n_queries} queries with limiter: {t_with_limiter}')
        logger.info('======================================================================================')

    @pytest.mark.mr_ci
    def test_ai_model_bundle(self):
        bundle1 = AIModelBundle(
            bundles={
                AIModelType.LLM: 'abc',
                AIModelType.REASONING_LLM: 'def',
            }
        )
        assert bundle1.llm == 'abc'
        assert bundle1.reasoning_llm == 'def'

        bundle2 = AIModelBundle(
            bundles={
                AIModelType.REASONING_LLM: 'def',
            }
        )
        assert bundle2.llm == 'def'
        assert bundle2.reasoning_llm == 'def'

        bundle3 = AIModelBundle(
            bundles={
                AIModelType.VLM: 'abc',
                AIModelType.REASONING_VLM: 'def',
            }
        )
        assert bundle3.vlm == 'abc'
        assert bundle3.reasoning_vlm == 'def'

        bundle4 = AIModelBundle(
            bundles={
                AIModelType.REASONING_VLM: 'def',
            }
        )
        assert bundle4.vlm == 'def'
        assert bundle4.reasoning_vlm == 'def'


if __name__ == '__main__':
    # 手动执行
    test_case = TestAIModelE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_configs()
    test_case.test_llm_does_not_exist()
    test_case.test_llm_with_wrong_api_key()
    test_case.test_llm()
    test_case.test_llm_timeout_and_retry()
    test_case.test_embedding()
    test_case.test_embedding_batch()
    test_case.test_rerank()
    test_case.test_rerank_timeout()
    test_case.test_llm_limiter()
    test_case.test_reasoning_llm_v2()
    test_case.test_reasoning_llm_v3()
    test_case.test_llm_stream()
    test_case.test_reasoning_llm_v2_stream()
    test_case.test_reasoning_llm_v3_stream()
    test_case.test_reasoning_vlm()
    test_case.test_reasoning_vlm_stream()
    test_case.test_ai_model_bundle()
