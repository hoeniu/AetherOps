"""
接口测试：AI模型相关 API
"""
import os
import pytest
import sys
from humanfriendly.text import random_string

# 根目录
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../..")
sys.path.insert(0, ROOT_DIR)
from tests.base_test_case import BaseTestCase


class TestAIModelAPI(BaseTestCase):
    @pytest.fixture(scope="class", autouse=True)
    def setup_and_teardown_class(self, mock_data):
        TestAIModelAPI.client = mock_data.client
        TestAIModelAPI.headers = mock_data.headers
        # 临时模型名称
        TestAIModelAPI.model_name = "model1-" + random_string(6)
        yield

    @pytest.mark.mr_ci
    def test_register_ai_models(self):
        """测试注册多个AI模型"""
        request_data = {
            "configs": [
                {
                    "name": TestAIModelAPI.model_name,
                    "type": "text_embedding",
                    "backend": "volcengine",
                    "api_key": "8b52eb53-cc4f-44b4-a59b-73e179fc9e3a",
                    "base_url": "https://ark.cn-beijing.volces.com/api/v3",
                    "endpoint": "ep-20241108104331-4jfp9",
                    "max_context_len": 4096,
                    "max_tokens": 4096,
                    "rpm": 1000
                },
            ],
            "overwrite": True
        }
        response = self.client.post(
            "/api/v1/register_ai_models",
            json=request_data,
            headers=self.headers
        )
        assert response.status_code == 200
        assert response.json() == {}

    @pytest.mark.mr_ci
    def test_list_ai_models(self):
        """测试列出AI模型"""
        response = self.client.get(
            "/api/v1/list_ai_models",
            headers=self.headers
        )
        assert response.status_code == 200
        body = response.json()
        assert isinstance(body.get("total"), int)
        data = body.get("data")
        assert isinstance(data, list)
        names = [d.get("model_name") for d in data]
        assert TestAIModelAPI.model_name in names

    @pytest.mark.mr_ci
    def test_get_ai_model_detail(self):
        """测试获取AI模型详情"""
        name = TestAIModelAPI.model_name
        response = self.client.get(
            f"/api/v1/ai_model_detail?name={name}",
            headers=self.headers
        )
        assert response.status_code == 200
        detail = response.json()
        # 接口可能返回字段名不同
        assert detail.get("name") == name or detail.get("model_name") == name
        assert detail.get("type") or detail.get("model_type")
        assert detail.get("backend") or detail.get("model_backend")

    @pytest.mark.mr_ci
    def test_embedding_score(self):
        """测试计算文本embedding相似度"""
        # 使用已注册的text_embedding模型
        model_name = TestAIModelAPI.model_name
        payload = {
            "text1": "这是一个测试文本",
            "text2": "这是另一个测试文本",
            "model": model_name
        }
        response = self.client.post(
            "/api/v1/embedding_score",
            json=payload,
            headers=self.headers
        )
        assert response.status_code == 200
        result = response.json()
        # 验证返回的相似度分数在[0,1]范围内
        assert isinstance(result.get("score"), (int, float))
        assert 0 <= result.get("score") <= 1

    @pytest.mark.mr_ci
    def test_delete_ai_model(self):
        """测试删除AI模型"""
        name = TestAIModelAPI.model_name
        response = self.client.post(
            f"/api/v1/delete_ai_model?name={name}",
            headers=self.headers
        )
        assert response.status_code == 200
        assert response.json() == {}
        # 再次列出，确认删除
        resp2 = self.client.get(
            "/api/v1/list_ai_models",
            headers=self.headers
        )
        assert resp2.status_code == 200
        names = [d.get("model_name") for d in resp2.json().get("data")]
        assert name not in names
