import pytest
from kbx.common.types import TokenCounterConfig
from kbx.common.token_counter.token_counter_factory import get_token_counter


class TestTokenCounter:
    @pytest.fixture
    def accurate_tiktoken_config(self):
        return TokenCounterConfig(
            counter='accurate',
            kwargs={
                'tokenizer_type': 'tiktoken',
                'encoding_name': 'cl100k_base'
            }
        )

    @pytest.fixture
    def accurate_transformers_config(self):
        return TokenCounterConfig(
            counter='accurate',
            kwargs={
                'tokenizer_type': 'transformers',
                'model_name': 'bert-base-uncased'
            }
        )

    @pytest.fixture
    def estimated_config(self):
        return TokenCounterConfig(
            counter='estimated',
            kwargs={
                'chinese_factor': 1.5,
                'english_factor': 3.0
            }
        )

    @pytest.mark.mr_ci
    def test_accurate_tiktoken_counter(self, accurate_tiktoken_config: TokenCounterConfig):
        counter = get_token_counter(accurate_tiktoken_config)
        text = "这是一个测试文本，用于测试token计数的准确性。"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_accurate_transformers_counter(self, accurate_transformers_config: TokenCounterConfig):
        counter = get_token_counter(accurate_transformers_config)
        text = "这是一个测试文本，用于测试token计数的准确性。"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_accurate_tiktoken_empty_string(self, accurate_tiktoken_config: TokenCounterConfig):
        counter = get_token_counter(accurate_tiktoken_config)
        assert counter("") == 0

    @pytest.mark.mr_ci
    def test_accurate_transformers_empty_string(self, accurate_transformers_config: TokenCounterConfig):
        counter = get_token_counter(accurate_transformers_config)
        # Transformers tokenizer 会为空字符串添加 [CLS] 和 [SEP] 特殊 token
        assert counter("") == 2

    @pytest.mark.mr_ci
    def test_accurate_tiktoken_special_chars(self, accurate_tiktoken_config: TokenCounterConfig):
        counter = get_token_counter(accurate_tiktoken_config)
        text = "!@#$%^&*()_+{}|:\"<>?`~[]\\;',./"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_accurate_transformers_special_chars(self, accurate_transformers_config: TokenCounterConfig):
        counter = get_token_counter(accurate_transformers_config)
        text = "!@#$%^&*()_+{}|:\"<>?`~[]\\;',./"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_accurate_tiktoken_unicode(self, accurate_tiktoken_config: TokenCounterConfig):
        counter = get_token_counter(accurate_tiktoken_config)
        text = "こんにちは世界 안녕하세요 세계"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_accurate_transformers_unicode(self, accurate_transformers_config: TokenCounterConfig):
        counter = get_token_counter(accurate_transformers_config)
        text = "こんにちは世界 안녕하세요 세계"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_accurate_tiktoken_long_text(self, accurate_tiktoken_config: TokenCounterConfig):
        counter = get_token_counter(accurate_tiktoken_config)
        text = "这是一个很长的测试文本。" * 1000
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_accurate_transformers_long_text(self, accurate_transformers_config: TokenCounterConfig):
        counter = get_token_counter(accurate_transformers_config)
        text = "这是一个很长的测试文本。" * 1000
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_estimated_counter(self, estimated_config: TokenCounterConfig):
        counter = get_token_counter(estimated_config)
        text = "这是一个测试文本用于测试token计数的准确性。"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_accurate_counter_with_english(self, accurate_tiktoken_config: TokenCounterConfig):
        counter = get_token_counter(accurate_tiktoken_config)
        text = "This is an English text"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_estimated_counter_with_english(self, estimated_config: TokenCounterConfig):
        counter = get_token_counter(estimated_config)
        text = "This is an English text"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_accurate_counter_mixed(self, accurate_tiktoken_config: TokenCounterConfig):
        counter = get_token_counter(accurate_tiktoken_config)
        text = "这是一个混合文本 This is a mixed text"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_estimated_counter_mixed(self, estimated_config: TokenCounterConfig):
        counter = get_token_counter(estimated_config)
        text = "这是一个混合文本 This is a mixed text 用于测试token计数的准确性。"
        assert counter(text) > 0

    @pytest.mark.mr_ci
    def test_invalid_counter_type(self):
        with pytest.raises(ValueError):
            config = TokenCounterConfig(counter='invalid')
            get_token_counter(config)

    @pytest.mark.mr_ci
    def test_accurate_counter_invalid_tokenizer(self, accurate_tiktoken_config: TokenCounterConfig):
        accurate_tiktoken_config.kwargs['tokenizer_type'] = 'invalid'
        with pytest.raises(ValueError):
            get_token_counter(accurate_tiktoken_config)

    @pytest.mark.mr_ci
    def test_estimated_counter_zero_division(self, estimated_config: TokenCounterConfig):
        estimated_config.kwargs['chinese_factor'] = 0
        with pytest.raises(ValueError):
            counter = get_token_counter(estimated_config)
            counter("测试")

    @pytest.mark.mr_ci
    def test_estimated_counter_negative_factor(self, estimated_config: TokenCounterConfig):
        estimated_config.kwargs['chinese_factor'] = -1
        with pytest.raises(ValueError):
            get_token_counter(estimated_config)
