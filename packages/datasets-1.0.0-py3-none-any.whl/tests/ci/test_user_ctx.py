import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import pytest
from tests.base_test_case import BaseTestCase
from kbx.common.utils import inject_user_ctx
from kbx.common.types import UserContext
from kbx.knowledge_base.types import KBCreationConfig, VectorKeywordIndexConfig
from kbx.splitter.types import SplitterConfig
from kbx.parser.types import DocParseConfig
from kbx.rerank.types import RerankConfig


class TestUserContext(BaseTestCase):
    @pytest.mark.mr_ci
    def test_case1(self):
        vector_keyword_config = VectorKeywordIndexConfig(
            index_strategy="DefaultVectorKeywordIndex",
            text_embedding_model="doubao-embedding",
            splitter_config=SplitterConfig(name="RecursiveTextSplitter", chunk_size=1000),
            keyword_extractor="jieba",
            max_keywords_per_chunk=100,
        )
        assert vector_keyword_config.user_ctx is None

        user_ctx = UserContext(user_id='user1', tenant_id='tenant1', extra_kwargs={'a': 1, 'b': 2})

        vector_keyword_config2 = inject_user_ctx(config=vector_keyword_config, user_ctx=user_ctx, recursive=False)
        assert vector_keyword_config.user_ctx is not None
        assert vector_keyword_config2.user_ctx is not None
        assert vector_keyword_config.user_ctx == user_ctx
        assert vector_keyword_config == vector_keyword_config2

    @pytest.mark.mr_ci
    def test_case2(self):
        kb_config = KBCreationConfig(
            name='知识库名',
            description='这是一个知识库',
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(name="RecursiveTextSplitter", chunk_size=1000),
                keyword_extractor="jieba",
                max_keywords_per_chunk=100,
            ),
            rerank_config=RerankConfig(
                name="ModelRerank",
                kwargs={"model": "BAAI/bge-reranker-v2-m3"},
            ),
        )
        assert not hasattr(kb_config, 'user_ctx')
        assert kb_config.doc_parse_config.user_ctx is None
        assert kb_config.vector_keyword_config.user_ctx is None
        assert kb_config.rerank_config.user_ctx is None

        user_ctx = UserContext(user_id='user1', tenant_id='tenant1', extra_kwargs={'a': 1, 'b': 2})

        kb_config2 = inject_user_ctx(config=kb_config, user_ctx=user_ctx, recursive=True)
        assert not hasattr(kb_config, 'user_ctx')
        # inplace 修改测试
        assert kb_config.doc_parse_config.user_ctx is not None
        assert kb_config.vector_keyword_config.user_ctx is not None
        assert kb_config.rerank_config.user_ctx is not None
        assert kb_config.vector_keyword_config.user_ctx == user_ctx
        assert kb_config == kb_config2, f'Expect {kb_config} == {kb_config2}, given {kb_config} != {kb_config2}'


if __name__ == '__main__':
    test = TestUserContext()
    test.test_case1()
    test.test_case2()
