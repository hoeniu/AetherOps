import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys

sys.path.insert(0, ROOT_DIR)

import pytest
from textwrap import dedent
from kbx.common.types import DocData, DocElement, DocElementType, TOCNode, DocElementCollection, Table
from kbx.common.utils import generate_new_id
from kbx.splitter.splitter_factory import get_splitter
from kbx.splitter.types import SplitterConfig
from kbx.splitter.naive_text_splitter import NaiveTextSplitter
from kbx.splitter.recursive_text_splitter import RecursiveTextSplitter
from kbx.splitter.toc_aware_wrapper import TOCAwareWrapper
from kbx.parser.pptx.default_pptx_parser import DefaultPptxParser
from kbx.parser.types import DocParseConfig
from tests.base_test_case import BaseTestCase
from kbx.common.logging import logger


class TestTextSplitter(BaseTestCase):
    """文本分块器测试类，集成所有分块相关测试"""

    @classmethod
    def setup_class(cls):
        """初始化KBX环境"""
        # 获取基类的原始方法，准备手动控制调用
        from kbx.kbx import KBX

        # 设置测试数据目录
        cls.test_data_dir = os.environ.get('KBX_TEST_DATA_DIR', None)
        if not cls.test_data_dir:
            cls.test_data_dir = os.path.join(ROOT_DIR, 'cache/kbx_test_data')
        if not os.path.exists(cls.test_data_dir):
            logger.error(
                f'KBX test data dir "{cls.test_data_dir}" does not exists,'
                ' did you forget to download it or set custom path with "KBX_TEST_DATA_DIR"?'
            )

        # 设置默认的配置文件路径
        if not cls.kbx_yaml_file:
            cls.kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')

        # 仅初始化KBX，不注册AI模型
        if cls.kbx_yaml_file:
            KBX.init(config=cls.kbx_yaml_file)

    def setup_method(self):
        """初始化PPTX测试环境"""
        # 设置测试文件路径
        self.test_pptx_file = os.path.join(self.test_data_dir, "parser_data/test2.pptx")

        # 创建解析器
        self.doc_parser_config = DocParseConfig()
        self.parser = DefaultPptxParser(self.doc_parser_config)

    def require_pptx_file(self):
        """检查测试PPTX文件是否存在，不存在则跳过测试"""
        if not os.path.exists(self.test_pptx_file):
            pytest.skip(f"测试文件不存在: {self.test_pptx_file}")

    def create_test_doc_data(self):
        """创建测试用的DocData对象"""
        self.require_pptx_file()
        doc_id = generate_new_id()
        return self.parser.parse(self.test_pptx_file, doc_id)

    @pytest.mark.mr_ci
    def test_constructor(self):
        """测试构造函数和默认参数"""
        splitter = get_splitter(SplitterConfig(name="NaiveTextSplitter"))
        assert splitter._config.keep_delimiter is True
        assert splitter._config.chunk_size == 1024
        assert splitter._config.delimiters == ["\n\n", "\n", " "]
        assert splitter._config.overlap_size == 0

    @pytest.mark.mr_ci
    def test_split_basic(self):
        """测试基本分块功能"""
        splitter = get_splitter(SplitterConfig(name="NaiveTextSplitter"))

        doc_data = DocData(doc_id=generate_new_id(),
                           doc_elements=[
                               DocElement(doc_element_id=generate_new_id(),
                                          text="This is a test."),
                               DocElement(doc_element_id=generate_new_id(),
                                          text="Another test.")])

        chunks = splitter.split(doc_data)
        assert chunks[0].text == "This is a test.\nAnother test."

    @pytest.mark.mr_ci
    def test_split_edge_cases(self):
        """测试边缘情况"""
        splitter = get_splitter(SplitterConfig(name="NaiveTextSplitter"))

        # 测试空文档元素
        doc_data = DocData(doc_id=generate_new_id(), doc_elements=[])
        chunks = splitter.split(doc_data)
        assert len(chunks) == 0

        # 测试无分隔符情况
        doc_data = DocData(doc_id=generate_new_id(),
                           doc_elements=[
                               DocElement(
                                   doc_element_id=generate_new_id(),
                                   text="This is a test without delimiters")])
        chunks = splitter.split(doc_data)
        assert chunks[0].text == "This is a test without delimiters"

    def test_split_various_elements(self):
        """测试各种类型的文档元素"""
        splitter = get_splitter(SplitterConfig(name="NaiveTextSplitter"))

        doc_data = DocData(
            doc_id=generate_new_id(),
            doc_elements=[
                DocElement(
                    doc_element_id=generate_new_id(),
                    text="This is a test.",
                    content_description="Description 1"
                ),
                DocElement(
                    doc_element_id=generate_new_id(),
                    table=Table.from_2d_list(
                        [["col1", "col2"],
                         ["val1", "val2"]],
                        has_header=False,
                        caption="Table caption"),
                    type=DocElementType.TABLE
                )
            ]
        )

        chunks = splitter.split(doc_data)
        assert len(chunks) == 1
        assert chunks[0].text == "This is a test.\n\n|col1|col2|\n|val1|val2|"

    @pytest.mark.mr_ci
    def test_split_text(self):
        """测试RecursiveTextSplitter的split_text方法"""
        splitter = get_splitter(SplitterConfig(name="RecursiveTextSplitter"))

        # 测试常规文本分割
        text = "This is a test\nThis is another test"
        assert len(splitter.split_text(text)) == 1

        # 测试多换行符
        text = "This is a test\n\nThis is another test\n\n\nThis is a third test"
        assert len(splitter.split_text(text)) == 1

        # 测试短文本
        text = "This is a short test"
        assert splitter.split_text(text) == ["This is a short test"]

    @pytest.mark.mr_ci
    def test_code_block_split(self):
        """测试代码块分割"""
        splitter = get_splitter(
            SplitterConfig(name="RecursiveTextSplitter",
                           delimiters=["\n\n", "\n", "。", "？", " "],
                           chunk_size=500,
                           overlap_size=10))

        # 简化的Python代码示例
        python_code = dedent('''
            ```python
            import os
            import sys

            def example_function():
                """示例函数"""
                print("Hello World")
                return 42

            if __name__ == "__main__":
                result = example_function()
                print(f"Result: {result}")
            ```
            ''')

        # 长文本示例
        long_text = "这是一段长文本，用于测试分块功能。" * 20

        doc_data = DocData(doc_id=generate_new_id(),
                           doc_elements=[
                               DocElement(doc_element_id=generate_new_id(),
                                          text="这是一段正文",
                                          type=DocElementType.TEXT),
                               DocElement(doc_element_id=generate_new_id(),
                                          text=python_code,
                                          type=DocElementType.CODE_BLOCK),
                               DocElement(doc_element_id=generate_new_id(),
                                          text=long_text,
                                          type=DocElementType.TEXT), ])

        chunks = splitter.split(doc_data=doc_data)
        assert len(chunks) > 0

    @pytest.mark.mr_ci
    def test_table_split(self):
        """测试表格分割"""
        splitter = get_splitter(
            SplitterConfig(name="RecursiveTextSplitter",
                           chunk_size=500,
                           overlap_size=10))

        # 简单表格
        table_data = [["姓名", "年龄", "职业"], ["张三", "30", "工程师"],
                      ["李四", "25", "设计师"], ["王五", "35", "产品经理"]]

        doc_data = DocData(
            doc_id=generate_new_id(),
            doc_elements=[
                DocElement(
                    doc_element_id=generate_new_id(),
                    table=Table.from_2d_list(table_data, has_header=True, caption="人员信息表"),
                    type=DocElementType.TABLE
                )
            ]
        )

        chunks = splitter.split(doc_data=doc_data)
        assert len(chunks) > 0
        assert "|姓名|年龄|职业|" in chunks[0].text

    @pytest.mark.mr_ci
    def test_large_table_split(self):
        """测试大表格分割"""
        splitter = get_splitter(
            SplitterConfig(
                name="RecursiveTextSplitter",
                chunk_size=200,  # 较小的chunk_size以触发分块
                overlap_size=0))

        # 创建大表格
        header = ["列" + str(i) for i in range(1, 6)]
        rows = []
        for i in range(1, 21):
            row = ["数据" + str(i) + "-" + str(j) for j in range(1, 6)]
            rows.append(row)

        table_data = [header] + rows

        doc_data = DocData(
            doc_id=generate_new_id(),
            doc_elements=[
                DocElement(
                    doc_element_id=generate_new_id(),
                    table=Table.from_2d_list(table_data, has_header=True, caption="大数据表格示例"),
                    type=DocElementType.TABLE
                )
            ]
        )

        chunks = splitter.split(doc_data=doc_data)
        assert len(chunks) > 1  # 确保被分成多个块
        assert "大数据表格示例" in chunks[0].text

        # 确保表头在每个块中都存在
        header_text = "|".join(["列" + str(i) for i in range(1, 6)])
        for chunk in chunks:
            assert header_text in chunk.text, f"Header not found in chunk: {chunk.text}"

    @pytest.mark.mr_ci
    def test_manual_composition(self):
        """测试手动组合分块器"""
        # 创建基础分块器
        base_config = SplitterConfig(name="RecursiveTextSplitter",
                                     chunk_size=1024)
        base_splitter = RecursiveTextSplitter(base_config)

        # 创建TOC配置和包装器
        toc_config = SplitterConfig(chunk_size=1024, )
        toc_splitter = TOCAwareWrapper(base_splitter, toc_config)

        # 验证类型
        assert isinstance(toc_splitter, TOCAwareWrapper)
        assert isinstance(toc_splitter._base_splitter, RecursiveTextSplitter)

    @pytest.mark.mr_ci
    def test_toc_workflow(self):
        """测试TOC感知分块的完整工作流"""
        # 创建示例文档数据
        doc_data = create_sample_doc_data()

        # 输出一些调试信息
        print("\nTOC结构:")
        print(
            f"根节点: {doc_data.doc_toc.title}, 元素IDs: {doc_data.doc_toc.doc_element_ids}"
        )
        for child in doc_data.doc_toc.children:
            print(f"  子节点: {child.title}, 元素IDs: {child.doc_element_ids}")

        print("\n文档元素:")
        for i, elem in enumerate(doc_data.doc_elements):
            print(
                f"  元素[{i}]: {elem.doc_element_id}, 类型: {elem.type}, 文本: {elem.text[:30]}..."
            )

        # 配置分块器
        config = SplitterConfig(
            name="RecursiveTextSplitter",
            chunk_size=500,
        )

        print(f"\n分块器配置: chunk_size={config.chunk_size}")

        # 获取分块器
        splitter = get_splitter(config)

        # 执行分块
        chunks = splitter.split(doc_data)

        print(f"\n生成的chunks数量: {len(chunks)}")
        for i, chunk in enumerate(chunks):
            print(f"\nChunk {i + 1}:")
            print(f"  元素IDs: {chunk.doc_element_ids}")
            print(f"  内容长度: {len(chunk.text)}")
            print(f"  内容: {chunk.text[:50]}...")

        # 验证结果
        assert isinstance(splitter, TOCAwareWrapper)
        assert isinstance(splitter._base_splitter, RecursiveTextSplitter)
        assert len(chunks) > 0

    @pytest.mark.mr_ci
    def test_direct_elem_with_children_merge(self):
        """测试直接元素与子节点合并功能"""
        # 创建测试数据
        doc_data = create_toc_direct_elem_test_data()

        # 配置分块器
        config = SplitterConfig(
            name="RecursiveTextSplitter",
            chunk_size=100,  # 设置一个合理的chunk_size，确保能够测试合并逻辑
        )

        # 获取分块器
        splitter = get_splitter(config)

        # 执行分块
        chunks = splitter.split(doc_data)

        # 输出结果以便调试
        print(f"\n生成的chunks数量: {len(chunks)}")
        for i, chunk in enumerate(chunks):
            print(f"\nChunk {i + 1}:")
            print(f"  元素IDs: {chunk.doc_element_ids}")
            print(f"  内容长度: {len(chunk.text)}")
            print(f"  内容: {chunk.text[:50]}...")

        # 验证结果
        assert isinstance(splitter, TOCAwareWrapper)

        # 验证最基本的条件：确保生成了至少一个chunk
        assert len(chunks) > 0

        # 检查是否所有元素ID都被包含在生成的chunks中
        all_elem_ids = set()
        for chunk in chunks:
            all_elem_ids.update(chunk.doc_element_ids)

        expected_ids = {
            "title1", "direct1", "subtitle1", "subtext1", "subtitle2",
            "subtext2"
        }
        assert expected_ids.issubset(
            all_elem_ids
        ), f"某些元素ID未包含在生成的chunks中: {expected_ids - all_elem_ids}"

        # 检查第一个chunk包含所有元素
        first_chunk = chunks[0]
        assert len(first_chunk.doc_element_ids) == len(expected_ids)
        assert "测试标题" in first_chunk.text
        assert "这是测试标题下的直接内容" in first_chunk.text
        assert "子标题1" in first_chunk.text
        assert "子标题2" in first_chunk.text

    @pytest.mark.mr_ci
    def test_root_direct_elem_merge(self):
        """测试根节点直接元素与子节点的合并"""
        # 创建测试数据
        elements = []

        # 根节点下的直接元素
        intro = DocElement(doc_element_id="intro",
                           type=DocElementType.TEXT,
                           text="这是文档的介绍部分，是根节点的直接内容。")
        elements.append(intro)

        # 第一章标题
        ch1_title = DocElement(doc_element_id="ch1_title",
                               type=DocElementType.TITLE,
                               text="第一章：基础介绍",
                               meta_data={"title_level": 1})
        elements.append(ch1_title)

        # 第一章内容
        ch1_content = DocElement(doc_element_id="ch1_content",
                                 type=DocElementType.TEXT,
                                 text="这是第一章的内容，内容不多，适合合并。")
        elements.append(ch1_content)

        # 创建TOC结构
        # 根节点
        root_node = TOCNode(
            title="ROOT",
            level_str="0",
            self_doc_element_ids=["intro"],
            children_doc_element_ids=["ch1_title", "ch1_content"],
            num_tokens=30)

        # 第一章节点
        ch1_node = TOCNode(title="第一章：基础介绍",
                           level_str="0.1",
                           self_doc_element_ids=["ch1_title"],
                           children_doc_element_ids=["ch1_content"],
                           num_tokens=25)

        # 构建树结构
        root_node.children = [ch1_node]

        # 创建DocElementCollection并添加元素
        collection = DocElementCollection()
        for elem in elements:
            collection.append(elem)

        # 创建DocData
        doc_data = DocData(doc_id="test_doc",
                           file_name="test_root_direct_elem.md",
                           file_path="/tmp/test_root_direct_elem.md",
                           doc_elements=collection,
                           doc_toc=root_node)

        # 创建配置和分块器（设置合适的参数以测试合并逻辑）
        config = SplitterConfig(
            chunk_size=150,  # 设置足够大以容纳所有内容
        )

        base_splitter = NaiveTextSplitter(config)
        wrapper = TOCAwareWrapper(base_splitter, config)

        # 执行分块
        chunks = wrapper.split(doc_data)

        # 输出结果以便调试
        print(f"\n生成的chunks数量: {len(chunks)}")
        for i, chunk in enumerate(chunks):
            print(f"\nChunk {i + 1}:")
            print(f"  元素IDs: {chunk.doc_element_ids}")
            print(f"  内容长度: {len(chunk.text)}")
            print(f"  内容: {chunk.text[:50]}...")

        # 验证结果
        assert len(chunks) == 1, f"预期生成1个合并的chunk，实际生成了{len(chunks)}个"

        # 检查合并chunk是否包含所有元素ID
        merged_chunk = chunks[0]
        expected_ids = ["intro", "ch1_title", "ch1_content"]

        for elem_id in expected_ids:
            assert elem_id in merged_chunk.doc_element_ids, f"合并的chunk中缺少元素ID: {elem_id}"

        # 检查文本是否包含关键内容
        assert "这是文档的介绍部分" in merged_chunk.text
        assert "第一章：基础介绍" in merged_chunk.text
        assert "这是第一章的内容" in merged_chunk.text

    @pytest.mark.mr_ci
    def test_pptx_special_handling(self):
        """测试NaiveTextSplitter是否能正确识别和处理PPTX文件"""
        # 创建测试文档数据
        doc_data = self.create_test_doc_data()

        # 创建分块器
        splitter_config = SplitterConfig(
            name="NaiveTextSplitter",
            chunk_size=1024,
            overlap_size=100,
            delimiters=["\n\n", "\n", " ", ""],
            token_counter=None  # 使用默认配置
        )
        splitter = get_splitter(splitter_config)

        # 分块处理
        chunks = splitter.split(doc_data)

        # 输出分块结果
        print(f"\n总块数: {len(chunks)}")

        # 统计每个幻灯片的元素在多少个分块中出现
        slide_to_chunks = _count_slide_distribution(chunks,
                                                    doc_data.doc_elements)
        print("\n各幻灯片内容被分布的块数:")
        _print_slide_distribution(slide_to_chunks)

        # 计算平均每张幻灯片被分散到的块数
        avg_chunks_per_slide = sum(len(chunk_set) for chunk_set in slide_to_chunks.values()) / \
            len(slide_to_chunks) if slide_to_chunks else 0
        print(f"平均每张幻灯片被分散到 {avg_chunks_per_slide:.2f} 个块中")

        # 检查完美分块的幻灯片数量（每张幻灯片只在一个块中）
        perfect_slides = sum(1 for chunk_set in slide_to_chunks.values()
                             if len(chunk_set) == 1)
        print(f"完美分块的幻灯片: {perfect_slides}/{len(slide_to_chunks)} 张")

        # 打印样本块内容
        _print_sample_chunks(chunks, doc_data.doc_elements)

        # 验证结果
        # 1. 确认所有幻灯片元素都被包含在了分块中
        all_elements_covered = True
        for elem in doc_data.doc_elements:
            # 只检查有文本内容的元素
            if not splitter.is_valid_text(elem.text):
                continue

            found = False
            for chunk in chunks:
                if elem.doc_element_id in chunk.doc_element_ids:
                    found = True
                    break
            if not found:
                all_elements_covered = False
                print(f"警告: 元素 {elem.doc_element_id} 没有被包含在任何分块中")
        assert all_elements_covered, "所有有文本内容的文档元素应该被包含在分块中"

        # 2. 验证大多数幻灯片能保持在少量分块中（平均每张幻灯片被分到的块数应该较少）
        assert avg_chunks_per_slide < 2.0, f"平均每张幻灯片分散在太多块中: {avg_chunks_per_slide:.2f}"

        # 3. 验证是否有一定比例的幻灯片能完整保持在一个块中
        perfect_ratio = perfect_slides / len(
            slide_to_chunks) if slide_to_chunks else 0
        assert perfect_ratio >= 0.5, f"完美分块的幻灯片比例过低: {perfect_ratio:.2f}"

    @pytest.mark.mr_ci
    def test_compare_splitters(self):
        """比较不同配置的NaiveTextSplitter处理PPTX文件的效果"""
        # 创建测试文档数据
        doc_data = self.create_test_doc_data()

        # 常规NaiveTextSplitter配置
        naive_splitter_config = SplitterConfig(
            name="NaiveTextSplitter",
            chunk_size=1024,
            overlap_size=100,
            delimiters=["\n\n", "\n", " ", ""],
            token_counter=None  # 使用默认配置
        )
        naive_splitter = get_splitter(naive_splitter_config)

        # 短块配置的NaiveTextSplitter，用于对比不同分块设置的效果
        small_chunk_config = SplitterConfig(
            name="NaiveTextSplitter",
            chunk_size=200,  # 更小的块大小
            overlap_size=50,
            delimiters=["\n\n", "\n", " ", ""],
            token_counter=None  # 使用默认配置
        )
        small_chunk_splitter = get_splitter(small_chunk_config)

        # 分块和统计
        naive_chunks = naive_splitter.split(doc_data)
        small_chunks = small_chunk_splitter.split(doc_data)

        # 输出分块结果
        print("\n标准块大小分块器结果:")
        print(f"总块数: {len(naive_chunks)}")

        # 统计每个幻灯片的元素在多少个分块中出现
        slide_to_chunks_naive = _count_slide_distribution(
            naive_chunks, doc_data.doc_elements)
        print("\n各幻灯片内容被分布的块数 (标准块大小):")
        _print_slide_distribution(slide_to_chunks_naive)

        # 打印样本块内容
        print("\n标准块大小分块器样本块:")
        _print_sample_chunks(naive_chunks, doc_data.doc_elements)

        print("\n小块大小分块器结果:")
        print(f"总块数: {len(small_chunks)}")

        # 统计每个幻灯片的元素在多少个分块中出现
        slide_to_chunks_small = _count_slide_distribution(
            small_chunks, doc_data.doc_elements)
        print("\n各幻灯片内容被分布的块数 (小块大小):")
        _print_slide_distribution(slide_to_chunks_small)

        print("\n小块大小分块器样本块:")
        _print_sample_chunks(small_chunks, doc_data.doc_elements)

        # 验证两种配置下都能正确维护幻灯片边界
        naive_perfect_ratio = sum(
            1 for chunk_set in slide_to_chunks_naive.values()
            if len(chunk_set) == 1) / len(slide_to_chunks_naive)

        small_perfect_ratio = sum(
            1 for chunk_set in slide_to_chunks_small.values()
            if len(chunk_set) == 1) / len(slide_to_chunks_small)

        print(f"\n标准块大小完美分块率: {naive_perfect_ratio:.2f}")
        print(f"小块大小完美分块率: {small_perfect_ratio:.2f}")

        # 验证两种配置都能达到高比例的完美分块
        assert naive_perfect_ratio >= 0.9, (
            f"标准块大小完美分块率过低: {naive_perfect_ratio:.2f}")
        assert small_perfect_ratio >= 0.85, (
            f"小块大小完美分块率过低: {small_perfect_ratio:.2f}")

    @pytest.mark.mr_ci
    def test_title_extraction(self):
        """测试从PPTX文件中提取标题和验证分块中保留标题"""
        # 创建测试文档数据
        doc_data = self.create_test_doc_data()

        # 筛选标题元素
        titles = [
            elem for elem in doc_data.doc_elements
            if elem.type == DocElementType.TITLE
        ]
        assert len(titles) > 0, "应至少提取到一个标题"

        # 创建分块器
        splitter_config = SplitterConfig(name="NaiveTextSplitter",
                                         chunk_size=1024,
                                         overlap_size=100,
                                         delimiters=["\n\n", "\n", " ", ""],
                                         token_counter=None)
        splitter = get_splitter(splitter_config)

        # 分块处理
        chunks = splitter.split(doc_data)

        # 验证标题是否被保留在分块中
        title_ids = {title.doc_element_id for title in titles}
        title_in_chunks = set()

        for chunk in chunks:
            for title_id in title_ids:
                if title_id in chunk.doc_element_ids:
                    title_in_chunks.add(title_id)

        # 输出结果
        print(f"\n提取的标题数量: {len(titles)}")
        print(f"在分块中包含的标题数量: {len(title_in_chunks)}")

        # 验证所有标题都在分块中
        assert len(title_in_chunks) == len(title_ids), "不是所有标题都被保留在分块中"


def _count_slide_distribution(chunks, doc_elements):
    """统计每个幻灯片的内容被分布到多少个不同的块中"""
    slide_to_chunks = {}

    for i, chunk in enumerate(chunks):
        for elem_id in chunk.doc_element_ids:
            # 找到对应的幻灯片编号
            for elem in doc_elements:
                if elem.doc_element_id == elem_id:
                    slide_number = elem.meta_data.get("slide_number", 0)
                    if slide_number not in slide_to_chunks:
                        slide_to_chunks[slide_number] = set()
                    slide_to_chunks[slide_number].add(i)
                    break

    return slide_to_chunks


def _print_slide_distribution(slide_to_chunks):
    """打印幻灯片分布情况"""
    for slide_num in sorted(slide_to_chunks.keys()):
        chunks = slide_to_chunks[slide_num]
        print(f"  幻灯片 {slide_num}: 分布在 {len(chunks)} 个块中")


def _print_sample_chunks(chunks, doc_elements, sample_count=10):
    """打印样本块的内容"""
    for i, chunk in enumerate(chunks[:sample_count]):
        print(f"\n块 {i + 1} (长度: {len(chunk.text)} 字符):")
        # 只打印前100个字符
        print(f"文本预览: {chunk.text[:100]}..." if len(chunk.text) > 100 else f"文本预览: {chunk.text}")
        # 统计此块中包含的幻灯片编号
        slide_numbers = set()
        for elem_id in chunk.doc_element_ids:
            for elem in doc_elements:
                if elem.doc_element_id == elem_id:
                    slide_numbers.add(elem.meta_data.get("slide_number", 0))
                    break
        print(f"包含幻灯片编号: {sorted(slide_numbers)}")
        print(f"元数据: {chunk.meta_data}")


def create_sample_doc_data() -> DocData:
    """创建示例文档数据"""
    elements = []

    # 添加标题和内容
    elements.append(
        DocElement(doc_element_id="elem1",
                   type=DocElementType.TITLE,
                   text="示例文档",
                   meta_data={"title_level": 1}))
    elements.append(
        DocElement(doc_element_id="elem2",
                   type=DocElementType.TITLE,
                   text="第一章：简介",
                   meta_data={"title_level": 2}))
    elements.append(
        DocElement(doc_element_id="elem3",
                   type=DocElementType.TEXT,
                   text="这是第一章的内容。这里有一些文本，用于演示分块功能。" * 10))
    elements.append(
        DocElement(doc_element_id="elem4",
                   type=DocElementType.TITLE,
                   text="第二章：方法",
                   meta_data={"title_level": 2}))
    elements.append(
        DocElement(doc_element_id="elem5",
                   type=DocElementType.TEXT,
                   text="这是第二章的内容。这里介绍了一些方法和技术。" * 15))
    elements.append(
        DocElement(doc_element_id="elem6",
                   type=DocElementType.TEXT,
                   text="这是一些未被TOC引用的内容。" * 5))

    # 创建TOC结构
    # 首先创建子节点
    ch1 = TOCNode(title="第一章：简介",
                  level_str="0.1",
                  self_doc_element_ids=["elem2"],
                  children_doc_element_ids=["elem3"])
    ch2 = TOCNode(title="第二章：方法",
                  level_str="0.2",
                  self_doc_element_ids=["elem4"],
                  children_doc_element_ids=["elem5"])

    # 根节点包含所有文档元素ID
    root = TOCNode(
        title="ROOT",
        self_doc_element_ids=["elem1", "elem6"],
        children_doc_element_ids=["elem2", "elem3", "elem4", "elem5"])

    # 添加子节点到根节点
    root.children.append(ch1)
    root.children.append(ch2)

    # 创建文档数据
    return DocData(doc_id="doc1",
                   file_name="示例文档.md",
                   file_path="/path/to/示例文档.md",
                   doc_elements=elements,
                   doc_toc=root)


def create_toc_direct_elem_test_data() -> DocData:
    """创建用于测试直接元素与子节点合并的文档数据"""
    elements = []

    # 添加标题和内容
    elements.append(
        DocElement(doc_element_id="title1",
                   type=DocElementType.TITLE,
                   text="测试标题",
                   meta_data={"title_level": 1}))
    elements.append(
        DocElement(doc_element_id="direct1",
                   type=DocElementType.TEXT,
                   text="这是测试标题下的直接内容，应该可以与子标题合并。"))
    elements.append(
        DocElement(doc_element_id="subtitle1",
                   type=DocElementType.TITLE,
                   text="子标题1",
                   meta_data={"title_level": 2}))
    elements.append(
        DocElement(doc_element_id="subtext1",
                   type=DocElementType.TEXT,
                   text="这是子标题1的内容。"))
    elements.append(
        DocElement(doc_element_id="subtitle2",
                   type=DocElementType.TITLE,
                   text="子标题2",
                   meta_data={"title_level": 2}))
    elements.append(
        DocElement(doc_element_id="subtext2",
                   type=DocElementType.TEXT,
                   text="这是子标题2的内容。"))

    # 创建TOC结构
    # 根节点包含所有元素ID
    root = TOCNode(title="ROOT",
                   self_doc_element_ids=[],
                   children_doc_element_ids=[
                       "title1", "direct1", "subtitle1", "subtext1",
                       "subtitle2", "subtext2"
                   ])

    # 父节点包含其所有子元素
    main_title = TOCNode(title="测试标题",
                         level_str="0.1",
                         self_doc_element_ids=["title1", "direct1"],
                         children_doc_element_ids=[
                             "subtitle1", "subtext1", "subtitle2", "subtext2"
                         ],
                         num_tokens=60)

    # 子节点1
    sub1 = TOCNode(title="子标题1",
                   level_str="0.1.1",
                   self_doc_element_ids=["subtitle1"],
                   children_doc_element_ids=["subtext1"],
                   num_tokens=20)

    # 子节点2
    sub2 = TOCNode(title="子标题2",
                   level_str="0.1.2",
                   self_doc_element_ids=["subtitle2"],
                   children_doc_element_ids=["subtext2"],
                   num_tokens=20)

    # 构建树结构
    main_title.children.append(sub1)
    main_title.children.append(sub2)
    root.children.append(main_title)

    # 创建DocData
    # 创建DocElementCollection
    collection = DocElementCollection()
    for elem in elements:
        collection.append(elem)

    doc_data = DocData(doc_id="test_doc",
                       file_name="测试_直接元素合并.md",
                       file_path="/path/to/测试_直接元素合并.md",
                       doc_elements=collection,
                       doc_toc=root)

    return doc_data


if __name__ == '__main__':
    # 初始化KBX环境
    TestTextSplitter.setup_class()

    # 实例化单一测试类
    text_splitter_tests = TestTextSplitter()
    text_splitter_tests.setup_method()  # 初始化PPTX测试环境

    # 执行所有测试
    text_splitter_tests.test_constructor()
    text_splitter_tests.test_split_basic()
    text_splitter_tests.test_split_edge_cases()
    text_splitter_tests.test_split_various_elements()
    text_splitter_tests.test_split_text()
    text_splitter_tests.test_code_block_split()
    text_splitter_tests.test_table_split()
    text_splitter_tests.test_large_table_split()
    text_splitter_tests.test_manual_composition()
    text_splitter_tests.test_toc_workflow()
    text_splitter_tests.test_direct_elem_with_children_merge()
    text_splitter_tests.test_root_direct_elem_merge()
    text_splitter_tests.test_pptx_special_handling()
    text_splitter_tests.test_compare_splitters()
    text_splitter_tests.test_title_extraction()
