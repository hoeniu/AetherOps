import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys

sys.path.insert(0, ROOT_DIR)

import pytest
from kbx.common.prompt import get_category_prompts


class TestGetPrompt:
    @pytest.mark.mr_ci
    def test_get_prompt(self):
        prompts = get_category_prompts(category='structured')
        print(prompts)
        prompt = prompts['structured_index'].text.format(query="用户query")
        print(prompt)

        prompts = get_category_prompts(category='structured')
        text = prompts['structured_index'](template_type="text",
                                           query="用户query")
        print("text template test: ", text)

        prompts = get_category_prompts(category='structured')
        text = prompts['structured_index_jinja2_test'](template_type="jinja2",
                                                       query="用户query")
        print("jinja2 template test: ", text)
