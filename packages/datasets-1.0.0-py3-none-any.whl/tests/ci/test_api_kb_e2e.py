"""
接口测试：知识库相关 API
"""
import os
import pytest
import sys
from humanfriendly.text import random_string

# 根目录
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../..")
sys.path.insert(0, ROOT_DIR)
from tests.base_test_case import BaseTestCase
from kbx.common.logging import logger


class TestKBAPI(BaseTestCase):
    @pytest.fixture(scope="class", autouse=True)
    def setup_and_teardown_class(self, mock_data):
        # 初始化客户端和请求头
        TestKBAPI.client = mock_data.client
        TestKBAPI.headers = mock_data.headers
        yield

    @pytest.mark.mr_ci
    def test_create_kb(self):
        """测试创建知识库"""
        kb_name = "test-kb-" + random_string(6)
        payload = {"name": kb_name, "description": "测试知识库"}
        response = self.client.post(
            "/api/v1/create_kb",
            json=payload,
            headers=self.headers
        )
        assert response.status_code == 200
        data = response.json()
        assert data.get("kb_id")
        # 保存用于后续测试
        TestKBAPI.test_kb_id = data["kb_id"]
        logger.info(f"Created KB {TestKBAPI.test_kb_id}")

    @pytest.mark.mr_ci
    def test_list_kbs(self):
        """测试列出所有知识库"""
        response = self.client.get(
            "/api/v1/list_kbs",
            headers=self.headers
        )
        assert response.status_code == 200
        body = response.json()
        assert isinstance(body.get("total"), int)
        assert isinstance(body.get("data"), list)
        # 应至少包含刚创建的知识库
        ids = [kb.get("kb_id") for kb in body["data"]]
        assert TestKBAPI.test_kb_id in ids

    @pytest.mark.mr_ci
    def test_get_kb_detail(self):
        """测试获取知识库详情"""
        response = self.client.get(
            f"/api/v1/kb_detail?kb_id={TestKBAPI.test_kb_id}",
            headers=self.headers
        )
        assert response.status_code == 200
        info = response.json()
        assert info.get("kb_id") == TestKBAPI.test_kb_id
        assert info.get("user_id")
        assert info.get("kb_config")

    @pytest.mark.mr_ci
    def test_modify_kb_config(self):
        """测试修改知识库配置"""
        new_desc = "修改后的描述-" + random_string(4)
        new_config = {"name": f"mod-kb-{random_string(4)}", "description": new_desc}
        response = self.client.post(
            f"/api/v1/modify_kb_config?kb_id={TestKBAPI.test_kb_id}",
            json=new_config,
            headers=self.headers
        )
        assert response.status_code == 200
        body = response.json()
        assert body.get("kb_id") == TestKBAPI.test_kb_id
        assert body.get("kb_config", {}).get("description") == new_desc

    @pytest.mark.mr_ci
    def test_remove_kb(self):
        """测试删除知识库"""
        response = self.client.post(
            f"/api/v1/remove_kb?kb_id={TestKBAPI.test_kb_id}",
            headers=self.headers
        )
        assert response.status_code == 200
        body = response.json()
        assert body.get("kb_id") == TestKBAPI.test_kb_id
        assert "message" in body
