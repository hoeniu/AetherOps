import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import pytest
from tests.base_test_case import BaseTestCase
from kbx.common.utils import get_pydantic_config_changes
from kbx.common.types import DocFileType
from kbx.knowledge_base.types import KBCreationConfig, DocParseConfig, \
    SplitterConfig, VectorKeywordIndexConfig, KnowledgeGraphIndexConfig


class TestPydanticConfigChanges(BaseTestCase):
    @pytest.mark.mr_ci
    def test_case1(self):
        kb_config1 = KBCreationConfig()
        kb_config2 = KBCreationConfig()

        diff = get_pydantic_config_changes(kb_config1, kb_config2)

        assert diff == {}

    @pytest.mark.mr_ci
    def test_case2(self):
        kb_config1 = KBCreationConfig()
        kb_config2 = VectorKeywordIndexConfig()

        try:
            _ = get_pydantic_config_changes(kb_config1, kb_config2)
        except ValueError:
            pass

    @pytest.mark.mr_ci
    def test_case3(self):
        kb_config1 = KBCreationConfig(
            name='测试知识库',
            description='测试知识库描述',
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "DefaultPdfParser",
                    DocFileType.TXT: "DefaultTxtParser"
                }
            ),
            kg_config=KnowledgeGraphIndexConfig(
                index_strategy="DefaultGraphIndex",
                llm_model="doubao-1.5-pro-32k",
                embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                ),
                schema_dict={},
            ),
        )
        kb_config2 = KBCreationConfig(
            name='测试知识库',
            description='测试知识库描述',
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "DefaultPdfParser",
                    DocFileType.TXT: "DefaultTxtParser"
                }
            ),
            kg_config=KnowledgeGraphIndexConfig(
                index_strategy="DefaultGraphIndex",
                llm_model="doubao-1.5-pro-32k",
                embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                ),
                schema_dict={},
            ),
        )
        expected_diff = {}

        diff = get_pydantic_config_changes(kb_config1, kb_config2)
        assert diff == expected_diff

        kb_config2.name = '测试知识库2'
        expected_diff['name'] = kb_config2.name
        diff = get_pydantic_config_changes(kb_config1, kb_config2)
        assert diff == expected_diff

        kb_config2.doc_parse_config.file_parsers[DocFileType.PPTX] = 'DefaultPptxParser'
        # 非递归版
        diff = get_pydantic_config_changes(kb_config1, kb_config2, recursive=False)
        expected_diff['doc_parse_config'] = kb_config2.doc_parse_config
        assert diff == expected_diff
        # 递归版
        expected_recursive_diff = expected_diff.copy()
        expected_recursive_diff['doc_parse_config'] = {'file_parsers': kb_config2.doc_parse_config.file_parsers}
        recursive_diff = get_pydantic_config_changes(kb_config1, kb_config2, recursive=True)
        assert recursive_diff == expected_recursive_diff, f'{recursive_diff}!= {expected_recursive_diff}'

        kb_config2.kg_config.splitter_config.name = 'AwesomeSplitter'
        expected_recursive_diff['kg_config'] = {'splitter_config': {'name': kb_config2.kg_config.splitter_config.name}}
        recursive_diff = get_pydantic_config_changes(kb_config1, kb_config2, recursive=True)
        assert recursive_diff == expected_recursive_diff, f'{recursive_diff} != {expected_recursive_diff}'


if __name__ == '__main__':
    test = TestPydanticConfigChanges()
    test.test_case1()
    test.test_case2()
    test.test_case3()
