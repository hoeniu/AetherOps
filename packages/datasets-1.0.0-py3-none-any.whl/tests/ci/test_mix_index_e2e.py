import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import json
from tests.base_test_case import BaseTestCase

import pytest
from kbx.common.types import KBXError
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, DeepThinkConfig, \
    SplitterConfig, QueryConfig, VectorKeywordIndexConfig, QueryResults
from kbx.knowledge_base.graph.default_graph_index import KnowledgeGraphIndexConfig
from kbx.knowledge_base.structured.default_structured_index import StructuredIndexConfig
from kbx.rerank.types import RerankConfig
from kbx.knowledge_base.dynamic_doc.default_dynamic_doc_index import DynamicDocIndexConfig


class TestMixIndexE2E(BaseTestCase):
    def setup_method(self):
        self._kb_name = "混合索引测试知识库"
        self._kb_description = "这是一个混合索引测试知识库，同时配置四种索引"

        with open(os.path.join(ROOT_DIR, "tests/schema/schema.json"), encoding="utf-8") as fd:
            self._schema_dict = json.load(fd)

    @pytest.mark.no_ci
    def test_std_case(self):
        # index configs
        structured_config = StructuredIndexConfig(
            index_strategy="DefaultStructuredIndex",
            llm_model="volcengine-deepseek-v3",
            sql_gen_llm_model="volcengine-deepseek-v3",
        )
        vector_keyword_config = VectorKeywordIndexConfig(
            index_strategy="DefaultVectorKeywordIndex",
            text_embedding_model="doubao-embedding",
            splitter_config=SplitterConfig(name="RecursiveTextSplitter", chunk_size=1024),
            keyword_extractor="jieba",
            max_keywords_per_chunk=100,
        )
        kg_config = KnowledgeGraphIndexConfig(
            index_strategy="DefaultGraphIndex",
            llm_model="volcengine-deepseek-v3",
            embedding_model="doubao-embedding",
            splitter_config=SplitterConfig(
                name="NaiveTextSplitter",
                delimiters=["\n\n"],
            ),
            schema_dict=self._schema_dict,
        )
        dynamic_doc_config = DynamicDocIndexConfig(
            index_strategy='DefaultDynamicDocIndex',
        )

        kb_config_without_rerank = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            structured_config=structured_config,
            vector_keyword_config=vector_keyword_config,
            kg_config=kg_config,
            dynamic_doc_config=dynamic_doc_config,
        )

        kb_config_with_rerank = kb_config_without_rerank.model_copy(
            update={"rerank_config": RerankConfig(
                name="ModelRerank",
                kwargs={"model": "BAAI/bge-reranker-v2-m3"},
            )}
        )

        kb_configs = [kb_config_without_rerank, kb_config_with_rerank]
        for kb_config in kb_configs:
            try:
                # 如果已经存在，尝试进行旧数据删除
                # previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
                # previous_kb.remove_kb()
                kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
                kb_name2id = dict([(item.name, item.kb_id) for item in kbs_info])
                existed_kb_id = kb_name2id.get(kb_config.name, None)
                if existed_kb_id:
                    # 已经存在，尝试从DB中读取
                    print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
                    kb = KBX.get_existed_kb(kb_id=existed_kb_id)
                else:
                    # 未存在，尝试创建
                    print(f'Try to create new kb {kb_config.name} (id={existed_kb_id})')
                    kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

                    results = kb.insert_docs(
                        file_list=[
                            os.path.join(self.test_data_dir, '上海GDP数据.csv'),
                            os.path.join(self.test_data_dir, '中国平安.txt'),
                        ]
                    )
                    if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
                        raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

            except RuntimeError:
                pass

            # 使用知识库直接查询
            query1 = QueryConfig(
                text="上海2024年哪个月的GDP最高，数值是多少？",
                top_k=5,
                score_threshold=0.0,
            )
            query2 = QueryConfig(
                text="中国平安的高管有哪些？",
                top_k=5,
                score_threshold=0.0,
                deep_think=DeepThinkConfig(
                    llm_model="doubao-1.5-pro-256k",
                ),
            )
            queries = [query1, query2]
            for query in queries:
                # 使用KBX在顶层进行查询
                print(f"\n\n****************** query = {query.text} ****************** ")
                query_results = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
                assert isinstance(query_results, QueryResults), \
                    f"Query result should be a QueryResults object, given {type(query_results)}"
                assert isinstance(query_results.results, list), \
                    f"Retrieval results should be a list, given {type(query_results.results)}"
                assert len(query_results) > 0, "Failed to get query result"

                for k, qr in enumerate(query_results):
                    print(f'--------------- # {k} ---- index type: {qr.index_type} -------------')
                    if qr.structured_result:
                        print(f"SQL: {qr.structured_result.sql}")
                    print(f"Result: {qr.try_get_content_as_str()}")
                    print(f"Score: {qr.score}\n")


if __name__ == "__main__":
    # 手动执行
    test_case = TestMixIndexE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_std_case()
