import os

from kbx.common.utils import generate_new_id
from tests.base_test_case import BaseTestCase
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

import pytest


class TestTenantAPI(BaseTestCase):
    @pytest.fixture(scope="class", autouse=True)
    def setup_method(self, mock_data):
        TestTenantAPI.client = mock_data.client
        TestTenantAPI.tenant_id = generate_new_id()

    @pytest.mark.mr_ci
    def test_create_tenant(self):
        response = self.client.post(
            "/api/v1/tenants/",
            json={"name": "test_tenant", "desired_tenant_id": TestTenantAPI.tenant_id}
        )
        assert response.status_code == 201
        TestTenantAPI.tenant_id = response.json()
        assert isinstance(TestTenantAPI.tenant_id, str)

    @pytest.mark.mr_ci
    def test_get_tenant(self):
        response = self.client.get(
            f"/api/v1/tenants/{TestTenantAPI.tenant_id}",
        )
        assert response.status_code == 200
        assert response.json() == {"id": TestTenantAPI.tenant_id, "name": "test_tenant"}

    @pytest.mark.mr_ci
    def test_update_tenant(self):
        response = self.client.put(
            f"/api/v1/tenants/{TestTenantAPI.tenant_id}",
            json={"name": "new_name"}
        )
        assert response.status_code == 200
        assert response.json() == {"id": TestTenantAPI.tenant_id, "name": "new_name"}

    @pytest.mark.mr_ci
    def test_list_tenants(self):
        response = self.client.get(
            "/api/v1/tenants/",
        )
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert any(item.get("id") == TestTenantAPI.tenant_id for item in data)

    @pytest.mark.mr_ci
    def test_delete_tenant(self):
        response = self.client.delete(
            f"/api/v1/tenants/{TestTenantAPI.tenant_id}",
        )
        assert response.status_code == 204

    @pytest.mark.mr_ci
    def test_get_tenant_not_found(self):
        response = self.client.get(
            "/api/v1/tenants/non_existent",
        )
        assert response.status_code == 404

    @pytest.mark.mr_ci
    def test_create_tenant_already_exists(self):
        # 创建已存在的租户名
        self.client.post(
            "/api/v1/tenants/",
            json={"name": "duplicate_tenant", "desired_tenant_id": "dup_id"}
        )
        response = self.client.post(
            "/api/v1/tenants/",
            json={"name": "duplicate_tenant"}
        )
        assert response.status_code == 400

    @pytest.mark.mr_ci
    def test_update_tenant_not_found(self):
        response = self.client.put(
            "/api/v1/tenants/non_existent",
            json={"name": "x"}
        )
        assert response.status_code == 404

    @pytest.mark.mr_ci
    def test_delete_tenant_not_found(self):
        response = self.client.delete(
            "/api/v1/tenants/non_existent",
        )
        assert response.status_code == 404
