import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)
import pytest
from tests.base_test_case import BaseTestCase
from kbx.common.utils import generate_new_id
from kbx.common.constants import DEFAULT_USER_ID, DEFAULT_TENANT_ID, DEFAULT_TENANT_NAME, DEFAULT_USER_NAME
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, VectorKeywordIndexConfig, \
    SplitterConfig, RerankConfig


class TestKBXTenantUserE2E(BaseTestCase):
    def setup_method(self):
        self._vector_kb_config = KBCreationConfig(
            name='测试向量索引知识库',
            description='这是一个测试向量索引知识库',
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(name="RecursiveTextSplitter"),
                keyword_extractor="jieba",
                max_keywords_per_chunk=100,
            ),
            rerank_config=RerankConfig(
                name="ModelRerank",
                kwargs={"model": "BAAI/bge-reranker-v2-m3"},
            ),
        )

        self._tenant_id = generate_new_id()
        self._tenant_name = 'a_random_new_tenant'

        self._batch_tenant_num = 100
        self._batch_tenant_ids = []
        self._batch_tenant_names = []
        for i in range(self._batch_tenant_num):
            self._batch_tenant_ids.append(generate_new_id())
            self._batch_tenant_names.append(f'test_tenant_{i}')

        self._user_id = generate_new_id()
        self._user_name = 'a_random_new_user'

        self._batch_user_num = 100
        self._batch_user_ids = []
        self._batch_user_names = []
        for i in range(self._batch_user_num):
            self._batch_user_ids.append(generate_new_id())
            self._batch_user_names.append(f'test_user_{i}')

    def _try_remove_tenant(self, tenant_id: str = None, tenant_name: str = None):
        try:
            if tenant_id:
                KBX.remove_tenant(tenant_id=tenant_id)
        except ValueError:
            pass

        try:
            if tenant_name:
                tenant_info = KBX.get_tenant_info(tenant_name=tenant_name)
                KBX.remove_tenant(tenant_id=tenant_info.id)
        except ValueError:
            pass

    def _try_remove_user(self, tenant_id: str, user_id: str = None, user_name: str = None):
        try:
            if user_id:
                KBX.remove_user(user_id=user_id)
        except ValueError:
            pass

        try:
            if user_name:
                user_info = KBX.get_user_info(user_name=user_name, tenant_id=tenant_id)
                assert user_info.tenant_id == tenant_id
                KBX.remove_user(user_id=user_info.id)
        except ValueError:
            pass

    @pytest.mark.mr_ci
    def test_tenant_errors(self):
        with pytest.raises(ValueError):
            KBX.add_tenant(tenant_name=DEFAULT_TENANT_NAME)
        with pytest.raises(ValueError):
            KBX.add_tenant(tenant_name="random_xxqw_tenant", desired_tenant_id=DEFAULT_TENANT_ID)
        with pytest.raises(ValueError):
            KBX.get_tenant_info(tenant_id="id_does_not_exist")

    @pytest.mark.mr_ci
    def test_tenant(self):
        self._try_remove_tenant(tenant_id=self._tenant_id, tenant_name=self._tenant_name)

        # 指定tenant_id
        tenant_id = KBX.add_tenant(tenant_name=self._tenant_name, desired_tenant_id=self._tenant_id)
        assert tenant_id == self._tenant_id
        tenant_info = KBX.get_tenant_info(tenant_id=self._tenant_id)
        assert tenant_info.id == self._tenant_id
        assert tenant_info.name == self._tenant_name
        KBX.remove_tenant(tenant_id=tenant_id)

        # 不指定tenant_id，自动生成
        tenant_id = KBX.add_tenant(tenant_name=self._tenant_name)
        tenant_info = KBX.get_tenant_info(tenant_id=tenant_id)
        assert tenant_info.id == tenant_id
        assert tenant_info.name == self._tenant_name
        KBX.remove_tenant(tenant_id=tenant_id)

    @pytest.mark.mr_ci
    def test_tenant_batch(self):
        for i in range(self._batch_tenant_num):
            self._try_remove_tenant(tenant_id=self._batch_tenant_ids[i], tenant_name=self._batch_tenant_names[i])

        # 批量添加租户
        for i in range(self._batch_tenant_num):
            tenant_id = KBX.add_tenant(
                tenant_name=self._batch_tenant_names[i], desired_tenant_id=self._batch_tenant_ids[i])
            assert tenant_id == self._batch_tenant_ids[i]

        # 批量获取租户信息
        all_tenant_list = []
        offset = 0
        limit = 8
        while True:
            tenant_list = KBX.list_tenants(offset=offset, limit=limit)
            # 过滤非本次测试的租户
            all_tenant_list.extend([tenant for tenant in tenant_list if tenant.name in self._batch_tenant_names])
            assert len(tenant_list) <= limit

            if len(tenant_list) < limit:
                break
            offset += len(tenant_list)
        assert len(all_tenant_list) == self._batch_tenant_num
        for i in range(self._batch_tenant_num):
            tenant_info = all_tenant_list[i]
            index = self._batch_tenant_names.index(tenant_info.name)
            assert self._batch_tenant_ids[index] == tenant_info.id

        for i in range(self._batch_tenant_num):
            self._try_remove_tenant(tenant_id=self._batch_tenant_ids[i], tenant_name=self._batch_tenant_names[i])

    @pytest.mark.mr_ci
    def test_user_errors(self):
        with pytest.raises(ValueError):
            KBX.add_user(user_name=DEFAULT_USER_NAME, tenant_id=DEFAULT_TENANT_ID)
        with pytest.raises(ValueError):
            KBX.add_user(user_name=self._user_name, tenant_id="tenant_does_not_exists")
        with pytest.raises(ValueError):
            KBX.add_user(user_name=self._user_name, tenant_id=DEFAULT_TENANT_ID, desired_user_id=DEFAULT_USER_ID)

    @pytest.mark.mr_ci
    def test_user(self):
        self._try_remove_user(tenant_id=self._tenant_id, user_id=self._user_id, user_name=self._user_name)

        # 先添加租户
        tenant_id = KBX.add_tenant(tenant_name=self._tenant_name, desired_tenant_id=self._tenant_id)
        assert tenant_id == self._tenant_id
        tenant_info = KBX.get_tenant_info(tenant_id=self._tenant_id)

        # 添加用户，并指定user_id
        user_id = KBX.add_user(user_name=self._user_name, tenant_id=tenant_info.id, desired_user_id=self._user_id)
        assert user_id == self._user_id
        user_info1 = KBX.get_user_info(tenant_id=tenant_info.id, user_id=self._user_id)
        user_info2 = KBX.get_user_info(tenant_id=tenant_info.id, user_name=self._user_name)
        assert user_info1 == user_info2
        assert user_info1.name == self._user_name
        assert user_info1.id == self._user_id
        assert user_info1.tenant_id == tenant_info.id
        KBX.remove_user(user_id=user_id)

        # 添加用户，不指定user_id
        user_id = KBX.add_user(user_name=self._user_name, tenant_id=tenant_info.id)
        user_info1 = KBX.get_user_info(tenant_id=tenant_info.id, user_id=user_id)
        user_info2 = KBX.get_user_info(tenant_id=tenant_info.id, user_name=self._user_name)
        assert user_info1 == user_info2
        assert user_info1.name == self._user_name
        assert user_info1.id == user_id
        assert user_info1.tenant_id == tenant_info.id
        KBX.remove_user(user_id=user_id)

    @pytest.mark.mr_ci
    def test_user_batch(self):
        self._try_remove_tenant(tenant_id=self._tenant_id, tenant_name=self._tenant_name)
        for i in range(self._batch_user_num):
            self._try_remove_user(
                tenant_id=self._tenant_id,
                user_id=self._batch_user_ids[i],
                user_name=self._batch_user_names[i]
            )

        # 先添加租户
        tenant_id = KBX.add_tenant(tenant_name=self._tenant_name, desired_tenant_id=self._tenant_id)

        # 批量添加用户
        for i in range(self._batch_user_num):
            # print(f'Try to add user {i}')
            user_id = KBX.add_user(
                user_name=self._batch_user_names[i],
                tenant_id=tenant_id,
                desired_user_id=self._batch_user_ids[i]
            )
            assert user_id == self._batch_user_ids[i]

            # 注册模型配置
            KBX.register_ai_models_from_conf(self.ai_models_yaml_file, overwrite=True, user_id=user_id)
            config, client = KBX.get_ai_model_config_and_client(name="doubao-1.5-pro-32k", user_id=user_id)

            # 创建知识库
            kb = KBX.create_new_kb(kb_config=self._vector_kb_config, user_id=user_id)
            assert kb.kb_id is not None
            assert kb.user_id == user_id

        # 批量获取用户信息
        all_user_list = []
        offset = 0
        limit = 8
        while True:
            user_list = KBX.list_users(tenant_id=tenant_id, offset=offset, limit=limit)
            # 过滤非本次测试的用户
            all_user_list.extend([user for user in user_list if user.name in self._batch_user_names])
            assert len(user_list) <= limit
            if len(user_list) < limit:
                break
            offset += len(user_list)
        assert len(all_user_list) == self._batch_user_num
        for i in range(self._batch_user_num):
            user_info = all_user_list[i]
            index = self._batch_user_names.index(user_info.name)
            assert self._batch_user_ids[index] == user_info.id

        KBX.remove_tenant(tenant_id=tenant_id)


if __name__ == '__main__':
    # 手动执行
    test_case = TestKBXTenantUserE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_tenant_errors()
    test_case.test_tenant()
    test_case.test_tenant_batch()
    test_case.test_user_errors()
    test_case.test_user()
    test_case.test_user_batch()
