import json
import os
from kbx.common.types import KBXGlobalConfig, GraphDSConfig, KeywordDSConfig, \
    DocDSConfig, FileDSConfig, KeywordDSConfig, StructuredDSConfig
from kbx.knowledge_base.graph.default_graph_index import DefaultGraphIndex
from kbx.knowledge_base.types import KnowledgeGraphIndexConfig
from kbx.parser.parser_factory import get_parser
from kbx.parser.types import DocParseConfig

from kbx.kbx import KBX

if __name__ == '__main__':

    '''进行必要的初始化参数配置'''
    kbx_config = KBXGlobalConfig()
    '''使用上述全局配置进行KBX初始化'''
    kbx_config.work_dir = 'data'
    kbx_config.graph_ds = GraphDSConfig(type="networkx")
    kbx_config.doc_ds = DocDSConfig(type="nano_docsystem")
    kbx_config.file_ds = FileDSConfig(
        type='nano_filesystem',
        connection_kwargs={
            'root_dir': os.path.join(kbx_config.work_dir, 'files'),
        }
    )
    kbx_config.keyword_ds = KeywordDSConfig(
        type='es',
        connection_kwargs={
            'host': '127.0.0.1',
            'port': '12345',
        }
    )
    kbx_config.structured_ds = StructuredDSConfig(type='sqlite', connection_kwargs={
        "db_path": '/home/rain/test_sqlite.db',
    })
    KBX.init(kbx_config)

    parser = get_parser("DefaultTxtParser", DocParseConfig())
    doc_data = parser.parse("tests/graph_input_docs/中国平安.txt", "fgasdjghkafjghieuqr29347193824fjshf")
    schema = json.load(open('tests/schema/schema.json', 'r'))
    index = DefaultGraphIndex('test_insert', KnowledgeGraphIndexConfig(schema_dict=schema))
    index.insert_docs(doc_data)
