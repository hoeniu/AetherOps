import logging
import os
import sys

# 初始化KBX
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
# 添加项目根目录到PATH
sys.path.insert(0, ROOT_DIR)
from kbx.kbx import KBX
import pytest
from celery import Celery


@pytest.fixture(scope="session")
def setup_logging():
    """配置日志"""
    logging.basicConfig(level=logging.INFO)


@pytest.fixture(scope="session", autouse=True)
def init_kbx():
    """初始化KBX"""
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    KBX.init(config=kbx_yaml_file)
    logging.info("KBX initialized")


@pytest.fixture(scope="class")
def celery_app():
    """初始化Celery应用"""
    # app = Celery('tasks', broker="sqla+sqlite:///celery.sqlite", backend="db+sqlite:///celery.sqlite")
    app = Celery('tasks', broker=KBX.config.celery.broker_url,
                 backend=KBX.config.celery.result_backend)
    return app


class TestTenantTask:
    tenant_id = None
    user_id = None

    @classmethod
    def setup_class(cls):
        # 创建测试租户
        cls.tenant_name = 'test_tenant'
        tenant_id = KBX.add_tenant(cls.tenant_name)
        assert tenant_id is not None
        TestTenantTask.tenant_id = tenant_id
        # 创建测试用户
        user_id = KBX.add_user('test_user', tenant_id)
        assert user_id is not None
        TestTenantTask.user_id = user_id

    @classmethod
    def teardown_class(cls):
        # 存在则删除测试用户
        if TestTenantTask.user_id:
            KBX.remove_user(TestTenantTask.user_id)
        # 存在则删除测试租户
        if TestTenantTask.tenant_id:
            KBX.remove_tenant(TestTenantTask.tenant_id)

    @pytest.mark.order(1)
    def test_remove_user(self, celery_app):
        result = celery_app.send_task('kbx.tasks.tenant_task.remove_user', args=[TestTenantTask.user_id])
        assert result is not None
        TestTenantTask.user_id = None

    @pytest.mark.order(2)
    def test_remove_tenant(self, celery_app):
        result = celery_app.send_task('kbx.tasks.tenant_task.remove_tenant', args=[TestTenantTask.tenant_id])
        assert result is not None
        TestTenantTask.tenant_id = None
