import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)

import json
from tests.base_test_case import BaseTestCase
from kbx.common.types import GraphDSConfig
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, SplitterConfig, \
    KnowledgeGraphIndexConfig, QueryConfig, QueryResults


class TestGraphIndexScanerE2E(BaseTestCase):
    def setup_method(self):
        with open(os.path.join(ROOT_DIR, "tests/schema/schema_industry.json")) as fd:
            self._schema_dict = json.load(fd)

    def test_std_case(self):
        kb_name = "思谋智能读码器知识库"
        kb_description = "这是思谋智能读码器知识库，包含各种智能读码器知识信息。"
        graph_ds_config = GraphDSConfig(type='networkx',
                                        connection_kwargs={
                                            "graphml_file": "./cache/smore.graphml"})
        kb_config = KBCreationConfig(
            name=kb_name,
            description=kb_description,
            is_external_datastore=False,
            kg_config=KnowledgeGraphIndexConfig(
                index_strategy="DefaultGraphIndex",
                llm_model="doubao-1.5-pro-256k",
                embedding_model="BAAI/bge-m3",
                schema_dict=self._schema_dict,
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                ),
                external_graph_ds=graph_ds_config
            ),
        )
        kb = None
        try:
            # 如果已经存在，尝试进行旧数据删除
            kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
        except RuntimeError:
            pass
        if not kb:
            kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        kb.modify_kb_config(kb_config)
        assert kb.kb_config.kg_config.llm_model == "doubao-1.5-pro-256k"
        # 使用知识库直接查询
        query = QueryConfig(
            text="思谋vs500和VG800P智能读码器有哪些区别？",
            top_k=20,
            score_threshold=0.1,
        )
        query_result = kb.retrieve(query=query)
        assert isinstance(query_result, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_result)}"
        assert isinstance(query_result.results, list), \
            f"Retrieval results should be a list, given {type(query_result.results)}"
        assert len(query_result) > 0, "Failed to get query result"
        if query.top_k > 0:
            assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                                                     f"given {query.top_k} and {len(query_result)}"

        print(f'Get {len(query_result)} results from kb ("{kb.kb_config.name}")')
        for k, qr in enumerate(query_result):
            print(f'------------------------- #{k}, score={qr.score} -------------------------')
            print(qr.graph_triplets)
            print(qr.subgraph_options)
        # result = kb.reindex(kb.list_doc_ids())
        # print(result)


if __name__ == "__main__":
    # 手动执行
    test_case = TestGraphIndexScanerE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_std_case()
