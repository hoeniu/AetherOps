import json
import os
import re
import time
from math import isnan

import pandas
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, KnowledgeGraphIndexConfig
from kbx.splitter.types import SplitterConfig

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')


def setup(schema):
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    KBX.init(config=kbx_yaml_file)
    ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
    KBX.register_ai_models_from_conf(ai_models_yaml_file, overwrite=True, user_id=DEFAULT_USER_ID)
    # schema = json.load(open(schemapath, 'r'))
    kb_config = KBCreationConfig(
        name='enterprise_test11',
        description='',
        is_external_datastore=False,
        kg_config=KnowledgeGraphIndexConfig(
            index_strategy="DefaultGraphIndex",
            llm_model="doubao-1.5-pro-32k",
            embedding_model="doubao-embedding",
            schema_dict=schema,
            splitter_config=SplitterConfig(
                name="NaiveTextSplitter",
                delimiters=["\n\n"],
            ),
        ),
    )
    kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
    kb_name2id = dict([(item.name, item.kb_id) for item in kbs_info])
    existed_kb_id = kb_name2id.get(kb_config.name, None)
    if existed_kb_id:
        # 已经存在，尝试从DB中读取
        print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.get_existed_kb(kb_id=existed_kb_id)
    else:
        # 未存在，尝试创建
        print(f'Try to restore new kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
    ds = kb.index_map['knowledge_graph'].data_store
    return ds


def escape(text):
    return re.sub(u'[^\u0020-\uD7FF\u0009\u000A\u000D\uE000-\uFFFD\U00010000-\U0010FFFF]+', '', text)


def to_attr(attr, schema, name_attr_map):
    node_attr = {}
    for k, v in attr.items():
        if k in name_attr_map and v and (isinstance(v, str) or not isnan(v)):
            node_attr[name_attr_map[k]] = escape(str(v))
    return node_attr


def location_to_name(attr, code_location_map):
    if '注册省份' in attr and attr['注册省份'] in code_location_map:
        attr['注册省份'] = code_location_map[attr['注册省份']]
    if '注册城市' in attr and attr['注册城市'] in code_location_map:
        attr['注册城市'] = code_location_map[attr['注册城市']]
    return attr


def get_level_from_code(code):
    if code.endswith('0000'):
        return '0'
    elif code.endswith('00'):
        return '1'
    else:
        return '2'


def get_superior_code(code, code_id_map):
    if code.endswith('0000'):
        return None
    elif code.endswith('00'):
        return code[0:2] + '0000'
    else:
        if code[0:4] + '00' in code_id_map:
            return code[0:4] + '00'
        else:
            return code[0:2] + '0000'


def formal_location_name(code_name_map, province, city=None):
    if city is None:
        for code, name in code_name_map.items():
            if code.endswith('0000') and name.startswith(province):
                return (code, name), (None, None)
        print(province, city)
        return None, None
    else:
        for code, name in code_name_map.items():
            if name.startswith(city):
                superior_code = get_superior_code(code, code_name_map)
                if superior_code and not superior_code.endswith('0000'):
                    superior_code = get_superior_code(superior_code, code_name_map)
                if (not superior_code) and name.startswith(city) and name.startswith(province):
                    return (code, name), (code, name)
                elif superior_code and code_name_map[superior_code].startswith(province):
                    return (superior_code, code_name_map[superior_code]), (code, name)
                else:
                    print(superior_code, code, name, province, city)
        return None, None


if __name__ == '__main__':
    filenames = [
        "../enterprise_process/csv/data_listed.csv",
        "../enterprise_process/csv/md_institution_1.csv",
        "../enterprise_process/csv/md_institution_2.csv",
        "../enterprise_process/csv/md_institution_3.csv",
        "../enterprise_process/csv/md_institution_4.csv",
        "../enterprise_process/csv/md_institution_5.csv",
        "../enterprise_process/csv/md_institution_6.csv",
        "../enterprise_process/csv/md_institution_7.csv",
    ]
    with open('./tests/schema/schema.json', 'r') as fp:
        schema = json.load(fp)
        print(schema)
    ds = setup(schema)
    code_location_data = pandas.read_csv('../enterprise_process/行政区代码表.csv', dtype={'code': str, 'name': str})
    code_location_map = {}
    code_id_map = {}
    for i in range(len(code_location_data)):
        code_location_map[code_location_data.iloc[i]['code']] = code_location_data.iloc[i]['name']
        start_time = time.time()
        k = ds.insert_node({"名称": code_location_data.iloc[i]['name'], '代码': code_location_data.iloc[i]['code'],
                           '级别': get_level_from_code(code_location_data.iloc[i]['code']), '类型': '地区'})
        end_time = time.time()
        print(i, "th insert data", code_location_data.iloc[i]['name'], f"cost: {end_time - start_time} s")
        code_id_map[code_location_data.iloc[i]['code']] = k
        superior_code = get_superior_code(code_location_data.iloc[i]['code'], code_id_map)
        if superior_code:
            superior_id = code_id_map[superior_code]
            start_time = time.time()
            ds.insert_edge(superior_id, k, {"类型": "下级"})
            ds.insert_edge(k, superior_id, {"类型": "上级"})
            end_time = time.time()
            print(i, f"th insert edge {superior_id} -> {k}", code_location_data.iloc[i]['name'],
                  f"cost: {end_time - start_time} s")
    print(code_location_map)
    name_attr_map = {
        'PARTY_ID': '代码',
        'PARTY_FULL_NAME': '名称',
        'PARTY_SHORT_NAME': '简称',
        'PARTY_SHORT_NAME_EN': '英文简称',
        'OFFICE_ADDR': '办公地址',
        'PRIME_OPERATING': '主营业务',
        'INST_STATUS': '状态',
        'REG_DATE': '注册日期',
        'REG_COUNTRY_CD': '国籍',
        'REG_PROVINCE': '注册省份',
        'REG_CITY': '注册城市',
        'REG_ADDR': '注册地址',
        'REG_CAP': '注册资金',
        'REG_CAP_CURR_CD': '注册资金币种',
        'WEBSITE': '网站',
        'OPA_SCOPE': '经营范围',
        'PROFILE': '介绍',
        'PARTY_FULL_NAME_EN': '英文名称',
        'EMAIL': '邮箱',
        'TEL': '电话',
        'FAX': '传真',
        'LEGAL_ENTITY_ID': '工商登记号',
        'CLOSE_DATE': '终止日期',
    }
    dtype = {
        'PARTY_ID': str,
        'PARTY_FULL_NAME': str,
        'PARTY_SHORT_NAME': str,
        'PARTY_SHORT_NAME_EN': str,
        'OFFICE_ADDR': str,
        'PRIME_OPERATING': str,
        'INST_STATUS': str,
        'REG_DATE': str,
        'REG_COUNTRY_CD': str,
        'REG_PROVINCE': str,
        'REG_CITY': str,
        'REG_ADDR': str,
        'REG_CAP': str,
        'REG_CAP_CURR_CD': str,
        'WEBSITE': str,
        'OPA_SCOPE': str,
        'PROFILE': str,
        'PARTY_FULL_NAME_EN': str,
        'EMAIL': str,
        'TEL': str,
        'FAX': str,
        'LEGAL_ENTITY_ID': str,
        'CLOSE_DATE': str,
    }
    name_node_map = {
        'LEGAL_REP': '法定代表人',
        'BOARD_SECRY': '董事会秘书',
    }
    industry_node_info = {
        "INDUSTRYCSRC1": "所属行业",
        # "INDUSTRYCSRC2": "所属行业",
    }
    for filename in filenames:
        print("Process file", filename)
        data = pandas.read_csv(filename, dtype=dtype)
        data.columns = list(map(lambda x: x.upper(), data.columns))
        # print(data.columns)
        for i in range(len(data)):
            # print(dict(data.iloc[i]))
            attr = dict(data.iloc[i])
            n_attr = to_attr(attr, schema, name_attr_map)
            n_attr['类型'] = '企业'
            n_attr = location_to_name(n_attr, code_location_map)
            # network.add_node(k, **n_attr)
            if '名称' not in n_attr:
                print(n_attr)
                print(data.iloc[i])
            start_time = time.time()
            node_id = ds.upsert_node(n_attr, properties_for_search={'名称': n_attr['名称']},
                                     override_when_exists=False, align_method='same_properties')
            end_time = time.time()
            print(i, "th upsert data", n_attr, f"cost: {end_time - start_time} s")
            enterprise_id = node_id
            start_time = time.time()
            if '注册省份' in n_attr:
                # network.add_edge(k, code_id_map[attr['注册省份']], **{"类型": "位置"})
                f_province, f_city = formal_location_name(code_location_map, n_attr['注册省份'])
                # print(f"Formal location {f_province}")
                if f_province and f_province[0] in code_id_map:
                    # print(f"Upsert edge {f_province}")
                    ds.upsert_edge(enterprise_id, code_id_map[f_province[0]], {"类型": "位置"}, {"类型": "位置"})
            if '注册省份' in n_attr and '注册城市' in n_attr:
                # network.add_edge(k, code_id_map[attr['注册城市']], **{"类型": "位置"})
                f_province, f_city = formal_location_name(code_location_map, n_attr['注册省份'], n_attr['注册城市'])
                # print(f"Formal location {f_province}, {f_city}")
                if f_city and f_city[0] in code_id_map:
                    # print(f"Upsert edge {f_province}, {f_city}")
                    ds.upsert_edge(enterprise_id, code_id_map[f_city[0]], {"类型": "位置"}, {"类型": "位置"})
            end_time = time.time()
            print(i, f"th upsert edge {enterprise_id}", {"类型": "位置"}, f"cost: {end_time - start_time} s")
            # add person nodes
            for p, v in name_node_map.items():
                if p in attr and v and attr[p] and (isinstance(attr[p], str) or not isnan(attr[p])):
                    # network.add_node(k, **{"名称": escape(str(attr[p])), '类型': "人"})
                    rep_type = '人'
                    align_method = 'same_edges'
                    if attr[p].endswith("公司") or attr[p].endswith("(有限合伙)"):
                        rep_type = '企业'
                        align_method = 'same_properties'
                    person_attr = {"名称": escape(str(attr[p])), '类型': rep_type}
                    person_enterprise_relation = {"类型": "任职", "职位": escape(str(v))}
                    align_edges = [[person_attr, {"类型": "任职"}, {'名称': n_attr['名称']}]]
                    start_time = time.time()
                    node_id = ds.upsert_node(person_attr,
                                             properties_for_search=person_attr,
                                             override_when_exists=True,
                                             align_method=align_method,
                                             edges_for_alignment=align_edges)
                    end_time = time.time()
                    print(i, "th upsert data", person_attr, f"cost: {end_time - start_time} s")
                    person_id = node_id
                    start_time = time.time()
                    # network.add_edge(k, enterprise_id, **person_enterprise_relation)
                    ds.upsert_edge(person_id, enterprise_id, person_enterprise_relation, person_enterprise_relation)
                    end_time = time.time()
                    print(i, f"th upsert edge {person_id}->{enterprise_id}", person_enterprise_relation,
                          f"cost: {end_time - start_time} s")
            # add industry nodes
            for p, v in industry_node_info.items():
                if p in attr and v and attr[p] and (isinstance(attr[p], str) or not isnan(attr[p])):
                    industries = attr[p].split('-')
                    level = 0
                    superior_id = None
                    for c in range(len(industries)):
                        ind = industries[c]
                        ind = escape(ind.strip())
                        industry_attr = {"名称": ind, '类型': "行业", '级别': str(level)}
                        # network.add_node(k, **industry_attr)
                        start_time = time.time()
                        node_id = ds.upsert_node(industry_attr,
                                                 properties_for_search={'名称': industry_attr['名称']},
                                                 override_when_exists=True,
                                                 align_method='same_properties')
                        end_time = time.time()
                        print(i, "th upsert node", industry_attr,
                              f"cost: {end_time - start_time} s")
                        start_time = time.time()
                        level = level + 1
                        industry_id = node_id
                        industry_enterprise_relation = {"类型": "所属行业"}
                        # network.add_edge(enterprise_id, industry_id, **industry_enterprise_relation)
                        ds.upsert_edge(enterprise_id, industry_id,
                                       industry_enterprise_relation,
                                       industry_enterprise_relation)
                        end_time = time.time()
                        print(i, f"th upsert edge: {enterprise_id}->{industry_id}", industry_enterprise_relation,
                              f"cost: {end_time - start_time} s")
                        if superior_id:
                            industry_relation = {"类型": "下级"}
                            start_time = time.time()
                            # network.add_edge(superior_id, industry_id, **industry_relation)
                            ds.upsert_edge(superior_id, industry_id, industry_relation, industry_relation)
                            industry_relation = {"类型": "上级"}
                            # network.add_edge(industry_id, superior_id, **industry_relation)
                            ds.upsert_edge(industry_id, superior_id, industry_relation, industry_relation)
                            end_time = time.time()
                            print(i, f"th upsert edge: {industry_id}->{superior_id}", industry_relation,
                                  f"cost: {end_time - start_time} s")
                        superior_id = industry_id
            # add location nodes

    ds.flush()
