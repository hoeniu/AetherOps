import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
from tests.base_test_case import BaseTestCase
from kbx.common.types import VideoEmbeddingStrategy, KBXError
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, DocParseConfig, \
    QueryConfig, VectorKeywordIndexConfig
from kbx.parser.types import VideoStrategyConfig
from kbx.common.logging import logger
from kbx.splitter.types import SplitterConfig


class TestVideoIndexE2E(BaseTestCase):
    def setup_method(self):
        self._kb_name = "五轴产品视频"
        self._kb_description = "这是一个包含五轴产品视频资料的知识库"

    def test_video_case(self, generate=False):
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                video_strategy=VideoStrategyConfig(
                    type=VideoEmbeddingStrategy.VIDEO2TEXT_TEXT_EMBEDDING,
                    vision_model='doubao-1.5-vision-pro-32k',
                    num_frames=6,
                    enable_scene_split=True
                ),
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model='doubao-embedding',
                splitter_config=SplitterConfig(name='NaiveTextSplitter')
            ),
        )
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

        file_list = [
            os.path.join(self.test_data_dir, 'video_data/0518-Airpods视频制作-B735视频.mp4'),
        ]
        results = kb.insert_docs(
            file_list=file_list
        )
        if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
            raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

        # 使用知识库直接查询
        query = QueryConfig(
            text="AirPods检测有哪些挑战？",
            top_k=3,
            score_threshold=0.1,
        )
        query_result = kb.retrieve(query=query)

        assert isinstance(query_result, list), f"Query result should be a list, given {query_result}"
        assert len(query_result) > 0, "Failed to get query result"
        if query.top_k > 0:
            assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                                                     f"given {query.top_k} and {len(query_result)}"

        print(f'Get {len(query_result)} results from kb ("{kb.kb_config.name}")')
        retrieval_text = ''
        for k, qr in enumerate(query_result):
            print(f'------------------------- #{k}, score={qr.score} -------------------------')
            print(qr.chunk.text)
            retrieval_text += '\n' + qr.chunk.text

        if generate:
            client_config, client = KBX.get_ai_model_config_and_client('doubao-1.5-vision-pro-32k')
            response_text = client.chat(
                client_config,
                messages=[
                    {"role": "user", "content": f"根据以下检索到的文档内容，回答问题:{query.text} \n{retrieval_text}"},
                ],
                temperature=0.7
            ).choices[0].message.content
            logger.debug(f'最终答案为：{response_text}')


if __name__ == "__main__":
    # 手动执行
    test_case = TestVideoIndexE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_video_case(generate=True)
