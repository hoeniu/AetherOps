import os
import time
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../'))
import sys
stdlib_path = os.path.dirname(os.__file__)
sys.path.insert(0, ROOT_DIR)
# sys.path.insert(0, stdlib_path)  # 将标准库路径插入到 sys.path 的开头，防止与本地库冲突
# print(sys.path)

from kbx.kbx import KBX
from kbx.splitter.types import SplitterConfig

from cache.text_chunk_example import get_doc_data
# from kbx.knowledge_base.vector.default_vector_index import DefaultVectorIndex
from kbx.knowledge_base.vector_keyword_keyword.default_vector_keyword_index import DefaultVectorKeywordIndex
from kbx.knowledge_base.types import KBCreationConfig, DocParseConfig, \
    SplitterConfig, QueryConfig, VectorKeywordIndexConfig
from kbx.common.types import DocFileType
# from kbx.rerank.types import RerankConfig
from kbx.common.constants import DEFAULT_USER_ID


if __name__ == '__main__':
    config_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    # print(ROOT_DIR)
    yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')  # 包含一个或多个AI大模型配置的yaml文件
    if len(sys.argv) > 1:
        yaml_file = sys.argv[1]

    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    KBX.init(config=kbx_yaml_file)
    KBX.register_ai_models_from_conf(model_configs=yaml_file, overwrite=True)

    kb_name = "向量索引测试知识库"
    kb_description = "这是一个建筑规范知识库，包含各种建筑规范知识信息"
    kb_config = KBCreationConfig(
        kb_name=kb_name,
        description=kb_description,
        is_external_datastore=False,
        doc_parse_config=DocParseConfig(
            file_parsers={
                DocFileType.PDF: "DefaultPdfParser",
            }
        ),
        vector_config=VectorKeywordIndexConfig(
            index_strategy="DefaultVectorKeywordIndex",
            text_embedding_model="BAAI/bge-m3",
            splitter_config=SplitterConfig(name="RecursiveTextSplitter",),
            # keyword_extractor="jieba",
            # max_keywords_per_chunk=100,
        ),
        # rerank_config=RerankConfig(
        #     name="ModelRerank",
        #     kwargs={"model": "BAAI/bge-reranker-v2-m3"},
        # ),
    )

    kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
    kb_name2id = dict([(item.name, item.kb_id) for item in kbs_info])
    existed_kb_id = kb_name2id.get(kb_config.name, None)
    if existed_kb_id:
        # 已经存在，尝试从DB中读取
        print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.get_existed_kb(kb_id=existed_kb_id)
    else:
        # 未存在，尝试创建
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        print(f'Try to create new kb {kb_config.name} (id={kb._kb_id})')

    index_config = VectorKeywordIndexConfig()
    vector_index = DefaultVectorKeywordIndex(kb_id=kb._kb_id, index_config=index_config)

    # 1. 插入文本
    data = []
    for i in range(10):
        data.extend(get_doc_data())

    t_start = time.time()
    vector_index.insert_single_doc(doc=data)
    t_take = time.time() - t_start
    print('insert take: ', t_take)  # 31 vs 91
    # print(len(vector_index.chunk_embedding_list[0][-1]))

    # 2. 移除
    # vector_index.remove(['4'])
    # print(vector_index._doc_store._doc_id2chunk_id)

    # 3. 所有文档重索引
    # index_config.text_embedding_model = 'BAAI/bge-m3'
    # vector_index.splitter_config = SplitterConfig(delimiters=['))))))))))))'])
    # vector_index.reindex_all()
    # print(len(vector_index.chunk_embedding_list[0][-1]))

    # 检索
    # print("all vectors: ", vector_index._vector_store._collection.get(include=["embeddings"]))
    # query = QueryConfig(text='美股下跌')
    # res = vector_index.retrieve(query)
    # print(res)
    # print('-------------------------')

    # 重索引
    # vector_index.splitter_config = SplitterConfig(delimiters=['))))))))))))'])
    # vector_index.reindex('4')

    # 检索
    # print("all vectors: ", vector_index._vector_store._collection.get(include=["embeddings"]))
    query = QueryConfig(text='美股下跌')
    res = vector_index.retrieve(query)
    print(res)
