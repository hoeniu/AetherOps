import os
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../'))
import sys
sys.path.insert(0, ROOT_DIR)
import argparse

from kbx.knowledge_base.types import KeywordIndexConfig, QueryConfig
from kbx.knowledge_base.keyword.default_keyword_index import DefaultKeywordIndex
from cache.text_chunk_example import get_doc_data
# from kbx.splitter.types import SplitterConfig
from tests.datastore.tool import create_default_user_tenant_kb


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Insert data with a specified turn value.")
    parser.add_argument('--turn', type=str, required=False,
                        default='1-3',
                        help='The turn value to be used for insertion.')
    args = parser.parse_args()

    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    # KBX.init(config=kbx_yaml_file)

    config = KeywordIndexConfig()
    kb_id: str = create_default_user_tenant_kb()
    os.makedirs(kb_id, exist_ok=True)
    keyword_index = DefaultKeywordIndex(kb_id, config)

    # 插入文档
    data = get_doc_data()
    keyword_index.insert_docs(data)
    # keyword_index.insert(data, turn='1-3')
    # keyword_index.insert(data, turn='4-5')
    # keyword_index.insert(data, turn='6-10')
    query = QueryConfig(text='美股紧缩', score_threshold=0)
    res1 = keyword_index.retrieve(query)
    # print(res1)
    # print("\n\n")

    keyword_index.insert_docs(data)
    query = QueryConfig(text='美股紧缩', score_threshold=0)
    res1 = keyword_index.retrieve(query)
    # print(res1)
    # print("\n\n")

    # keyword_index.keyword_store.delete_ds(kb_id)

    # 删除文档
    # keyword_index.remove('3')
    # keyword_index.remove(['1', '2'])

    # 检索
    # query = QueryConfig(text='他紧握着那封信，发现庄园的门开了。天气降温了，多穿衣服')
    # res = keyword_index.retrieve(query)
    # print(res)

    # 重索引
    # keyword_index.splitter_config = SplitterConfig(delimiters=['))))))))))))))'])

    # keyword_index.reindex(['1', '4'])

    # 检索
    # query = QueryConfig(text='美股紧缩', score_threshold=0)
    # res1 = keyword_index.retrieve(query)
    # print(res1)
