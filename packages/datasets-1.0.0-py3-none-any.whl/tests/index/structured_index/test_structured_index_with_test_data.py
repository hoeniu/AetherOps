import os
import json
from typing import Dict, List, Any
from concurrent.futures import ThreadPoolExecutor

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys

sys.path.insert(0, ROOT_DIR)

from kbx.common.types import DocFileType
from kbx.common.constants import DEFAULT_USER_ID
from kbx.common.types import StructuredDSConfig
from kbx.knowledge_base.types import StructuredIndexConfig
from kbx.knowledge_base.types import KBCreationConfig, DocParseConfig, QueryConfig


def flatten_and_sort(data: List[Any]) -> List[Any]:
    """
    将嵌套的list展平, 并排序每个子list
    """
    result = []

    for item in data:
        if isinstance(item, list):
            result.extend(flatten_and_sort(item))
        elif isinstance(item, tuple):
            result.extend(flatten_and_sort(list(item)))
        else:
            # if not isinstance(item, type(None)):  # label 中有None，但是KBX检索出的值中None被过滤掉了，因此，才出也过滤None值
            #     result.append(str(item))
            result.append(str(item))
    return sorted(result)


def are_lists_equal(list1: List[Any], list2: List[Any]) -> bool:
    """
    判断list是否相等, 忽略元素顺序
    """
    return flatten_and_sort(list1) == flatten_and_sort(list2)


def compute_result_metric(generated_results: List[List[Any]], gold_results: List[List[Any]]) -> float:
    if len(generated_results) != len(gold_results):
        raise ValueError("The length of generated_sqls and gold_sqls must be the same.")
    match_count = sum(1 for generated, gold in zip(generated_results, gold_results)
                      if flatten_and_sort(generated) == flatten_and_sort(gold))
    total_count = len(generated_results)
    return match_count / total_count


def retrieve(db_id: str, questions: List[Dict[str, str]],
             llm_model: str, sql_gen_llm_model: str):
    db_dir_tmp = os.path.join(args.db_root_dir, db_id)
    kb_files = []
    for file in os.listdir(db_dir_tmp):
        if file.endswith('.csv') or file.endswith('.xlsx'):
            kb_files.append(os.path.join(db_dir_tmp, file))

    KBX.register_ai_models_from_conf(ai_models_yaml_file, overwrite=True, user_id=DEFAULT_USER_ID)
    struceted_index_config = StructuredIndexConfig(llm_model=llm_model, sql_gen_llm_model=sql_gen_llm_model)
    structured_ds = StructuredDSConfig(type="sqlite")
    KBX.config.structured_ds = structured_ds
    kb_config = KBCreationConfig(name=db_id,
                                 description=db_id,
                                 is_external_datastore=False,
                                 structured_config=struceted_index_config,
                                 doc_parse_config=DocParseConfig(file_parsers={
                                     DocFileType.CSV: "DefaultCsvParser",
                                     DocFileType.EXCEL: "DefaultExcelParser"
                                 }))
    kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID, limit=50)
    name2id = dict([(item.name, item.kb_id) for item in kbs_info])
    existed_kb_id = name2id.get(kb_config.name, None)

    if existed_kb_id:
        print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.get_existed_kb(kb_id=existed_kb_id)
    else:
        print(f'Try to create new kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        _ = kb.insert_docs(file_list=kb_files)
    generated_res = []
    gold_res = []
    errors_data = None
    error_nums_list = [len(questions), 0]
    for q in questions:
        query = QueryConfig(top_k=1)
        query.text = q["question"]
        kb_res = kb.retrieve(query=query)
        if kb_res:
            generated_res.append(kb_res[0].structured_result.data)
        else:
            generated_res.append([])
        if not are_lists_equal(generated_res[-1], q["result"]):
            errors_data = {"question": [], "sql": []}
            errors_data["question"].append(q["question"])
            errors_data["sql"].append(q["sql"])
            error_nums_list[1] += 1
        gold_res.append(q["result"])
    return db_id, errors_data, error_nums_list, generated_res, gold_res


if __name__ == '__main__':
    import argparse
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    parser = argparse.ArgumentParser(description='Params Parser')
    parser.add_argument('--db_root_dir', type=str, required=True, help="DB root dir.")
    parser.add_argument('--db_data_file', type=str, required=True, help="DB data files.")
    parser.add_argument('--llm_model', type=str, default="doubao-1.5-pro-32k", required=False, help="LLM.")
    parser.add_argument(
        '--sql_gen_llm_model',
        type=str,
        default="doubao-1.5-pro-32k",
        required=False, help="SQL GEN LLM."
    )
    args = parser.parse_args()
    """ 包含cspider dev.json的406条测试数据, 14个知识库
        python tests/index/structured_index/test_structured_index_with_test_data.py \
            --db_root_dir cache/kbx_structured_index_test_data/data_files/  \
            --db_data_file cache/kbx_structured_index_test_data/test_data.json
    """

    with open(args.db_data_file, 'r') as f:
        test_data = json.load(f)
    ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
    from kbx.kbx import KBX
    KBX.init(config=kbx_yaml_file)
    error_nums = 0
    generated_results = []
    gold_results = []
    error_data = {}
    error_nums_dict = {}
    num_query = 0
    with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as pool:
        future_results = [
            pool.submit(retrieve,
                        db_id=db_id,
                        questions=questions,
                        llm_model=args.llm_model,
                        sql_gen_llm_model=args.sql_gen_llm_model
                        ) for db_id, questions in test_data.items()
        ]
        for future in future_results:
            res = future.result()
            if res:
                db_id, err_data, error_nums_list, generated_res, gold_res = res
                num_query += len(gold_res)
                error_nums_dict[db_id] = error_nums_list
                error_data[db_id] = err_data
                generated_results.extend(generated_res)
                gold_results.extend(gold_res)
    acc = compute_result_metric(generated_results, gold_results)
    print(f"The Execution Accuracy (EX) of {num_query} questions of {len(error_nums_dict)} KB is: {acc}")
