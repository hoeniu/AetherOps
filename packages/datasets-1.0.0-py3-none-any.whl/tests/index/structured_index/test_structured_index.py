import os
import sys
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../..'))

from kbx.common.constants import DEFAULT_USER_ID

from kbx.kbx import KBX
from kbx.knowledge_base.types import QueryConfig
from kbx.common.types import DocElement, DocData, DocElementType
from kbx.knowledge_base.types import StructuredIndexConfig, KBCreationConfig
from kbx.knowledge_base.structured.default_structured_index import DefaultStructuredIndex
from kbx.datastore.ds_factory import get_structured_datastore


def insert_data(structured_index: DefaultStructuredIndex):
    doc = DocData()
    doc.doc_id = "xx-1-xx"
    doc.file_name = "中国部分城市受欢迎程度.xlsx"
    doc.file_path = "中国部分城市受欢迎程度.xlsx"
    table1: List[List[str]] = [["城市", "受欢迎程度"], ["北京", "2930000"], ["上海", "13960000"], ["广州", "3645000"],
                               ["深圳", "300000"], ["重庆", "90000"], ["天津", "150000"]]
    table2: List[List[str]] = [["城市", "受欢迎程度"], ["天津", "150000"], ["成都", "22000"], ["杭州", "3800000"], ["济南", "26000"],
                               ["青岛", "80000"], ]
    metadata = {'file_type': 'xlsx'}
    doc_elem1 = DocElement(doc_element_id="table1-xxx", type=DocElementType.TABLE, table=table1, meta_data=metadata)
    doc_elem2 = DocElement(doc_element_id="table2-xxx", type=DocElementType.TABLE, table=table2, meta_data=metadata)
    doc.doc_elements = [doc_elem1, doc_elem2]
    res = structured_index.insert_single_doc(doc_data=doc)
    print("插入错误信息如下： ", res)

    doc = DocData()
    doc.doc_id = "xx-2-xx"
    doc.file_name = "中国部分城市人口数据.xlsx"
    doc.file_path = "中国部分城市人口数据.xlsx"
    table3: List[List[str]] = [["城市", "城市人口"], ["海口", "29000"], ["银川", "60000"], ["厦门", "5000"], ["珠海", "3000"],
                               ["乌鲁木齐", "90000"]]
    table4: List[List[str]] = [["城市", "城市人口"], ["烟台", "150000"], ["武汉", "390000"], ["苏州", "3900000"], ["宁波", "56000"],
                               ["太原", "90000"], ]
    metadata = {'file_type': 'xlsx'}
    doc_elem3 = DocElement(doc_element_id="table3-xxx", type=DocElementType.TABLE, table=table3, meta_data=metadata)
    doc_elem4 = DocElement(doc_element_id="table4-xxx", type=DocElementType.TABLE, table=table4, meta_data=metadata)
    doc.doc_elements = [doc_elem3, doc_elem4]
    res = structured_index.insert_single_doc(doc_data=doc)
    print("插入错误信息如下： ", res)


def delete_data(structured_index: DefaultStructuredIndex, doc_ids: List[str] = ["xx-1-xx", "xx-2-xx"]):
    res = structured_index.remove_docs(doc_ids=doc_ids)
    print("删除错误信息如下： ", res)


def retrieve(structured_index: DefaultStructuredIndex):
    query = QueryConfig()
    query.text = "上海和北京的受欢迎程度？"
    result = structured_index.retrieve(query=query)
    print(f"{query.text} 检索结果如下: {result} \n\n")

    query = QueryConfig()
    query.text = "成都的受欢迎程度？"
    result = structured_index.retrieve(query=query)
    print(f"{query.text} 检索结果如下: {result} \n\n")

    query = QueryConfig()
    query.text = "银川的城市人口？"
    result = structured_index.retrieve(query=query)
    print(f"{query.text} 检索结果如下: {result} \n\n")

    query = QueryConfig()
    query.text = "宁波的城市人口？"
    result = structured_index.retrieve(query=query)
    print(f"{query.text} 检索结果如下: {result} \n\n")

    query = QueryConfig()
    query.text = "请给出目前最受欢迎的2个城市？"
    result = structured_index.retrieve(query=query)
    print(f"{query.text} 检索结果如下: {result} \n\n")

    query = QueryConfig()
    query.text = "请给出目前人口最多的2个城市？"
    result = structured_index.retrieve(query=query)
    print(f"{query.text} 检索结果如下: {result} \n\n")


if __name__ == '__main__':

    ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
    '''进行必要的初始化参数配置'''
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    if len(sys.argv) > 1:
        kbx_yaml_file = sys.argv[1]

    ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
    KBX.init(config=kbx_yaml_file)
    # KBX.config.structured_ds = structured_ds
    '''注册需要的llm/embedding等大模型'''
    yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
    KBX.register_ai_models_from_conf(model_configs=yaml_file, overwrite=True)
    '''知识库相关操作'''
    struceted_index_config = StructuredIndexConfig(llm_model='doubao-1.5-pro-32k')
    # 下述指定方法为外部数据库
    # structured_ds.connection_kwargs["url"] = "external_structured_ds.db"
    # struceted_index_config.external_structured_ds = structured_ds
    kb_config = KBCreationConfig(name="部分城市的受欢迎程度和人口数据（模拟数据）",
                                 description="目前主要包含了部分城市的受欢迎程度和人口数据（模拟数据）",
                                 is_external_datastore=False,
                                 structured_config=struceted_index_config)
    kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
    kb_name2id = dict([(item.name, item.kb_id) for item in kbs_info])
    existed_kb_id = kb_name2id.get(kb_config.name, None)
    if existed_kb_id:
        # 已经存在，尝试从DB中读取
        print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.get_existed_kb(kb_id=existed_kb_id)
    else:
        # 未存在，尝试创建
        print(f'Try to restore new kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

    database = get_structured_datastore(kb_id=kb.kb_id, index_config=struceted_index_config)
    database.connect()
    # database.delete_ds()
    structured_index = DefaultStructuredIndex(kb_id=kb.kb_id, index_config=struceted_index_config)
    delete_data(structured_index=structured_index)
    insert_data(structured_index=structured_index)
    insert_data(structured_index=structured_index)
    delete_data(structured_index=structured_index)
    insert_data(structured_index=structured_index)
    print(f"{kb.kb_id} kb tables: ", database.show_tables())
    retrieve(structured_index=structured_index)
    database.close()
