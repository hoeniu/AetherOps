import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
sys.path.insert(0, ROOT_DIR)

from kbx.common.types import DocFileType
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.common.types import StructuredDSConfig
from kbx.knowledge_base.types import StructuredIndexConfig
from kbx.knowledge_base.types import KBCreationConfig, DocParseConfig, QueryConfig


if __name__ == '__main__':
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    if len(sys.argv) > 1:
        kbx_yaml_file = sys.argv[1]

    ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
    KBX.init(config=kbx_yaml_file)
    structured_ds = StructuredDSConfig()
    structured_ds.type = "sqlite"
    structured_ds.connection_kwargs["url"] = "structured_index_test_demo.db"
    KBX.config.structured_ds = structured_ds
    # 注册大模型
    KBX.register_ai_models_from_conf(ai_models_yaml_file, overwrite=True, user_id=DEFAULT_USER_ID)
    all_ai_model_configs = KBX.get_all_ai_model_configs()
    # llm_config, llm_client = KBX.get_ai_model_config_and_client(name="doubao-1.5-pro-32k", user_id=DEFAULT_USER_ID)
    struceted_index_config = StructuredIndexConfig(llm_model='doubao-1.5-pro-32k')
    kb_config = KBCreationConfig(
        name="一线城市近几年GDP经济数据",
        description="目前主要包括北京、上海、广州、深圳的GDP经济数据",
        is_external_datastore=False,
        structured_config=struceted_index_config,
        doc_parse_config=DocParseConfig(
            file_parsers={
                DocFileType.CSV: "DefaultCsvParser",
                DocFileType.EXCEL: "DefaultExcelParser"
            }
        )
    )
    kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
    kb_name2id = dict([(item.name, item.kb_id) for item in kbs_info])
    existed_kb_id = kb_name2id.get(kb_config.name, None)
    if existed_kb_id:
        # 已经存在，尝试从DB中读取
        print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.get_existed_kb(kb_id=existed_kb_id)
    else:
        # 未存在，尝试创建
        print(f'Try to restore new kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

    kb.remove_docs(kb.list_doc_ids()[0])
    results = kb.insert_docs(
        file_list=[
            os.path.join(ROOT_DIR, 'cache/samples/北京GDP数据.csv'),
            os.path.join(ROOT_DIR, 'cache/samples/上海GDP数据.csv'),
            os.path.join(ROOT_DIR, 'cache/samples/广州GDP数据.csv'),
            os.path.join(ROOT_DIR, 'cache/samples/深圳GDP数据.csv'),
        ]
    )
    # print(results)
    # print('Insert docs into kb')
    # doc_ids = kb.list_doc_ids()
    # print(f"Inserted: All docs in kb: {doc_ids}")
    # kb.remove_docs(doc_ids)
    # doc_ids = kb.list_doc_ids()
    # print(f"Removed: All docs in kb: {doc_ids}")
    # results = kb.insert_docs(
    #     file_list=[
    #         os.path.join(ROOT_DIR, 'cache/samples/北京GDP数据.csv'),
    #         os.path.join(ROOT_DIR, 'cache/samples/上海GDP数据.csv'),
    #         os.path.join(ROOT_DIR, 'cache/samples/广州GDP数据.csv'),
    #         os.path.join(ROOT_DIR, 'cache/samples/深圳GDP数据.csv'),
    #     ]
    # )
    # print(results)
    # doc_ids = kb.list_doc_ids()
    # print(f"Inserted: All docs in kb: {doc_ids}")

    llm_config, llm_client = KBX.get_ai_model_config_and_client(name="doubao-1.5-pro-32k", user_id=DEFAULT_USER_ID)
    prompt = "请根据知识库的内容{data}，回答用户的问题：{query}"
    query = QueryConfig()
    query.text = "北京2024年9月份的GDP是多少"
    kb_res = kb.retrieve(query=query)
    text = "\n\n".join([kbr.try_get_content_as_str() for kbr in kb_res])
    print("kb query res: ", text)
    sql = "\n\n".join([kbr.structured_result.sql for kbr in kb_res])
    resp = llm_client.chat(
        model_config=llm_config,
        messages=[
            {"role": "user", "content": prompt.format(query=query.text, data=text)},
        ],
    ).choices[0].message.content
    print(f"{query.text} 的结果如下: {resp} \n\n")

    query = QueryConfig()
    query.text = "上海2024年9月份的GDP是多少"
    kb_res = kb.retrieve(query=query)
    text = "\n\n".join([kbr.try_get_content_as_str() for kbr in kb_res])
    print("kb query res: ", text)
    sql = "\n\n".join([kbr.structured_result.sql for kbr in kb_res])
    resp = llm_client.chat(
        model_config=llm_config,
        messages=[
            {"role": "user", "content": prompt.format(query=query.text, data=text)},
        ],
    ).choices[0].message.content
    print(f"{query.text} 的结果如下: {resp} \n\n")

    query = QueryConfig()
    query.text = "广州2024年9月份的GDP是多少"
    kb_res = kb.retrieve(query=query)
    text = "\n\n".join([kbr.try_get_content_as_str() for kbr in kb_res])
    print("kb query res: ", text)
    sql = "\n\n".join([kbr.structured_result.sql for kbr in kb_res])
    resp = llm_client.chat(
        model_config=llm_config,
        messages=[
            {"role": "user", "content": prompt.format(query=query.text, data=text)},
        ],
    ).choices[0].message.content
    print(f"{query.text} 的结果如下: {resp} \n\n")

    query = QueryConfig()
    query.text = "深圳2024年9月份的GDP是多少"
    kb_res = kb.retrieve(query=query)
    text = "\n\n".join([kbr.try_get_content_as_str() for kbr in kb_res])
    print("kb query res: ", text)
    sql = "\n\n".join([kbr.structured_result.sql for kbr in kb_res])
    resp = llm_client.chat(
        model_config=llm_config,
        messages=[
            {"role": "user", "content": prompt.format(query=query.text, data=text)},
        ],
    ).choices[0].message.content
    print(f"{query.text} 的结果如下: {resp} \n\n")

    # TODO: 暂时不支持跨表联合查询
    query = QueryConfig()
    query.text = "北京、上海、广州和深圳在2024年9月份的GDP分别是多少"
    kb_res = kb.retrieve(query=query)
    text = "\n\n".join([kbr.try_get_content_as_str() for kbr in kb_res])
    print("kb query res: ", text)
    sql = "\n\n".join([kbr.structured_result.sql for kbr in kb_res])
    resp = llm_client.chat(
        model_config=llm_config,
        messages=[
            {"role": "user", "content": prompt.format(query=query.text, data=text)},
        ],
    ).choices[0].message.content
    print(f"{query.text} 的结果如下: {resp} \n\n")

    query = QueryConfig()
    query.text = "北京2023全年的GDP是多少"
    kb_res = kb.retrieve(query=query)
    text = "\n\n".join([kbr.try_get_content_as_str() for kbr in kb_res])
    print("kb query res: ", text)
    sql = "\n\n".join([kbr.structured_result.sql for kbr in kb_res])
    resp = llm_client.chat(
        model_config=llm_config,
        messages=[
            {"role": "user", "content": prompt.format(query=query.text, data=text)},
        ],
    ).choices[0].message.content
    print(f"{query.text} 的结果如下: {resp} \n\n")

    query = QueryConfig()
    query.text = "北京2020年第四季度和2023年第四季度的GDP的均值是多少"
    kb_res = kb.retrieve(query=query)
    text = "\n\n".join([kbr.try_get_content_as_str() for kbr in kb_res])
    print("kb query res: ", text)
    sql = "\n\n".join([kbr.structured_result.sql for kbr in kb_res])
    resp = llm_client.chat(
        model_config=llm_config,
        messages=[
            {"role": "user", "content": prompt.format(query=query.text, data=text)},
        ],
    ).choices[0].message.content
    print(f"{query.text} 的结果如下: {resp} \n\n")

    query = QueryConfig()
    query.text = "北京2022年第四季度的GDP和2023年的第四季度的GDP的分别是多少"
    kb_res = kb.retrieve(query=query)
    text = "\n\n".join([kbr.try_get_content_as_str() for kbr in kb_res])
    print("kb query res: ", text)
    sql = "\n\n".join([kbr.structured_result.sql for kbr in kb_res])
    resp = llm_client.chat(
        model_config=llm_config,
        messages=[
            {"role": "user", "content": prompt.format(query=query.text, data=text)},
        ],
    ).choices[0].message.content
    print(f"{query.text} 的结果如下: {resp} \n\n")

    query = QueryConfig()
    query.text = "北京2022年第四季度的GDP和2023年的第四季度的GDP的和是多少"
    kb_res = kb.retrieve(query=query)
    text = "\n\n".join([kbr.try_get_content_as_str() for kbr in kb_res])
    sql = "\n\n".join([kbr.structured_result.sql for kbr in kb_res])
    resp = llm_client.chat(
        model_config=llm_config,
        messages=[
            {"role": "user", "content": prompt.format(query=query.text, data=text)},
        ],
    ).choices[0].message.content
    print(f"{query.text} 的结果如下: {resp} \n\n")
