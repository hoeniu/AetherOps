import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)

from kbx.common.logging import logger


class BaseTestCase:
    test_data_dir: str = None
    kbx_yaml_file: str = None
    ai_models_yaml_file: str = None

    @classmethod
    def setup_class(cls):
        from kbx.kbx import KBX
        cls.test_data_dir = os.environ.get('KBX_TEST_DATA_DIR', None)
        if not cls.test_data_dir:
            cls.test_data_dir = os.path.join(ROOT_DIR, 'cache/kbx_test_data')
        if not os.path.exists(cls.test_data_dir):
            logger.error(
                f'KBX test data dir "{cls.test_data_dir}" does not exists,'
                ' did you forget to download it or set custom path with "KBX_TEST_DATA_DIR"?'
            )

        # 设置默认的配置文件路径
        if not cls.kbx_yaml_file:
            cls.kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
        if not cls.ai_models_yaml_file:
            cls.ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')

        if cls.kbx_yaml_file:
            if not KBX.is_initialized():
                KBX.init(config=cls.kbx_yaml_file)

        if cls.ai_models_yaml_file:
            KBX.register_ai_models_from_conf(model_configs=cls.ai_models_yaml_file, overwrite=True)

    @classmethod
    def teardown_class(cls):
        from kbx.kbx import KBX
        KBX.close()
        pass
