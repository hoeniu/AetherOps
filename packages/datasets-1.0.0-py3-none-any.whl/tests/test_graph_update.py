import json
import os
import re
from typing import List

import pandas
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, KnowledgeGraphIndexConfig
from kbx.splitter.types import SplitterConfig


def extract_value(text):
    pattern = r"担保金额为[\s\w\.]*元"
    p = re.findall(pattern, text)
    if p:
        value = p[0][len("担保金额为"):].strip()
        return value
    return None


def simplify_entity(entity: dict) -> dict:
    """
    简化实体,只保留名称和类型
    Args:
        entity (dict): 实体字典

    Returns:
        dict: 只包含名称和类型的实体dict
    """
    simple_properties = [
        '类型',
        '名称',
    ]
    return dict(filter(lambda kv: kv[0] in simple_properties, entity.items()))


def search_entity_by_name(ds, entity: dict, name_properties: List[str] = ["名称", "简称", "英文名称", "英文简称"]):
    entity = simplify_entity(entity)
    entities = []
    for name in name_properties:
        extended_entity = {}
        for k, v in entity.items():
            if k != "名称" and k != "简称":
                extended_entity[k] = v
            else:
                extended_entity[name] = v
        entities += ds.search_node_by_property(extended_entity)
    return list(set(entities))


def guarantee_to_graph(filename, data_store):
    data = pandas.read_csv(filename)
    for i in range(len(data)):
        if not data.iloc[i]['guarantor_company_name'] or not isinstance(data.iloc[i]['guarantor_company_name'], str):
            continue
        if not data.iloc[i]['guaranteed_company_name'] or not isinstance(data.iloc[i]['guaranteed_company_name'], str):
            continue
        if not data.iloc[i]['name'] or not isinstance(data.iloc[i]['name'], str):
            continue
        src = {"名称": data.iloc[i]['guarantor_company_name'], '类型': '企业'}
        dst = {"名称": data.iloc[i]['guaranteed_company_name'], '类型': '企业'}
        value = extract_value(data.iloc[i]['level2_content'])
        edge = {"类型": "担保", "介绍": data.iloc[i]['level2_content'], "公告日期": data.iloc[i]['notice_date']}
        if value:
            edge["数量"] = value
        same_name_nodes = search_entity_by_name(data_store, src)
        if same_name_nodes:
            src_id = same_name_nodes[0]
            data_store.update_node(src_id, src,
                                   override_when_exists=False)
            if len(same_name_nodes) > 1:
                print(f"Warning: more than 1 same name company found {same_name_nodes}")
        else:
            src_id = data_store.upsert_node(src, properties_for_search=src,
                                            override_when_exists=True, align_method='same_properties')
        same_name_nodes = search_entity_by_name(data_store, dst)
        if same_name_nodes:
            dst_id = same_name_nodes[0]
            data_store.update_node(dst_id, dst,
                                   override_when_exists=False)
            if len(same_name_nodes) > 1:
                print(f"Warning: more than 1 same name company found {same_name_nodes}")
        else:
            dst_id = data_store.upsert_node(dst, properties_for_search=dst,
                                            override_when_exists=True, align_method='same_properties')
        data_store.upsert_edge(src_id, dst_id, edge,
                               edge_properties_for_alignment={"类型": "担保"},
                               override_when_exists=False)


def escape(text):
    return re.sub(u'[^\u0020-\uD7FF\u0009\u000A\u000D\uE000-\uFFFD\U00010000-\U0010FFFF]+', '', text)


def manager_to_graph(filename, data_store):
    dtype = {
        "code": str,
        "name": str,
        "person_name": str,
        "position": str,
        "sex": str,
        "high_degree": str,
        "age": str,
        "resume": str,
        "hold_num": str,
        "salary": str,
        "incumbent_time": str,
        "incumbent_date": str
    }
    data = pandas.read_csv(filename, dtype=dtype)
    for i in range(len(data)):
        if not data.iloc[i]['person_name'] or not isinstance(data.iloc[i]['person_name'], str):
            continue
        if not data.iloc[i]['name'] or not isinstance(data.iloc[i]['name'], str):
            continue
        src = {"名称": escape(data.iloc[i]['person_name']),
               '类型': '人'}
        if data.iloc[i]['sex'] and data.iloc[i]['sex'] != "None" \
                and isinstance(data.iloc[i]['sex'], str) and data.iloc[i]['sex'] != '':
            src['性别'] = escape(data.iloc[i]['sex'])
        if data.iloc[i]['high_degree'] and data.iloc[i]['high_degree'] != "None" \
                and isinstance(data.iloc[i]['high_degree'], str) and data.iloc[i]['high_degree'] != '':
            src["学历"] = escape(data.iloc[i]['high_degree'])
        if data.iloc[i]['resume'] and data.iloc[i]['resume'] != "None" \
                and isinstance(data.iloc[i]['resume'], str) and data.iloc[i]['resume'] != '':
            src["介绍"] = escape(data.iloc[i]['resume'])
        if data.iloc[i]['salary'] and data.iloc[i]['salary'] != "None" \
                and isinstance(data.iloc[i]['salary'], str) and data.iloc[i]['salary'] != '':
            src["薪资"] = data.iloc[i]['salary']
        if data.iloc[i]['age'] and data.iloc[i]['age'] != "None" and data.iloc[i]['age'] != '':
            try:
                src["出生日期"] = "{}年".format(2023 - int(data.iloc[i]['age']))
            except Exception as e:
                print(e)
        dst = {"代码": data.iloc[i]['code'], "简称": escape(data.iloc[i]['name']), '类型': '企业'}
        edge = {"类型": "任职", "职位": data.iloc[i]['position']}
        if data.iloc[i]['incumbent_date'] and isinstance(data.iloc[i]['incumbent_date'], str) and \
                data.iloc[i]['incumbent_date'] != "None" and \
                data.iloc[i]['incumbent_date'] != '':
            edge = {"类型": "任职", "职位": data.iloc[i]['position'], "开始日期": data.iloc[i]['incumbent_date']}
        dst_id = data_store.upsert_node(dst, properties_for_search=dst,
                                        override_when_exists=False, align_method='same_properties')
        align_edges = [[{"名称": src["名称"], '类型': '人'}, {"类型": "任职"}, {'简称': dst['简称'], '类型': dst['类型']}]]
        src_id = data_store.upsert_node(src, properties_for_search={"名称": src["名称"], '类型': '人'},
                                        override_when_exists=False,
                                        align_method='same_edges',
                                        edges_for_alignment=align_edges)
        data_store.upsert_edge(src_id, dst_id, edge, {"类型": "任职", "职位": data.iloc[i]['position']})


def get_holder_type(name):
    company_key_words = [
        "投资",
        "公司",
        "基金",
        "企业",
        "Investment",
        "Investments",
        "Limited",
        "Ltd.",
        "Partners",
        "Inc.",
        "L.P.",
        "LLP",
        "LLC",
        "LIMITED",
        "Fund",
        "Holding",
        "Co.",
        "Group",
        "Company",
        "Bank",
        "Trading",
        "Trust",
        "Trustees",
        "管理计划"
    ]
    gov_key_words = [
        "财政部",
        "国资委",
        "委员会",
        "市国有资产",
        "省国有资产",
        "政府",
        "投资局",
        "办公室",
        "共和国",
    ]
    for k in company_key_words:
        if name.find(k) != -1:
            return "企业"
    for k in gov_key_words:
        if name.find(k) != -1:
            return "政府机构"
    return "人"


def holder_to_graph(filename, data_store):
    data = pandas.read_csv(filename, dtype={'code': str,
                                            'name': str,
                                            'holder_name': str,
                                            'shares_type': str,
                                            'hold_num': str,
                                            'hold_num_ratio': str,
                                            'hold_num_change': str,
                                            'change_ratio': str,
                                            'holder_rank': str,
                                            'end_date': str})
    for i in range(len(data)):
        if not data.iloc[i]['holder_name'] or not isinstance(data.iloc[i]['holder_name'], str):
            continue
        src = {"名称": data.iloc[i]['holder_name'],
               '类型': get_holder_type(data.iloc[i]['holder_name'])}
        # print(src)
        dst = {"代码": data.iloc[i]['code'], "简称": data.iloc[i]['name'], '类型': '企业'}

        edge = {"类型": "持股", "数量": data.iloc[i]['hold_num'],
                "占比": data.iloc[i]['hold_num_ratio'] + '%',
                "增减数量": data.iloc[i]['hold_num_change'],
                "类别": data.iloc[i]['shares_type'],
                "统计日期": data.iloc[i]['end_date']}
        if str(data.iloc[i]['change_ratio']) and str(data.iloc[i]['change_ratio']) != 'nan':
            edge['增减比例'] = str(data.iloc[i]['change_ratio']) + '%'
        # print(edge)
        dst_id = data_store.upsert_node(dst, properties_for_search=dst,
                                        override_when_exists=False, align_method='same_properties')
        if src['类型'] == '企业' or src['类型'] == '政府机构':
            same_name_nodes = search_entity_by_name(data_store, src)
            if same_name_nodes:
                src_id = same_name_nodes[0]
                data_store.update_node(src_id, src,
                                       override_when_exists=False)
                if len(same_name_nodes) > 1:
                    print(f"Warning: more than 1 same name company found {same_name_nodes}")
            else:
                src_id = data_store.upsert_node(src, properties_for_search=src,
                                                override_when_exists=False, align_method='same_properties')
        else:
            align_edges = [[src, {"类型": "任职"}, dst]]
            src_id = data_store.upsert_node(src, properties_for_search=src,
                                            override_when_exists=False,
                                            align_method='same_edges',
                                            edges_for_alignment=align_edges)
        data_store.upsert_edge(src_id, dst_id, edge, edge)


def fund_holder_to_graph(filename, data_store):
    data = pandas.read_csv(filename, dtype={'code': str,
                                            'name': str,
                                            'org_type': str,
                                            'holder_code': str,
                                            'holder_name': str,
                                            'total_shares': str,
                                            'hold_value': str,
                                            'total_shares_ratio': str,
                                            'freeshares_ratio': str,
                                            'free_market_cap': str,
                                            'free_shares': str,
                                            'fund_code': str,
                                            'fund_derivecode': str,
                                            'netvalue_ratio': str,
                                            'report_date': str})
    for i in range(len(data)):
        if not data.iloc[i]['holder_name'] or not isinstance(data.iloc[i]['holder_name'], str):
            continue
        # if data.iloc[i]['org_type'] == '01':
        #     org_type = '基金'
        # elif data.iloc[i]['holder_name'].endswith('公司'):
        #     org_type = '企业'
        src = {"代码": data.iloc[i]['holder_code'], "名称": data.iloc[i]['holder_name'],
               '类型': '基金'}
        # print(src)
        dst = {"代码": data.iloc[i]['code'], "简称": data.iloc[i]['name'], '类型': '企业'}

        edge = {"类型": "持股", "数量": data.iloc[i]['total_shares'],
                "占比": data.iloc[i]['total_shares_ratio'] + '%',
                "统计日期": data.iloc[i]['report_date']}
        dst_id = data_store.upsert_node(dst, properties_for_search=dst,
                                        override_when_exists=False, align_method='same_properties')
        same_name_nodes = search_entity_by_name(data_store, src)
        if same_name_nodes:
            src_id = same_name_nodes[0]
            data_store.update_node(src_id, src,
                                   override_when_exists=False)
            if len(same_name_nodes) > 1:
                print(f"Warning: more than 1 same name company found {same_name_nodes}")
        else:
            src_id = data_store.upsert_node(src, properties_for_search=src,
                                            override_when_exists=False, align_method='same_properties')

        data_store.upsert_edge(src_id, dst_id, edge, edge)


def check_index(ds):
    for p, ind in ds.index.items():
        for v, s in ind.items():
            for ent in s:
                node = ds.search_node_by_id(ent)
                if node[p] != v:
                    print("{} VS {}".format(node[p], v))


ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')


def setup(schema):
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    KBX.init(config=kbx_yaml_file)
    ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
    KBX.register_ai_models_from_conf(ai_models_yaml_file, overwrite=True, user_id=DEFAULT_USER_ID)
    # schema = json.load(open(schemapath, 'r'))
    kb_config = KBCreationConfig(
        name='enterprise',
        description='',
        is_external_datastore=False,
        kg_config=KnowledgeGraphIndexConfig(
            index_strategy="DefaultGraphIndex",
            llm_model="doubao-1.5-pro-32k",
            embedding_model="doubao-embedding",
            schema_dict=schema,
            splitter_config=SplitterConfig(
                name="NaiveTextSplitter",
                delimiters=["\n\n"],
            ),
        ),
    )
    kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
    kb_name2id = dict([(item.name, item.kb_id) for item in kbs_info])
    existed_kb_id = kb_name2id.get(kb_config.name, None)
    if existed_kb_id:
        # 已经存在，尝试从DB中读取
        print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.get_existed_kb(kb_id=existed_kb_id)
    else:
        # 未存在，尝试创建
        print(f'Try to restore new kb {kb_config.name} (id={existed_kb_id})')
        kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
    ds = kb.index_map['knowledge_graph'].data_store
    return ds


if __name__ == '__main__':
    # config = GraphDSConfig(type="networkx", connection_kwargs={})
    with open('../enterprise_process/schema.json', 'r') as fp:
        schema = json.load(fp)
        print(schema)
    ds = setup(schema)

    print("Processing guarantee")
    guarantee_to_graph(filename='../enterprise_process/csv/guarantee.csv', data_store=ds)
    print("Processing manager")
    manager_to_graph('../enterprise_process/csv/manager.csv', data_store=ds)
    # check_index(ds)
    print("Processing holder")
    holder_to_graph('../enterprise_process/csv/holder.csv', data_store=ds)
    print("Processing fund holder")
    '''
    fund_holder_to_graph('../enterprise_process/csv/fund_holder.csv', data_store=ds)
    '''
    ds.flush()
