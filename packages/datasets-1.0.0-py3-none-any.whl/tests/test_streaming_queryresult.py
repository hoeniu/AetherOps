import json
import requests
from typing import List, Optional, Any, Dict
from tests.helper import gen_test_auth_token


server_address = 'http://localhost:30018'
api_key = gen_test_auth_token()


def test_retrieval(
        text: Optional[str],
        messages: Optional[List[Dict[str, Any]]],
        top_k: int,
        score_threshold: float,
        deep_think: Optional[Dict[str, Any]],
        stream: bool,
        kb_ids: List[str],
        enable_index_types: Optional[List[str]],
        user_id: str):
    data = {
        'text': text,
        'top_k': top_k,
        'score_threshold': score_threshold,
        'deep_think': deep_think,
        'enable_index_types': enable_index_types,
        'stream': stream
    }
    if data['stream']:
        response = requests.post(
            url=f"{server_address}/retrieval",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "Accept": "text/event-stream"
            },
            json=data,
            params={"kb_ids": kb_ids, "user_id": user_id},
            stream=True
        )

        if response.status_code == 200:
            for line in response.iter_lines():
                if line:
                    decode_line = line.decode('utf8')
                    if decode_line.startswith('data:'):
                        try:
                            formatter_data = decode_line.split(":", 1)[1].strip()
                            res_data = json.loads(formatter_data)
                            if res_data.get("is_final", False):
                                for res in res_data["results"]:
                                    print(f"retrieve res: {res}")
                            else:
                                for step in res_data["step_messages"]:
                                    print(f"step_name: {step['step_name']}\n"
                                          f"type: {step['type']}\n"
                                          f"content: {step['content']}")

                        except Exception as e:
                            print(f'解析json数据失败, {e}')
        else:
            print(f"检索失败，状态码: {response.status_code}")
            print("错误信息:", response.text)

    else:
        response = requests.post(
            url=f"{server_address}/retrieval",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "Accept": "text/event-stream"
            },
            json=data,
            params={"kb_ids": kb_ids, "user_id": user_id},
            stream=False
        )
        if response.status_code == 200:
            retrieve_res = response.json()['results']
            for res in retrieve_res:
                print(f"retrieve res: {res}")


if __name__ == '__main__':
    qr_res_list = test_retrieval(
        text="KBX是什么？",
        top_k=3,
        messages=None,
        score_threshold=0,
        deep_think={
            "max_iter": 3,
            "llm_model": "doubao-1.5-pro-256k"
        },
        stream=False,
        kb_ids=['29ad049f-c017-476d-9498-cff7ce339215'],
        enable_index_types=['vector_keyword'],
        user_id='3a7a1250-d043-41c8-bf2a-af8fbc48bb85'
    )
    qr_res_list = test_retrieval(
        text="KBX是什么？",
        top_k=3,
        messages=None,
        score_threshold=0,
        deep_think={
            "max_iter": 3,
            "llm_model": "doubao-1.5-pro-256k"
        },
        stream=True,
        kb_ids=['29ad049f-c017-476d-9498-cff7ce339215'],
        enable_index_types=['vector_keyword'],
        user_id='3a7a1250-d043-41c8-bf2a-af8fbc48bb85'
    )
