import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
import json
from tests.base_test_case import BaseTestCase
from kbx.common.types import GraphDSConfig
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, SplitterConfig, \
    KnowledgeGraphIndexConfig, QueryConfig, QueryResults


class TestGraphIndexE2E(BaseTestCase):
    def setup_method(self):
        with open(os.path.join(ROOT_DIR, "tests/schema/schema.json")) as fd:
            self._schema_dict = json.load(fd)
        self._kb_name = "上市公司知识库"
        self._kb_description = "这是一个知识图谱知识库，包含各种金融知识信息"

    def test_std_case(self):
        graph_ds_config = GraphDSConfig(type='networkx',
                                        connection_kwargs={
                                            "graphml_file": '../enterprise_process/enterprise_listed.graphml'})

        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            kg_config=KnowledgeGraphIndexConfig(
                index_strategy="DefaultGraphIndex",
                llm_model="doubao-1.5-pro-32k",
                embedding_model="doubao-embedding",
                schema_dict=self._schema_dict,
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                ),
                external_graph_ds=graph_ds_config
            ),
        )
        kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
        kb_name2id = dict([(item.name, item.kb_id) for item in kbs_info])
        existed_kb_id = kb_name2id.get(kb_config.name, None)
        if existed_kb_id:
            # 已经存在，尝试从DB中读取
            print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
            kb = KBX.get_existed_kb(kb_id=existed_kb_id)
        else:
            # 未存在，尝试创建
            print(f'Try to restore new kb {kb_config.name} (id={existed_kb_id})')
            kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

        # 使用知识库直接查询
        query = QueryConfig(
            text="万科企业的高管有哪些？",
            top_k=1,
            score_threshold=0.1,
        )
        query_result = kb.retrieve(query=query)
        assert isinstance(query_result, QueryResults), \
            f"Query result should be a QueryResults object, given {type(query_result)}"
        assert isinstance(query_result.results, list), \
            f"Retrieval results should be a list, given {type(query_result.results)}"
        assert len(query_result) > 0, "Failed to get query result"
        if query.top_k > 0:
            assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                                                     f"given {query.top_k} and {len(query_result)}"

        print(f'Get {len(query_result)} results from kb ("{kb.kb_config.kb_name}")')
        for k, qr in enumerate(query_result):
            print(f'------------------------- #{k}, score={qr.score} -------------------------')
            print(qr.graph_triplets)
            print(qr.chunk)


if __name__ == "__main__":
    # 手动执行
    test_case = TestGraphIndexE2E()
    test_case.setup_class()
    test_case.test_std_case()
