import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys

sys.path.insert(0, ROOT_DIR)
import pickle
import json
from typing import Dict, List
from kbx.common.types import DocData, DocElement, Chunk, IndexType

index_type_list = list(IndexType)


def convert(path: str):
    doc_file_old: str = f"{path}/doc_data.pickle"
    doc_file_new: str = f"{path}/doc_data.json"
    id_map_file_old = f"{path}/id_map.pickle"
    id_map_file_new = f"{path}/id_map.json"
    with open(doc_file_old, 'rb') as rf:
        doc_data = pickle.load(rf)
        with open(doc_file_new, 'w') as wf:
            temp_dict = {key: value.model_dump_json() for key, value in doc_data.items()}
            json.dump(temp_dict, wf)
    for index_type in index_type_list:
        r_file = f"{path}/{index_type}.pickle"
        w_file = f"{path}/{index_type}.json"
        with open(r_file, 'rb') as rf:
            chunk_data = pickle.load(rf)
            with open(w_file, 'w') as wf:
                temp_dict = {key: value.model_dump_json() for key, value in chunk_data.items()}
                json.dump(temp_dict, wf)
    with open(id_map_file_old, 'rb') as rf:
        id_map = pickle.load(rf)
        with open(id_map_file_new, 'w') as wf:
            json.dump(id_map, wf)


def fill_doc_element_item(doc_element_dict: Dict, doc_data: DocData):
    for doc_element in doc_data.doc_elements:
        doc_element_dict[doc_element.doc_element_id] = doc_element


def load(path: str):
    doc_file: str = f"{path}/doc_data.json"
    id_map_file: str = f"{path}/id_map.json"
    with open(doc_file, 'r', encoding='utf-8') as file_handler:
        doc_data_temp = json.load(file_handler)
        doc_data: Dict[str, DocData] = {key: DocData.model_validate_json(value) for key, value in doc_data_temp.items()}
        # print(doc_data)
        doc_element_dict: [str, DocElement] = dict()
        for doc_data_ins in doc_data.values():
            fill_doc_element_item(doc_element_dict, doc_data_ins)
        # print(doc_element_dict)

    for index_type in index_type_list:
        with open(f"{path}/{index_type}.json", 'r', encoding='utf-8') as file_handler:
            chunk_data_temp = json.load(file_handler)
            chunk = {key: Chunk.model_validate_json(value)
                     for key, value in chunk_data_temp.items()}
            print(len(chunk))
            # print(chunk)
    with open(id_map_file, 'r', encoding='utf-8') as file_handler:
        id_map: Dict[str, List[str]] = json.load(file_handler)
        print(len(id_map))
        # print(id_map)


if __name__ == "__main__":
    print(sys.argv)
    if len(sys.argv) > 2:
        if sys.argv[1] == "convert":
            convert(sys.argv[2])
        else:
            load(sys.argv[2])
    else:
        print("按以下格式使用脚本 python tools/convert_pickle_to_json.py [convert/load] [pickle文件夹相对于工作目录的路径]")
