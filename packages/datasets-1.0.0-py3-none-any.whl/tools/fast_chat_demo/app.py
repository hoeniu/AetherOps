import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
import logging
import streamlit as st
from src.core import L1_PAGES_KEY
from src.kbx_chatbot_page import KBXChatBotPage
from src.core import FCBDConfig, FCBD_CONFIG_KEY
from typing import List


logging.basicConfig(level=logging.INFO,
                    # filename='output.log',
                    datefmt='%Y/%m/%d %H:%M:%S',
                    format='[%(asctime)s] [%(levelname)s] [%(filename)s:%(lineno)d] %(message)s')


def get_fcbd_config(force_reload: bool = False) -> FCBDConfig:
    if force_reload or FCBD_CONFIG_KEY not in st.session_state:
        # reload from file
        config_file = os.path.join('config', 'settings.yaml')
        if 'FCBD_CONFIG_PATH' in os.environ:
            config_file = os.environ['FCBD_CONFIG_PATH']
        fcbd_config: FCBDConfig = FCBDConfig.load_from_yaml(config_file)
        logging.info(f'Load FCBD config file: {config_file}')
        st.session_state[FCBD_CONFIG_KEY] = fcbd_config

    return st.session_state[FCBD_CONFIG_KEY]


fcbd_config = get_fcbd_config(force_reload=False)

st.set_page_config(
    layout='wide',
)


@st.cache_data
def load_l1_pages() -> List:
    pages = []

    for chatbot_config in fcbd_config.chatbots:
        pages.append(
            st.Page(
                page=KBXChatBotPage(
                    config=chatbot_config,
                ),
                title=chatbot_config.name,
                url_path='cb-' + chatbot_config.name,
                icon=chatbot_config.icon,
            )
        )

    return pages


if L1_PAGES_KEY not in st.session_state:
    st.session_state[L1_PAGES_KEY] = load_l1_pages()

pg = st.navigation(
    pages=st.session_state[L1_PAGES_KEY],
)

pg.run()
