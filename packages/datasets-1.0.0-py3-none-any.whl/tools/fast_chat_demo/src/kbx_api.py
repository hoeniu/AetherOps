import os
import requests
import json
from typing import List, Dict, Optional, Any, Tuple
from textwrap import dedent
KBX_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
sys.path.insert(0, KBX_DIR)
from kbx.kbx import KBX

import logging
logger = logging.getLogger('QA_logger')


class KBXClient:
    def __init__(self, auth_token: str, kbx_url: str):
        self.auth_token = auth_token
        self.kbx_url = kbx_url

    def _send_request(self, method, endpoint, json=None, params=None, stream=False):
        headers = {"Authorization": f"Bearer {self.auth_token}", "Content-Type": "application/json"}

        url = f"{self.kbx_url}/api/v1{endpoint}"
        response = requests.request(method, url, json=json, params=params, headers=headers, stream=stream)

        return response

    def _list_kbs(self):
        return self._send_request("GET", "/list_kbs").json()

    def _get_kb_details(self, kb_id):
        data = {
            'kb_id': kb_id
        }
        response = self._send_request("GET", "/kb_detail", params=data).json()
        return response

    def _retrieval(self,
                   text: Optional[str] = "",
                   messages: Optional[List[Dict[str, str]]] = [],
                   top_k: int = 3,
                   score_threshold: float = 0,
                   keyword_similarity_weight: float = 0,
                   kb_ids: List[str] = [],
                   enable_index_types: Optional[List[str]] = None,
                   deep_think: Optional[Dict[str, Any]] = None):
        data = {
            'text': text,
            'messages': messages,
            'top_k': top_k,
            'score_threshold': score_threshold,
            "vector_dynamic_kwargs": {
                "keyword_similarity_weight": keyword_similarity_weight,
            },
            'enable_index_types': enable_index_types,
            'deep_think': deep_think,
            'stream': True,
        }
        retrieved_res = self._send_request(
            "POST",
            "/retrieval",
            json=data,
            params={'kb_ids': kb_ids},
            stream=True
        )
        return retrieved_res


class KBXChatClient(KBXClient):
    def __init__(self, auth_token: str, kbx_url: str, user_id: str, ai_model_config: Dict):
        super().__init__(auth_token, kbx_url)
        self._ai_model_config = ai_model_config
        KBX.register_ai_models_from_conf(model_configs=os.path.join(
            KBX_DIR, self._ai_model_config['yaml_file']), overwrite=True)

        self._LLM_config, self._LLM_client = KBX.get_ai_model_config_and_client(
            self._ai_model_config['generator_LLM_name'], user_id=user_id)

    def _generate_LLM_response(self, query: str, retrieved_text: str):
        system_prompt = "你是基于KBX研发的知识库问答助手，集成基础知识库以及多种Agent检索功能，为用户提供快速、准确的知识回答。"
        if retrieved_text:
            # 统一处理文本和图检索的上下文格式
            user_prompt = dedent(f"""
                                 请基于以下上下文知识信息回答问题。

                                 上下文信息：
                                 {retrieved_text}

                                 问题：{query}

                                 请基于上述上下文信息，给出准确、完整的回答。如果上下文信息不足以回答问题，请说明原因。""")
        else:
            user_prompt = query
        generated_text = self._LLM_client.chat(
            self._LLM_config,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            stream=True)
        return generated_text

    def _retrieval_res_formatter(self, retrieval_data: List) -> Tuple[str, List]:
        """将检索结果列表拼接为字符串用于生成回答并将结果转换为适合前端展示的数据结构"""
        retrieval_text = ""
        reference_context = []
        for res_item in retrieval_data:
            if res_item.get('graph_triplets', None):
                retrieval_text += '[["' + '"],\n["'.join(list(set(['", "'.join(triplet)
                                                                   for triplet in res_item['graph_triplets']]))) + '"]]'
                retrieved_info = {
                    'score': res_item['score'],
                    'doc_name': None,
                    'doc_id': None,
                    'kb_id': res_item['kb_id'],
                    'raw_data': [{'type': 'graph', 'content': res_item['subgraph_options']}]
                }
                reference_context.append(retrieved_info)
            elif res_item.get('chunk', None):
                retrieval_text += (res_item['chunk']['text'] + '\n')
                retrieved_info = {
                    'kb_id': res_item['kb_id'],
                    'doc_name': res_item['meta_data']['doc_name'],
                    'doc_id': res_item['doc_id'],
                    'score': res_item['score'],
                    'raw_data': []
                }
                markdown_content = ""
                if res_item['chunk'].get('doc_elements', []):
                    for ele in res_item['chunk'].get('doc_elements', []):
                        if ele.get('type') == 'table':
                            table_html = ele.get('table', {}).get('html')
                            retrieved_info['raw_data'].append({"type": "table", "content": table_html})
                            markdown_content += f"\n\n{table_html}\n\n"
                        elif ele.get('type') == 'figure':
                            img_url = ele.get('data_file_url')
                            retrieved_info['raw_data'].append({"type": "image", "content": img_url})
                            markdown_content += f"\n\n![]({img_url})\n\n"
                        elif ele.get('type') == 'audio':
                            audio_url = ele.get('data_file_url')
                            retrieved_info['raw_data'].append({"type": "audio", "content": audio_url})
                            markdown_content += f"\n\n<audio controls>\n  <source src=\"{audio_url}\" type=\"audio/mpeg\">\n</audio>\n\n" # noqa
                        elif ele.get('type') == 'video':
                            video_url = ele.get('data_file_url')
                            retrieved_info['raw_data'].append({"type": "video", "content": video_url})
                            markdown_content += f"\n\n<video controls width=\"100%\">\n  <source src=\"{video_url}\" type=\"video/mp4\">\n</video>\n\n" # noqa
                        elif ele.get('type') == 'code_block':
                            code_content = ele.get('text')
                            retrieved_info['raw_data'].append({"type": "code", "content": code_content})
                            markdown_content += f"\n\n{code_content}\n\n"
                        else:
                            retrieved_info['raw_data'].append({"type": "text", "content": ele.get('text')})
                            markdown_content += f"\n\n{ele.get('text')}\n\n"
                else:
                    retrieved_info['raw_data'].append({"type": "text", "content": res_item['chunk']['text']})
                    markdown_content = res_item['chunk']['text']
                retrieved_info['markdown_content'] = markdown_content
                reference_context.append(retrieved_info)

        return retrieval_text, reference_context

    def create_chat_message(self, query, top_k, score_threshold, keyword_similarity_weight,
                            enable_index_types, kb_ids, enable_agent):
        previous_messages_round = 3
        text = ""
        messages = []
        try:
            messages = json.loads(query)['messages'][-(previous_messages_round * 2 + 1):]
        except Exception:
            text = query
            raise ValueError(f'query is not a valid json for messages: {query}')

        if enable_agent and self._ai_model_config['agent_LLM_name']:
            deep_think = {
                "llm_model": self._ai_model_config['agent_LLM_name'],
            }
        else:
            deep_think = None
            if messages:
                text = messages[-1]["content"]
                messages = []

        retrieval_response = self._retrieval(text, messages, top_k, score_threshold,
                                             keyword_similarity_weight,
                                             kb_ids,
                                             enable_index_types,
                                             deep_think)

        retrieval_data = []
        retrieved_text = ""
        for line in retrieval_response.iter_lines():
            if line:
                decode_line = line.decode('utf8')
                if decode_line.startswith('data:'):
                    formatter_data = decode_line.split(":", 1)[1].strip()
                    res_data = json.loads(formatter_data)
                    if res_data.get("is_final", False):
                        retrieval_data = res_data["results"]
                    elif res_data.get("step_messages"):
                        yield res_data["step_messages"][0]

        if retrieval_data:
            retrieved_text, reference_context = self._retrieval_res_formatter(retrieval_data)
            yield reference_context
        user_query = text if text else messages[-1]["content"]
        generated_text = self._generate_LLM_response(
            user_query, retrieved_text)
        yield generated_text
