import yaml
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


# some constants
FCBD_CONFIG_KEY = 'FCBD_CONFIG'
CB_STATE_DICT_KEY = 'CHATBOT_STATE_DICT'
L1_PAGES_KEY = 'L1_PAGES'


class ChatBotConfig(BaseModel):
    name: str
    caption: str = ''
    icon: str = ''
    image_path: str = ''
    user_avatar: str = 'pics/user_avatar.png'
    assistant_avatar: str = 'pics/assistant_avatar.png'
    sidebar_image: str = ''
    display_image: str = ''
    recommended_questions: List[str] = []

    api_client_kwargs: Dict[str, Any] = Field(default_factory=dict)


class FCBDConfig(BaseModel):
    chatbots: List[ChatBotConfig] = Field(default_factory=list)

    @staticmethod
    def load_from_yaml(file_path: str) -> 'FCBDConfig':
        with open(file_path, encoding='utf-8') as fd:
            config_data = yaml.safe_load(fd)
        return FCBDConfig(**config_data)


class ChatBotState(BaseModel):
    config: Optional[ChatBotConfig] = None
    client: Any = None
    messages: List[Dict] = Field(default_factory=list)
