import os
import json
import yaml
import asyncio
from pydantic import BaseModel, Field
from fastapi.responses import StreamingResponse
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware


import sys
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../')
sys.path.insert(0, ROOT_DIR)
KBX_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
sys.path.insert(0, KBX_DIR)
# Import your KBXChatClient
from src.kbx_api import KBXChatClient


import logging
logger = logging.getLogger('server_logger')
logger.setLevel(logging.DEBUG)
file_handler = logging.FileHandler('server.log')
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

app = FastAPI(
    title="KBX Rag Chat API",
    description="API for interacting with KBX rag chat service"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)


# 定义请求模型
class QueryRequest(BaseModel):
    query: str = Field(default="", description="查询字符串")
    top_k: int = Field(default=20, ge=1, le=100, description="本次检索返回的最大结果数量")
    score_threshold: float = Field(default=0.2, ge=0, lt=1, description="本次检索返回结果的最小分数阈值")


@app.on_event("startup")
async def startup_event():
    from kbx.kbx import KBX
    KBX.init(config=os.path.join(KBX_DIR, 'conf/kbx_settings.yaml'))
    # Read configuration from config file
    config_file = os.path.join('config', 'settings.yaml')
    with open(config_file) as fd:
        config_data = yaml.safe_load(fd)
    app.state.kbx_client = KBXChatClient(**config_data['chatbots'][0]['api_client_kwargs'])
    print("KBXChatClient initialized successfully")


async def get_rag_res(query, top_k, score_threshold):
    reference_context, response, response_type = app.state.kbx_client.create_chat_message(
        query,
        top_k,
        score_threshold,
        0,
        None
    )
    if response_type == "rag_response":
        generate_text = ""
        for event in response:
            if hasattr(event, 'choices') and event.choices:
                choice = event.choices[0]
                delta_content = choice.delta.content if hasattr(choice.delta, 'content') else None
                generate_text += delta_content
                yield generate_text, None
        yield generate_text, reference_context

    elif response_type == "direct_response":
        chars = list(response)
        for char in chars:
            yield char, None


async def stream_response(query: str, top_k: int, score_threshold: float):
    async for answer, reference_context in get_rag_res(query, top_k, score_threshold):
        response_data = {
            "answer": answer,
            "contexts": reference_context
        }
        # 转换为JSON并添加特殊分隔符
        await asyncio.sleep(0)
        yield f"data: {json.dumps(response_data)}\n\n"


@app.post("/chat")
async def chat(request: QueryRequest):
    logger.debug(f"ori query: {request.query}")
    # 支持demo请求格式以及rag评测格式
    try:
        standard_messages = []
        messages = json.loads(request.query)['messages']

        # TODO: 确认message格式是否统一（三个应用）
        if len(messages) == 1 and messages[0]['role'] == 'user':
            true_query = request.query
        else:
            for message in messages:
                if isinstance(message, dict) and 'role' in message and 'content' in message:
                    if message['role'] == 'user':
                        standard_messages.append({'role': 'user', 'content': message['content']})
                    elif message['role'] == 'assistant':
                        try:
                            assistant_content = json.loads(message['content'])['answer']
                            standard_messages.append({'role': 'assistant', 'content': assistant_content})
                        except Exception:
                            del standard_messages[-1]
                else:
                    continue
            true_query = json.dumps({'messages': standard_messages}, ensure_ascii=False)
    except Exception:
        true_query = request.query
    logger.debug(f"true query: {true_query}")
    return StreamingResponse(
        stream_response(
            true_query,
            request.top_k,
            request.score_threshold
        ),
        media_type="text/event-stream"
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=60000)
