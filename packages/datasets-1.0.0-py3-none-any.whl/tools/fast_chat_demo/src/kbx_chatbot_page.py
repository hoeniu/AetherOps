import os
KBX_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
sys.path.insert(0, KBX_DIR)

import streamlit as st
import uuid
from streamlit_echarts import st_echarts
from typing import Dict
from src.core import CB_STATE_DICT_KEY, ChatBotState, ChatBotConfig
from src.kbx_api import KBXChatClient

import json
import logging
logger = logging.getLogger('QA_logger')
logger.setLevel(logging.DEBUG)
file_handler = logging.FileHandler('QA.log')
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)


class KBXChatBotPage:
    def __init__(self, config: ChatBotConfig) -> None:
        self._config = config
        from kbx.kbx import KBX
        KBX.init(config=os.path.join(KBX_DIR, 'conf/kbx_settings.yaml'))

    def _reset_chatbot_state(self) -> None:
        if self._config.name in st.session_state[CB_STATE_DICT_KEY]:
            raise RuntimeError(f'Duplicate chatbot name {self._config.name}')

        st.session_state[CB_STATE_DICT_KEY][self._config.name] = ChatBotState()
        client = KBXChatClient(**self._config.api_client_kwargs)
        st.session_state[CB_STATE_DICT_KEY][self._config.name].client = client
        st.session_state[CB_STATE_DICT_KEY][self._config.name].messages = []
        st.session_state.extra_display = True
        st.session_state.chat_input = ""
        st.session_state.selected_kbs = []

    def call_custom_chat_page(self) -> None:
        if CB_STATE_DICT_KEY not in st.session_state:
            st.session_state[CB_STATE_DICT_KEY] = {}
        if self._config.name not in st.session_state[CB_STATE_DICT_KEY]:
            self._reset_chatbot_state()

        client = st.session_state[CB_STATE_DICT_KEY][self._config.name].client
        messages = st.session_state[CB_STATE_DICT_KEY][self._config.name].messages

        kbs_info = client._list_kbs()['data']
        kb_name_id = dict([(item['name'], item['kb_id']) for item in kbs_info])
        all_kb_ids = [item['kb_id'] for item in kbs_info]

        with st.sidebar:
            st.image(self._config.sidebar_image)

            st.session_state.enable_agent = st.checkbox("🌐 开启深度思考", value=False)
            # 使用expander创建可折叠的知识库选择面板
            with st.expander("📚 知识库列表", expanded=True):
                st.markdown(
                    '<span title="默认情况下，所有RAG知识库都处于选中状态，表示会使用全部知识库进行检索。'
                    '如果需要禁用某些知识库，请取消对应知识库前的勾选框。'
                    '若所有知识库均被取消勾选，则系统自动使用全部知识库进行检索。">💡 Tips</span>',
                    unsafe_allow_html=True
                )

                # 显示所有知识库的checkbox
                for kb_name in kb_name_id.keys():
                    is_selected = st.checkbox(
                        kb_name,
                        value=True,
                        key=f"kb_{kb_name}"
                    )
                    if is_selected and kb_name_id[kb_name] not in st.session_state.selected_kbs:
                        st.session_state.selected_kbs.append(kb_name_id[kb_name])
                    if not is_selected and kb_name_id[kb_name] in st.session_state.selected_kbs:
                        st.session_state.selected_kbs.remove(kb_name_id[kb_name])

            with st.expander("🔍️ 检索相关参数", expanded=False):
                top_k = st.number_input('选择 RAG 检索的 top-k 值:', min_value=1, max_value=50, value=3, step=1)
                st.session_state.top_k = top_k

                score_threshold = st.slider('设置检索分数阈值:', min_value=0.0, max_value=1.0, value=0.2, step=0.1)
                st.session_state.score_threshold = score_threshold

                keyword_similarity_weight = st.slider('设置关键词相似度权重:', min_value=0.0, max_value=1.0, value=0.0, step=0.1)
                st.session_state.keyword_similarity_weight = keyword_similarity_weight

        if st.session_state.extra_display:
            with st.container(border=True):
                st.markdown("## 💭  推荐问题")

                recommended_questions = [
                    f':rainbow:  {question}' for question in self._config.recommended_questions]

                for question in recommended_questions:
                    if st.button(question, key=f"btn_{question}"):
                        st.session_state.chat_input = question[11:]
                        st.rerun()

        for i, msg_item in enumerate(messages):
            self.display_message_with_trace_info(msg_item)

        prompt = st.chat_input(placeholder='请输入您的问题')

        if st.session_state.chat_input or prompt:
            final_prompt = st.session_state.chat_input if st.session_state.chat_input else prompt
            st.session_state.extra_display = False
            st.session_state.chat_input = ""
            if not client:
                st.info("未能成功初始化客户端，请检查对应的参数配置")
                st.stop()

            st.session_state[CB_STATE_DICT_KEY][self._config.name].messages.append(
                {"role": "user", "content": final_prompt}
            )
            st.chat_message("user", avatar=self._config.user_avatar).markdown(final_prompt)

            with st.chat_message("assistant", avatar=self._config.assistant_avatar):
                if st.session_state.enable_agent:
                    with st.container(border=True):
                        st.markdown("## 🔍 思考过程")
                        step_placeholder = st.empty()

            standard_messages = []
            for msg_item in st.session_state[CB_STATE_DICT_KEY][self._config.name].messages:
                standard_messages.append({"role": msg_item['role'], "content": msg_item['content']})

            streaming_res = client.create_chat_message(
                query=json.dumps({"messages": standard_messages}, ensure_ascii=False),
                top_k=st.session_state.top_k,
                score_threshold=st.session_state.score_threshold,
                keyword_similarity_weight=st.session_state.keyword_similarity_weight,
                enable_index_types=None,
                kb_ids=st.session_state.selected_kbs if st.session_state.selected_kbs else all_kb_ids,
                enable_agent=st.session_state.enable_agent
            )
            logger.debug(f"question: {standard_messages[-1]['content']}")

            display_text = ""
            reasoning_text = ""
            step_messages = ""
            reference_context = []

            def process_streaming_output():
                nonlocal step_messages
                nonlocal reference_context

                def update_display(chunk, is_reasoning=False):
                    nonlocal display_text
                    nonlocal reasoning_text
                    if is_reasoning:
                        reasoning_text += chunk
                        resoning_placeholder.code(reasoning_text)
                    else:
                        display_text += chunk
                        assistant_placeholder.markdown(display_text)

                answer = ""
                current_step = ""
                step_num = 1
                for tmp_res in streaming_res:
                    if isinstance(tmp_res, dict):
                        if not current_step == tmp_res['step_name']:
                            step_messages += "---\n\n"
                            step_messages += f"\n\n### Step{step_num}: {tmp_res['step_name']}\n\n"
                            step_num += 1
                        step_messages += tmp_res['content']
                        step_placeholder.markdown(step_messages, unsafe_allow_html=True)
                        current_step = tmp_res['step_name']
                    elif isinstance(tmp_res, list):
                        reference_context = tmp_res
                        with st.container(border=True):
                            st.markdown("## 📚 知识引用")
                            for reference_item in tmp_res:
                                if reference_item.get('markdown_content'):
                                    label = (reference_item['doc_name'] + ':' + f"{reference_item['score']:.4f}")
                                    with st.expander(label=label, icon='📕'):
                                        if reference_item.get('score', None):
                                            st.progress(reference_item['score'], f"相关度={(reference_item['score']):.4f}")
                                        text = ''
                                        text += '* 数据集id：' + reference_item.get('kb_id', '') + '\n'
                                        text += '* 文档id：' + reference_item.get('doc_id', '') + '\n'
                                        text += '-------\n'
                                        st.markdown(text)
                                        st.markdown(reference_item['markdown_content'], unsafe_allow_html=True)
                                else:
                                    # 知识图谱渲染
                                    st_echarts(reference_item['raw_data'][0]['content'], height="700px")
                    else:
                        resoning_placeholder = st.empty()
                        assistant_placeholder = st.empty()
                        for event in tmp_res:
                            if hasattr(event, 'choices') and event.choices:
                                choice = event.choices[0]
                                delta_content = choice.delta.content if hasattr(choice.delta, 'content') else None
                                reasoning_content = getattr(choice.delta, 'reasoning_content', None)
                                if delta_content:
                                    update_display(delta_content)
                                    answer += delta_content
                                if reasoning_content:
                                    update_display(reasoning_content, is_reasoning=True)
                                    answer += reasoning_content
                                if hasattr(choice, 'finish_reason') and choice.finish_reason:
                                    print(f"finish_reason: {choice.finish_reason}")
                                    if choice.finish_reason == 'stop':
                                        break
                return answer, step_messages, reference_context

            msg_id = str(uuid.uuid4())
            answer, step_data, reference_context = process_streaming_output()
            st.session_state[CB_STATE_DICT_KEY][self._config.name].messages.append(
                {
                    "role": "assistant",
                    "content": display_text,
                    "step_messages": step_messages,
                    "reasoning_text": reasoning_text,
                    "reference_context": reference_context,
                    "unique_id": msg_id
                })
            if msg_id not in st.session_state:
                st.session_state[msg_id] = {'button_clicked': False, 'feedback': 'fair'}
            st.rerun()

    def __call__(self) -> None:
        st.title(self._config.name)
        if self._config.caption:
            st.caption(self._config.caption)

        self.call_custom_chat_page()

    def display_message_with_trace_info(self, msg: Dict) -> None:
        avatar = None
        if msg['role'] == 'assistant':
            avatar = self._config.assistant_avatar
        elif msg['role'] == 'user':
            avatar = self._config.user_avatar
        with st.chat_message(msg['role'], avatar=avatar):
            if msg.get('reasoning_text', None):
                st.code(msg['reasoning_text'])
            if msg.get('step_messages', None):
                with st.container(border=True):
                    st.markdown("## 🔍 思考过程")
                    st.markdown(msg['step_messages'], unsafe_allow_html=True)
            if msg.get('reference_context', None):
                with st.container(border=True):
                    st.markdown("## 📚 知识引用")
                    for reference_item in msg['reference_context']:
                        if reference_item.get('markdown_content', False):
                            label = (reference_item['doc_name'] + ':' + f"{reference_item['score']:.4f}")
                            with st.expander(label=label, icon='📕'):
                                if reference_item.get('score', None):
                                    st.progress(reference_item['score'], f"相关度={(reference_item['score']):.4f}")
                                text = ''
                                text += '* 数据集id：' + reference_item.get('kb_id', '') + '\n'
                                text += '* 文档id：' + reference_item.get('doc_id', '') + '\n'
                                text += '-------\n'
                                st.markdown(text)
                                st.markdown(reference_item['markdown_content'], unsafe_allow_html=True)
                        else:
                            # 知识图谱渲染
                            st_echarts(reference_item['raw_data'][0]['content'], height="700px")
            st.markdown(msg['content'], unsafe_allow_html=True)
            if msg['role'] == 'assistant':
                if not st.session_state[msg['unique_id']].get('button_clicked'):
                    button_placeholder = st.empty()
                    col = button_placeholder.columns([3, 3])
                    with col[1]:
                        col1, col2, col3 = st.columns([1, 1, 1])
                        st.write("""
                            <style>
                            [class*="stButton"] > button {
                                width: 100%;
                                padding: 10px;
                            }
                            </style>
                            """, unsafe_allow_html=True)
                        with col1:
                            if st.button('👍 Good', key=f"{msg['unique_id']}_good"):
                                st.session_state[msg['unique_id']]['feedback'] = 'good'
                                st.session_state[msg['unique_id']]['button_clicked'] = True
                                logger.info(f"msg id: {msg['unique_id']}, User feedback: good")
                        with col2:
                            if st.button('👎 Bad', key=f"{msg['unique_id']}_bad"):
                                st.session_state[msg['unique_id']]['feedback'] = 'bad'
                                st.session_state[msg['unique_id']]['button_clicked'] = True
                                logger.info(f"msg id: {msg['unique_id']}, User feedback: bad")
                        with col3:
                            if st.button('💬 Fair', key=f"{msg['unique_id']}_fair"):
                                st.session_state[msg['unique_id']]['feedback'] = 'fair'
                                st.session_state[msg['unique_id']]['button_clicked'] = True
                                logger.info(f"msg id: {msg['unique_id']}, User feedback: fair")
                else:
                    st.write(f"📝 您选择了: {st.session_state[msg['unique_id']]['feedback']} 评价。感谢您的反馈！")
