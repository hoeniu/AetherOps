import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
import warnings
from termcolor import colored
from kbx.bin.launch_restful_svc import main


if __name__ == "__main__":
    warnings.warn(
        colored(
            '\n=========================================================================================\n'
            'This script will be deprecated soon. Please use the following command instead:\n'
            '\n'
            '    python -m kbx.bin.launch_restful_svc\n'
            '\n=========================================================================================\n',
            'yellow'
        ),
        UserWarning,
        stacklevel=2
    )
    main()
