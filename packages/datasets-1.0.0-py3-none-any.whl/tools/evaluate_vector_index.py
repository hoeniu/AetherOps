import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
import json
import asyncio

from kbx.common.types import KBXError
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, \
    SplitterConfig, QueryConfig, VectorKeywordIndexConfig
from kbx.rerank.types import RerankConfig
from kbx.common.prompt import get_category_prompts
from kbx.common.logging import logger

from ragas.utils import RAGAS_SUPPORTED_LANGUAGE_CODES
from ragas import evaluate, SingleTurnSample, EvaluationDataset
from ragas.metrics import ContextRecall, ContextPrecision
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from ragas.run_config import RunConfig


class VectorIndexEvaluator:
    def __init__(self,
                 config,
                 kb_name="向量索引评估知识库",
                 kb_description="这是一个知识库"):
        kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
        self._all_model_configs = 'conf/ai_models.yaml'
        ai_models_yaml_file = os.path.join(ROOT_DIR, self._all_model_configs)
        KBX.init(config=kbx_yaml_file)
        KBX.register_ai_models_from_conf(ai_models_yaml_file, overwrite=True, user_id=DEFAULT_USER_ID)

        self._query_file = config.query_file
        self._documents = config.documents
        self._text_embedding_model = config.text_embedding_model
        self._retrieved_result = config.retrieved_result
        self._kb_name = kb_name
        self._kb_description = kb_description
        self._top_k = config.top_k
        self._score_threshold = config.score_threshold
        self._llm = config.evaluate_llm

        self._LLM_config, self._LLM_client = KBX.get_ai_model_config_and_client(self._llm)

        if config.rerank_model:
            self._rerank_config = RerankConfig(
                name="ModelRerank",
                kwargs={"model": config.rerank_model},
            )
        else:
            self._rerank_config = None

    def build_kb(self):
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model=self._text_embedding_model,
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    chunk_size=500,
                    overlap_size=50,
                    delimiters=["\n\n", "。", ". ", " ", ""],
                    keep_delimiter=True),
                # keyword_extractor="jieba",
                # max_keywords_per_chunk=20,
            ),
            rerank_config=self._rerank_config
        )
        kbs_info, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
        kb_name2id = dict([(item.name, item.kb_id) for item in kbs_info])
        existed_kb_id = kb_name2id.get(kb_config.name, None)
        if existed_kb_id:
            # 已经存在，尝试从DB中读取
            print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
            self._kb = KBX.get_existed_kb(kb_id=existed_kb_id)
        else:
            # 未存在，尝试创建
            self._kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
            print(f'Try to create new kb {kb_config.name} (id={self._kb.kb_id})')

            if os.path.isfile(self._documents):
                files = [self._documents]
            elif os.path.isdir(self._documents):
                files = [os.path.join(self._documents, doc) for doc in os.listdir(self._documents)]
            else:
                raise ValueError(f"documents should be a file or a directory, given {self._documents}")
            # 向空知识库插入文档
            results = self._kb.insert_docs(
                file_list=files
            )
            if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
                raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

    def get_query_data(self):
        # 目前要求是json格式的data，包括question, context, answer键
        with open(self._query_file, 'r', encoding='utf-8') as f:
            part_data = json.load(f)
        return part_data

    def retrieve(self, top_k=None, score_threshold=None):
        top_k = top_k if top_k else self._top_k
        score_threshold = score_threshold if score_threshold else self._score_threshold
        data = self.get_query_data()
        for _, item in enumerate(data):
            # 获取检索结果，评估用
            retrieved_contexts_info = []
            # 所有检索到的文本做拼接，生成response用
            retrieval_full_text = ''

            if not isinstance(item, dict):
                continue
            query_text = item["question"]
            if not isinstance(query_text, str):
                continue
            query = QueryConfig(
                text=query_text,
                top_k=top_k,
                score_threshold=score_threshold,
                vector_dynamic_kwargs={
                    "keyword_similarity_weight": 0,
                }
            )

            # 使用KBX在顶层进行查询
            query_result = self._kb.retrieve(query=query)
            assert isinstance(query_result, list), f"Query result should be a list, given {query_result}"
            assert len(query_result) > 0, "Failed to get query result"
            if query.top_k > 0:
                assert query.top_k >= len(query_result), \
                    f"Query result should be no more than top_k, given {query.top_k} and {len(query_result)}"

            print(f'Get {len(query_result)} results from kb ("{self._kb.kb_config.name}")')
            for k, qr in enumerate(query_result):
                print(f'------------------------- #{k}, score={qr.score} -------------------------')
                retrieved_contexts_info.append(
                    {
                        "text": qr.chunk.text,
                        "score": qr.score,
                        "doc_id": qr.doc_id,
                    }
                )
                retrieval_full_text += '\n' + qr.chunk.text

            item['retrieved_contexts'] = retrieved_contexts_info
            prompt = f"根据以下检索到的文档内容，回答问题:{query.text} \n{retrieval_full_text}"
            response = self._call_llm(self._LLM_config, self._LLM_client, prompt)
            item['retriever_answer'] = response

        with open(self._retrieved_result, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        return data

    def _call_llm(self, client_config, client, prompt, temperature=0.7):
        response = client.chat(
            client_config,
            messages=[
                {"role": "user", "content": prompt},
            ],
            temperature=temperature
        )
        return response

    def _get_llm_config(self, model_name, run_config):
        if isinstance(self._all_model_configs, str):
            from pathlib import Path
            yaml_path = Path(self._all_model_configs)
            if yaml_path.exists() and yaml_path.is_file():
                if yaml_path.suffix.lower() == '.yaml' or yaml_path.suffix.lower() == '.yml':
                    import yaml
                    with open(self._all_model_configs, 'r') as fd:
                        data = yaml.safe_load(fd)
                else:
                    import json
                    with open(self._all_model_configs, 'r') as fd:
                        data = json.load(fd)
        for model_dict in data:
            if model_dict['name'] == model_name:
                break

        base_url = model_dict['base_url']
        api_key = model_dict['api_key']
        model_type = model_dict['type']
        if model_type == 'llm':
            return LangchainLLMWrapper(
                ChatOpenAI(
                    base_url=base_url,
                    api_key=api_key,
                    model=model_name,
                    temperature=0.0
                ),
                run_config=run_config
            )
        elif model_type == 'text_embedding':
            return LangchainEmbeddingsWrapper(
                OpenAIEmbeddings(
                    base_url=base_url,
                    api_key=api_key,
                    model=model_name,
                    tiktoken_enabled=False
                ),
                run_config=run_config
            )
        else:
            raise ValueError(f"Unsupported model type: {model_type}")

    def _format_data(self, data):
        samples_list = []
        for item in data:
            if not isinstance(item["question"], str):
                continue
            samples_list.append(SingleTurnSample(
                user_input=item["question"],
                retrieved_contexts=[context['text']
                                    for context in item['retrieved_contexts']],
                response=item["retriever_answer"],
                reference=item["answer"]
            ))

        dataset = EvaluationDataset(samples=samples_list)
        return dataset

    def _evaluate_retrieved_context_by_ragas(
        self,
        metric_type,
        language,
        save_file,
        evaluate_data=None,
        evaluate_embedding="doubao-embedding"
    ):

        assert args.language in list(
            RAGAS_SUPPORTED_LANGUAGE_CODES.keys()), "language is not supported"

        metric_dict = {
            'context_recall': ContextRecall(),
            'context_precision': ContextPrecision(),
        }
        run_config = RunConfig(timeout=600, log_tenacity=True)
        evaluate_llm = self._llm
        llm = self._get_llm_config(evaluate_llm, run_config)
        embedding = self._get_llm_config(evaluate_embedding, run_config)

        if isinstance(evaluate_data, str):
            with open(evaluate_data, 'r', encoding='utf-8') as f:
                evaluate_data = json.load(f)
        elif evaluate_data is None:
            evaluate_data = self.retrieve()

        formatted_results = self._format_data(evaluate_data)

        metrics_list = []
        for metric in metric_type:
            metric_method = metric_dict[metric]
            if language != 'english':
                # change language
                adapted_prompts = asyncio.run(
                    metric_method.adapt_prompts(language="chinese", llm=llm))
                metric_method.set_prompts(**adapted_prompts)

            # set model
            metric_method.llm = llm
            metric_method.embeddings = embedding
            metrics_list.append(metric_method)

        results = evaluate(dataset=formatted_results, metrics=metrics_list, run_config=run_config)

        df = results.to_pandas()
        final_context_recall = df['context_recall'].mean()
        final_context_precision = df['context_precision'].mean()
        logger.debug(f"overall context recall: {final_context_recall}")
        logger.debug(f"overall context precision: {final_context_precision}")
        df.to_csv(save_file, index=True, encoding='utf-8_sig')

    def _evaluate_response_by_crag(self, evaluate_data, save_file):
        truthfulness = 0
        num_data = 0
        if isinstance(evaluate_data, str):
            with open(evaluate_data, 'r', encoding='utf-8') as f:
                evaluate_data = json.load(f)
        for item in evaluate_data:
            if not isinstance(item, dict):
                continue
            query = item['question']
            gt = item['answer']
            response = item['retriever_answer']

            prompt = get_category_prompts('evaluator')['crag_evaluator'].text
            user_input = prompt.format(question=query, ground_truth=gt, prediction=response)

            response = self._call_llm(self._LLM_config, self._LLM_client, user_input)
            score = float(response)

            logger.debug("overall truthfulness: {score}")
            item['score'] = str(score)
            truthfulness += score
            num_data += 1

        import pandas as pd
        df = pd.DataFrame(evaluate_data)
        df.to_csv(save_file, index=False)

    def evaluate(self,
                 metric_type,
                 language,
                 save_path,
                 evaluate_data=None,
                 evaluate_embedding="doubao-embedding"):
        if not os.path.exists(save_path):
            os.makedirs(save_path, exist_ok=True)

        self._evaluate_retrieved_context_by_ragas(
            metric_type, language,
            os.path.join(save_path, 'retreved_context.csv'),
            evaluate_data, evaluate_embedding)
        self._evaluate_response_by_crag(evaluate_data, os.path.join(save_path, 'response.csv'))


if __name__ == "__main__":
    # 手动执行
    import argparse
    os.environ["RAGAS_DEBUG"] = "true"
    ragas_metric_dict = {
        'context_recall': ContextRecall(),
        'context_precision': ContextPrecision(),
    }

    parser = argparse.ArgumentParser(
        description="Calculate different metrics based on the metric type.")
    # kb相关
    parser.add_argument(
        '--query_file',
        default=os.path.join(ROOT_DIR, 'cannot_retrieved_context_77items.json'),
        help="JSON file for data storage."
    )
    parser.add_argument('--documents', default='./data/80000_docs', help="txt/PDF/docx file path  to add to kb.")

    # retrieve相关
    parser.add_argument('--top_k', default=2, help='Number of retrieved contexts.')
    parser.add_argument('--score_threshold', default=0.0, help='Score threshold for retrieved contexts.')
    parser.add_argument(
        '--retrieved_result',
        default=os.path.join(ROOT_DIR, 'results_test.json'),
        help='JSON file for all retrieved results.'
    )
    parser.add_argument('--text_embedding_model', default='doubao-embedding', help="Embedding model for vector index.")
    parser.add_argument('--rerank_model', default=None, help="Rerank model for vector index.")

    # evaluate相关
    parser.add_argument('--metric_type', choices=ragas_metric_dict.keys(), nargs='+', default=[
                        'context_recall', 'context_precision', ], help="Type of metric to calculate.")
    parser.add_argument('--language', default='english',
                        help="Language type of target data.")

    parser.add_argument(
        '--evaluate_result_path',
        default=os.path.join(ROOT_DIR, 'cache/evalutate_result'),
        help="Path to save the evaluation results."
    )
    parser.add_argument('--evaluate_llm', default='doubao-pro-32k', help="LLM model for evaluation.")
    parser.add_argument('--evaluate_embedding', default='doubao-embedding', help="Embedding model for evaluation.")
    args = parser.parse_args()

    import nest_asyncio
    nest_asyncio.apply()

    evaluator = VectorIndexEvaluator(args)
    evaluator.build_kb()
    data = evaluator.retrieve()
    # data = args.retrieved_result
    evaluator.evaluate(
        args.metric_type,
        args.language,
        args.evaluate_result_file,
        data,
        evaluate_embedding=args.evaluate_embedding
    )
