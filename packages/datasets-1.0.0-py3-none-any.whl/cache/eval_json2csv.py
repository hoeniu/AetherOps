import os

ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
import pandas as pd
import json

def json2csv():
    with open('chanpin.json', 'r', encoding='utf-8') as f:
        json_data = json.load(f)

    for item in json_data:
        item['deepseek'] = ''
        item['KBX'] = ''
        item['gpt'] = ''
        item['question'] = '请根据文档，回答以下问题：' + item['question']
        # print(item)

    # 将JSON数据转换为DataFrame
    df = pd.DataFrame(json_data)

    # 将DataFrame写入CSV文件
    df.to_csv('chanpin_human_eval.csv', index=False)

    print("JSON数据已成功转换并保存到output.csv")


PROMPT = "# 任务：给你一个问题、一个模型的预测结果和一个 Ground Truth 答案，你的任务是对模型的预测结果和 Ground Truth 答案的匹配程度进行打分。请按照以下说明一步一步进行判断。\n1. 如果模型预测与 Ground Truth 答案中提供的信息完全匹配，得分为1分。\n2. 如果模型预测与 Ground Truth 答案匹配，但预测结果中额外包含一些和问题相关的信息，得分为1分。\n3. 如果模型预测的结构漏掉了部分 Ground Truth 答案的信息，得分为0.5分。\n4. 如果模型预测表明它无法回答问题或没有足够的信息，而Ground Truth 答案中有足够的信息，则得分为0分。\n5. 如果模型预测与 Ground Truth 答案中提供的信息完全不匹配，或者模型预测中包含和问题完全不相关的信息，得分为-1分。\n\n# 示例：\n问题：3 分 15 秒是多少秒？\nGround Truth：195 秒\n预测：3 分 15 秒是195 秒。\nscore：1\n问题：谁是《驯悍记》（2002 年出版）的作者？\nGround Truth: 威廉·莎士比亚\n预测：《驯悍记》的作者是威廉·莎士比亚，他是一个伟大的作家，著名作品有《哈姆莱特》《李尔王》《麦克白》等。\nscore：1\n问题：谁在《生活大爆炸》中扮演谢尔顿？\nGround Truth：吉姆·帕森斯\n预测：抱歉，我不知道。\nscore：0\n\n给你的问题、预测结果和 Ground Truth 答案如下：\n问题：{question}\nGround Truth：{ground_truth}\n预测：{prediction}，现在请开始打分，请直接输出分数，不要输出别的内容。"


def get_deepseek_response():
    file_path = 'cache/kbx_test_data/chanpin_human_eval.xlsx'
    # 读取Excel文件
    df = pd.read_excel(file_path)
    cnt = 0
    from kbx.kbx import KBX
    from kbx.common.constants import DEFAULT_USER_ID
    kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
    KBX.init(config=kbx_yaml_file)
    ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
    KBX.register_ai_models_from_conf(ai_models_yaml_file, overwrite=True, user_id=DEFAULT_USER_ID)
    client_config, client = KBX.get_ai_model_config_and_client('doubao-pro-32k')

    truthfulness = 0
    num = 0
    for _, row in df.iterrows():
        cnt += 1
        if cnt == 56:
            break
        if row['source'] in ['消费五轴-V2.0', 'Airpods检测', 'VHS8000', 'VS600', '五轴产品sop设计']:
            continue
        response = row['ds回答']
        question = row['question']
        # print("question:", row['question'])
        answer = row['answer']
        response = client.chat(
            client_config,
            prompt=PROMPT.format(question=question, ground_truth=answer, prediction=response)
        )
        # cleaned_string = response.strip('"')
        # try:
        #     score = json.loads(response)['score']
            
        # except:
        #     print('error', response)
        #     continue
        #     # from ipdb import set_trace
        #     # set_trace()
        score = float(response)
        print('score by llm', score)
        truthfulness += score
        num += 1
    print('truthfulness:, num', truthfulness / num, num)

    
    
if __name__ == '__main__':
    get_deepseek_response()   # 最终结果：0.7051282051282052