import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
from typing import Any, Dict
from tests.base_test_case import BaseTestCase
from kbx.common.types import DocFileType, KBXError, ImageEmbeddingStrategy, GraphDSConfig
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.datastore.ds_factory import get_doc_datastore
from kbx.knowledge_base.types import KBCreationConfig, DocParseConfig, \
    SplitterConfig, QueryConfig, VectorKeywordIndexConfig, KnowledgeGraphIndexConfig
from kbx.knowledge_base.knowledge_base import KnowledgeBase
from kbx.parser.types import PdfOcrStrategyConfig, ImageStrategyConfig
from kbx.rerank.types import RerankConfig


GOODS = "电力电缆"
LLM_MODEL = "volcengine-deepseek-r1"  #"volcengine-deepseek-r1"  # "deepseek-r1:70b"  # 671b
EMBEDDING_MODEL = "BAAI/bge-m3"  # "bge-m3:latest"
PROPERTYS = ["质保期", "评审办法", "资质要求", "交货期", "合同"]  # 供货期 -> 交货期
QUERY = "电力电缆的质保期和评审办法是什么？"  # 服务类 软件类


class TestVectorKeywordIndexE2E(BaseTestCase):
    def setup_method(self):
        self._kb_name = "采购文件知识库"
        self._kb_description = "这是一个采购文件知识库"
        self._kb = None
        
        # graph index
        import json
        with open(os.path.join(ROOT_DIR, "tests/schema/schema_industry.json")) as fd:
            self._schema_dict = json.load(fd)

    def _create_std_kb(self, kb_config: KBCreationConfig = None):
        if self._kb:
            return
        # try:
        #     # 如果已经存在，尝试进行旧数据删除
        #     previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
        #     previous_kb.remove_kb()
        # except RuntimeError:
        #     pass
        # self._kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        # print(f'Try to create new kb {kb_config.name} (id={self._kb.kb_id})')

        all_kb_id_names = KBX.list_kbs(user_id=DEFAULT_USER_ID)
        kb_name2id = dict([(name, id) for id, name in all_kb_id_names])
        existed_kb_id = kb_name2id.get(kb_config.name, None)
        if existed_kb_id:
            # 已经存在，尝试从DB中读取
            print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
            self._kb = KBX.get_existed_kb(kb_id=existed_kb_id)
        else:
            # 未存在，尝试创建
            print(f'Try to create new kb {kb_config.name} (id={existed_kb_id})')
            self._kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

        # scanner_dir = '2023年/2023年'
        # scanner_dir = '/project/kbx_dynamic/KBX/cache/kbx_test_data/all/all'
        scanner_dir = 'ProcurementDoc'
        # # scanner_dir = 'aaa'
        # scanner_files = [os.path.join(self.test_data_dir, scanner_dir, doc) for i, doc in enumerate(os.listdir(os.path.join(self.test_data_dir, scanner_dir))) if i < 2] #  doc.startswith(('A', 'B')) or doc.lower().endswith(('.xlsx'))]  # noqa
        # failed_files = ['010.采购文件-110kV瓷柱式高压交流SF6断路器采购项目-发出版本.docx', '075.采购文件-变配电站设备安全数据采集服务-发出版本.docx', 'A11.招标文件-110kV赤湾输变电工程项目等主变采购-发出版本（最终版）.docx', 'B09.招标文件-2023-2024年度前海片区表计批量升级轮换工程-挂网版（住建）.docx', 'B09.招标文件-2024年度前海片区表计批量升级轮换工程-挂网版.docx']
        # scanner_files = [os.path.join(scanner_dir, doc) for doc in os.listdir(scanner_dir)]
        # scanner_files = [os.path.join(self.test_data_dir, scanner_dir, doc) for i, doc in enumerate(os.listdir(os.path.join(self.test_data_dir, scanner_dir)))]
        
        
        results = self._kb.insert_docs(
            # file_list=[
            #     # os.path.join(self.test_data_dir, 'VS600产品规格书.pdf'),]
            #     # os.path.join(self.test_data_dir, '2023-04-05：以史为鉴：从银行业危机到衰退和降息有多远？.pdf'),
            #     os.path.join(self.test_data_dir, '五轴产品汇报-脱敏-1.pdf'),
            # ]
            # file_list=scanner_files
            file_list=[os.path.join(self.test_data_dir, '2023年/2023年/007.招标文件-兰园配电改造工程低压柜采购项目-发出版本.docx')],
        )
        if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
            from ipdb import set_trace; set_trace()
            raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")
        
        with get_doc_datastore(self._kb.kb_id) as doc_ds:
            doc_data, err = doc_ds.load_doc_data('16e89e38-a357-40b5-a648-f2d2a0dd20db')
        from ipdb import set_trace
        set_trace()

    def _process_deepseek_output(self, text):
        llm_output = text.split("</think>")[-1].split('<separator>')
        item_to_buy = llm_output[0]
        questions = llm_output[1:]
        all_queries = ','.join(questions)
        return questions, all_queries, item_to_buy

    # TODO qianhai
    def _filter_doc_ids(self, query, kb_id):
        
        # LLM_MODEL = "volcengine-deepseek-r1"  # "deepseek-r1:70b"
        
        
        doc_data_list = []
        # doc_info_dict = {}
        doc_info_list = []
        doc_id_list = []
        with get_doc_datastore(kb_id) as doc_store:
            doc_ids, err = doc_store.list_doc_ids()
            if err.code != KBXError.Code.SUCCESS:
                # logger.error(f"Failed to list doc ids: {err}")
                return []
            for doc_id in doc_ids:
                doc_data, err = doc_store.load_doc_data(doc_id=doc_id)
                doc_data_list.append(doc_data)
                # TODO: 获取文档摘要
                doc_info_list.append({
                    'file_name': doc_data.file_name,
                    # 'summary': doc_data.summary,
                    'doc_id': doc_id
                })
                doc_id_list.append(doc_id)
                # doc_info_dict[doc_data.file_name] = doc_id
        import json
        document_info = json.dumps(doc_info_list, ensure_ascii=False)
        client_config, client = KBX.get_ai_model_config_and_client(LLM_MODEL)
        final_prompt = f"""你是一个专业的采购文档专家。请根据用户的输入内容提取待采购的核心产品关键词，从文件信息表中找出和关键词相关的所有文档。遵循以下规则：\n\n## 输入信息：\n1. 用户输入：'<待采购货品或者项目关键词>的<信息类型请求>' 。核心：要解析待采购货品部分，忽略后边的信息类型请求\n2. 文件列表：[{{'file_name':文件名1,'doc_id':ID1}}, ...]\n\n## 要求：\n1. 优先保留更多匹配结果而非精确过滤，要最大限度召回相关文档\n2. 仅输出匹配到的doc_id值，禁止包含file_name或其他说明文字\n3. 多个结果时用<separator>分隔，例如：123<separator>456\n4. 严格保持输出纯净，不要添加任何标点或格式\n5. 保持原始doc_id的大小写格式\n\n## 示例\n[输入]：阻燃电线的供应商资质是什么？\n[解析]: \n- 待采购货品或者项目关键词: 阻燃、电线、阻燃电线\n- 匹配文件：\n  {{'file_name':'BVV阻燃电线工艺规范','doc_id':'efff-221'}}\n  {{'file_name':'电线类产品认证标准','doc_id':'2bisu-009'}}\n[输出] 'efff-221<separator>2bisu-009'\n\n## 当前文件信息表（JSON格式）：\n{document_info}\n\n## 用户输入：\n{query}\n\n请直接输出匹配的doc_id："""
        response = client.chat(
            client_config,
            prompt=final_prompt,  # f"请根据用户的输入分析其感兴趣的条目，从文件信息表中找到所有相关的文件，输出文件id（即doc_id）。文件信息表（list）：每个文档是一个字典，包含以下字段：\n  - `doc_id` (int)：文档的唯一标识符。\n  - `file_name` (str)：文档的文件名。\n\n 请判断文件名和用户输入的相关性，输出所有相关的文件的doc_id，不要遗漏。\n\n 用户的输入: {query}\n\n 文件信息表：{document_info}\n\n 若找到多个文件，请用<separator>分隔doc_id。请直接输出用<separator>分隔的doc_id，不要输出其他内容。",
            temperature=0.7
        )
        # print("ffinal_prompt, ", final_prompt)
        doc_ids = response.replace("\n", "").split("</think>")[-1].split('<separator>')
        # for iii in doc_info_list:
        #     for doc_id in doc_ids:
        #         if iii['doc_id'] == doc_id:
        #             print(iii['file_name'])

        return doc_ids

    def _retrieve(self, kb: KnowledgeBase, vector_dynamic_kwargs: Dict[str, Any] = None):
        llm_response = ''
        query = '开关柜的服务期限/工期/交货期'
        # 开关柜的供货期，资质要求
        # query = '电力电缆'
        
        # step1：大模型生成查询问题
        client_config, client = KBX.get_ai_model_config_and_client(LLM_MODEL)
        final_response_text = client.chat(
            client_config,
            system_prompt="你是经验丰富的资料员，擅长从文档资料库中搜集历史数据。现在用户要从文档资料库中搜索曾经采购过的货品及其属性的值，将搜索结果作为经验，基于这些经验来决策下次采购的货品属性。",  # 请根据文档，为待采购的货品补充对应属性的值。",
            prompt=f"请从用户的要求中提取待查询的属性和货品，基于属性生成查询的问题输入到文档资料库中。\n\n## 要求：\n货品和问题之间请用<separator>进行分隔，且问题前不要加序号。### 输出格式\n货品<separator>问题1<separator>问题2\n\n\n\n##示例\n用户的要求为：绿植，供货期和供应商\n输出：绿植<separator>供货期是多久？<separator>供应商是哪家？\n\n 用户的问题：{query} \n\n 请直接输出问题，不要输出其他内容。",
            temperature=0.7
        )
        queries, all_queries, item_to_buy = self._process_deepseek_output(final_response_text)
        print("agent output: ", queries)  # final_response_text.split("</think>")[-1])
        
        # step2：大模型生成查询的doc范围
        selected_doc_ids = self._filter_doc_ids(query, kb.kb_id)
        print('--------------select doc ids', selected_doc_ids)
        if len(selected_doc_ids) == 0:
            selected_doc_ids = None
        
        # step3：根据生成的查询问题，多次查询，并补充属性
        for i in range(len(queries)):
            query_text = queries[i].replace("\n", "")
            query = QueryConfig(
                text=query_text,
                top_k=5,
                score_threshold=0.0,  # TODO qianhai：阈值调一下
                vector_dynamic_kwargs=vector_dynamic_kwargs or {
                    "keyword_similarity_weight": 0.0,
                    "selected_doc_ids": selected_doc_ids
                }
            )

            # selected_doc_ids = None
            # selected_doc_ids = ['a006df97-c8a0-40fa-8d90-ebfa1047d286', '495e999a-36c8-40da-ae3f-8dd3b74151a2', '7610ad3f-3985-4ba7-bb3b-5d6654e93da7', 'f3e4bbcb-6050-4464-bf44-eb1e3d0982a3']

            # query_result = KBX.retrieve(query=query, kb_ids=[kb.kb_id], selected_doc_ids=selected_doc_ids)
            query_result = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
            assert isinstance(query_result, list), f"Query result should be a list, given {query_result}"
            assert len(query_result) > 0, "Failed to get query result"
            if query.top_k > 0:
                assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                                                        f"given {query.top_k} and {len(query_result)}"

            print(f'Get {len(query_result)} results from kb ("{kb.kb_config.name}")')
            retrieval_text = ''
            for k, qr in enumerate(query_result):
                print(f'------------------------- #{k}, score={qr.score} -------------------------')
                print(qr.text_chunk.text)
                retrieval_text += '\n' + qr.text_chunk.text
                
                # 获取file_name
                file_name = qr.meta_data.get("doc_name", "")
                print("chunk from file :", file_name)
                
                # 获取doc_id
                doc_id = qr.doc_id
                chunk_id = qr.text_chunk.chunk_id
                print("doc id and chunk id:", doc_id, chunk_id)
                
                # graph索引的result
                if qr.graph_triplets:
                    print(qr.graph_triplets)
                if qr.subgraph_options:
                    print(qr.subgraph_options)

            client_config, client = KBX.get_ai_model_config_and_client(LLM_MODEL)
            response_text = client.chat(
                client_config,
                system_prompt=f"你擅长根据历史文档数据总结信息以指导未来决策，基于经验来决定下次采购货品的属性。以下的文档资料记录了历史采购的货品具有哪些属性及其对应的值，请根据历史数据，为待采购的货品的每个属性补充合适的值。例如，某件货品有5次从供应商A处采购，有1次从供应商B处采购，则属性为供应商，该属性应补充的值为A。",
                prompt=f"请从用户要求中提取出货品的名称和待补充的属性:\n\n 用户要求：{query_text} \n\n 历史文档数据：{retrieval_text} \n\n 请补充属性的值，注意，只补充用户要求中的属性，其余属性请忽略。",
                temperature=0.7
            )
            final_response = response_text.split("</think>")[-1]
            llm_response += '\n\n' + final_response
            print(f"propertyyyyyyyyyyyyyy: {final_response}")

        # step4：大模型整合待采购对象、历史属性值，写招标文件
        client_config, client = KBX.get_ai_model_config_and_client(LLM_MODEL)
        final_response_text = client.chat(
            client_config,
            system_prompt="你是经验丰富的招标员，请根据文档资料库中的数据和用户的需求，撰写招标需求文件。",  # 请根据文档，为待采购的货品补充对应属性的值。",
            prompt=f"## 文档资料库中的数据：\n{llm_response} \n\n## 待采购的货品或项目\n{item_to_buy} \n\n## 用户的需求：{all_queries} \n\n请根据上述数据，撰写招标文件。",
            temperature=0.7
        )
        print(f"response_text: {final_response_text}")

    def test_vector_index_case(self):
        # 只开启vector index
        vec_kb_config = KBCreationConfig(
            name="good_kb",
            description=self._kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    # DocFileType.PDF: "MinerUPDFParser",
                    DocFileType.DOCX: "DefaultDocxParser",
                    DocFileType.EXCEL: "DefaultExcelParser",
                },
                # image_strategy=ImageStrategyConfig(
                #     type=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,  # ImageEmbeddingStrategy.NONE
                #     vision_model='OpenGVLab/InternVL2-26B'
                # ),
                # pdf_ocr_strategy=PdfOcrStrategyConfig(parser_type='MinerU')
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model=EMBEDDING_MODEL,  # "bge-m3:latest",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    chunk_size=1024,
                    overlap_size=50,
                    # delimiters=["\n\n", "。", ". ", " ", ""]
                ),
            ),
            rerank_config=RerankConfig(
                rerank_type="ModelRerank",
                rerank_kwargs={"rerank_model": "BAAI/bge-reranker-v2-m3"},
            ),
        )
        self._kb = None
        self._create_std_kb(vec_kb_config)
        # self._retrieve(self._kb)
        # self._modify_config()
        
    def test_graph_vector_index_case(self):
        graph_ds_config = GraphDSConfig(type='networkx',
                                        connection_kwargs={
                                            "graphml_file": "./cache/smore.graphml"})
        vec_graph_kb_config = KBCreationConfig(
            name="vec_graph_kb",
            description=self._kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    # DocFileType.PDF: "MinerUPDFParser",
                    DocFileType.DOCX: "DefaultDocxParser",
                    DocFileType.EXCEL: "DefaultExcelParser",
                },
                image_strategy=ImageStrategyConfig(
                    type=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,  # ImageEmbeddingStrategy.NONE
                    vision_model='OpenGVLab/InternVL2-26B'
                ),
                # pdf_ocr_strategy=PdfOcrStrategyConfig(parser_type='MinerU')
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model=EMBEDDING_MODEL,  # "bge-m3:latest",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    chunk_size=1024,
                    overlap_size=50,
                    delimiters=["\n\n", "。", ". ", " ", ""]
                ),
            ),
            kg_config=KnowledgeGraphIndexConfig(
                index_strategy="DefaultGraphIndex",
                llm_model=LLM_MODEL,
                embedding_model=EMBEDDING_MODEL,
                schema_dict=self._schema_dict,
                external_graph_ds=graph_ds_config
            ),
            rerank_config=RerankConfig(
                rerank_type="ModelRerank",
                rerank_kwargs={"rerank_model": "linux6200/bge-reranker-v2-m3"},
            ),
        )
        self._kb = None
        self._create_std_kb(vec_graph_kb_config)
        self._retrieve(self._kb)


if __name__ == "__main__":
    # 手动执行
    test_case = TestVectorKeywordIndexE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_vector_index_case()
    # test_case.test_graph_vector_index_case()
