import os
KBX_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
sys.path.insert(0, KBX_DIR)

import streamlit as st
import uuid
from streamlit_echarts import st_echarts
from typing import Dict
from src.core import CB_STATE_DICT_KEY, ChatBotState, ChatBotConfig
from src.kbx_doc_write_api import DocWriterClient
from src.kbx_chatbot_page import KBXChatBotPage

import json
import logging
logger = logging.getLogger('QA_logger')
logger.setLevel(logging.DEBUG)
file_handler = logging.FileHandler('QA.log')
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)


class DocWriterChatBotPage(KBXChatBotPage):
    def __init__(self, config: ChatBotConfig, user_id: str) -> None:
        super().__init__(config, user_id)

    def _reset_chatbot_state(self) -> None:
        if self._config.name in st.session_state[CB_STATE_DICT_KEY]:
            raise RuntimeError(f'Duplicate chatbot name {self._config.name}')

        st.session_state[CB_STATE_DICT_KEY][self._config.name] = ChatBotState()
        client = DocWriterClient(**self._config.api_client_kwargs)
        st.session_state[CB_STATE_DICT_KEY][self._config.name].client = client
        st.session_state[CB_STATE_DICT_KEY][self._config.name].messages = []
        st.session_state.extra_display = True
        st.session_state.chat_input = ""

    def call_custom_chat_page(self) -> None:
        if CB_STATE_DICT_KEY not in st.session_state:
            st.session_state[CB_STATE_DICT_KEY] = {}
        if self._config.name not in st.session_state[CB_STATE_DICT_KEY]:
            self._reset_chatbot_state()

        client = st.session_state[CB_STATE_DICT_KEY][self._config.name].client
        messages = st.session_state[CB_STATE_DICT_KEY][self._config.name].messages

        kb_name_id = dict([(name, id) for id, name in client._list_kbs()])
        with st.sidebar:
            st.image(self._config.sidebar_image)
            option = st.selectbox(
                label='RAG知识库:',
                options=kb_name_id.keys()
            )

            st.session_state.kb_option = option
            top_k = st.number_input('选择 RAG 检索的 top-k 值:', min_value=1, max_value=50, value=5, step=1)
            st.session_state.top_k = top_k

            score_threshold = st.slider('设置检索分数阈值:', min_value=0.0, max_value=1.0, value=0.0, step=0.1)
            st.session_state.score_threshold = score_threshold

            # keyword_similarity_weight = st.slider('设置关键词相似度权重:', min_value=0.0, max_value=1.0, value=0.0, step=0.1)
            # st.session_state.keyword_similarity_weight = keyword_similarity_weight

        if st.session_state.extra_display:
            with st.container(border=True):
                st.markdown("## 💭  推荐问题")

                recommended_questions = [
                    f':rainbow:  {question}' for question in self._config.recommended_questions]

                for question in recommended_questions:
                    if st.button(question, key=f"btn_{question}"):
                        st.session_state.chat_input = question[11:]
                        st.rerun()

        for i, msg_item in enumerate(messages):
            self.display_message_with_trace_info(msg_item)

        prompt = st.chat_input(placeholder='请输入您的问题')

        number_dict = {
            1: '\n\n### 一、',
            2: '\n\n### 二、',
            3: '\n\n### 三、',
            4: '\n\n### 四、',
            5: '\n\n### 五、',
            6: '\n\n### 六、',
        }
        if st.session_state.chat_input or prompt:
            final_prompt = st.session_state.chat_input if st.session_state.chat_input else prompt
            st.session_state.extra_display = False
            st.session_state.chat_input = ""
            if not client:
                st.info("未能成功初始化客户端，请检查对应的参数配置")
                st.stop()

            st.session_state[CB_STATE_DICT_KEY][self._config.name].messages.append(
                {"role": "user", "content": final_prompt}
            )
            st.chat_message("user", avatar=self._config.user_avatar).markdown(final_prompt)

            with st.chat_message("assistant", avatar=self._config.assistant_avatar):
                resoning_placeholder1 = st.empty()
                assistant_placeholder1 = st.empty()

                # col1, col2 = st.columns(2)
                # with col1:
                #     resoning_placeholder = st.empty()
                # with col2:
                #     assistant_placeholder = st.empty()
                # assistant_placeholder.text('')  # 答案正在生成中，请稍等片刻～

            standard_messages = []
            for msg_item in st.session_state[CB_STATE_DICT_KEY][self._config.name].messages:
                standard_messages.append({"role": msg_item['role'], "content": msg_item['content']})

            # 只提取最新的用户消息作为query参数
            latest_user_message = [{"role": "user", "content": final_prompt}]

            def process_request_streaming_output(response, resoning_placeholder,
                                                 assistant_placeholder, if_display_answer=False):
                answer = ""
                answer_text = ""
                reasoning_text = ""
                display_text = ""
                if response.status_code == 200:
                    for chunk in response.iter_lines():
                        if chunk:
                            chunk_data = json.loads(chunk.decode("utf-8"))
                            if 'response' in chunk_data:
                                content = chunk_data['response']
                                if '<think>' in content:
                                    in_reasoning_block = True
                                    reasoning_text += content.replace('<think>', '')
                                elif '</think>' in content:
                                    in_reasoning_block = False
                                    reasoning_text += content.replace('</think>', '')
                                else:
                                    if in_reasoning_block:
                                        reasoning_text += content
                                        answer += content
                                        resoning_placeholder.code(reasoning_text)
                                    else:
                                        answer += content
                                        answer_text += content
                                        if if_display_answer:
                                            display_text += content
                                            assistant_placeholder.markdown(display_text)
                                # print(chunk_data['response'])
                                if hasattr(chunk_data, 'done_reason'):
                                    if chunk_data.done_reason == 'stop':
                                        break
                                    else:
                                        # print(f"finish_reson: {choice.finish_reason}")
                                        pass
                    return answer, answer_text, reasoning_text

            def process_streaming_output(generated_text, resoning_placeholder,
                                         assistant_placeholder, if_display_answer=False):
                answer = ""
                answer_text = ""
                reasoning_text = ""
                display_text = ""

                for event in generated_text:
                    if event.model == 'deepseek-r1:70b':
                        if hasattr(event, 'choices') and event.choices:
                            choice = event.choices[0]
                            content = getattr(choice.delta, 'content', None)
                            if '<think>' in content:
                                in_reasoning_block = True
                                reasoning_text += content.replace('<think>', '')
                            elif '</think>' in content:
                                in_reasoning_block = False
                                reasoning_text += content.replace('</think>', '')
                            else:
                                if in_reasoning_block:
                                    reasoning_text += content
                                    answer += content
                                    resoning_placeholder.code(reasoning_text)
                                else:
                                    answer += content
                                    answer_text += content
                                    if if_display_answer:
                                        display_text += content
                                        assistant_placeholder.markdown(display_text)
                            if hasattr(choice, 'finish_reason'):
                                if choice.finish_reason == 'stop':
                                    break
                                else:
                                    # print(f"finish_reson: {choice.finish_reason}")
                                    pass
                    else:  # volcengine
                        if hasattr(event, 'choices') and event.choices:
                            choice = event.choices[0]
                            delta_content = getattr(choice.delta, 'content', None)
                            reasoning_content = getattr(choice.delta, 'reasoning_content', None)

                            # from ipdb import set_trace; set_trace()
                            if delta_content:
                                answer += delta_content
                                answer_text += delta_content
                                if if_display_answer:
                                    display_text += delta_content
                                    assistant_placeholder.markdown(display_text)
                            if reasoning_content:
                                # update_display(reasoning_content, is_reasoning=True)
                                reasoning_text += reasoning_content
                                answer += reasoning_content
                                resoning_placeholder.code(reasoning_text)
                            if hasattr(choice, 'finish_reason'):
                                if choice.finish_reason == 'stop':
                                    break
                                else:
                                    # print(f"finish_reson: {choice.finish_reason}")
                                    pass
                return answer, answer_text, reasoning_text

            llm_response = ''
            display_text = ''  # '正在分析用户的输入...\n\n'  #display_text1  # ""
            # reasoning_text = ''  #display_text1  # ""
            # assistant_placeholder.markdown(display_text)
            answer_text = ''
            all_display_text = ''
            all_reasoning_text = ''

            # step1
            # """
            response_text1 = \
                client.generate_retrieved_questions(
                    query=json.dumps({"messages": latest_user_message}, ensure_ascii=False),
                )  # 这里不输入历史消息standard_messages，只获取最新的用户输入
            import openai
            if not isinstance(response_text1, openai.Stream):
                display_text1, query_list, all_queries, item_to_buy = \
                    response_text1[0], response_text1[1], response_text1[2], response_text1[3]

            else:
                answer, answer_text, reasoning_text1 = process_streaming_output(response_text1, resoning_placeholder1, assistant_placeholder1, if_display_answer=False)  # noqa

                query_list, all_queries, item_to_buy = \
                    client.process_llm_output(answer_text)
                display_text1 = '# 1. 用户的查询内容\n\n' + item_to_buy + '\n\n' + all_queries

            display_text += (display_text1 + '\n\n正在搜索相关文档...\n\n')
            all_display_text += display_text
            all_reasoning_text += reasoning_text1
            assistant_placeholder1.markdown(display_text + '\n\n')
            # """

            # step2
            # display_text2, selected_doc_ids = client.select_doc_id(
            #     query=json.dumps({"messages": standard_messages}, ensure_ascii=False),
            #     kb_ids=[kb_name_id.get(st.session_state.kb_option)]
            # )

            # """
            response_text2, doc_info_dict = client.select_doc_id(
                query=item_to_buy,
                kb_ids=[kb_name_id.get(st.session_state.kb_option)]
            )  # stream = True
            with st.chat_message("assistant", avatar=self._config.assistant_avatar):
                resoning_placeholder2 = st.empty()
                assistant_placeholder2 = st.empty()
            import requests
            if isinstance(response_text2, openai.Stream) or isinstance(response_text2, requests.models.Response):

                if isinstance(response_text2, openai.Stream):
                    answer, answer_text, reasoning_text2 = process_streaming_output(response_text2, resoning_placeholder2, assistant_placeholder2, if_display_answer=False)  # noqa
                elif isinstance(response_text2, requests.models.Response):
                    answer, answer_text, reasoning_text2 = process_request_streaming_output(response_text2, resoning_placeholder2, assistant_placeholder2, if_display_answer=False)  # noqa
                selected_doc_ids = answer_text.replace("\n", "").split("</think>")[-1].split('<separator>')

                file_name_list = []
                for doc_id in selected_doc_ids:
                    try:
                        file_name_list.append(doc_info_dict[doc_id])
                    except KeyError:
                        continue
                # all_file_names = '\n\n'.join(doc_info_dict[doc_id] for doc_id in selected_doc_ids)
                all_file_names = '\n\n'.join(file_name_list)
                display_text2 = '# 2. 查询到相关文档\n\n' + all_file_names
            elif isinstance(response_text2, list) and len(response_text2) == 0:
                selected_doc_ids = None
                display_text2 = '# 2. 查询到相关文档\n\n'
                reasoning_text2 = ''
            else:
                display_text2 = response_text2
                selected_doc_ids = doc_info_dict

            # display_text += (display_text2 + '\n\n')
            # assistant_placeholder2.markdown(display_text)
            assistant_placeholder2.markdown(display_text2 + '\n\n')

            display_text2 += ('\n\n' + '正在从上述文档中检索相关的文字...' + '\n\n')
            all_display_text += display_text2
            all_reasoning_text += reasoning_text2
            assistant_placeholder2.markdown(display_text2)
            # """

            all_reference_context = []

            placeholders = []

            # ##############fake###########
            # all_queries = ''
            # selected_doc_ids = None  # ['7aaf641d-cffc-4ae4-8223-1d31d4991aec']  # None
            # ##############fake###########

            if not all_queries:
                query_list = ["交货期", "交货方式", "质保期", "付款方式和条件"]
                # query_list = ["质保期", "付款方式和条件"]

            for i in range(len(query_list)):
                # if i == 1:
                #     break

                with st.chat_message("assistant", avatar=self._config.assistant_avatar):
                    resoning_placeholder = st.empty()
                    assistant_placeholder = st.empty()
                placeholders.append((resoning_placeholder, assistant_placeholder))

                query_text = query_list[i].replace("\n", "")
                # if '空调' in item_to_buy and '交货期' in query_text:
                #     continue
                #     kongtiao_flag = True
                # else:
                #     kongtiao_flag = False
                #     query_text = '工期 交货期'
                # from ipdb import set_trace; set_trace()
                reference_context, generated_text, response_type = client.create_chat_message(
                    query_text=query_text,
                    selected_doc_ids=selected_doc_ids,
                    top_k=st.session_state.top_k,
                    score_threshold=st.session_state.score_threshold,
                    keyword_similarity_weight=0,
                    enable_index_types=None,
                    kb_ids=[kb_name_id.get(st.session_state.kb_option)],
                    # kongtiao_flag=kongtiao_flag
                )
                all_reference_context.extend(reference_context)

                logger.debug(f"question: {standard_messages[-1]['content']}")

                # display_text += '### 3. 查询结果\n\n'

                if i == 0:
                    display_text = "# 3. 项目需求文件\n\n---------------------------------------------------------------------\n\n"   #### - 问题：<" + query_text + '>的查询结果如下：\n\n'  # noqa
                else:
                    display_text = ""  # "\n\n#### - 问题：<" + query_text + '>的查询结果如下：\n\n'
                all_display_text += display_text

                if response_type == 'rag_response':
                    answer, answer_text, reasoning_text_i = process_streaming_output(generated_text, placeholders[i][0], placeholders[i][1], if_display_answer=True)  # noqa

                    answer_text = answer_text.replace('--', '\n\n')
                    process_text0 = answer_text.split("💡")[0].rstrip().rstrip('#').rstrip()
                    process_text1 = "💡*" + answer_text.split("💡")[-1].replace("\n", "") + "*"
                    print("llm outputttttttttttttttt: ", answer_text)
                    if i == 0:
                        pre_answer_text = "## 商务要求\n\n### 一、货物需求及数量一览表\n\n| 序号 | 货物名称 | 规格型号 | 单位 | 参考数量 | 备注 |\n| --- | --- | --- | --- | --- | --- |\n| 1   |       |     |    |        |      |\n| 2   |       |     |    |        |      |\n| 3   |       |     |    |        |      |\n\n"  # noqa
                    else:
                        pre_answer_text = ""
                    answer_text = pre_answer_text + number_dict[i + 2] + query_text + '\n\n' + answer_text
                    all_display_text += (pre_answer_text + number_dict[i + 2] + query_text + '\n\n' + process_text0 + '\n\n' + process_text1 + '\n\n\n\n')  # noqa
                    all_reasoning_text += reasoning_text_i
                    placeholders[i][1].markdown(display_text + answer_text)

                    # from ipdb import set_trace; set_trace()

                    # logger.debug(f"msg id: {msg_id}, answer: {answer}")
                elif response_type == 'direct_response':
                    display_text = generated_text
                    # logger.debug(f"msg id: {msg_id}, answer: {display_text}")
                elif response_type == 'media_response':
                    display_text = generated_text
                    # logger.debug(f"msg id: {msg_id}, answer: {display_text}")

                llm_response += '\n\n' + answer_text

            all_display_text += "\n\n### 六、报价要求\n\n投标方所提供的商务总报价仅供招标方进行商务评审使用，并不构成招标方关于采购金额或数量的承诺。最终的采购金额与数量将依据实际期间内招标方发出的采购订单为准，招标人和中标人之间将根据各规格的中标单价签订单价购销合同。\n\n投标报价需涵盖完成本项目所需的所有成本与费用，这包括但不限于：货物及其辅助材料的加工制造、生产过程中的监造、制造、工厂内的检验与测试、包装、运输至招标方指定地点、安装指导、培训服务、质保期内的服务以及缺陷责任期的服务等全过程产生的费用。此外，还应包含保险费、管理费、利润、规费、税金（需考虑国家最新的税费政策），以及针对原材料价格波动和供货周期变化等因素的风险评估\n\n\n\n### 七、签订合同\n\n中标通知书发出后30天内。中标人与__________签订合同。\n\n\n\n### 八、其他\n\n\n\n"  # noqa

            # step4
            # with st.chat_message("assistant", avatar=self._config.assistant_avatar):
            #     resoning_placeholder_final = st.empty()
            #     assistant_placeholder_final = st.empty()
            # display_text = "\n\n### 4. 撰写招标文件 \n\n\n\n"
            # all_display_text += display_text
            # assistant_placeholder_final.markdown(display_text)

            # final_response = client.write_procurement_doc(llm_response, item_to_buy, all_queries)
            # answer_final, answer_text_final, reasoning_text_final = process_streaming_output(final_response, resoning_placeholder_final, assistant_placeholder_final, if_display_answer=True)  # noqa
            # assistant_placeholder_final.markdown(display_text + answer_text_final + '\n\n')
            # all_display_text += answer_text_final
            # all_reasoning_text += reasoning_text_final

            msg_id = str(uuid.uuid4())
            st.session_state[CB_STATE_DICT_KEY][self._config.name].messages.append(
                {
                    "role": "assistant",
                    "content": all_display_text,
                    "reasoning_text": all_reasoning_text,
                    "reference_context": all_reference_context,
                    "unique_id": msg_id,
                    # 'pre_display': display_text1 + '\n' + display_text2
                })
            if msg_id not in st.session_state:
                st.session_state[msg_id] = {'button_clicked': False, 'feedback': 'fair'}
            st.rerun()