import numpy as np
import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)

from kbx.kbx import KBX
kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
KBX.init(config=kbx_yaml_file)
ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
KBX.register_ai_models_from_conf(model_configs=ai_models_yaml_file, overwrite=True)


embedding_config, embedding_client = \
                KBX.get_ai_model_config_and_client('BAAI/bge-m3')

embed1 = embedding_client.text_embedding(embedding_config, text='vimo的优势是什么')
embed2 = embedding_client.text_embedding(embedding_config, text='我是中国人我是中国人我是中国人')
embed1 = np.linalg.norm(embed1)
embed2 = np.linalg.norm(embed2)

cosine_sim = np.dot(embed1, embed2) / (embed1 * embed2)
print('相似度：：：', cosine_sim)