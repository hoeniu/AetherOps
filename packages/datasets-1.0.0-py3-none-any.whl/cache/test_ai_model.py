import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
from kbx.kbx import KBX


if __name__ == '__main__':
    yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')  # 包含一个或多个AI大模型配置的yaml文件
    if len(sys.argv) > 1:
        yaml_file = sys.argv[1]

    KBX.register_ai_models_from_yaml(yaml_file=yaml_file, overwrite=True)
    print(f'Register ai models in {yaml_file}')

    chat_config, chat_client = KBX.get_ai_model_config_and_client('qwen2_5-32b-int8')
    query = "你知道太阳的直径是多少吗？"
    query_batch = ["你知道太阳的直径是多少吗？", "地球和火星之间的距离是多少？"]
    response = chat_client.chat(chat_config, prompt=query, system_prompt="你是一个天文专家，请为用户提供尽可能专业的答疑")
    print(f'query={query}\nresponse={response}')

    embedding_config, embedding_client = KBX.get_ai_model_config_and_client('doubao-embedding')
    embedding = embedding_client.text_embedding(embedding_config, text=query)
    embedding_batch = embedding_client.text_embedding_batch(model_config=embedding_config, texts=query_batch)
    print(f'\nquery: {query}\nembedding: {embedding_batch[0]}\n{len(embedding_batch[0])}')  # 2560维向量
