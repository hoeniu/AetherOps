import pandas as pd
import json


file_dict = {
    "产品资料": [
        "VS500",
        "VG800P",
        "VHS8000",
        "VS600",
        "VG800产品规格书_119",
        "VS2000P产品规格书",
        "VS800P读码器单页",
        "VS800读码器单页",
        "VS1000P读码器单页",
        "思谋智能一体化设备.json",
        "思谋智能一体化设备_eng",
        "思谋智能传感器系列产品.json",
        "思谋智能传感器系列产品_eng",
        "思谋智能制造产品体系",
        "思谋智能工业平台.json",
        "思谋智能工业平台_eng",
        "思谋董事长介绍.json",
        "思谋董事长介绍_eng",
        "五轴组装SOP",
        "五轴优势",
        "Airpods检测",
        "消费五轴-V2.0",
        "五轴产品汇报-脱敏",
        "五轴产品sop设计",
        "0918五轴一体机优化视频1_1",
        "耳机充电仓",
        "Saleskit-五轴检测"
    ],
    "开发手册": [
        "smoregauge",
        "dataflow",
        "smp"
    ],
    "公司资料": [
        "gpt4_output_chairman_zh",
        "公司介绍.json",
        "公司介绍_eng",
        "思谋解决方案及案例.json",
        "思谋解决方案及案例_eng",
        "smartmore_sft_filtered"
    ]
}

file_dict_categories = ["公司资料", "开发手册", "产品资料"]
category_counts = {category: 0 for category in file_dict_categories}
dic = {}
with open('./kbx_test_data/all_QA_114.json', 'r', encoding='utf-8') as f:
    json_data = json.load(f)

li = []
for key, value in file_dict.items():
        for val in value:
            li.append(val)
cnt = 0
for item in json_data:
    source = item['source']
    flag = 0
    cnt +=1
    for key, value in file_dict.items():
        for val in value:
            if val in source:
                dic[key] = dic.get(key, 0) + 1
    # for val in li:
    #     if val in source:
    #         dic[val] = dic.get(val, 0) + 1
    #         flag = 1
    # if flag == 0:
    #     print(source)


print(dic, cnt)