import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)

from kbx.common.types import DocData, DocElement, DocElementType
from kbx.common.utils import generate_new_id
from kbx.splitter.splitter_factory import get_splitter
from kbx.splitter.types import SplitterConfig


# Test constructor
def test_constructor():
    splitter = get_splitter(SplitterConfig(text_chunk_token_size=500,
                    text_chunk_overlap=50,
                    text_chunk_delimiters=["\n\n", ". ", " ", ""],
                    keep_delimiter=True),
                    )
    doc_data = DocData(doc_id=generate_new_id(), doc_elements=[
        DocElement(doc_element_id=generate_new_id(), text="")
    ])
    
    # Cheap Alitalia Flights\nAlitalia is Italy’s flag carrier, and has its headquarters in Rome. It maintains hubs at both Rome’s Leonardo da Vinci Fiumicino International Airport and Milan’s Malpensa International Airport, the two busiest airpors in the country. Its full name is Alitalia – Linee Aeree Italiane, and the name Alitalia is a play on the Italian word for wings (“ali”) and the name of the country (“Italia”).\nAlitalia flies to more than 100 destinations in Africa, Asia, North America, South America and Europe.\nThe airline has been in financial difficulty for several years (including a period of time when it said it couldn’t pay its workers’ salaries), at one point considering a merger with Air France and KLM (which own 2% of the airline) and more recently getting assistance from the Italian government (which owns 49% of the airline) to help privatize the airline. As of January 2007, Alitalia was looking for a buyer to purchase just over 30% of its shares.\nIn addition to its financial woes, Alitalia recently had a pretty bad record of losing its passengers’ luggage.\nAlitalia is a member of the SkyTeam airline alliance.\nReady to fly? Search for international airfare and cheap air tickets today.
    
    chunks = splitter.split(doc_data)
    from ipdb import set_trace
    set_trace()


# Test case 1: Basic splitting
def test_split_basic():
    splitter = get_splitter("NaiveTextSplitter", SplitterConfig())

    doc_data = DocData(doc_id=generate_new_id(), doc_elements=[
        DocElement(doc_element_id=generate_new_id(), text="This is a test."),
        DocElement(doc_element_id=generate_new_id(), text="Another test.")
    ])

    chunks = splitter.split(doc_data)

    assert len(chunks) == 2
    assert chunks[0].text == "This is a test."
    assert chunks[1].text == "Another test."


# Test case 2: Empty doc_elements
def test_split_empty_doc_elements():
    splitter = get_splitter("NaiveTextSplitter", SplitterConfig())

    doc_data = DocData(doc_id=generate_new_id(), doc_elements=[])

    chunks = splitter.split(doc_data)

    assert len(chunks) == 0


# Test case 3: Doc_elements with various fields
def test_split_doc_elements_with_fields():
    splitter = get_splitter("NaiveTextSplitter", SplitterConfig())

    doc_data = DocData(doc_id=generate_new_id(), doc_elements=[
        DocElement(doc_element_id=generate_new_id(), text="This is a test.", content_description="Description 1"),
        DocElement(doc_element_id=generate_new_id(),
                   table=[["col1", "col2"], ["val1", "val2"]],
                   table_caption="Table caption",
                   type=DocElementType.TABLE)
    ])

    chunks = splitter.split(doc_data)

    assert len(chunks) == 2
    assert chunks[0].text == "col1: val1; col2: val2"
    assert chunks[1].text == "This is a test.Description 1"


# Test case 4: Keep delimiter
def test_split_keep_delimiter():
    splitter = get_splitter("NaiveTextSplitter", SplitterConfig(keep_delimiter=True))

    doc_data = DocData(doc_id=generate_new_id(), doc_elements=[
        DocElement(doc_element_id=generate_new_id(), text="This is a test.\n\nAnother test.")
    ])

    chunks = splitter.split(doc_data)

    assert len(chunks) == 1
    assert chunks[0].text == "This is a test.\n\nAnother test."


# Test case 5: Splitting with no delimiters found
def test_split_text_no_delimiters():
    splitter = get_splitter("NaiveTextSplitter", SplitterConfig(text_chunk_delimiters=[]))

    doc_data = DocData(doc_id=generate_new_id(), doc_elements=[
        DocElement(doc_element_id=generate_new_id(), text="This is a test without delimiters")
    ])

    chunks = splitter.split(doc_data)
    assert chunks[0].text == "This is a test without delimiters"


# Test splitting with custom delimiter
def test_split_text_custom_delimiter():
    splitter = get_splitter("NaiveTextSplitter", SplitterConfig(text_chunk_delimiters=["."], keep_delimiter=True))

    doc_data = DocData(doc_id=generate_new_id(), doc_elements=[
        DocElement(doc_element_id=generate_new_id(), text="This is a test. Another test")
    ])
    chunks = splitter.split(doc_data)
    assert len(chunks) == 1
    assert chunks[0].text == "This is a test. Another test"


def test_split_text():
    splitter = get_splitter("RecursiveTextSplitter", SplitterConfig())

    # Test splitting text with one newline
    text = "This is a test\nThis is another test"
    expected_chunks = ["This is a test\nThis is another test"]
    assert splitter.split_text(text) == expected_chunks

    # Test splitting text with multiple newlines
    text = "This is a test\n\nThis is another test\n\n\nThis is a third test"
    expected_chunks = ["This is a test", "This is another test", "\nThis is a third test"]
    assert splitter.split_text(text) == expected_chunks

    # Test splitting text with chunks larger than the chunk size
    text = "This is a very long test that should be split into multiple chunks"
    expected_chunks = ["This is a very long test that should be split into multiple chunks"]
    assert splitter.split_text(text) == expected_chunks

    # Test splitting text with chunks smaller than the chunk size
    text = "This is a short test"
    expected_chunks = ["This is a short test"]
    assert splitter.split_text(text) == expected_chunks


if __name__ == '__main__':
    test_constructor()