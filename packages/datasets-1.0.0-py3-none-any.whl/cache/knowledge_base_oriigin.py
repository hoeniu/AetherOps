from __future__ import annotations
from typing import List, Union, Tuple, Dict, Optional, Any, Iterable
from abc import ABC
import os
import json
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor
from sqlalchemy.orm import Session
from kbx.common.constants import DEFAULT_USER_ID
from kbx.common.utils import generate_new_id, get_pydantic_config_changes, inject_user_ctx
from kbx.common.types import DocData, IndexType, DocElementType, DocFileType, DocStatus, \
    DocInfo, KBXError, UserContext
from kbx.common.logging import logger
from kbx.knowledge_base.types import KBCreationConfig, QueryConfig, QueryResult
from kbx.knowledge_base.base_index import BaseIndex
from kbx.knowledge_base.index_factory import get_knowledge_graph_index, \
    get_structured_index, get_vector_keyword_index
from kbx.parser.parser_factory import get_parser
from kbx.db.types import UserORM, KBInfoORM, DocInfoORM, FileInfoORM
from kbx.db.session import DBSession
from kbx.datastore.ds_factory import get_file_datastore, get_doc_datastore
from kbx.datastore.types import FileType
from kbx.rerank.rerank_factory import get_rerank


INDEX_CONFIG_ATTR_TYPE_PAIRS = [
    # ('keyword_config', IndexType.KEYWORD),
    # ('vector_config', IndexType.VECTOR),
    ('vector_keyword_config', IndexType.VECTOR_KEYWORD),
    ('structured_config', IndexType.STRUCTURED),
    ('kg_config', IndexType.KNOWLEDGE_GRAPH),
]


class KnowledgeBase(ABC):
    def __init__(self, *args, **kwargs) -> None:
        """知识库类型，禁止直接通过__init__进行实例构造，必须使用以下方法获得实例
        - create_new_kb: 用于创建一个新知识库实例
        - get_existed_kb: 用于获取一个已存在的知识库实例
        """
        raise RuntimeError(
            f'Please do not call {self.__class__.__name__}.__init__() directly.'
            'Use create_new_kb or get_existed_kb instead.'
        )

    @property
    def index_map(self) -> Dict[IndexType, BaseIndex]:
        return self._index_map

    @staticmethod
    def create_new_kb(
        kb_config: KBCreationConfig,
        user_id: str,
        desired_kb_id: Optional[str] = None,
    ) -> KnowledgeBase:
        """创建一个新的空知识库
        如果因为配置不合法或其他原因导致知识库创建失败，会抛出异常

        Args:
            kb_config (Optional[KBCreationConfig]): 知识库的配置参数
            user_id (str): 该知识库所属用户的user_id
            desired_kb_id (Optional[str]): 期望新创建知识库使用的唯一id，默认为空，此时会自动生成一个新的kb_id

        Returns:
            KnowledgeBase: 知识库实例
        """
        if not kb_config.name or not isinstance(kb_config.name, str):
            raise ValueError(f'Please provide a valid name for the knowledge base, given "{kb_config.name}"')

        kb = KnowledgeBase.__new__(KnowledgeBase)

        with DBSession() as db:
            # 查询租户id
            user = db.query(UserORM).filter(UserORM.id == user_id).first()
            if user is None:
                raise ValueError(f'User id {user_id} does not exists.')
            kb._tenant_id = user.tenant_id

        kb._user_id = user_id
        kb._kb_config = inject_user_ctx(
            config=kb_config,
            user_ctx=UserContext(user_id=kb._user_id, tenant_id=kb._tenant_id),
            recursive=True,
        )
        kb._kb_id = None

        with DBSession() as db:
            if desired_kb_id:
                previous_kb_info = db.query(KBInfoORM).filter_by(
                    user_id=user_id,
                    tenant_id=kb._tenant_id,
                    id=desired_kb_id
                ).first()
                if previous_kb_info:
                    raise RuntimeError(
                        f'Knowledge base {desired_kb_id} already exists, '
                        'can not create a new one with the same id.'
                    )
                kb._kb_id = desired_kb_id
            else:
                # 如果没有指定有效的desired_kb_id，统一为None，后续由数据库自动生成
                desired_kb_id = None

            previous_kb_info = db.query(KBInfoORM).filter_by(
                user_id=user_id, tenant_id=kb._tenant_id, name=kb_config.name).first()
            if previous_kb_info:
                raise RuntimeError(
                    f'Knowledge base {kb_config.name} already exists, '
                    'can not create a new one with the same name.'
                )

            kb_info = KBInfoORM(
                id=desired_kb_id,
                name=kb_config.name,
                description=kb_config.description,
                creation_config_json=kb_config.model_dump_json(),
                tenant_id=kb._tenant_id,
                user_id=user_id,
            )
            db.add(kb_info)
            db.commit()

            kb._kb_id = str(kb_info.id)
            kb._tenant_id = kb_info.tenant_id

        # 提前准备好index
        kb._index_map = {
            IndexType.VECTOR_KEYWORD: kb._try_get_vector_keyword_index(),
            IndexType.STRUCTURED: kb._try_get_structured_index(),
            IndexType.KNOWLEDGE_GRAPH: kb._try_get_knowledge_graph_index(),
        }
        # 过滤未开启的index索引
        kb._index_map = dict(filter(lambda kv: kv[1] is not None, kb._index_map.items()))

        return kb

    @staticmethod
    def get_existed_kb(
        kb_id: Optional[str] = None,
        kb_name: Optional[str] = None,
        user_id: str = DEFAULT_USER_ID,
    ) -> KnowledgeBase:
        """给定一个已经存在的知识库唯一id或名称，从数据库中读取相关信息，然后初始化对应的实例
        如果kb_id不存在，会直接抛出异常

        Args:
            kb_id (Optional[str]): 知识库唯一id，与kb_name至少提供一个
            kb_name (Optional[str]): 知识库名称，与kb_id至少提供一个
            user_id (str): 该知识库所属用户的user_id

        Returns:
            KnowledgeBase: 知识库实例
        """
        if not kb_id and not kb_name:
            raise ValueError('Please provide valid kb_id or kb_name.')

        tenant_id = None
        # 查询db，尝试恢复kb_id对应的知识库相关信息
        with DBSession() as db:
            filter_kwargs = {'user_id': user_id}
            if kb_id:
                filter_kwargs['id'] = kb_id
            if kb_name:
                filter_kwargs['name'] = kb_name
            kb_info_orm = db.query(KBInfoORM).filter_by(**filter_kwargs).first()
            if kb_info_orm is None:
                raise RuntimeError(f"Knowledge base {kb_id} does not exists for user {user_id}")
            else:
                kb_id = kb_info_orm.id
                kb_name = kb_info_orm.name
                tenant_id = kb_info_orm.tenant_id

        kb = KnowledgeBase.__new__(KnowledgeBase)
        kb._kb_id = kb_id
        kb._kb_config = inject_user_ctx(
            config=KBCreationConfig(**json.loads(kb_info_orm.creation_config_json)),
            user_ctx=UserContext(user_id=user_id, tenant_id=tenant_id),
            recursive=True,
        )
        kb._user_id = user_id
        kb._tenant_id = tenant_id

        # 提前准备好index
        kb._index_map = {
            IndexType.VECTOR_KEYWORD: kb._try_get_vector_keyword_index(),
            IndexType.STRUCTURED: kb._try_get_structured_index(),
            IndexType.KNOWLEDGE_GRAPH: kb._try_get_knowledge_graph_index(),
        }
        # 过滤未开启的index索引
        kb._index_map = dict(filter(lambda kv: kv[1] is not None, kb._index_map.items()))

        return kb

    def remove_kb(self) -> None:
        """删除此知识库"""

        # TODO: 需要加锁？

        # 注意这里的删除逻辑是：
        # - 删除所有文档
        # - 删除各个（空）索引
        # - 删除相关Datastore
        # - 删除知识库记录

        err_msg_list = []

        # 删除文档
        while doc_ids := self.list_doc_ids():
            self.remove_docs(doc_ids=doc_ids)

        # 删除索引
        for index_type in self.index_map.keys():
            try:
                self.index_map[index_type].remove_index()
            except Exception as e:
                err_msg_list.append(f'Failed to remove {index_type} index for knowledge base {self.kb_id}:\n{e}')

        # 删除File/Doc Datastore
        try:
            with get_file_datastore(self.kb_id) as file_ds:
                file_ds.delete_ds()
        except Exception as e:
            err_msg_list.append(f'Remove file datastore for knowledge base {self.kb_id} failed: {e}')

        try:
            with get_doc_datastore(self.kb_id) as doc_ds:
                doc_ds.delete_ds()
        except Exception as e:
            err_msg_list.append(f'Remove doc datastore for knowledge base {self.kb_id} failed: {e}')

        # 删除知识库相关记录
        with DBSession() as db:
            db.query(KBInfoORM).filter_by(id=self.kb_id, user_id=self.user_id, tenant_id=self.tenant_id).delete()
            db.commit()

        if err_msg_list:
            logger.error(
                'Something went wrong when removing knowledge base'
                f' {self.kb_id}:\n' + "\n".join(err_msg_list)
            )

        # 把相关信息设为无效值
        self._kb_id = None
        self._kb_config = None
        self._user_id = None
        self._tenant_id = None

    @staticmethod
    def if_kb_exists(
        kb_id: Optional[str] = None,
        kb_name: Optional[str] = None,
        user_id: str = DEFAULT_USER_ID,
    ) -> bool:
        """判断指定kb_id/kb_name的知识库是否存在

        Args:
            kb_id (Optional[str]): 知识库唯一id，与kb_name至少提供一个
            kb_name (Optional[str]): 知识库名称，与kb_id至少提供一个
            user_id (str): 该知识库所属用户的user_id

        Returns:
            bool: 指定知识库是否存在
        """
        if not kb_id and not kb_name:
            raise ValueError('Please provide valid kb_id or kb_name.')

        # 查询db，尝试恢复kb_id对应的知识库相关信息
        with DBSession() as db:
            filter_kwargs = {'user_id': user_id}
            if kb_id:
                filter_kwargs['id'] = kb_id
            if kb_name:
                filter_kwargs['name'] = kb_name
            kb_info_orm = db.query(KBInfoORM).filter_by(**filter_kwargs).first()
            return kb_info_orm is not None

    @property
    def kb_config(self) -> KBCreationConfig:
        """获取本知识库的参数配置

        Returns:
            KBCreationConfig: 本知识库的参数配置
        """
        if self._kb_config:
            # 返回一个深拷贝，防止外部直接对其进行修改
            return self._kb_config.model_copy(deep=True)
        else:
            return None

    @property
    def kb_name(self) -> str:
        """获取本知识库的名称

        Returns:
            str: 知识库名称
        """
        return str(self.kb_config.name)

    @property
    def kb_id(self) -> str:
        """获取本知识库的唯一id

        Returns:
            str: 知识库唯一id
        """
        return str(self._kb_id)

    @property
    def user_id(self) -> str:
        """获取本知识库的用户id

        Returns:
            str: 用户id
        """

        return self._user_id

    @property
    def tenant_id(self) -> str:
        """获取本知识库的租户id

        Returns:
            str: 租户id
        """

        return self._tenant_id

    def get_legal_config_attr_changes(self) -> List[Union[str, Tuple[str, List]]]:
        """获取本知识库允许修改的配置属性
        Returns:
            List[Union[str, Tuple[str, List]]]: 允许修改的配置属性Key列表，
                如果是一级属性，则对应元素为str类型，如果是二级属性（例如某个IndexConfig的配置），则为元组，
                元组第一个元素为一级属性名称，第二个元素为二级属性中允许修改的部分，例如
                [
                    'name',
                    'description',
                    ('vector_config': ['embedding_model']),
                    ('kg_config': ['embedding_model', 'llm_model']),
                ]
        """
        legal_changes = [
            'name',
            'description',
            'rerank_config',
        ]

        for key, index_type in INDEX_CONFIG_ATTR_TYPE_PAIRS:
            if index_type in self.index_map:
                legal_changes.append((key, self.index_map[index_type].get_legal_config_attr_changes()))

        return legal_changes

    def validate_kb_config_changes(self, config_diff: Dict[str, Any]) -> KBXError:
        """检查知识库配置修改是否合法，如果存在不允许的修改，返回（所有）对应的错误信息

        Args:
            config_diff (Dict[str, Any]): 知识库配置发生变动的部分

        Returns:
            KBXError: 错误信息
        """
        illegal_changes: List[str] = []

        # NOTE: 检查是否有非法修改
        # 先处理顶层属性中禁止修改的部分
        illegal_attrs = [
            'is_external_datastore',
            'doc_parse_config',  # TODO: 待实现
        ]
        for key in illegal_attrs:
            if key in config_diff:
                illegal_changes.append(f'Can not modify {key} field')
        # 再处理各类索引相关的修改
        for key, index_type in INDEX_CONFIG_ATTR_TYPE_PAIRS:
            if key in config_diff:
                if index_type not in self.index_map:
                    # NOTE: 目前不支持对创建知识库时禁用的索引进行改配置
                    # TODO: 待实现创建知识库后开启新index或禁用旧index
                    illegal_changes.append(f'Can not modify {key} field because {index_type} index is not enabled')
                else:
                    # 如果索引存在，检查是否有非法修改
                    err = self.index_map[index_type].validate_index_config_changes(config_diff[key])
                    if err.code != KBXError.Code.SUCCESS:
                        illegal_changes.append(f'Illegal {key}: {err.msg}')

        if len(illegal_changes) == 0:
            return KBXError()
        else:
            illegal_changes_str = "\n\t".join(illegal_changes)
            return KBXError(
                code=KBXError.Code.INVALID_VALUE,
                msg=(f"Invalid KB config changes for kb {self.kb_config.name} "
                     f'(id={self.kb_id}):\n{illegal_changes_str}')
            )

    def modify_kb_config(self, new_kb_config: KBCreationConfig) -> KBXError:
        """修改知识库配置

        Args:
            new_kb_config (KBCreationConfig): 新的知识库配置

        Returns:
            KBXError: 错误信息
        """
        # 先复制一份，避免外部修改
        new_kb_config = inject_user_ctx(
            config=new_kb_config.model_copy(deep=True),
            user_ctx=UserContext(user_id=self.user_id, tenant_id=self.tenant_id),
            recursive=True
        )

        err = KBXError()
        config_diff = get_pydantic_config_changes(self.kb_config, new_kb_config, recursive=True)
        if not config_diff:
            # 如果没有任何修改，直接返回
            return err

        # 实现逻辑：
        #   1. 先检查是否有不允许的非法参数修改，如果有的话直接返回对应错误消息，不对现有知识库做任何修改
        #   2. 检查KBCreationConfig顶层属性是否有发生合法修改，并进行对应处理
        #   3. 如果发生了某特定索引相关的修改，调用对应Index的modify_index_config接口

        # step 1
        err = self.validate_kb_config_changes(config_diff)
        if err.code != KBXError.Code.SUCCESS:
            # 如果存在非法修改，直接返回对应错误
            return err

        # step 2
        for key in ['name', 'description', 'rerank_config']:
            if key in config_diff:
                # 如果修改了此类参数，只需要更新kb_info表中的记录即可，不涉及额外变动
                with DBSession() as db:
                    db.query(KBInfoORM).filter_by(id=self.kb_id, user_id=self.user_id, tenant_id=self.tenant_id).update(
                        {key: getattr(new_kb_config, key)}
                    )
                    db.commit()
                    setattr(self._kb_config, key, getattr(new_kb_config, key))

        # step 3
        index_errors = {}
        for key, index_type in INDEX_CONFIG_ATTR_TYPE_PAIRS:
            if key in config_diff:
                # 如果修改了某特定索引相关的配置，调用对应Index的modify_index_config接口
                tmp_err, need_reindex = self.index_map[index_type].modify_index_config(getattr(new_kb_config, key))
                if tmp_err.code != KBXError.Code.SUCCESS:
                    # 如果修改失败，记录对应错误
                    index_errors[index_type] = tmp_err
                else:
                    # 改配成功
                    setattr(self._kb_config, key, getattr(new_kb_config, key))
                    # 检查是否需要额外调用reindex_all，各个文档状态由reindex_all负责更新
                    if need_reindex:
                        self.reindex_all(reparse=False)
        if len(index_errors) > 0:
            err = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f'Failed to modify KB config for kb {self.kb_config.name} (id={self.kb_id}):\n' + str(index_errors)
            )

        # 更新kb_info表中的记录
        # NOTE: 这里不判断err是否出错，原因是考虑万一出现部分修改成功、部分失败的情况
        with DBSession() as db:
            kb_info_orm = db.query(KBInfoORM).filter_by(
                id=self.kb_id, user_id=self.user_id, tenant_id=self.tenant_id).first()
            kb_info_orm.creation_config_json = self.kb_config.model_dump_json()
            db.commit()

        return err

    def _update_doc_info(self, doc_info: DocInfo, db: Optional[Session] = None):
        """更新文档信息"""
        doc_info_orm = DocInfoORM.from_pydantic(
            doc_info=doc_info,
            kb_id=self.kb_id,
            user_id=self.user_id,
            tenant_id=self.tenant_id
        )
        if db:
            db.merge(doc_info_orm)
            db.commit()
        else:
            with DBSession() as db:
                db.merge(doc_info_orm)
                db.commit()

    def _upload_file(self, file_path: str) -> DocInfo:
        doc_info = DocInfo()
        doc_info.doc_status = DocStatus.PARSING

        if not isinstance(file_path, str) or file_path == '':
            doc_info.err_info = KBXError(
                code=KBXError.Code.INVALID_VALUE,
                msg=f'Please provide a valid file path, given "{file_path}"'
            )
            doc_info.doc_status = DocStatus.UPLOAD_FAILED
            return doc_info

        if not os.path.isfile(file_path):
            doc_info.err_info = KBXError(
                code=KBXError.Code.INVALID_VALUE,
                msg=f'File {file_path} does not exist or it is not a file.'
            )
            doc_info.doc_status = DocStatus.UPLOAD_FAILED
            return doc_info

        # 检查文件大小
        file_size = os.path.getsize(file_path)
        from kbx.kbx import KBX
        if file_size > KBX.config.upload_file_size_limit:
            doc_info.err_info = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f'File "{file_path}" is too large, max size is '
                f'{KBX.config.upload_file_size_limit} bytes, given {file_size}.'
            )
            doc_info.doc_status = DocStatus.UPLOAD_FAILED
            return doc_info

        doc_id = generate_new_id()
        # 检查之前是否有同名文件
        with DBSession() as db:
            fname = os.path.basename(file_path)
            previous_doc = db.query(DocInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id,
                file_path=os.path.join(FileType.RAW_DOC_FILES, fname)
            ).first()
            if previous_doc:
                doc_id = previous_doc.id

        # 文档上传
        with get_file_datastore(self.kb_id) as file_ds:
            rets = file_ds.upload_files(file_list=[file_path], save_dir=FileType.RAW_DOC_FILES)
        err, file_info = rets[0]
        doc_info.raw_file_info = file_info
        if err.code != KBXError.Code.SUCCESS:
            doc_info.err_info = err
            doc_info.doc_status = DocStatus.UPLOAD_FAILED
            return doc_info
        assert file_info is not None

        # 只要上传成功，就需要更新业务数据库中的DocInfo/FileInfo记录
        doc_info.doc_id = doc_id
        doc_info.raw_file_info = file_info
        with DBSession() as db:
            # 创建一条文件信息记录
            new_file_info_orm = FileInfoORM.from_pydantic(
                file_info=doc_info.raw_file_info,
                kb_id=self.kb_id,
                user_id=self.user_id,
                tenant_id=self.tenant_id,
                doc_id_if_raw_doc_file=doc_id,
                doc_id_if_extra_file=None,
            )
            existing_file_info_orm = db.query(FileInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id,
                file_path=file_info.file_path
            ).first()
            if existing_file_info_orm:
                # 如果之前有相同文件记录，则需要更新id
                new_file_info_orm.id = existing_file_info_orm.id
            db.merge(new_file_info_orm)
            db.commit()

            # 覆盖写入新的doc_info记录
            # 即将进入文档解析阶段
            doc_info.doc_status = DocStatus.UPLOAD_SUCCESS
            self._update_doc_info(doc_info, db=db)
        return doc_info

    def _parse_doc(self, doc_info: DocInfo) -> Tuple[DocInfo, Optional[DocData]]:
        if doc_info.doc_status == DocStatus.UPLOAD_FAILED:
            # 如果上传失败，直接返回，除此之外其他状态均可正常进行文档解析
            return doc_info, None

        # 先更新为PARSING状态
        doc_info.doc_status = DocStatus.PARSING
        self._update_doc_info(doc_info, db=None)

        # NOTE: 不管之后文档解析成功或失败，先插入一个empty doc data占位，
        #       保证系统中每一个记录的doc_id均可以查询到对应的doc_data
        doc_data = DocData(
            doc_id=doc_info.doc_id,
            file_name=os.path.split(doc_info.raw_file_info.file_path)[-1],
            file_path=doc_info.raw_file_info.file_path,
            doc_elements=[]
        )
        with get_doc_datastore(self.kb_id) as doc_store:
            doc_store.save_doc_data(doc_data=doc_data)
            doc_store.flush()

        file_type = DocFileType.get_file_type_by_file_name(doc_info.raw_file_info.file_path)
        if file_type == DocFileType.UNKNOWN:
            doc_info.doc_status = DocStatus.PARSE_FAILED
            doc_info.err_info = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f"Unsupported doc file type: {doc_info.raw_file_info.file_path}"
            )
            self._update_doc_info(doc_info, db=None)
            return doc_info, None

        parser_map = self.kb_config.doc_parse_config.file_parsers.copy()

        if file_type not in parser_map:
            # 如果没有配置对应文件格式的解析器，直接忽略
            doc_info.doc_status = DocStatus.PARSE_FAILED
            doc_info.err_info = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f'No valid parser for {doc_info.raw_file_info.file_path}'
            )
            self._update_doc_info(doc_info, db=None)
            return doc_info, None
        parser_name: str = parser_map[file_type]
        # 文档解析
        from kbx.kbx import KBX
        try:
            if KBX.celery_app is None:
                # 如果没有配置celery，直接在当前进程中解析
                file_ds = get_file_datastore(self.kb_id)
                parser = get_parser(parser_name, self.kb_config.doc_parse_config, file_ds)
                doc_data = parser.parse(file_path=doc_info.raw_file_info.file_path, doc_id=doc_info.doc_id)
            else:
                # 如果配置了celery，使用celery异步解析
                result = KBX.celery_app.send_task(
                    'kbx.tasks.document_parse_task.parse_document_file',
                    kwargs={
                        'file_path': doc_info.raw_file_info.file_path,
                        'doc_id': doc_info.doc_id,
                        'parser_name': parser_name,
                        'doc_parse_config_json_str': self.kb_config.doc_parse_config.model_dump_json(),
                        'kb_id': self.kb_id,
                    }
                )
                # https://docs.celeryq.dev/en/latest/userguide/tasks.html#avoid-launching-synchronous-subtasks
                doc_data = result.get(disable_sync_subtasks=False)
                assert doc_data is not None
                assert isinstance(doc_data, DocData)
        except Exception as e:
            doc_info.doc_status = DocStatus.PARSE_FAILED
            doc_info.err_info = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f'Failed to parse {doc_info.raw_file_info.file_path}: {e}'
            )
            self._update_doc_info(doc_info, db=None)
            return doc_info, None

        # doc_data立即写入doc_store
        with get_doc_datastore(self.kb_id) as doc_store:
            doc_store.save_doc_data(doc_data=doc_data)
            doc_store.flush()

        with DBSession() as db:
            # 确认解析出doc_data后，更新doc_info记录
            db.merge(
                DocInfoORM.from_pydantic(
                    doc_info=doc_info,
                    kb_id=self.kb_id,
                    user_id=self.user_id,
                    tenant_id=self.tenant_id
                )
            )

            # 查找并插入额外的文件
            for element in doc_data.doc_elements:
                if element.data_file_path:
                    # 访问file_ds获取相关文件信息
                    with file_ds:
                        rets = file_ds.list_files(element.data_file_path, limit=1)
                        if len(rets) == 0 or rets[0].file_path != element.data_file_path:
                            # 如果文件不存在，报错
                            err_msg = f"Can not find extra data file {element.data_file_path} " \
                                f"for {doc_info.raw_file_info.file_path}"
                            logger.error(err_msg)
                            continue
                        extra_file_info = rets[0]
                    doc_info.extra_files_info.append(extra_file_info)
                    new_file_info_orm = FileInfoORM.from_pydantic(
                        file_info=extra_file_info,
                        kb_id=self.kb_id,
                        user_id=self.user_id,
                        tenant_id=self.tenant_id,
                        doc_id_if_extra_file=doc_info.doc_id,
                    )
                    existing_file_info_orm = db.query(FileInfoORM).filter_by(
                        tenant_id=self.tenant_id,
                        user_id=self.user_id,
                        kb_id=self.kb_id,
                        file_path=element.data_file_path
                    ).first()
                    if existing_file_info_orm:
                        # 如果之前有相同文件记录，则需要复用旧id
                        new_file_info_orm.id = existing_file_info_orm.id
                    db.merge(new_file_info_orm)

            db.commit()

        doc_info.doc_status = DocStatus.PARSE_SUCCESS
        self._update_doc_info(doc_info, db=None)

        return doc_info, doc_data

    def _parse_doc_by_id(self, doc_id: str) -> DocInfo:
        with DBSession() as db:
            doc_info_orm = db.query(DocInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id,
                id=doc_id,
            ).first()
            if doc_info_orm is None:
                return DocInfo(
                    doc_id=doc_id,
                    err_info=KBXError(
                        code=KBXError.Code.RUNTIME_ERROR,
                        msg=f'Failed to parse doc: doc_id {doc_id} not found'
                    )
                )
            doc_info = doc_info_orm.to_pydantic()
        doc_info, _ = self._parse_doc(doc_info=doc_info)
        return doc_info

    def _index_doc(self, doc_info: DocInfo, doc_data: DocData) -> DocInfo:
        if doc_info.doc_status == DocStatus.UPLOAD_FAILED or doc_info.doc_status == DocStatus.PARSE_FAILED:
            return doc_info

        # 先更新为PARSING状态
        doc_info.doc_status = DocStatus.INDEXING
        self._update_doc_info(doc_info, db=None)

        for index_type, index in self.index_map.items():
            # 在对应的index里插入文档
            # TODO: 后续统一改为单个文档的插入接口
            err = index.insert_single_doc(doc_data)
            if err.code != KBXError.Code.SUCCESS:
                # 记录错误信息
                doc_info.doc_status = DocStatus.INDEX_FAILED
                doc_info.err_info = KBXError(
                    code=KBXError.Code.RUNTIME_ERROR,
                    msg=f'Failed to build {index_type} index for {doc_info.raw_file_info.file_path}: {err.msg}'
                )
                self._update_doc_info(doc_info, db=None)
                return doc_info

        # 插入文档一切正常
        doc_info.doc_status = DocStatus.COMPLETE
        doc_info.err_info = KBXError(code=KBXError.Code.SUCCESS)
        self._update_doc_info(doc_info, db=None)
        return doc_info

    def insert_single_doc(self, file_path: str) -> DocInfo:
        """对单个本地文档文件进行入库，包括如下步骤

        - 检查输入文件路径是否合法
        - 上传至KBX文件存储
        - 调用parser解析成DocData
        - 使用解析出的DocData建立索引

        任意一个环节出错，会直接返回，错误信息通过DocInfo的err_info和doc_status体现

        Args:
            file_path (str): 文档（本地）路径

        Returns:
            DocInfo: 文档状态信息，注意，如果返回的DocInfo.doc_status为UPLOAD_FAILED，则DocInfo.err_info包含错误信息，表明该文档未成功上传，
                如果DocInfo.doc_status为COMPLETE，则DocInfo.err_info.code为SUCCESS，表示文档插入成功未出错，
                否则意味着在某个环节出错，DocInfo.doc_status为对应环节，DocInfo.err_info包含对应错误信息。
        """
        # 1. 上传文档
        doc_info = self._upload_file(file_path=file_path)
        if doc_info.err_info.code != KBXError.Code.SUCCESS:
            # 如果上传失败，直接返回
            return doc_info

        # 2. 解析文档
        doc_info, doc_data = self._parse_doc(doc_info=doc_info)
        if doc_info.err_info.code != KBXError.Code.SUCCESS:
            # 如果解析失败，直接返回
            return doc_info

        # 3. 为此文档建立索引
        doc_info = self._index_doc(doc_info=doc_info, doc_data=doc_data)

        return doc_info

    def insert_docs(self, file_list: Union[str, List[str]]) -> List[DocInfo]:
        """对一系列本地文档文件进行入库，包括如下步骤

        - 存入文件存储
        - 调用parser解析成DocData
        - 建立索引

        注意，如果输入文件列表存在重名的文件会直接报错

        Args:
            file_list (Union[str, List[str]]): 文档（本地）路径列表

        Returns:
            List[DocInfo]: 各文档的入库结果，长度与输入的file_list相同，对应每个文件在插入后的相关状态信息
                注意，如果返回的DocInfo.doc_status为UPLOAD，则DocInfo.err_info包含错误信息，表明该文档未成功上传，
                如果DocInfo.doc_status为COMPLETE，则DocInfo.err_info.code为SUCCESS，表示文档插入成功未出错，
                否则意味着在某个环节出错，DocInfo.doc_status为对应环节，DocInfo.err_info包含对应错误信息。
        """
        if isinstance(file_list, str):
            file_list = [file_list]

        from kbx.kbx import KBX

        if len(file_list) > KBX.config.upload_file_batch_limit:
            # 如果本次上传的文件数量超过限制，直接报错
            raise ValueError(
                'Failed to insert docs because total file num exceeds limit: '
                f'{len(file_list)} vs {KBX.config.upload_file_batch_limit}'
            )

        if any([not isinstance(file_path, str) or file_path == '' for file_path in file_list]):
            raise ValueError(
                f'Please provide valid file paths, given {file_list}'
            )

        file_names = [os.path.basename(file_path) for file_path in file_list]
        if len(set(file_names)) != len(file_names):
            raise ValueError(
                f'Can not insert duplicate files:\n{file_names}'
            )

        rets = []

        # 串行调用
        rets = [self.insert_single_doc(file_path) for file_path in file_list]

        # 多线程调用
        # TODO: 当前各种datastore还不支持并行，因此暂时无法使用
        '''
        with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as pool:
            rets = list(pool.map(self.insert_single_doc, file_list))
        '''

        return rets

    def _try_get_vector_keyword_index(self) -> Optional[BaseIndex]:
        if self._kb_config.vector_keyword_config is None:
            return None

        return get_vector_keyword_index(
            self._kb_config.vector_keyword_config.index_strategy,
            self.kb_id,
            self._kb_config.vector_keyword_config
        )

    def _try_get_structured_index(self) -> Optional[BaseIndex]:
        if self._kb_config.structured_config is None:
            return None

        return get_structured_index(
            self._kb_config.structured_config.index_strategy,
            self.kb_id,
            self._kb_config.structured_config
        )

    def _try_get_knowledge_graph_index(self) -> Optional[BaseIndex]:
        if self._kb_config.kg_config is None:
            return None

        return get_knowledge_graph_index(
            self._kb_config.kg_config.index_strategy,
            self.kb_id,
            self._kb_config.kg_config
        )

    def list_doc_ids(self, offset: int = 0, limit: int = 20) -> List[str]:
        """列举本知识库所包含的文档id列表

        Args:
            offset (int): 分页偏移量，也就是从第几个item开始查询，默认从0开始
            limit (int): 分页大小限制，也就是本次查询最多返回多少个item

        Returns:
            List[str]: 指定分页范围内的文档id列表
        """
        # 从DB中查询符合条件的文档id列表
        with DBSession() as db:
            doc_ids = db.query(DocInfoORM.id).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id
            ).offset(offset=offset).limit(limit=limit).all()
            return [doc_id for (doc_id,) in doc_ids]

    def list_docs_info(self, offset: int = 0, limit: int = 20) -> List[DocInfo]:
        """列举本知识库所包含的文档列表

        Args:
            offset (int): 分页偏移量，也就是从第几个item开始查询，默认从0开始
            limit (int): 分页大小限制，也就是本次查询最多返回多少个item

        Returns:
            List[DocInfo]: 指定分页范围内的文档列表
        """
        with DBSession() as db:
            doc_info_orms = db.query(DocInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id
            ).offset(offset).limit(limit).all()
            doc_infos = [doc_info_orm.to_pydantic() for doc_info_orm in doc_info_orms]
        return doc_infos

    def get_doc_info(self, doc_id: str) -> DocInfo:
        """获取某个文档的相关信息

        Args:
            doc_id (str): 文档id

        Raises:
            NotImplementedError: _description_

        Returns:
            DocInfo: 文档相关信息
        """
        with DBSession() as db:
            doc_info_orm = db.query(DocInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id,
                id=doc_id
            ).first()
            if doc_info_orm is None:
                raise RuntimeError(f'Failed to find doc_id={doc_id} in knowledge base (id={self.kb_id})')
            return doc_info_orm.to_pydantic()

    def get_doc_data(self, doc_id: str) -> DocData:
        """获取某个文档的DocData内容数据

        Args:
            doc_id (str): 文档id

        Returns:
            DocData: 文档数据
        """
        with get_doc_datastore(self.kb_id) as doc_ds:
            doc_data, err = doc_ds.load_doc_data(doc_id)
        if err.code != KBXError.Code.SUCCESS:
            raise RuntimeError(err.msg)
        return doc_data

    def _update_docs_status(self, doc_ids: Iterable[str], doc_status: DocStatus):
        with DBSession() as db:
            db.query(DocInfoORM).filter(
                DocInfoORM.tenant_id == self.tenant_id,
            ).filter(
                DocInfoORM.user_id == self.user_id
            ).filter(
                DocInfoORM.kb_id == self.kb_id
            ).filter(
                DocInfoORM.id.in_(doc_ids)
            ).update(
                {
                    'doc_status': doc_status
                }
            )
            db.commit()

    def reindex(self, doc_ids: Union[str, List[str]], reparse: bool = False) -> Dict[str, KBXError]:
        """对部分文档重新建立索引

        Args:
            doc_ids (Union[str, List[str]]): 需要重新建立索引的文档id
            reparse (bool): 是否需要重新解析文档

        Returns:
            Dict[str, KBXError]: 执行reindex后的错误信息， 格式为{doc_id1: err1, doc_id2: err2, ...}
        """
        if isinstance(doc_ids, str):
            doc_ids = [doc_ids]

        # 记录reindex过程中哪些文档出错了，格式为{doc_id: err_msg}
        doc_id_errors: Dict[str, KBXError] = {}

        if reparse:
            # 需要重新解析文档
            # 串行调用
            doc_info_list = [self._parse_doc_by_id(doc_id) for doc_id in doc_ids]
            # 多线程调用
            # TODO: 当前各种datastore还不支持并行，因此暂时无法使用
            '''
            from kbx.kbx import KBX
            with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as pool:
                doc_inf_list = list(pool.map(self._parse_doc_by_id, doc_ids))
            '''
            doc_id_errors = {
                doc_info.doc_id: KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=doc_info.err_info.msg)
                for doc_info in doc_info_list
                if doc_info.err_info.code != KBXError.Code.SUCCESS
            }

        # 检查doc_ids中是否存在不存在的doc_id，提前标记出错
        with get_doc_datastore(self.kb_id) as doc_store:
            all_available_doc_ids, err = doc_store.list_doc_ids()
            if err.code != KBXError.Code.SUCCESS:
                raise RuntimeError(f'[Internal Error] Failed to list_doc_ids: {err.msg}')
            illegal_doc_ids = set(doc_ids) - set(all_available_doc_ids)
            doc_id_errors.update({
                doc_id: KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=f'doc_id {doc_id} not found')
                for doc_id in illegal_doc_ids
            })

        # 调用index.reindex前，剔除掉解析失败或不存在的非法文档id
        success_doc_ids = set(doc_ids) - set(doc_id_errors.keys())

        # TODO: 异步并发优化
        for k, index in self.index_map.items():
            tmp_errs = index.reindex(success_doc_ids)
            if tmp_errs:
                for tmp_err in tmp_errs:
                    doc_id, err_msg = tmp_err
                    doc_index_err_msg = str(k) + ': ' + err_msg
                    if doc_id not in doc_id_errors:
                        doc_id_errors[doc_id] = KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=doc_index_err_msg)
                    else:
                        doc_id_errors[doc_id].msg += f'\n{doc_index_err_msg}'

        # reindex后批量把成功的文档状态设置为COMPLETE，失败的文档错误信息进行更新
        success_doc_ids = set(doc_ids) - set(doc_id_errors.keys())
        self._update_docs_status(doc_ids=success_doc_ids, doc_status=DocStatus.COMPLETE)
        if len(doc_id_errors) > 0:
            with DBSession() as db:
                for doc_id, err in doc_id_errors.items():
                    logger.error(f'Failed to reindex doc_id {doc_id}: {err.msg}')
                    doc_info_orm = db.query(DocInfoORM).filter(
                        DocInfoORM.tenant_id == self.tenant_id,
                    ).filter(
                        DocInfoORM.user_id == self.user_id
                    ).filter(
                        DocInfoORM.kb_id == self.kb_id
                    ).filter(
                        DocInfoORM.id == doc_id
                    ).first()
                    if doc_info_orm:
                        doc_info_orm.err_code = err.code
                        doc_info_orm.err_msg = err.msg
                        doc_info_orm.doc_status = DocStatus.INDEX_FAILED
                db.commit()

        return doc_id_errors

    def reindex_all(self, reparse: bool = False) -> Dict[str, KBXError]:
        """对全部文档重新建立索引

        Args:
            reparse (bool): 是否需要重新解析文档

        Returns:
            Dict[str, KBXError]: 执行reindex后的错误信息， 格式为{doc_id1: err1, doc_id2: err2, ...}
        """
        doc_id_errors: Dict[str, KBXError] = {}

        # 先获取所有文档的doc_id列表（limit设置为-1）
        doc_ids = self.list_doc_ids(offset=0, limit=-1)

        if reparse:
            # 串行调用
            doc_info_list = [self._parse_doc_by_id(doc_id) for doc_id in doc_ids]
            # 多线程调用
            # TODO: 当前各种datastore还不支持并行，因此暂时无法使用
            '''
            from kbx.kbx import KBX
            with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as pool:
                doc_inf_list = list(pool.map(self._parse_doc_by_id, doc_ids))
            '''
            doc_id_errors.update({
                doc_info.doc_id: KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=doc_info.err_info.msg)
                for doc_info in doc_info_list
                if doc_info.err_info.code != KBXError.Code.SUCCESS
            })
        else:
            # 如果不做重新的解析，先检查是否存在之前就解析失败的文档，提前标记出错
            with DBSession() as db:
                parse_failed_doc_info_orms = db.query(DocInfoORM).filter(
                    DocInfoORM.tenant_id == self.tenant_id,
                ).filter(
                    DocInfoORM.user_id == self.user_id
                ).filter(
                    DocInfoORM.kb_id == self.kb_id
                ).filter(
                    DocInfoORM.doc_status == DocStatus.PARSE_FAILED
                ).all()
                doc_id_errors.update({
                    doc_info_orm.id: KBXError(
                        code=KBXError.Code.RUNTIME_ERROR,
                        msg=f"Failed to parse doc_id={doc_info_orm.id} before reindex"
                    )
                    for doc_info_orm in parse_failed_doc_info_orms
                })

        success_doc_ids = set(doc_ids) - set(doc_id_errors.keys())
        # reindex前先把所有解析成功的文档状态置为INDEXING状态
        self._update_docs_status(doc_ids=success_doc_ids, doc_status=DocStatus.INDEXING)

        # TODO: 异步并发优化
        for k, index in self.index_map.items():
            tmp_errs = index.reindex_all()
            if tmp_errs:
                for tmp_err in tmp_errs:
                    doc_id, err_msg = tmp_err
                    doc_index_err_msg = str(k) + ': ' + err_msg
                    if doc_id not in doc_id_errors:
                        doc_id_errors[doc_id] = KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=doc_index_err_msg)
                    else:
                        doc_id_errors[doc_id].msg += f'\n{doc_index_err_msg}'

        # reindex后批量把成功的文档状态设置为COMPLETE，失败的文档错误信息进行更新
        success_doc_ids = set(success_doc_ids) - set(doc_id_errors.keys())
        self._update_docs_status(doc_ids=success_doc_ids, doc_status=DocStatus.COMPLETE)
        if len(doc_id_errors) > 0:
            with DBSession() as db:
                for doc_id, err in doc_id_errors.items():
                    logger.error(f'Failed to reindex doc_id {doc_id}: {err.msg}')
                    doc_info_orm = db.query(DocInfoORM).filter(
                        DocInfoORM.tenant_id == self.tenant_id,
                    ).filter(
                        DocInfoORM.user_id == self.user_id
                    ).filter(
                        DocInfoORM.kb_id == self.kb_id
                    ).filter(
                        DocInfoORM.id == doc_id
                    ).first()
                    if doc_info_orm:
                        doc_info_orm.err_code = err.code
                        doc_info_orm.err_msg = err.msg
                        doc_info_orm.doc_status = DocStatus.INDEX_FAILED
                db.commit()

        return doc_id_errors

    def remove_docs(self, doc_ids: Union[str, List[str]]) -> List[Tuple[str, KBXError]]:
        """删除一个或多个文档的索引数据

        Args:
            doc_ids (Union[str, List[str]]): _description_

        Returns:
            Dict[IndexType, List[Tuple[str, str]]]: 如果执行成功直接返回None，否则会把错误信息进行返回，
                格式为[(doc_id, err), (doc_id, err), ...]
        """
        if isinstance(doc_ids, str):
            doc_ids = [doc_ids]

        doc_id2err: Dict[str, KBXError] = {}

        # 删除文件、DocInfo记录
        file_ds = get_file_datastore(self.kb_id)
        doc_ds = get_doc_datastore(self.kb_id)
        with DBSession() as db:
            for doc_id in doc_ids:
                doc_info_orm = db.query(DocInfoORM).filter_by(
                    tenant_id=self.tenant_id,
                    user_id=self.user_id,
                    kb_id=self.kb_id,
                    id=doc_id
                ).first()
                if doc_info_orm is None:
                    if doc_id in doc_id2err:
                        continue
                    doc_id2err[doc_id] = KBXError(
                        code=KBXError.Code.RUNTIME_ERROR,
                        msg=f"Failed to find DocInfo record for doc_id={doc_id}"
                    )
                    continue

                # 注意，只要上面成功获取到了doc_info_orm，接下来任意中间环节即使失败也要尝试继续执行剩余步骤的删除，
                # 并且保证最终删除doc_info_orm，实现此文档的软删除
                for index in self.index_map.values():
                    tmp_errs = index.remove_docs(doc_ids=[doc_id])
                    if tmp_errs:
                        if tmp_errs[0][0] != doc_id:
                            raise RuntimeError(f'Unexpected doc_id, expected {doc_id}, given {tmp_errs[0][0]}')
                        doc_id2err[doc_id] = KBXError(KBXError.Code.RUNTIME_ERROR, tmp_errs[0][1])

                # First delete physical files
                with ExitStack() as stack:
                    stack.enter_context(file_ds)
                    stack.enter_context(doc_ds)

                    # Delete raw doc file
                    err = file_ds.delete_file(doc_info_orm.file_path)
                    if err.code != KBXError.Code.SUCCESS:
                        doc_id2err[doc_id] = err

                    # Delete doc data
                    err = doc_ds.delete_doc_data(doc_id=doc_id)
                    if err.code != KBXError.Code.SUCCESS:
                        doc_id2err[doc_id] = err

                    # Delete any extra files
                    for extra_file_info_orm in doc_info_orm.extra_files_info:
                        file_ds.delete_file(extra_file_info_orm.file_path)

                # 不管上面是否出错，这里都要删除DocInfoORM，实现此文档的软删除
                # NOTE: 不需要额外进行file_info_orm的删除，因为会进行关联删除
                db.delete(doc_info_orm)
                db.commit()

        return list(doc_id2err.items())

    def retrieve(self, query: QueryConfig) -> List[QueryResult]:
        """在本知识库中进行查询

        Args:
            query (QueryConfig): 查询参数

        Returns:
            List[QueryResult]: 查询结果
        """
        results_map = {}
        if not query.enable_index_types:
            selected_index = self.index_map
        else:
            selected_index = {
                key: self.index_map[key] for key in query.enable_index_types if key in self.index_map
            }

        if len(selected_index) == 0:
            raise ValueError(
                'You must enable at least one index type, given '
                f'{query.enable_index_types}, available {self.index_map}'
            )
        elif len(selected_index) == 1:
            # 如果只涉及一个index，直接调用
            k, index = list(selected_index.items())[0]
            tmp_res = index.retrieve(query=query)
            if tmp_res:
                results_map[k] = tmp_res
        else:
            # 多种索引并发调用
            with ThreadPoolExecutor(max_workers=len(selected_index)) as pool:
                future_results = [(k, pool.submit(index.retrieve, query=query)) for k, index in selected_index.items()]
                for k, future_result in future_results:
                    tmp_res = future_result.result()
                    if tmp_res:
                        results_map[k] = tmp_res

        if len(results_map) == 0:
            # 如果没有检索出有效结果，直接返回
            return []

        results_flat = [x for _, v in results_map.items() for x in v]

        # 调用rerank模型进行结果重排
        if self.kb_config.rerank_config:
            rerank_model = get_rerank(self.kb_config.rerank_config)
            results_flat = rerank_model.rerank(query, results_flat)

        with get_doc_datastore(self.kb_id) as doc_ds:
            for res in results_flat:
                res.meta_data = {'kb_name': self.kb_name}
                if res.doc_id:
                    doc_name = os.path.basename(self.get_doc_info(res.doc_id).raw_file_info.file_path)
                    res.meta_data.update({'doc_name': doc_name})

                if res.text_chunk:
                    doc_ele = doc_ds.get_doc_element_by_id(res.text_chunk.doc_element_ids[0])[0]
                    if doc_ele.type == DocElementType.FIGURE:
                        res.raw_data = {'base64': doc_ele.image_b64}
                    elif doc_ele.type == DocElementType.AUDIO or doc_ele.type == DocElementType.VIDEO:
                        res.raw_data = {'file_path': doc_ele.data_file_path}
                    elif doc_ele.type == DocElementType.TABLE:
                        res.raw_data = {'table': doc_ele.table}

        return results_flat

    def get_media_bytes(self, file_path: str) -> bytes:
        """从给定路径读取音视频文件并转化为音视频二进制数据。

        Args:
            file_path (str): 音视频文件路径

        Returns:
            bytes: 音视频二进制数据
        """
        with get_file_datastore(self.kb_id) as file_ds:
            with file_ds.open(file_path, 'rb', encoding=None) as f:
                binary_data = f.read()

        return binary_data
