
import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)

import requests
import json


url = "http://211.93.18.49:60000/chat"
headers = {
    "accept": "text/event-stream",
    "Content-Type": "application/json"
}

def get_kbx_response(question):
    data = {
        "query": question
    }

    response = requests.post(url, headers=headers, json=data)
    response_content = response.content
    content_str = response_content.decode('utf-8')
    lines = content_str.strip().split('\n\n')
    answers = ''
    for line in lines:
        data_json = json.loads(line.replace('data: ', ''))
        if 'answer' in data_json and data_json['answer'] is not None:
            answers += data_json['answer']
    # print(answers)
    final_response = answers.split("</think>")[-1]
    return final_response

questions = ['五轴产品硬件降本进展中，通过选型优化和细节设计分别降本多少？', '五轴产品化进展中，通过8轴5联动节省多少成本？', 'ViMo Deeplearning 深度学习训练软件产品有哪些亮点?']

with open('cache/kbx_test_data/chanpin_qa_all.json', 'r', encoding='utf-8') as f:
    json_data = json.load(f)

# with open('cache/kbx_test_data/kbx_response_new.txt', 'a+', encoding='utf-8') as f:
#     for item in json_data:
#         query = item['question']
#         item['response'] = get_kbx_response(query)
#         f.write(f"response: {item['response']}\n\n")
with open('cache/kbx_test_data/kbx_response_new.txt', 'a+', encoding='utf-8') as f:
    for q in questions:
        response = get_kbx_response(q)
        f.write(f"response: {response}\n\n")
    


try:
    with open('cache/kbx_test_data/kbx_responses.json', 'w', encoding='utf-8') as f:
        json.dump(json_data, f, ensure_ascii=False, indent=4)
except Exception as e:
    print(e)
    from ipdb import set_trace
    set_trace()


# curl -X POST "http://211.93.18.49:60000/chat" -H "accept: text/event-stream" -H "Content-Type: application/json" -d '{"query": "Airpods检测有哪些挑战？"}'