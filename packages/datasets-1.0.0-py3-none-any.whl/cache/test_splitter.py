import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

from kbx.common.types import DocData, DocElement
from kbx.common.utils import generate_new_id
from kbx.splitter.splitter_factory import get_splitter
from kbx.splitter.types import SplitterConfig



splitter = get_splitter("NaiveTextSplitter", SplitterConfig())

doc_data = DocData(doc_id=generate_new_id(), doc_elements=[
    DocElement(doc_element_id=generate_new_id(), text="""当前市场最大争论是美联储紧缩会否引发美国经济衰退和金融危机，进而导致美股大幅下挫。虽然市场尚未达成共识，但是本文尝试“超前”分析美股调整对 A 股的传导机制及影响。\n\n美股调整可能通过资本流动（资产配置再平衡）、货币政策、经济基本面和恐慌情绪四种渠道影响 A 股。随着外资持续流入，外资在 A 股市场
的影响力已经不容忽视。当外资大幅放缓流入或者流出时，内资“迷信”
外资掌握更多信息。在美元主导的国际货币体系下，美联储紧缩引发全
球金融收缩，A 股尚未成功在中国央行逆势宽松下独树一帜，尤其是在
中国深度融入金融经贸全球化的今天。尤为关键的是，恐慌情绪易于传
染。在高度不确定性的环境下，避险是本能行为，不仅发生在 A 股，也
发生在欧洲和日本等主要股票市场。当单月 VIX 大涨 50%或者陆股通净
流出时，A 股基本上会收跌。但是，VIX 是经济金融危机的“副产品”，高
度不可预测。\n2023 年美股下跌分两种情形，一是阶段性技术调整，呈现“N”型走势。关
键是底部出现时点。参考 2020 年政策底、经济底和市场底经验，美股不
确定性越早落地，A 股越有机会凭借国内经济复苏领先优势走出独立行
情。二是美股陷入“熊市”危机，连续两年明显收跌。美股历史上出现四次
连续两年以上收跌，无一不是撞上了严重的经济事件。概率虽低，但是 A
股遇上后难言独立行情。2023 年海外不确定性依然较大，市场参与者保
持适度谨慎和灵活性，做好预案。"""),
    DocElement(doc_element_id=generate_new_id(), text="Another test.")
])

chunks = splitter.split(doc_data)
print(chunks)