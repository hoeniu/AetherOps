import json
import pandas as pd
import argparse
from openai import OpenAI
from textwrap import dedent
import concurrent.futures
from typing import Dict, Any
import time


class CRAGEvaluator:
    def __init__(self, api_key: str, model: str, base_url: str):
        """Initialize CRAG evaluator.

        Args:
            api_key: OpenAI API key
            model: OpenAI model name
            base_url: API base URL
        """
        self._client = OpenAI(
            api_key=api_key,
            base_url=base_url,
        )
        self._model = model

    def _call_llm(self, prompt: str, temperature: float = 0.7) -> str:
        """Call OpenAI API.

        Args:
            prompt: Input prompt
            temperature: Temperature for generation

        Returns:
            OpenAI response as string
        """
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=temperature
        )
        return response.choices[0].message.content

    def _evaluate_item(self, item: Dict[str, Any], evaluate_prompt: str) -> Dict[str, Any]:
        """Evaluate a single item.

        Args:
            item: Data item to evaluate
            evaluate_prompt: Prompt template for evaluation

        Returns:
            Updated item with score
        """
        if not isinstance(item, dict):
            return item

        query = item.get('question')
        ground_truth = item.get('gt')
        prediction = item.get('llm_answer')

        if not all([query, ground_truth, prediction]):
            return item

        try:
            user_input = evaluate_prompt.format(question=query, ground_truth=ground_truth, prediction=prediction)
            response = self._call_llm(user_input)
            score = float(response)
            item['score'] = score
        except (ValueError, KeyError) as e:
            print(f"Warning: Error processing item: {e}")
            item['score'] = None

        return item

    def evaluate(self,
                 evaluate_prompt: str,
                 input_file: str,
                 output_file: str,
                 max_workers: int = 10) -> None:
        """Evaluate responses using CRAG method with thread pool.

        Args:
            evaluate_prompt: Prompt template for evaluation
            input_file: Path to input file (CSV or JSON)
            output_file: Path to save evaluation results
            max_workers: Maximum number of worker threads
        """
        # Load data
        if input_file.endswith('.csv'):
            data = pd.read_csv(input_file).to_dict('records')
        elif input_file.endswith('.json'):
            with open(input_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
        else:
            raise ValueError("Input file must be CSV or JSON")

        start_time = time.time()
        total_score = 0
        num_items = 0

        # Process items using thread pool
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Create a list of futures
            future_to_item = {
                executor.submit(self._evaluate_item, item, evaluate_prompt): item
                for item in data
            }

            # Process results as they complete
            for future in concurrent.futures.as_completed(future_to_item):
                result = future.result()
                if result.get('score') is not None:
                    total_score += result['score']
                    num_items += 1

        # Calculate average score
        avg_score = total_score / num_items if num_items > 0 else 0
        end_time = time.time()

        print(f"Overall truthfulness: {avg_score:.2f}")
        print(f"Total items evaluated: {num_items}")
        print(f"Time taken: {end_time - start_time:.2f} seconds")

        # Save results
        df = pd.DataFrame(data)
        df.to_csv(output_file, index=False)
        print(f"Results saved to {output_file}")


def main():
    parser = argparse.ArgumentParser(description="Evaluate responses using CRAG method")
    parser.add_argument('--input_file', required=True, help='Input file path (CSV or JSON)')
    parser.add_argument('--output_file', required=True, help='Output file path for results')
    parser.add_argument('--max_workers', type=int, default=10, help='Maximum number of worker threads')
    args = parser.parse_args()

    LLM_MODEL = "qwen2_5-32b-int8"
    API_KEY = "sk-xxx"
    BASE_URL = "http://xxx.xx.xx.xx/v1"

    EVALUATE_PROMPT = dedent("""
        # 任务：给你一个问题、一个模型的预测结果和一个 Ground Truth 答案，你的任务是对模型的预测结果和 Ground Truth 答案的匹配程度进行打分。请按照以下说明一步一步进行判断。
        1. 如果模型预测与 Ground Truth 答案中提供的信息完全匹配，得分为1分。
        2. 如果模型预测与 Ground Truth 答案匹配，但预测结果中额外包含一些和问题相关的信息，得分为1分。
        3. 如果模型预测的结构漏掉了部分 Ground Truth 答案的信息，得分为0.5分。
        4. 如果模型预测表明它无法回答问题或没有足够的信息，而Ground Truth 答案中有足够的信息，则得分为0分。
        5. 如果模型预测与 Ground Truth 答案中提供的信息完全不匹配，或者模型预测中包含和问题完全不相关的信息，得分为-1分。

        # 示例：
        问题：3 分 15 秒是多少秒？
        Ground Truth：195 秒
        预测：3 分 15 秒是195 秒。
        score：1
        问题：谁是《驯悍记》（2002 年出版）的作者？
        Ground Truth: 威廉·莎士比亚
        预测：《驯悍记》的作者是威廉·莎士比亚，他是一个伟大的作家，著名作品有《哈姆莱特》《李尔王》《麦克白》等。
        score：1
        问题：谁在《生活大爆炸》中扮演谢尔顿？
        Ground Truth：吉姆·帕森斯
        预测：抱歉，我不知道。
        score：0

        给你的问题、预测结果和 Ground Truth 答案如下：
        问题：{question}
        Ground Truth：{ground_truth}
        预测：{prediction}

        请直接输出分数，不要输出别的内容。
    """)

    # Create evaluator and run evaluation
    evaluator = CRAGEvaluator(API_KEY, LLM_MODEL, BASE_URL)
    evaluator.evaluate(EVALUATE_PROMPT, args.input_file, args.output_file, args.max_workers)


if __name__ == "__main__":
    main()
