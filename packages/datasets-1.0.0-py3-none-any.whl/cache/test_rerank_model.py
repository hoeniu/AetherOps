import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
from kbx.kbx import KBX
import numpy as np
kbx_yaml_file = os.path.join(ROOT_DIR, 'conf/kbx_settings.yaml')
ai_models_yaml_file = os.path.join(ROOT_DIR, 'conf/ai_models.yaml')
KBX.init(config=kbx_yaml_file)
KBX.register_ai_models_from_conf(model_configs=ai_models_yaml_file, overwrite=True)


rerank_config, rerank_client = KBX.get_ai_model_config_and_client(
    name="BAAI/bge-reranker-v2-m3",
)

embed_config, embed_client = KBX.get_ai_model_config_and_client(
    name="BAAI/bge-m3",
)
txt1 = '平安的汪册资是多少'
txt2 = '中国平安注册资金 1亿\n万科股本70亿\n中国平安持股(20%)万科'
embedding1, embedding2 = embed_client.text_embedding_batch(
    embed_config,
    texts=[txt1, txt2]
)
embedding1 = embedding1 / np.linalg.norm(embedding1)
embedding2 = embedding2 / np.linalg.norm(embedding2)
score = np.dot(embedding1, embedding2)

from chromadb.utils import distance_functions
cosine_score = 1 - distance_functions.cosine(embedding1, embedding2)
print(score, cosine_score)



from ipdb import set_trace; set_trace()



texts1 = [
    "智能读码器 VS500	名称	智能读码器 VS500",
    "智能读码器 VS500	特点	即插即用，无复杂操作，无学习成本，安装调试便捷；丰富的接口设计，支持串口、USB以及IO；定制高景深镜头，安装距离超广；体积小巧",
    "智能读码器 VS500	通信协议/通讯协议	采用USB、RS为通信方式",
    "ISBN	属于	智能读码器 VS500",
    "智能读码器 VS500	应用行业	制造",
    "智能读码器 VS500	光源	红色光点",
    "智能读码器 VS500	属于	图像传感器",
    "智能读码器 VS300	应用行业	医疗",
    'Codabar	属于	智能读码器 VS500',
    'UPC - A 13mil 45 - 280mm	属于	智能读码器 VS500',
    "智能读码器 VS300	名称	智能读码器 VS300",
    "智能读码器 VS300	特点	高精度识别，支持多种码制；工业级防护，适应恶劣环境；快速响应，实时数据传输",
    "智能读码器 VS300	通信协议/通讯协议	支持RS232、RS485、USB等多种通信方式",
    "智能读码器 VS300	光源	蓝色LED",
    "智能读码器 VS300	属于	图像传感器",
    "智能读码器 VS600	名称	智能读码器 VS600",
    "智能读码器 VS600	应用行业	物流",
    "智能读码器 VS600	特点	超高速扫描，支持动态读取；大视野范围，多码同时识别；智能防抖，稳定可靠"
]

texts2 = [
    "2023年1月 10536.22",
    "2023年2月 43214.85",
    "2019年3月 7856.62",
]


query1 = "VS600是什么"  # VS500读码器用在了哪些行业
query2 = "上海哪个月的gdp最高？"

rets1 = rerank_client.rerank(
    rerank_config,
    query=query1,
    texts=["智能读码器 VS600	名称	智能读码器 VS600", "智能读码器 VS600	属于	图像传感器", "智能读码器 VS500	特点	即插即用，无复杂操作，无学习成本，安装调试便捷；丰富的接口设计，支持串口、USB以及IO；定制高景深镜头，安装距离超广；体积小巧"],
    top_n=4
)

rets2 = rerank_client.rerank(
    rerank_config,
    query=query2,
    texts=texts2,
    top_n=4
)

rets3 = rerank_client.rerank(
    rerank_config,
    query=query1,
    texts=["智能读码器 VS600	属于	图像传感器", "智能读码器 VS600	名称	智能读码器 VS600"],
    top_n=4
)

for ret in rets1:
    print(ret)

for ret in rets2:
    print(ret)

for ret in rets3:
    print(ret)

