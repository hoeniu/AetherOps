import pickle
import json


with open('volumes/doc_data/c5cc7d59-60c8-4e9f-a343-111d1c8ff19c/3a7a1250-d043-41c8-bf2a-af8fbc48bb85/74f92d9e-bc1a-4a5d-8491-35c6649bb25b/vector.pickle', 'rb') as f:
    chunk_data = pickle.load(f)
    assert type(chunk_data) == dict
    from ipdb import set_trace
    set_trace()

with open('cannot_retrieved_context.json', 'r', encoding='utf-8') as f:
    data = json.load(f)


cnt = 0
for item in data:
    for k, v in chunk_data.items():
        # print(k, v)
        if item["retrieved_contexts"][0]['text'] in v.text:
            cnt += 1

print(cnt, len(data))