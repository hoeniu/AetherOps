import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
from typing import Any, Dict
from tests.base_test_case import BaseTestCase
from kbx.common.types import DocFileType, KBXError, ImageEmbeddingStrategy
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, DocParseConfig, \
    SplitterConfig, QueryConfig, KnowledgeGraphIndexConfig
from kbx.knowledge_base.knowledge_base import KnowledgeBase
from kbx.parser.types import PdfOcrStrategyConfig, ImageStrategyConfig
import json


class TestVectorKeywordIndexE2E(BaseTestCase):
    def setup_method(self):
        self._kb_name = "kg索引读码器知识库"
        self._kb_description = "这是一个读码器知识库，包含各种读码器规范知识信息"
        self._kb = None
        
        with open(os.path.join(ROOT_DIR, "tests/schema/schema_industry.json"), encoding="utf-8") as fd:
            self._schema_dict = json.load(fd)

    def _create_std_kb(self, kb_config: KBCreationConfig = None):
        if self._kb:
            return
        # try:
        #     # 如果已经存在，尝试进行旧数据删除
        #     previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
        #     previous_kb.remove_kb()
        # except RuntimeError:
        #     pass
        # self._kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        # print(f'Try to create new kb {kb_config.name} (id={self._kb.kb_id})')

        all_kb_id_names = KBX.list_kbs(user_id=DEFAULT_USER_ID)
        kb_name2id = dict([(name, id) for id, name in all_kb_id_names])
        existed_kb_id = kb_name2id.get(kb_config.name, None)
        if existed_kb_id:
            # 已经存在，尝试从DB中读取
            print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
            self._kb = KBX.get_existed_kb(kb_id=existed_kb_id)
        else:
            # 未存在，尝试创建
            print(f'Try to create new kb {kb_config.name} (id={existed_kb_id})')
            self._kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

            # scanner_dir = 'scanner_files'
            # scanner_files = [os.path.join(self.test_data_dir, scanner_dir, doc) for doc in os.listdir(os.path.join(self.test_data_dir, scanner_dir))]  # noqa
            # print(f'scanner_files: {scanner_files}')
            results = self._kb.insert_docs(
                file_list=[
                    os.path.join(self.test_data_dir, 'VS500产品规格书.pdf'),
                    # os.path.join(self.test_data_dir, '2023-04-05：以史为鉴：从银行业危机到衰退和降息有多远？.pdf'),
                    # os.path.join(self.test_data_dir, '五轴产品汇报-脱敏-1.pdf'),
                ]
                # file_list=scanner_files
            )
            if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
                raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

    def _retrieve(self, kb: KnowledgeBase, vector_dynamic_kwargs: Dict[str, Any] = None):
        query_text = "VS500智能读码器有哪些特点？"  # VHS8000坚固性工业手持读码器有哪些特性？  VS500智能读码器有哪些特点？VG800P智能读码器被成功应用于哪些行业？
        query = QueryConfig(
            text=query_text,
            top_k=20,
            score_threshold=0.0,
            vector_dynamic_kwargs=vector_dynamic_kwargs or {
                "keyword_similarity_weight": 0.0,
            }
        )

        # # 使用知识库直接查询
        # query_result = kb.retrieve(query=query)
        # # print("------------------results using knowledge base:  ", query_result)
        # assert isinstance(query_result, list), f"Query result should be a list, given {query_result}"
        # assert len(query_result) > 0, "Failed to get query result"
        # if query.top_k > 0:
        #     assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
        #                                              f"given {query.top_k} and {len(query_result)}"

        # # 使用KBX在顶层进行查询
        query_result = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
        assert isinstance(query_result, list), f"Query result should be a list, given {query_result}"
        assert len(query_result) > 0, "Failed to get query result"
        if query.top_k > 0:
            assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                                                     f"given {query.top_k} and {len(query_result)}"

        print(f'Get {len(query_result)} results from kb ("{kb.kb_config.name}")')
        retrieval_text = ''
        for k, qr in enumerate(query_result):
            print(f'------------------------- #{k}, score={qr.score} -------------------------')
            print(qr.text_chunk.text)
            retrieval_text += '\n' + qr.text_chunk.text
            # 保存检索的图片
            
            # from kbx.datastore.ds_factory import get_doc_datastore
            # import base64
            # from PIL import Image
            # from io import BytesIO
            # with get_doc_datastore(kb_id=kb.kb_id) as pdf_doc_ds:
            #     elements = pdf_doc_ds.load_doc_data(qr.text_chunk.doc_id)[0].doc_elements
            # for ele in elements:
            #     if not ele.image_b64:
            #         continue
            #     if qr.text_chunk.doc_element_ids[0] == ele.doc_element_id and ele.image_b64:
            #         img_data = BytesIO(base64.b64decode(ele.image_b64))
            #         image = Image.open(img_data)
            #         image.save(os.path.join(self.test_data_dir, f'{ele.image_caption}_rank{k + 1}_score{qr.score:3f}.png'))
        client_config, client = KBX.get_ai_model_config_and_client('doubao-pro-32k')
        response_text = client.chat(
            client_config,
            prompt=f"根据以下检索到的文档内容，回答问题:{query.text} \n{retrieval_text}",
            temperature=0.7
        )
        print(f"response_text: {response_text}")

    def test_vector_index_case(self):
        # 只开启vector index
        vec_kb_config = KBCreationConfig(
            name="_kfb",
            description=self._kb_description,
            is_external_datastore=False,
            # doc_parse_config=DocParseConfig(
            #     file_parsers={
            #         DocFileType.PDF: "MinerUPDFParser",
            #     },
            #     image_strategy=ImageStrategyConfig(
            #         type=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,
            #         vision_model='OpenGVLab/InternVL2-26B'
            #     ),
            #     pdf_ocr_strategy=PdfOcrStrategyConfig(parser_type='MinerU')
            # ),
            kg_config=KnowledgeGraphIndexConfig(
                index_strategy="DefaultGraphIndex",
                llm_model="doubao-1.5-pro-256k",
                embedding_model="BAAI/bge-m3",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    delimiters=["\n\n"],
                ),
                schema_dict=self._schema_dict,
            ),
        )
        self._kb = None
        self._create_std_kb(vec_kb_config)
        self._retrieve(self._kb)
        # self._modify_config()

    def test_vector_keyword_index_case(self):
        # 同时开启vector index和keyword index
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "DefaultPdfParser",
                }
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                # netease-youdao/bce-embedding-base_v1",
                # BAAI/bge-m3",
                # "doubao-embedding",
                splitter_config=SplitterConfig(name="NaiveTextSplitter", chunk_size=1024),
                keyword_extractor="jieba",
                max_keywords_per_chunk=100,
            ),
            # rerank_config=RerankConfig(
            #     rerank_type="ModelRerank",
            #     rerank_kwargs={"rerank_model": "BAAI/bge-reranker-v2-m3"},
            # ),
        )
        vector_dynamic_kwargs = {
            "keyword_similarity_weight": 0.2,
        }
        self._kb = None
        self._create_std_kb(kb_config)
        self._retrieve(self._kb, vector_dynamic_kwargs)
        self._retrieve(self._kb, vector_dynamic_kwargs)


if __name__ == "__main__":
    # 手动执行
    test_case = TestVectorKeywordIndexE2E()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_vector_index_case()
    # test_case.test_vector_keyword_index_case()
