from kbx.common.types import TextChunk, DocData, DocElement, DocElementType


def gen_text_chunk(chunk_num=3):
    chunk1 = TextChunk()
    chunk1.text = """
"指标名称":" 建筑业";"单位":"亿元";"2019年2季度":"141.45";"2019年1-2季度累计":"329.24";"累计同比±(%)":"14";"链接":"http://tjj.sz.gov.cn/zwgk/zfxxgkml/tjsj/tjyb/content/post_3082324.html"
"""
    chunk1.chunk_id = '11'

    chunk2 = TextChunk()
    chunk2.text = """
"指标名称":" 其他服务业";"单位":"亿元";"2019年2季度":"1553.05";"2019年1-2季度累计":"2929.84";"累计同比±(%)":"10.1";"链接":"http://tjj.sz.gov.cn/zwgk/zfxxgkml/tjsj/tjyb/content/post_3082324.html"
"""
    chunk2.chunk_id = '22'

    chunk3 = TextChunk()
    chunk3.text = """
"指标名称":" 金融业 ";"单位":"亿元";"2019年2季度":"875.5";"2019年1-2季度累计":"1663.16";"累计同比±(%)":"7";"链接":"http://tjj.sz.gov.cn/zwgk/zfxxgkml/tjsj/tjyb/content/post_3082324.html"
"""
    chunk3.chunk_id = '33'

    chunk4 = TextChunk()
    chunk4.text = """"指标名称":"第三产业";"单位":"亿元";"2019年2季度":"3941.95";"2019年1-2季度累计":"7373.66";"累计同比±(%)":"7.5";"链接":"http://tjj.sz.gov.cn/zwgk/zfxxgkml/tjsj/tjyb/content/post_3082324.html"
    """
    chunk4.chunk_id = '44'

    chunk5 = TextChunk()
    chunk5.text = """"指标名称":"规模以上工业增加值";"单位":"亿元";"2019年8月":"—";"2019年1-8月累计":"—";"累计同比±(%)":"4.6";"链接":"http://tjj.sz.gov.cn/zwgk/zfxxgkml/tjsj/tjyb/content/post_3082324.html"
    """
    chunk5.chunk_id = '55'

    chunk6 = TextChunk()
    chunk6.text = """量子计算机的革命性潜力正在逐步显现。与传统计算机不同，量子计算机利用量子比特进行信息处理，这使得它们在解决复杂问题时比传统计算机快得多。科学家们正在探索量子计算在药物发现、气候模拟和密码学等领域的应用。
    """
    chunk6.chunk_id = '66'

    chunk7 = TextChunk()
    chunk7.text = """根据最新市场分析，我们的新产品线在过去一个季度内实现了显著的市场份额增长。归功于创新的设计和有效的营销策略，我们的销售额比去年同期增长了20%。预计在接下来的财年，这一增长趋势将持续。
    """
    chunk7.chunk_id = '77'

    chunk8 = TextChunk()
    chunk8.text = """气候变化是一个复杂的系统，涉及大量的变量和不确定性。量子计算机可以处理这些复杂的计算，提供更精确的气候模型，帮助科学家更好地理解和预测气候变化。
    """
    chunk8.chunk_id = '88'

    chunk9 = TextChunk()
    chunk9.text = """探索比较的五大必游之地。首先，不要错过历史悠久的各个地表，它见证了这座城市的兴衰。接下来，漫步在自然公园里，享受自然的宁静。别忘了品尝当地的特色美食，它将让你的味蕾跳起舞来。最后，别忘了在购物街享受购物的乐趣。
    """
    chunk9.chunk_id = '99'

    chunk10 = TextChunk()
    chunk10.text = """本文档提供了关于最新软件开发工具包（SDK）的详细指南。它包括了安装指南、API参考和最佳实践。开发者可以通过这个SDK轻松集成我们的服务，以增强他们的应用程序功能。请确保遵循所有安全协议和编码标准，以确保最佳的开发体验。
    """
    chunk10.chunk_id = '10'

    if chunk_num == 3:
        return [chunk1, chunk2, chunk3]
    else:
        return [chunk1, chunk2, chunk3, chunk4, chunk5, chunk6, chunk7, chunk8, chunk9, chunk10]

def get_doc_data():
    doc1 = DocData()
    doc1.doc_id = '1'
    element1 = DocElement(doc_element_id="doc1_text1", type=DocElementType.TEXT, text="""大规模联邦金融分析预测实验系统运行需要服务器、网络、存储、算力等资源，资源需求情况分为：硬件资源、系统资源、网络资源和软件资源。
    """)
    element2 = DocElement(doc_element_id="doc1_text2", type=DocElementType.TEXT, text="""部署在鹏城云脑II的ModelArts环境中，可以提供计算中心内网的计算资源，因此系统部署的服务器之间可以通过以太网互联，为了保障模型训练的效率，服务器之间的网络带宽要求为万兆。
    """)
    element3 = DocElement(doc_element_id="doc1_text3", type=DocElementType.TEXT, text="""系统的核心平台是联邦学习平台，提供隐私计算、联邦特征工程和联邦学习算法
    """)
    doc1.doc_elements = [element1, element2, element3]

    doc2 = DocData()
    doc2.doc_id = '2'
    element21 = DocElement(doc_element_id="doc2_text1", type=DocElementType.TEXT, text=""""指标名称":" 建筑业";"单位":"亿元";"2019年2季度":"141.45";"2019年1-2季度累计":"329.24";"累计同比±(%)":"14";"链接":"http://tjj.sz.gov.cn/zwgk/zfxxgkml/tjsj/tjyb/content/post_3082324.html"
    """)
    element22 = DocElement(doc_element_id="doc2_text2", type=DocElementType.TEXT, text=""""指标名称":" 其他服务业";"单位":"亿元";"2019年2季度":"1553.05";"2019年1-2季度累计":"2929.84";"累计同比±(%)":"10.1";"链接":"http://tjj.sz.gov.cn/zwgk/zfxxgkml/tjsj/tjyb/content/post_3082324.html"
    """)
    element23 = DocElement(doc_element_id="doc2_text3", type=DocElementType.TEXT, text=""""指标名称":" 金融业 ";"单位":"亿元";"2019年2季度":"875.5";"2019年1-2季度累计":"1663.16";"累计同比±(%)":"7";"链接":"http://tjj.sz.gov.cn/zwgk/zfxxgkml/tjsj/tjyb/content/post_3082324.html"
    """)
    doc2.doc_elements = [element21, element22, element23]

    doc3 = DocData()
    doc3.doc_id = '3'
    element31 = DocElement(doc_element_id="doc3_text1", type=DocElementType.TEXT, text="""量子计算机的革命性潜力正在逐步显现。与传统计算机不同，量子计算机利用量子比特进行信息处理，这使得它们在解决复杂问题时比传统计算机快得多。科学家们正在探索量子计算在药物发现、气候模拟和密码学等领域的应用。参考 2020 年政策底、经济底和市场底经验，美股不确定性越早落地，A 股越有机会凭借国内经济复苏领先优势走出独立行情。二是美股陷入“熊市”危机，连续两年明显收跌。美股历史上出现四次连续两年以上收跌，无一不是撞上了严重的经济事件。概率虽低，但是 A股遇上后难言独立行情。2023 年海外不确定性依然较大，市场参与者保持适度谨慎和灵活性，做好预案。
    """)
    element32 = DocElement(doc_element_id="doc3_text2", type=DocElementType.TEXT, text="""气候变化是一个复杂的系统，涉及大量的变量和不确定性。量子计算机可以处理这些复杂的计算，提供更精确的气候模型，帮助科学家更好地理解和预测气候变化。当前市场最大争论是美联储紧缩会否引发美国经济衰退和金融危机，进而导致美股大幅下挫。虽然市场尚未达成共识，但是本文尝试“超前”分析美股调整对 A 股的传导机制及影响。\n\n美股调整可能通过资本流动（资产配置再平衡）、货币政策、经济基本面和恐慌情绪四种渠道影响 A 股。随着外资持续流入，外资在 A 股市场的影响力已经不容忽视。当外资大幅放缓流入或者流出时，内资“迷信”外资掌握更多信息。在美元主导的国际货币体系下，美联储紧缩引发全球金融收缩，A 股尚未成功在中国央行逆势宽松下独树一帜，尤其是在中国深度融入金融经贸全球化的今天。))))))))))))))尤为关键的是，恐慌情绪易于传染。在高度不确定性的环境下，避险是本能行为，不仅发生在 A 股，也发生在欧洲和日本等主要股票市场。当单月 VIX 大涨 50%或者陆股通净流出时，A 股基本上会收跌。但是，VIX 是经济金融危机的“副产品”，高度不可预测。\n\n2023 年美股下跌分两种情形，一是阶段性技术调整，呈现“N”型走势。关键是底部出现时点。参考 2020 年政策底、经济底和市场底经验，美股不确定性越早落地，A 股越有机会凭借国内经济复苏领先优势走出独立行情。二是美股陷入“熊市”危机，连续两年明显收跌。美股历史上出现四次连续两年以上收跌，无一不是撞上了严重的经济事件。概率虽低，但是 A股遇上后难言独立行情。2023 年海外不确定性依然较大，市场参与者保持适度谨慎和灵活性，做好预案。
    """)
    doc3.doc_elements = [element31, element32]

    doc4 = DocData()
    doc4.doc_id = '4'
    element41 = DocElement(doc_element_id="doc4_text1", type=DocElementType.TEXT, text="""当前市场最大争论是美联储紧缩会否引发美国经济衰退和金融危机，进而导致美股大幅下挫。虽然市场尚未达成共识，但是本文尝试“超前”分析美股调整对 A 股的传导机制及影响。\n\n美股调整可能通过资本流动（资产配置再平衡）、货币政策、经济基本面和恐慌情绪四种渠道影响 A 股。随着外资持续流入，外资在 A 股市场的影响力已经不容忽视。当外资大幅放缓流入或者流出时，内资“迷信”外资掌握更多信息。在美元主导的国际货币体系下，美联储紧缩引发全球金融收缩，A 股尚未成功在中国央行逆势宽松下独树一帜，尤其是在中国深度融入金融经贸全球化的今天。))))))))))))))尤为关键的是，恐慌情绪易于传染。在高度不确定性的环境下，避险是本能行为，不仅发生在 A 股，也发生在欧洲和日本等主要股票市场。当单月 VIX 大涨 50%或者陆股通净流出时，A 股基本上会收跌。但是，VIX 是经济金融危机的“副产品”，高度不可预测。\n\n2023 年美股下跌分两种情形，一是阶段性技术调整，呈现“N”型走势。关键是底部出现时点。参考 2020 年政策底、经济底和市场底经验，美股不确定性越早落地，A 股越有机会凭借国内经济复苏领先优势走出独立行情。二是美股陷入“熊市”危机，连续两年明显收跌。美股历史上出现四次连续两年以上收跌，无一不是撞上了严重的经济事件。概率虽低，但是 A股遇上后难言独立行情。2023 年海外不确定性依然较大，市场参与者保持适度谨慎和灵活性，做好预案。""")
    doc4.doc_elements = [element41]

    return [doc1, doc2, doc3, doc4]
    # return [doc3, doc4]

def get_chunk_ids(doc_ids):
    doc_chunk_dict = {
        "1": ['11', '22', '33'],
        "2": ['44', '55', '66'],
        "3": ['77', '88', '99'],
        "4": ['10'],
    }
    return doc_chunk_dict[doc_ids]
