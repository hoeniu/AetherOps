import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
import sys
sys.path.insert(0, ROOT_DIR)

import pytest

from tests.base_test_case import BaseTestCase
from kbx.common.types import AudioEmbeddingStrategy, DocData, ImageEmbeddingStrategy
from kbx.common.utils import generate_new_id
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, VectorKeywordIndexConfig
from kbx.parser.parser_factory import get_parser
from kbx.parser.types import AudioStrategyConfig, DocParseConfig, ImageStrategyConfig, \
    CodeStrategyConfig, PdfOcrStrategyConfig
# from kbx.common.utils import doc_element_to_markdown


class TestParser(BaseTestCase):
    def setup_method(self):
        self._kb_name = "文档测试"
        self._doc_parser_config = DocParseConfig(
            audio_strategy=AudioStrategyConfig(type=AudioEmbeddingStrategy.SPEECH2TEXT_TEXT_EMBEDDING,
                                               split_mode='size',
                                               voice_model='FunAudioLLM/SenseVoiceSmall',
                                               refinement_model='Qwen/Qwen2.5-7B-Instruct'),
            image_strategy=ImageStrategyConfig(type=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,
                                               vision_model='doubao-1.5-vision-pro-32k'),
            code_strategy=CodeStrategyConfig(
                code_summarizer='doubao-1.5-pro-32k'
            ),
            pdf_ocr_strategy=PdfOcrStrategyConfig(
                parser_type='VLMPdfParser',
                vlm_model='Qwen2.5-VL-72B-Instruct',
                use_consecutive_pages=False
            )
        )
        self.kb_config = KBCreationConfig(
            name=self._kb_name,
            description="这是一个文档测试知识库",
            is_external_datastore=False,
            doc_parse_config=self._doc_parser_config,
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="BAAI/bge-m3",
            ),
        )
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=self.kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass
            
        # KBX.create_new_kb(self.kb_config, user_id=DEFAULT_USER_ID)
        from kbx.common.utils import generate_new_id, inject_user_ctx
        from kbx.common.constants import DEFAULT_TENANT_ID
        from kbx.common.types import UserContext
        inject_user_ctx(config=self.kb_config, user_ctx=UserContext(
                user_id=DEFAULT_USER_ID,
                tenant_id=DEFAULT_TENANT_ID,
            ), recursive=True)
        
    def test_parse_pdf_parser(self):
        parser = get_parser("VLMPdfParser", self._doc_parser_config)
        # file_path = os.path.join(self.test_data_dir, "parser_data/11125873.pdf")
        file_path = os.path.join(self.test_data_dir, "parser_data/线路中边桩坐标计算的通用Gauss-Legendre公式 (1).pdf")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        assert len(doc_data.doc_elements) > 0
        # '''
        # with open('data/pdf_log_11125873_0603.txt', 'w') as f:
        with open('data/vlmparser_线路中边桩_0603.txt', 'w') as f:
            f.write(str(doc_data))
        # '''
        


if __name__ == '__main__':
    test_case = TestParser()
    import time
    time1 = time.time()
    test_case.setup_class()
    test_case.setup_method()
    test_case.test_parse_pdf_parser()
    time2 = time.time()
    print(f"time: {time2 - time1}")