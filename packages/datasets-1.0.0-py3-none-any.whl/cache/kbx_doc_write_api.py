import os
import requests
import json
from pathlib import Path
from typing import List, Dict
from textwrap import dedent
KBX_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')
import sys
sys.path.insert(0, KBX_DIR)
from kbx.kbx import KBX

import logging
logger = logging.getLogger('QA_logger')

from src.kbx_api import KBXClient
from kbx.common.types import KBXError



class DocWriterClient(KBXClient):
    def __init__(self, api_key: str, kbx_url: str, user_id: str, ai_model_config: Dict):
        super().__init__(api_key, kbx_url, user_id)
        self._ai_model_config = ai_model_config
        KBX.register_ai_models_from_conf(model_configs=os.path.join(
            KBX_DIR, self._ai_model_config['yaml_file']), overwrite=True)

        self._LLM_config, self._LLM_client = KBX.get_ai_model_config_and_client(
            self._ai_model_config['LLM_name'], user_id=self.user_id)

    def _filter_doc_ids(self, query, kb_id, stream=True):

        doc_data_list = []
        doc_info_dict = {}
        doc_info_list = []
        # doc_id_list = []

        from kbx.datastore.ds_factory import get_doc_datastore
        with get_doc_datastore(kb_id) as doc_store:
            doc_ids, err = doc_store.list_doc_ids()
            if err.code != KBXError.Code.SUCCESS:
                return []
            for doc_id in doc_ids:
                doc_data, err = doc_store.load_doc_data(doc_id=doc_id)
                doc_data_list.append(doc_data)
                # TODO: 获取文档摘要
                doc_info_list.append({
                    'file_name': doc_data.file_name,
                    # 'summary': doc_data.summary,
                    'doc_id': doc_id
                })
                # doc_id_list.append(doc_id)
                doc_info_dict[doc_id] = doc_data.file_name
        # with open(file_name, 'w', encoding='utf-8') as file:
        #     json.dump(doc_info_list, file, ensure_ascii=False, indent=4)

        # doc_info_list = doc_info_list[:20]
        document_info = json.dumps(doc_info_list, ensure_ascii=False)
        # client_config, client = KBX.get_ai_model_config_and_client(LLM_MODEL)
        # final_prompt = f"""你是一个专业的采购文档专家。请根据用户的输入内容提取待采购的产品，从文件信息表中找出和该产品相关的所有文档。遵循以下规则：\n\n## 输入信息：\n1. 用户输入：'<待采购货品或者项目关键词>的<信息类型请求>' 。核心：要解析待采购货品部分，忽略后边的信息类型请求\n2. 文件列表：[{{'file_name':文件名1,'doc_id':ID1}}, ...]\n\n## 要求：\n1. 优先保留更多匹配结果而非精确过滤，要最大限度召回相关文档\n2. 仅输出匹配到的doc_id值，禁止包含file_name或其他说明文字\n3. 多个结果时用<separator>分隔，例如：123<separator>456\n4. 严格保持输出纯净，不要添加任何标点或格式\n5. 保持原始doc_id的大小写格式\n\n## 示例\n[输入]：阻燃电线的供应商资质是什么？\n[解析]: \n- 待采购货品或者项目关键词: 阻燃、电线、阻燃电线\n- 匹配文件：\n  {{'file_name':'BVV阻燃电线工艺规范','doc_id':'efff-221'}}\n  {{'file_name':'电线类产品认证标准','doc_id':'2bisu-009'}}\n[输出] 'efff-221<separator>2bisu-009'\n\n## 当前文件信息表（JSON格式）：\n{document_info}\n\n## 用户输入：\n{query}\n\n请直接输出doc_id，不要输出其他内容。"""  # noqa
        print("用户输入：：：：：：：：：：", query)

        if not query:
            return [], 'empty'
        prompt_new = f"你擅长理解用户输入，并搜索相关的文档。请根据用户的输入，从文件信息表中找到所有与之有关联的文件，输出文件id（即doc_id）。\n\n文件信息表（list）：每个文档是一个字典，包含以下字段：\n  - `doc_id` (int)：文档的唯一标识符。\n  - `file_name` (str)：文档的文件名。\n\n 请保证所有相关文档都被找到，不要遗漏。\n\n 用户的输入: {query}\n\n文件信息表如下：{document_info}\n\n 若找到多个文件，请用<separator>分隔doc_id。请直接输出用<separator>分隔的doc_id，不要输出其他内容。"  # noqa

        response = self._LLM_client.chat(
            self._LLM_config,
            prompt=prompt_new,
            temperature=0.7,
            stream=stream
        )
        if stream:
            return response, doc_info_dict
        else:
            doc_ids = response.replace("\n", "").split("</think>")[-1].split('<separator>')

            all_file_names = '\n\n'.join(doc_info_dict[doc_id] for doc_id in doc_ids)

            print('2222222222222222222从知识库中查询到以下文档：', all_file_names)

            return doc_ids, all_file_names

    def process_llm_output(self, text):
        if len(text.split('<goods>')) == 1:
            # 用户输入中没有属性
            query_list = ''
            item_to_buy = text.replace("\n", "")  # split('<separator>')
        else:
            item_list = text.split('<goods>')[0].split('<separator>')
            item_to_buy = '\n'.join(item_list)

            query_list = text.split("</think>")[-1].split('<goods>')[1].split('<separator>')

        all_queries = '\n'.join(query_list)
        print('item to buyyyyyyyyyyyyyyy and all_queries:', item_to_buy, all_queries)

        return query_list, all_queries, item_to_buy

    def generate_retrieved_questions(self, query):
        # step1：大模型生成查询问题
        response_text1 = self._LLM_client.chat(
            self._LLM_config,
            # system_prompt="你是经验丰富的资料员，擅长从文档资料库中搜集历史数据。现在用户要从文档资料库中搜索曾经采购过的货品及其属性的值，将搜索结果作为经验，基于这些经验来决策下次采购的货品属性。",  # 请根据文档，为待采购的货品补充对应属性的值。",  # noqa
            # prompt=f"请从用户的要求中提取货品和待查询的属性，基于属性生成查询问题，输入到文档资料库中进行查询。\n\n## 要求：\n货品和查询问题之间请用<goods>进行分隔，查询问题之间请用<separator>进行分隔，货品之间也用<separator>进行分隔，且问题前不要加序号。如果未提取出货品，则只输出用<separator>分隔的问题。\n\n## 输出格式\n货品1<separator>货品2<goods>问题1<separator>问题2\n\n\n\n##示例\n用户的要求为：采购绿植和电缆，应该选择的供货期和供应商是什么？\n输出：绿植<separator>电缆<goods>供货期是多久？<separator>供应商是哪家？\n\n ## 以下是用户的要求\n\n{query} \n\n 请直接输出答案，不要输出其他内容。",  # noqa
            prompt=f"请从用户的要求中提取货品和与该货品有关联的属性信息，并进行输出。\n\n## 要求：\n货品和关联的属性信息之间请用<goods>进行分隔，关联的属性信息之间请用<separator>进行分隔，且问题前不要加序号。如果未提取出相关的属性信息，则只输出货品名称。\n\n## 输出格式\n货品<goods>信息1<separator>信息2\n\n\n\n##示例\n用户的要求为：我要采购电缆，请帮我生成项目需求书\n输出：电缆\n\n ## 以下是用户的要求\n\n{query} \n\n 请直接输出答案，不要输出其他内容。",  # <goods>20kv<separator>交货期是20天  # noqa
            temperature=0.7,
            stream=True  # False
        )
        return response_text1
        query_list, all_queries, item_to_buy = self._process_llm_output(response_text1)
        # query_list = ['资金来源和落实情况']
        # all_queries = '资金来源和落实情况'

        display_text = '### 1. 用户的查询内容\n\n' + item_to_buy + '；' + all_queries
        print("1111111111", display_text)  # final_response_text.split("</think>")[-1])
        return display_text, query_list, all_queries, item_to_buy

    def select_doc_id(self, query, kb_ids, stream=True):
        # step2：大模型生成查询的doc范围
        # TODO qianhai: 只有一个知识库
        kb_id = kb_ids[0]
        selected_doc_ids, all_file_names = self._filter_doc_ids(query, kb_id, stream)

        if stream:
            print('---------stream----all doc_id: file name', all_file_names)
            return selected_doc_ids, all_file_names  # response, doc_info_dict
        else:
            print('--------------select doc ids', selected_doc_ids)
            if len(selected_doc_ids) == 0:
                selected_doc_ids = None

            display_text = '### 2. 查询到相关文档\n\n' + all_file_names
            return display_text, selected_doc_ids

    def create_chat_message(self, query_text, selected_doc_ids, top_k,
                            score_threshold, keyword_similarity_weight,
                            enable_index_types, kb_ids):
        # query_text = query_list[i].replace("\n", "")
        rule_dict = {
            "交货期": '1. 准确识别并分类文本中提及的交货期（或称合同交货日期），分条列举出来。例如是20天，还是合同签订后10天，还是下单后5天。\n\n2. 基于文本内容，请你在最后给出明确的交货期的建议，并说明原因。\n\n请按以下结构化格式输出：\n\n#### 1. 交货期选项一\n\n（把具体日期标红，例如输出：交货期为成交通知书发出后<span style="color:red;">20个日历天</span>）\n\n#### 2. 交货期选项二\n\n\n\n##### 💡建议选择xxx，原因：xxx。\n\n',  # noqa
            "交货方式": '1. 准确识别并分类文本中提及的交货方式\n\n2. 基于文本内容，请你给出明确的建议。例如搜到的大多数交货方式是指定地点地面交货，则建议选择该方式。\n\n请按以下结构化格式输出：\n\n#### 1. 交货方式选项一\n\n#### 2. 交货方式选项二\n\n\n\n##### 💡建议选择xxx，原因：xxx。\n\n',  # noqa
            "质保期": '1. 准确识别并分类文本中提及的质保期（或称质量保证期）\n\n2. 基于文本内容，请你给出明确的建议。例如搜到的大多数质保期是从合同货物通过验收并投运后xx个月，则建议选择该选项。\n\n请按以下结构化格式输出：\n\n#### 1. 质保期选项一\n\n（把具体日期标红，例如输出：质保期为从合同货物通过验收并投运后<span style="color:red;">20个月</span>）#### 2. 质保期选项二\n\n\n\n##### 💡建议选择xxx，原因：xxx。\n\n',  # noqa
            "付款方式和条件": '1. 准确识别并分类文本中提及的付款方式和条件\n\n2. 基于文本内容，请你给出明确的建议。例如搜到的大多数付款方式和条件是分预付款、到货款、投运款和质保金四次支付，则建议选择该付款方式和条件*\n\n请按以下结构化格式输出：\n\n#### 1. 付款方式和条件选项一\n\n#### 2. 付款方式和条件选项二\n\n\n\n##### 💡建议选择xxx，原因：xxx。\n\n',  # noqa
            "结算方式": "1. 准确识别并分类文本中提及的结算方式（即以单价结算还是总价结算）\n\n2. 基于文本内容，请你给出明确的建议。例如搜到的大多数结算方式是按中标单价结算，则建议选择该结算方式。\n\n请按以下结构化格式输出：\n\n#### 1. 结算方式选项一\n\n#### 2. 结算方式选项二\n\n\n\n##### 💡建议选择xxx，原因：xxx。\n\n",  # noqa
        }

        pre_prompt = rule_dict[query_text]

        # if kongtiao_flag:
        #     query_text = '交货期是多少天'
        if query_text == "结算方式":
            query_text = '本合同按照单价结算还是总价结算？'
        elif query_text == "质保期":
            query_text = '质保期 质量保证期为从合同货物通过验收'
        retrieved_res = self._retrieval(query_text, top_k, score_threshold,
                                        keyword_similarity_weight, selected_doc_ids,
                                        kb_ids, enable_index_types)
        reference_context = []
        retrieved_text = ''
        retrieved_img_count = 0
        for res_item in retrieved_res:
            retrieved_text += (res_item['text_chunk']['text'] + '\n\n')
            retrieved_info = {
                'kb_id': res_item['kb_id'],
                'doc_name': res_item['meta_data']['doc_name'],
                'doc_id': res_item['doc_id'],
                'score': res_item['score'],
                'data_type': 'text',
                'data_str': res_item['text_chunk']['text']
            }
            print("chunk from file :", res_item['meta_data']['doc_name'])
            print("doc id:", res_item['doc_id'])

            raw_data = res_item.get('raw_data', {})
            if raw_data:
                if 'base64' in raw_data:
                    retrieved_info['img_b64'] = raw_data['base64']
                    retrieved_img_count += 1
                elif 'file_path' in raw_data:
                    bytes_data = self._get_media_bytes(res_item['kb_id'], raw_data['file_path'])
                    file_extension = Path(raw_data['file_path']).suffix.lower()
                    media_context = {'audio_bytes': bytes_data} if file_extension in [
                        '.mp3', '.wav'] else {'video_bytes': bytes_data}
                    retrieved_info.update(media_context)
                elif 'table' in raw_data:
                    table_list = raw_data['table']
                    retrieved_info.update({'table': table_list})
            else:
                retrieved_info['text'] = res_item['text_chunk']['text']

            reference_context.append(retrieved_info)

        # if len(retrieved_res) == retrieved_img_count:
        #     generated_text = self._generate_VLM_response(query, reference_context)
        # else:
        #     generated_text = self._generate_LLM_response(query, retrieved_text)

        # print("\n\nretrieved_texttttttttttt: ", retrieved_text)

        print("input and prompot: ", query_text, f"请根据提供的检索文本：{retrieved_text}，完成以下工作：\n\n" + pre_prompt)
        response_text = self._LLM_client.chat(
            self._LLM_config,
            # system_prompt=f"你擅长根据历史文档数据总结信息以指导未来决策，基于经验来决定下次采购货品的属性。以下的文档资料记录了历史采购的货品具有哪些属性及其对应的值，请根据历史数据，为待采购的货品的每个属性补充合适的值。例如，某件货品有5次从供应商A处采购，有1次从供应商B处采购，则属性为供应商，该属性应补充的值为A。",
            # prompt=f"请从用户要求中提取出货品的名称和待补充的属性:\n\n 用户要求：{query_text} \n\n 历史文档数据：{retrieved_text} \n\n 请补充属性的值，注意，只补充用户要求中的属性，其余属性请忽略。",  # noqa
            prompt=f"请根据提供的检索文本：{retrieved_text}，完成以下工作：\n\n" + pre_prompt,  #  + f"列举出所有能回答用户问题的答案，不要遗漏任何细节。\n\n## 用户query\n\n{query_text}\n\n ## 检索到的文档内容 \n\n{retrieved_text} ",   # 如果答案有多个，请列举出每个答案的详情，并统计数量，整理成表格。 例如，货品M有5次从供应商A处采购，则表格表头为：货品、供应商、次数，对应的值为M、A、5 \n\n## 检索到的文档内容 \n\n{retrieved_text} \n\n## 用户问题：{query_text}",  # noqa
            temperature=0.7,
            stream=True
        )
        # final_response = response_text.split("</think>")[-1]

        # print(f"33333333333属性xxx的值为: {final_response}")

        return reference_context, response_text, 'rag_response'

    def write_procurement_doc(self, history_data, item_to_buy, all_queries):
        # step4：大模型整合待采购对象、历史属性值，写招标文件
        final_response_text = self._LLM_client.chat(
            self._LLM_config,
            system_prompt="你是经验丰富的招标员，请根据文档资料库中的数据和用户的需求，撰写招标需求文件。",
            prompt=f"## 文档资料库中的数据：\n{history_data} \n\n## 待采购的货品或项目\n{item_to_buy} \n\n## 用户的需求：{all_queries} \n\n请根据上述数据，撰写招标文件。要求：要依据文档资料撰写，可尽量详尽地扩充，确保你的回答形成一个或多个内容丰富、逻辑连贯的长段落，避免使用分段符号，通过关联词保持段落连贯性，每段长度在400-600字。",  # noqa
            temperature=0.7,
            stream=True
        )
        print(f"444444444444444招标文件如下: {final_response_text}")

        return final_response_text
