import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
from typing import Any, Dict
from tests.base_test_case import BaseTestCase

from kbx.common.types import DocFileType, KBXError
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, \
    SplitterConfig, QueryConfig, VectorKeywordIndexConfig
# from kbx.rerank.types import RerankConfig
from kbx.common.utils import get_pydantic_config_changes
from kbx.knowledge_base.knowledge_base import KnowledgeBase
from kbx.parser.types import DocParseConfig
from kbx.rerank.types import RerankConfig

import pytest


class TestVectorKeywordIndexE2E(BaseTestCase):
    def setup_method(self):
        self._kb_name = "向量索引测试知识库kuaa"
        self._kb_description = "这是一个建筑规范知识库，包含各种建筑规范知识信息"
        self._kb = None

    def _create_std_kb(self, kb_config: KBCreationConfig = None):
        if self._kb:
            return
        try:
            # 如果已经存在，尝试进行旧数据删除
            previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
            previous_kb.remove_kb()
        except RuntimeError:
            pass
        self._kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        print(f'Try to create new kb {kb_config.name} (id={self._kb.kb_id})')

        # all_kb_id_names = KBX.list_kbs(user_id=DEFAULT_USER_ID)
        # kb_name2id = dict([(name, id) for id, name in all_kb_id_names])
        # existed_kb_id = kb_name2id.get(kb_config.name, None)
        # if existed_kb_id:
        # # 已经存在，尝试从DB中读取
        #     print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
        #     self._kb = KBX.get_existed_kb(kb_id=existed_kb_id)
        # else:
        #     # 未存在，尝试创建
        #     print(f'Try to restore new kb {kb_config.name} (id={existed_kb_id})')
        #     self._kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

        results = self._kb.insert_docs(
            file_list=[
                # os.path.join(self.test_data_dir, '2023-04-10：海外宏观周报：美国经济喜忧交织.pdf'),
                # os.path.join(self.test_data_dir, '2023-04-05：以史为鉴：从银行业危机到衰退和降息有多远？.pdf'),
                os.path.join(self.test_data_dir, '前海营业厅/中华人民共和国电力法（2015年修正）.pdf'),
                os.path.join(self.test_data_dir, '前海营业厅/电力供应与使用条例.docx'),
                os.path.join(self.test_data_dir, '前海营业厅/qianhai_info.txt'),
                os.path.join(self.test_data_dir, '前海营业厅/公司简介.txt'),
                os.path.join(self.test_data_dir, '前海营业厅/新版供电营业规则.pdf'),
            ]
        )
        if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
            raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

    def _retrieve(self, kb: KnowledgeBase, vector_dynamic_kwargs: Dict[str, Any] = None):
        query_text = "前海供电局营业厅在哪"  # 主要银行业危机是什么？", 3月欧洲经济如何  大宗商品价格怎么变化？  小王子和玫瑰的关系  承载板是如何实现滑动的？ Wind 图表  # noqa
        from kbx.agent.types import AgentConfig
        additional_system_prompt = "时间信息"  # NOTE 该prompt谨慎填写，会影响query rewrite、deepsearch两个步骤重新生成的query

        # 预期结果：只检索 “2023-04-05：以史为鉴：从银行业危机到衰退和降息有多远？.pdf”
        query_with_doc_filter = QueryConfig(
            messages=[
                {"role": "system", "content": additional_system_prompt},
                {"role": "user", "content": query_text},
            ],
            agent_rag=AgentConfig(
                llm_model="doubao-1.5-pro-256k",
            ),
            top_k=5,
            score_threshold=0.0,
            vector_dynamic_kwargs=vector_dynamic_kwargs or {
                "keyword_similarity_weight": 0.0,
            }
        )
        # 预期结果：只检索 “2023-04-05：以史为鉴：从银行业危机到衰退和降息有多远？.pdf”
        query_wo_filter = QueryConfig(
            text='2023年4月5日的银行业危机',
            agent_rag=AgentConfig(
                llm_model="doubao-1.5-pro-256k",
            ),
            top_k=5,
            score_threshold=0.0,
            vector_dynamic_kwargs=vector_dynamic_kwargs or {
                "keyword_similarity_weight": 0.0,
            }
        )
        # 预期结果：检索所有文档，但实际只检索了“2023-04-05：xxx.pdf”，说明若query中包含多种维度的信息，可能筛选文档会带来副作用，大模型失去了重点
        # 另外，如果把query_text变成："美国经济 2023年4月5日"，则在“2023-04-10：xxx”文档中检索
        query_wo_additional_system_prompt = QueryConfig(
            messages=[
                {"role": "user", "content": query_text},
            ],
            agent_rag=AgentConfig(
                llm_model="doubao-1.5-pro-256k",
            ),
            top_k=5,
            score_threshold=0.0,
            vector_dynamic_kwargs=vector_dynamic_kwargs or {
                "keyword_similarity_weight": 0.0,
            }
        )
        normal_query = QueryConfig(
            text=query_text,
            top_k=5,
            score_threshold=0.0,
            vector_dynamic_kwargs=vector_dynamic_kwargs or {
                "keyword_similarity_weight": 0.0,
            }
        )
        # queries = [query_with_doc_filter, query_wo_filter, query_wo_additional_system_prompt]
        queries = [normal_query]
        # # 使用知识库直接查询
        # query_result = kb.retrieve(query=query)
        # # print("------------------results using knowledge base:  ", query_result)
        # assert isinstance(query_result, list), f"Query result should be a list, given {query_result}"
        # assert len(query_result) > 0, "Failed to get query result"
        # if query.top_k > 0:
        #     assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
        #                                              f"given {query.top_k} and {len(query_result)}"

        # # 使用KBX在顶层进行查询
        for query in queries:
            print(f"\n\n\n\nquery: {query.messages}\n\n")
            query_result = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
            assert isinstance(query_result, list), f"Query result should be a list, given {query_result}"
            assert len(query_result) > 0, "Failed to get query result"
            if query.top_k > 0:
                assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                    f"given {query.top_k} and {len(query_result)}"

            print(f'Get {len(query_result)} results from kb ("{kb.kb_config.name}")')
            for k, qr in enumerate(query_result):
                print(f'------------------------- #{k}, score={qr.score}, doc_id={qr.doc_id} -------------------------')
                print(qr.text_chunk.text)

    def _modify_config(self):
        # self._create_std_kb()

        origin_kb_config = self._kb.kb_config
        new_kb_config = origin_kb_config.model_copy(deep=True)

        new_embedding_model = "doubao-embedding-large"
        new_kb_config.vector_keyword_config.text_embedding_model = new_embedding_model
        new_kb_config.vector_keyword_config.splitter_config.chunk_size = 2000

        config_diff1 = get_pydantic_config_changes(origin_kb_config, new_kb_config, True)
        print("config_diff1: ", config_diff1)
        error = self._kb.modify_kb_config(new_kb_config)
        assert error.code == KBXError.Code.SUCCESS
        assert self._kb.kb_config.vector_keyword_config.text_embedding_model == new_embedding_model
        # self._retrieve(self._kb)

        new_kb_config2 = new_kb_config.model_copy(deep=True)
        new_kb_config2.vector_keyword_config.max_keywords_per_chunk = 2
        config_diff2 = get_pydantic_config_changes(new_kb_config, new_kb_config2, True)
        print("config_diff2: ", config_diff2)
        error = self._kb.modify_kb_config(new_kb_config2)
        assert error.code == KBXError.Code.SUCCESS
        # self._retrieve(self._kb)

    def _reindex(self):
        # reindex
        doc_id_errors = self._kb.reindex(self._kb.list_doc_ids()[0], reparse=True)
        assert len(doc_id_errors) == 0, f'Expect len(doc_id_errors) == 0, given {len(doc_id_errors)}: {doc_id_errors!r}'

        # reindex_all
        doc_id_errors2 = self._kb.reindex_all(reparse=True)
        assert doc_id_errors2 == doc_id_errors, \
            f'Expect same doc_id_errors, given\n{doc_id_errors!r}\nand\n{doc_id_errors2!r}'
        # self._retrieve(self._kb)

    @pytest.mark.order(1)
    def test_keyword_index_case(self):
        # 只开启keyword index
        kwd_kb_config = KBCreationConfig(
            name="keyword_kb",
            description=self._kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "DefaultPdfParser",
                }
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                splitter_config=SplitterConfig(name="RecursiveTextSplitter", chunk_size=1024),
                keyword_extractor="jieba",
                max_keywords_per_chunk=100,
            ),
        )
        self._kb = None
        self._create_std_kb(kwd_kb_config)
        self._retrieve(self._kb)
        self._reindex()
        # self._modify_config()

    @pytest.mark.order(2)
    def test_vector_index_case(self):
        # 只开启vector index
        vec_kb_config = KBCreationConfig(
            name="vector_kb",
            description=self._kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "DefaultPdfParser",
                },
                summary_model="doubao-1.5-pro-32k",
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                splitter_config=SplitterConfig(name="RecursiveTextSplitter", chunk_size=1024),
            ),
            rerank_config=RerankConfig(
                name="ModelRerank",
                kwargs={"model": "BAAI/bge-reranker-v2-m3"},
            ),
            
        )
        self._kb = None
        self._create_std_kb(vec_kb_config)
        self._retrieve(self._kb)
        # self._reindex()
        # self._modify_config()

    @pytest.mark.order(3)
    def test_vector_keyword_index_case(self):
        # 同时开启vector index和keyword index
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "DefaultPdfParser",
                }
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                # netease-youdao/bce-embedding-base_v1",
                # BAAI/bge-m3",
                # "doubao-embedding",
                splitter_config=SplitterConfig(name="RecursiveTextSplitter", chunk_size=1024),
                keyword_extractor="jieba",
                max_keywords_per_chunk=100,
            ),
            # rerank_config=RerankConfig(
            #     name="ModelRerank",
            #     kwargs={"model": "BAAI/bge-reranker-v2-m3"},
            # ),
        )
        vector_dynamic_kwargs = {
            "keyword_similarity_weight": 0.2,
        }
        self._kb = None
        self._create_std_kb(kb_config)
        # from ipdb import set_trace; set_trace()
        self._retrieve(self._kb, vector_dynamic_kwargs)
        self._reindex()
        # self._modify_config()
        self._retrieve(self._kb, vector_dynamic_kwargs)


if __name__ == "__main__":
    # 手动执行
    test_case = TestVectorKeywordIndexE2E()
    test_case.setup_class()
    test_case.setup_method()
    # test_case.test_keyword_index_case()
    test_case.test_vector_index_case()
    # test_case.test_vector_keyword_index_case()
