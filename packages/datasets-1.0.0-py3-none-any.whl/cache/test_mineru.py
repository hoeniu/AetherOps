import os
ROOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
import sys
sys.path.insert(0, ROOT_DIR)
from typing import Any, Dict
from tests.base_test_case import BaseTestCase
from kbx.common.types import DocFileType, KBXError, ImageEmbeddingStrategy
from kbx.common.constants import DEFAULT_USER_ID
from kbx.kbx import KBX
from kbx.knowledge_base.types import KBCreationConfig, DocParseConfig, \
    SplitterConfig, QueryConfig, VectorKeywordIndexConfig
from kbx.knowledge_base.knowledge_base import KnowledgeBase
from kbx.parser.types import PdfOcrStrategyConfig, ImageStrategyConfig


class TestVectorKeywordIndexE2E(BaseTestCase):
    def setup_method(self):
        self._kb_name = "向量索引读码器知识库"
        self._kb_description = "这是一个读码器知识库，包含各种读码器规范知识信息"
        self._kb = None

    def _create_std_kb(self, kb_config: KBCreationConfig = None):
        if self._kb:
            return
        # try:
        #     # 如果已经存在，尝试进行旧数据删除
        #     previous_kb = KBX.get_existed_kb(kb_name=kb_config.name, user_id=DEFAULT_USER_ID)
        #     previous_kb.remove_kb()
        # except RuntimeError:
        #     pass
        # self._kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)
        # print(f'Try to create new kb {kb_config.name} (id={self._kb.kb_id})')

        all_kb_id_names, _ = KBX.list_kbs(user_id=DEFAULT_USER_ID)
        kb_name2id = dict([(item.name, item.kb_id) for item in all_kb_id_names])
        existed_kb_id = kb_name2id.get(kb_config.name, None)
        if existed_kb_id:
            # 已经存在，尝试从DB中读取
            print(f'Try to restore kb {kb_config.name} (id={existed_kb_id})')
            self._kb = KBX.get_existed_kb(kb_id=existed_kb_id)
        else:
            # 未存在，尝试创建
            print(f'Try to create new kb {kb_config.name} (id={existed_kb_id})')
            self._kb = KBX.create_new_kb(kb_config, user_id=DEFAULT_USER_ID)

            scanner_dir = 'scanner_files'
            # scanner_files = [os.path.join(self.test_data_dir, scanner_dir, doc) for doc in os.listdir(os.path.join(self.test_data_dir, scanner_dir))]  # noqa
            # print(f'scanner_files: {scanner_files}')
            results = self._kb.insert_docs(
                file_list=[
                    # os.path.join(self.test_data_dir, 'parser_data/线路中边桩坐标计算的通用Gauss-Legendre公式 (1).pdf'),
                    os.path.join(self.test_data_dir, 'parser_data/11125873.pdf'),
                    # os.path.join(self.test_data_dir, '2023-04-05：以史为鉴：从银行业危机到衰退和降息有多远？.pdf'),
                    # os.path.join(self.test_data_dir, '五轴产品汇报-脱敏-1.pdf'),
                ]
                # file_list=scanner_files
            )
            if any([doc_info.err_info.code != KBXError.Code.SUCCESS for doc_info in results]):
                raise RuntimeError(f"Failed to insert docs to knowledge base:\n{results}")

    def _retrieve(self, kb: KnowledgeBase, vector_dynamic_kwargs: Dict[str, Any] = None):
        query_text = "该处挡墙整体完"  # VHS8000坚固性工业手持读码器有哪些特性？  VS500智能读码器有哪些特点？VG800P智能读码器被成功应用于哪些行业？  线路边桩坐标计算的通用公式
        query = QueryConfig(
            text=query_text,
            top_k=20,
            score_threshold=0.0,
            vector_dynamic_kwargs=vector_dynamic_kwargs or {
                "keyword_similarity_weight": 0.0,
            }
        )

        # # 使用知识库直接查询
        # query_result = kb.retrieve(query=query)
        # # print("------------------results using knowledge base:  ", query_result)
        # assert isinstance(query_result, list), f"Query result should be a list, given {query_result}"
        # assert len(query_result) > 0, "Failed to get query result"
        # if query.top_k > 0:
        #     assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
        #                                              f"given {query.top_k} and {len(query_result)}"

        # # 使用KBX在顶层进行查询
        from kbx.knowledge_base.types import QueryResults
        query_result = KBX.retrieve(query=query, kb_ids=[kb.kb_id])
        assert query_result.id, f"Query result should have an id, given {query_result}"
        assert isinstance(query_result, QueryResults), \
                f"Query result should be a QueryResults object, given {type(query_result)}"
        assert isinstance(query_result.results, list), \
            f"Retrieval results should be a list, given {type(query_result.results)}"
        assert len(query_result) > 0, "Failed to get query result"
        if query.top_k > 0:
            assert query.top_k >= len(query_result), f"Query result should be no more than top_k, " \
                f"given {query.top_k} and {len(query_result)}"

        print(f'Get {len(query_result)} results from kb ("{kb.kb_config.name}")')
        retrieval_text = ''
        for k, qr in enumerate(query_result):
            print(f'------------------------- #{k}, score={qr.score} -------------------------')
            print(qr.chunk.text)
            retrieval_text += '\n' + qr.chunk.text
            # 保存检索的图片
            
            # from kbx.datastore.ds_factory import get_doc_datastore
            # import base64
            # from PIL import Image
            # from io import BytesIO
            # with get_doc_datastore(kb_id=kb.kb_id) as pdf_doc_ds:
            #     elements = pdf_doc_ds.load_doc_data(qr.text_chunk.doc_id)[0].doc_elements
            # for ele in elements:
            #     if not ele.image_b64:
            #         continue
            #     if qr.text_chunk.doc_element_ids[0] == ele.doc_element_id and ele.image_b64:
            #         img_data = BytesIO(base64.b64decode(ele.image_b64))
            #         image = Image.open(img_data)
            #         image.save(os.path.join(self.test_data_dir, f'{ele.image_caption}_rank{k + 1}_score{qr.score:3f}.png'))
        client_config, client = KBX.get_ai_model_config_and_client('doubao-pro-32k')
        response_text = client.chat(
            client_config,
            prompt=f"根据以下检索到的文档内容，回答问题:{query.text} \n{retrieval_text}",
            temperature=0.7
        )
        print(f"response_text: {response_text}")

    def test_vector_index_case(self):
        # 只开启vector index
        vec_kb_config = KBCreationConfig(
            name="_kfb",
            description=self._kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "MinerUPDFParser",
                },
                image_strategy=ImageStrategyConfig(
                    type=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,
                    vision_model='Pro/Qwen/Qwen2.5-VL-7B-Instruct'
                ),
                pdf_ocr_strategy=PdfOcrStrategyConfig(parser_type='MinerU')
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="BAAI/bge-m3",
                splitter_config=SplitterConfig(
                    name="NaiveTextSplitter",
                    chunk_size=1024,
                    overlap_size=50,
                    delimiters=["\n\n", "。", ". ", " ", ""]
                ),
            ),
        )
        self._kb = None
        self._create_std_kb(vec_kb_config)
        self._retrieve(self._kb)
        # self._modify_config()

    def test_vector_keyword_index_case(self):
        # 同时开启vector index和keyword index
        kb_config = KBCreationConfig(
            name=self._kb_name,
            description=self._kb_description,
            is_external_datastore=False,
            doc_parse_config=DocParseConfig(
                file_parsers={
                    DocFileType.PDF: "DefaultPdfParser",
                }
            ),
            vector_keyword_config=VectorKeywordIndexConfig(
                index_strategy="DefaultVectorKeywordIndex",
                text_embedding_model="doubao-embedding",
                # netease-youdao/bce-embedding-base_v1",
                # BAAI/bge-m3",
                # "doubao-embedding",
                splitter_config=SplitterConfig(name="NaiveTextSplitter", chunk_size=1024),
                keyword_extractor="jieba",
                max_keywords_per_chunk=100,
            ),
            # rerank_config=RerankConfig(
            #     rerank_type="ModelRerank",
            #     rerank_kwargs={"rerank_model": "BAAI/bge-reranker-v2-m3"},
            # ),
        )
        vector_dynamic_kwargs = {
            "keyword_similarity_weight": 0.2,
        }
        self._kb = None
        self._create_std_kb(kb_config)
        self._retrieve(self._kb, vector_dynamic_kwargs)
        self._retrieve(self._kb, vector_dynamic_kwargs)


    def test_mineru_pdf_parser(self):
        from kbx.parser.parser_factory import get_parser
        from kbx.common.types import DocData
        from kbx.common.utils import generate_new_id
        self._doc_parser_config = DocParseConfig(
            file_parsers={
                DocFileType.PDF: "MinerUPdfParser",
            },
            image_strategy=ImageStrategyConfig(
                type=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,
                vision_model='Pro/Qwen/Qwen2.5-VL-7B-Instruct'
            ),
            pdf_ocr_strategy=PdfOcrStrategyConfig(parser_type='MinerU')
        )
        parser = get_parser("MinerUPdfParser", self._doc_parser_config)
        # file_path = os.path.join(self.test_data_dir, "parser_data/线路中边桩坐标计算的通用Gauss-Legendre公式 (1).pdf")
        file_path = os.path.join(self.test_data_dir, "parser_data/11125873.pdf")
        doc_id = generate_new_id()
        doc_data = parser.parse(file_path, doc_id)
        assert isinstance(doc_data, DocData)
        # with open('data/线路中边桩_0603.txt', 'w') as f:
        with open('data/11125873_0603.txt', 'w') as f:
            for ele in doc_data.doc_elements:
                f.write(str(ele))
                f.write('\n')

if __name__ == "__main__":
    # 手动执行
    test_case = TestVectorKeywordIndexE2E()
    test_case.setup_class()
    test_case.setup_method()
    # test_case.test_vector_index_case()
    test_case.test_mineru_pdf_parser()
    # test_case.test_vector_keyword_index_case()
