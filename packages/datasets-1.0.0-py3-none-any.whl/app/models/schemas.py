from typing import List, Optional, Dict, Any
from pydantic import BaseModel
from datetime import datetime
from enum import Enum


class TenderCategory(str, Enum):
    BIDDING_METHOD = "bidding_method"
    BUSINESS_REQUIREMENTS = "business_requirements"
    TECHNICAL_REQUIREMENTS = "technical_requirements"
    QUALIFICATION_PROOFS = "qualification_proofs"
    CUSTOM = "custom"


class TenderSubCategory(str, Enum):
    # 投标方式子类别
    BIDDING_TYPE = "bidding_type"
    BIDDING_PROCESS = "bidding_process"
    BIDDING_DEADLINE = "bidding_deadline"
    BIDDING_LOCATION = "bidding_location"

    # 商务要求子类别
    PRICE_REQUIREMENTS = "price_requirements"
    PAYMENT_TERMS = "payment_terms"
    DELIVERY_TIME = "delivery_time"
    WARRANTY_PERIOD = "warranty_period"
    AFTER_SALES = "after_sales"

    # 技术要求子类别
    TECHNICAL_SPECS = "technical_specs"
    QUALITY_STANDARDS = "quality_standards"
    PERFORMANCE_REQUIREMENTS = "performance_requirements"

    # 资质证明子类别
    COMPANY_QUALIFICATION = "company_qualification"
    PROJECT_EXPERIENCE = "project_experience"
    FINANCIAL_CAPABILITY = "financial_capability"
    PERSONNEL_QUALIFICATION = "personnel_qualification"


class DocumentBase(BaseModel):
    filename: str


class DocumentCreate(DocumentBase):
    pass


class Document(DocumentBase):
    document_id: str
    upload_time: datetime
    status: str

    class Config:
        from_attributes = True


class DocumentDetail(Document):
    content: str
    metadata: Dict[str, Any]


class ExtractorBase(BaseModel):
    name: str
    description: str
    parameters_schema: Dict[str, Any]


class ExtractorCreate(ExtractorBase):
    implementation: str


class Extractor(ExtractorBase):
    extractor_id: str
    is_custom: bool

    class Config:
        from_attributes = True


class ExtractionRequest(BaseModel):
    extract_types: List[str]
    custom_extractors: Optional[List[Dict[str, Any]]] = None


class ExtractedContent(BaseModel):
    content: str
    start_line: int
    end_line: int
    status: str = "processed"
    category: TenderCategory
    sub_category: Optional[TenderSubCategory] = None
    confidence_score: Optional[float] = None
    metadata: Optional[Dict[str, Any]] = None


class ExtractionResult(BaseModel):
    extraction_id: str
    status: str
    results: Dict[str, ExtractedContent]
    categories_summary: Dict[TenderCategory, List[TenderSubCategory]]


class ContentModification(BaseModel):
    content: str
    modification_type: str
    instruction: Optional[str] = None
    selected_text: Optional[str] = None


class ErrorResponse(BaseModel):
    error_code: str
    message: str
    details: Optional[Dict[str, Any]] = None
