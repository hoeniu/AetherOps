from __future__ import annotations

import io
import os
import shutil
from filelock import FileLock
from datetime import datetime
from typing import List, Optional, Tuple, Union

from kbx.common.types import FileDSConfig, FileInfo, KBXError
from kbx.datastore.file.file_base import BaseFileDS
from kbx.datastore.base_ds import extract_list


def get_file_lock(file_path: str):
    lock_file_path = file_path + ".file_lock"
    return FileLock(lock_file_path)


class NanoFileDS(BaseFileDS):

    def __init__(self, config: FileDSConfig, kb_id: str):
        super().__init__(config, kb_id)
        os.makedirs(self._base_dir, exist_ok=True)

    @staticmethod
    def get_type() -> str:
        return "NanoFileDS"

    def _delete_ds(self) -> KBXError:
        return KBXError()

    def _upload_files(self, file_list: List[str], save_dir: str = "") -> List[Tuple[KBXError, Optional[FileInfo]]]:
        res = []
        abs_save_dir: str = self._path_factory.path_r2a(save_dir)

        os.makedirs(abs_save_dir, exist_ok=True)

        if not os.path.exists(abs_save_dir):
            raise RuntimeError("Failed to create path: {}.".format(save_dir))
        for file in file_list:
            try:
                file_name: str = os.path.basename(file)
                file_info: FileInfo = FileInfo()
                file_info.file_path = os.path.join(save_dir, file_name)
                file_info.file_raw_path = self.get_raw_path(file_info.file_path).lstrip('/')
                file_info.file_url = f"{self._file_service_prefix}/{file_info.file_raw_path}"
                file_info.file_name = file_name
                file_info.file_size = os.path.getsize(file)
                # logger.info("%s %d", file, file_info.file_size)
                abs_file_path = os.path.join(abs_save_dir, file_name)
                # logger.info("%s %s", file, abs_file_path)
                with get_file_lock(abs_file_path):
                    shutil.copy(file, abs_file_path)
                # ctime changes when meta changes.
                file_info.upload_date = datetime.fromtimestamp(os.path.getctime(abs_file_path))
                res.append((KBXError(code=KBXError.Code.SUCCESS), file_info))
            except Exception as e:
                res.append((KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e)), None))
        return res

    def _download_files(self, file_path: List[str], save_dir: str) -> List[KBXError]:
        res = []
        prefix = self._path_factory.path_r2a("")

        # 保证本地文件夹存在.
        os.makedirs(save_dir, exist_ok=True)

        for file in file_path:
            try:
                file_path = os.path.join(prefix, file)
                with get_file_lock(file_path):
                    shutil.copy(file_path, save_dir)
                res.append(KBXError(code=KBXError.Code.SUCCESS, msg=""))
            except Exception as e:
                res.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e)))
        return res

    def _delete_file(self, file_prefix: str) -> KBXError:
        abs_path: str = self._path_factory.path_r2a(file_prefix)
        try:
            if abs_path.endswith("/"):
                shutil.rmtree(abs_path)  # 递归删除文件夹.
            else:
                with get_file_lock(abs_path):
                    os.remove(abs_path)  # 删除文件.
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @staticmethod
    def recursive_find_files(abs_path):
        all_files = []
        for root, dirs, files in os.walk(abs_path):
            for file in files:
                file_path = os.path.join(root, file)
                all_files.append(file_path)
        return all_files

    def _list_files(self, file_prefix: str, offset: int = 0, limit: int = -1) -> List[FileInfo]:
        abs_path: str = self._path_factory.path_r2a(file_prefix)
        dir_name = os.path.dirname(abs_path)
        file_prefix = os.path.basename(abs_path)
        files_and_dirs = os.listdir(dir_name)
        folders = []
        files = []
        # 查找所有前缀满足要求的文件
        for item in files_and_dirs:
            item_path = os.path.join(dir_name, item)
            if item.startswith(file_prefix):
                if os.path.isfile(item_path):
                    files.append(item_path)
                else:
                    folders.append(item_path)
        # 递归查找所有前缀满足要求的folder中的文件.
        for folder in folders:
            if folder.startswith(file_prefix):
                files.extend(NanoFileDS.recursive_find_files(folder))
        result_file_list: List[FileInfo] = list()
        for file in files:
            raw_path = self.get_raw_path(file)
            file_url = f"{self._file_service_prefix}/{raw_path}"
            result_file_list.append(
                FileInfo(
                    file_path=self._path_factory.path_a2r(file),
                    file_raw_path=raw_path,
                    file_url=file_url,
                    file_name=os.path.basename(file),
                    file_size=os.path.getsize(file),
                    upload_date=datetime.fromtimestamp(os.path.getctime(file)),
                )
            )
        return extract_list(result_file_list, offset, limit)

    def _isfile(self, path: str) -> bool:
        abs_path = self._path_factory.path_r2a(path)
        with get_file_lock(abs_path):
            return os.path.isfile(abs_path)

    def _open(self, path: str, mode: str, encoding: Optional[str] = None, **kwargs) \
            -> Union[io.TextIOWrapper, io.BufferedReader, io.BufferedWriter]:
        abs_path = self._path_factory.path_r2a(path)
        with get_file_lock(abs_path):
            # Only support "r", "rb", "w", "wb", totally 4 modes.
            if mode in ["r", "rb", "w", "wb"]:
                if mode.startswith("w"):
                    abs_path_dir = os.path.dirname(abs_path)
                    os.makedirs(abs_path_dir, exist_ok=True)
                return open(abs_path, mode, encoding=encoding)
            raise TypeError(f"Unsupported mode {mode}.")

    def _get_raw_path(self, relative_path: str) -> str:
        return self._path_factory.path_r2r(relative_path)
