from __future__ import annotations

import io
from abc import abstractmethod

from typing import Optional, Union, Tuple, List, Literal, Any, overload
from kbx.common.types import FileDSConfig, FileInfo, KBXError
from kbx.datastore.base_ds import BaseDS, check_connected
from kbx.datastore.path_factory import PathFactory


class BaseFileDS(BaseDS):

    def __init__(self, config: FileDSConfig, kb_id: str):
        """
        使用时需要调用者初始化FileDS的实例，并管理其生命周期.
        文件存储的存储体基类，用于原始知识文档的存储备份，可使用文件存储、对象存储等方式实现

        FileDS不区分index_type和namespace, 方便调用者灵活配置路径.
        """
        super().__init__(kb_id, "", "")
        self._config: FileDSConfig = config
        self._path_factory = PathFactory(config, self.tenant_id, self.user_id, kb_id)
        self._base_dir = self._path_factory.path_r2a()

        from kbx.kbx import KBX
        self._file_service_prefix = KBX.config.file_service_prefix.rstrip('/')

    def _connect(self) -> None:
        pass

    def _close(self) -> None:
        pass

    def __enter__(self) -> BaseFileDS:
        return super().__enter__()

    def __exit__(self, exc_type: Optional[BaseException], exc_val: Any, exc_tb: Any) -> bool:
        return super().__exit__(exc_type=exc_type, exc_val=exc_val, exc_tb=exc_tb)

    @check_connected
    def upload_files(self, file_list: List[str], save_dir: str = "") -> List[Tuple[KBXError, Optional[FileInfo]]]:
        """
        给定一个或多个本地文件的路径，向当前的 FileDataStore 上传文件。
        调用后不会因为个别文件的上传失败而抛出异常，各个文件上传成功与否均通过返回值体现
        TODO(@dingdong): 提供同步和异步操作.

        Args:
            file_list (List[str]): 需要上传的本地文件路径列表
            save_dir (str): 将上述文件保存到哪个子文件夹里，可在上层制定路径规范以区分不同通途的文件，默认为""表示该知识库的根目录

        Returns:
            results (List[Tuple[KBXError, Optional[FileInfo]]]): 文件上传结果列表，长度与输入的file_list一致，包含错误信息与所上传的文件信息
                如果第k个文件上传成功，则results[k]类似于(KBXError(code=Code.SUCCESS, msg=""), FileInfo(file_path="/xxx/xx.pdf"))
                如果第k个文件上传失败，则results[k]类似于(KBXError(code=Code.RUNTIME_ERROR, msg="File does not exists"), None)
        """

        # TODO(@dingdong): 如果一个输入文件/local/path/to/abc.pdf，save_dir设置为"/raw_doc_files"，则实际保存路径为
        #   work_dir/filesystem/tenant_id/user_id/kb_id/raw_doc_files/abc.pdf
        return self._upload_files(file_list, save_dir)

    @abstractmethod
    def _upload_files(self, file_list: List[str], save_dir: str = "") -> List[Tuple[KBXError, Optional[FileInfo]]]:
        raise NotImplementedError

    @check_connected
    def download_files(self, file_path: List[str], save_dir: str) -> List[KBXError]:
        """
        从当前的 FileDataStore 下载一个或多个文件
        调用后不会因为个别文件的处理失败而抛出异常，各个文件是否处理成功通过返回值体现

        Args:
            file_path (List[str]): 需要下载的远程文件路径
            save_dir (str): 文件下载后保存到的本地文件夹路径

        Returns:
            results (List[KBXError]): 文件下载的错误信息列表，与输入的file_list一致
        """
        return self._download_files(file_path, save_dir)

    @abstractmethod
    def _download_files(self, file_path: List[str], save_dir: str) -> List[KBXError]:
        raise NotImplementedError

    @check_connected
    def delete_file(self, file_path: str) -> KBXError:
        """
        删除文件。如果file_path是一个文件路径，则精确删除该文件；如果file_path是一个文件夹，则批量删除该文件夹及其内部的所有文件

        Args:
            file_path (str): 文件或文件夹路径

        Returns:
            results (KBXError): 文件删除的错误信息
        """
        return self._delete_file(file_path)

    @abstractmethod
    def _delete_file(self, file_path: str) -> KBXError:
        raise NotImplementedError

    @check_connected
    def list_files(self, file_prefix: str, offset: int = 0, limit: int = -1) -> List[FileInfo]:
        """
        按指定前缀查找或列出对应的所有文件
        例如设置file_prefix="/abc"，则会将以下路径类型的文件列出
        - /abc
        - /abcd.txt
        - /abc/xxx.pdf
        - /abc/def/xxx.docx

        Args:
            file_prefix: 文件前缀
            offset (int): 分页参数
            limit (int): 分页参数

        Returns:

        """
        return self._list_files(file_prefix=file_prefix, offset=offset, limit=limit)

    @abstractmethod
    def _list_files(self, file_prefix: str, offset: int = 0, limit: int = 1000) -> List[FileInfo]:
        raise NotImplementedError

    @check_connected
    def open(self, path: str, mode: str, encoding: Optional[str] = None,
             **kwargs) -> Union[io.TextIOWrapper, io.BufferedReader]:
        """
        以mode('r', 'rb')所示的方式打开文件, 返回一个二进制流或者一个文本流
        在实现类中以重载的方式实现二进制流或文本流的具体方法.
        Args:
            path (str):
            mode (FileMode):
            encoding (Optional[str]):

        Returns:
            Union[io.TextIOWrapper, io.BufferedReader]

        """
        return self._open(path, mode, encoding, **kwargs)

    @abstractmethod
    def _isfile(self, path: str) -> bool:
        raise NotImplementedError

    @check_connected
    def isfile(self, path: str) -> bool:
        """
        检查某个路径是否是一个存在的文件（类似os.path.isfile）

        Args:
            path (str): 文件路径

        Returns:
            bool: 是否是一个存在的文件
        """
        return self._isfile(path)

    @abstractmethod
    def _open(self, path: str, mode: str, encoding: Optional[str] = None,
              **kwargs) -> Union[io.TextIOWrapper, io.BufferedReader, io.BufferedWriter]:
        raise NotImplementedError

    @overload
    def _open(self, path: str, mode: Literal['r'], encoding: Optional[str] = None, **kwargs) -> io.TextIOWrapper:
        pass

    @overload
    def _open(self, path: str, mode: Literal['rb'], encoding: Optional[str] = None, **kwargs) -> io.BufferedReader:
        pass

    @overload
    def _open(self, path: str, mode: Literal['w'], encoding: Optional[str] = None, **kwargs) -> io.TextIOWrapper:
        pass

    @overload
    def _open(self, path: str, mode: Literal['wb'], encoding: Optional[str] = None, **kwargs) -> io.BufferedWriter:
        pass

    @check_connected
    def get_raw_path(self, relative_path: str) -> str:
        """
        将kbx内部的相对路径，转换为形如{tenant_id}/{user_id}/{kb_id}/{relative_path}的路径
        接口不会对路径合法性（如是文件否存在）做出校验

        Args:
            relative_path (str): kbx内部存储文件的相对路径

        Returns:
            str: 转换后的路径
        """
        return self._get_raw_path(relative_path)

    @abstractmethod
    def _get_raw_path(self, relative_path: str) -> str:
        raise NotImplementedError

    @check_connected
    def get_file_url(self, file_path: str) -> str:
        """
        获取文件的url
        """
        return f"{self._file_service_prefix}/{self.get_raw_path(file_path)}"
