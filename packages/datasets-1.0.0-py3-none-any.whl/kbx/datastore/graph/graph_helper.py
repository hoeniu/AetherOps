import re
from typing import Dict, List, Tuple, Union


def convert_schema2nebula_tag(schema: Dict) -> Tuple[str, str, str, str]:
    props = []
    for prop in schema["属性"]:
        name = prop["类型"]
        data_type = prop["数据类型"]
        if data_type.lower() == "string":
            default_value = "''"
        elif data_type.lower() == "int":
            default_value = 0
        else:
            default_value = "''"
        comment = "" if "说明" not in prop.keys() else prop["说明"]
        props.append((name, data_type, default_value, comment))

    props_str = ", ".join([f"`{name}` {data_type.lower()} NOT NULL DEFAULT {default_value} COMMENT \'{comment}\'"
                           for name, data_type, default_value, comment in props])
    tag_name = "t_tag"
    create_tag_sql = f"CREATE TAG IF NOT EXISTS {tag_name} ({props_str});"
    edge_name = "t_edge"
    create_edge_sql = f"CREATE EDGE IF NOT EXISTS {edge_name} ({props_str});"
    return tag_name, create_tag_sql, edge_name, create_edge_sql


def graph_if_same_edge(edge1: Dict, edge2: Dict) -> bool:
    """
    判断edge1和edge2是否为同一个边
    Args:
        edge1 (Dict): 边字典, Key为属性名称, Value为属性值
        edge2 (Dict): 边字典, Key为属性名称, Value为属性值

    Returns:
        bool: 完全一致返回True, 否则返回False
    """
    if len(edge1.items()) != len(edge2.items()):
        return False
    return graph_if_align(edge1, edge2)


def graph_if_align(dict1: Dict, dict2: Dict) -> bool:
    """
    判断边是否可以对齐为一个边
    Args:
        dict1 (Dict): 字典, Key为属性名称, Value为属性值
        dict2 (Dict): 字典, Key为属性名称, Value为属性值

    Returns:
        bool: edge1的属性全包含于edge2中, 返回True, 否则返回False
    """
    for attr, val in dict1.items():
        if attr not in dict2.keys() or val != dict2[attr]:
            return False
    return True


def graph_contain_edge(edge: Dict, edge_list: List[Dict]) -> bool:
    """
    判断边是否在边列表中
    Args:
        edge (Dict): 边字典, Key为属性名称, Value为属性值
        edge_list (List[Dict]): 边字典列表, 字典Key为属性名称, Value为属性值

    Returns:
        bool: 如果边存在于列表中, 返回True, 否则返回False
    """
    if not edge_list:
        return False
    for edge_item in edge_list.items():
        if graph_if_same_edge(edge_item, edge):
            return True
    return False


def graph_get_prop(node: Dict, union: Union[str, List]) -> str:
    if isinstance(union, str):
        return node[union]
    for attr in union:
        if attr in node:
            return node[attr]
    return None


# use old item value only override
def graph_override(item: Dict, old_item: Dict, override: bool = True) -> Dict:
    for attr, val in old_item.items():
        if not override or attr not in item or not item[attr]:
            item[attr] = val
    return item


def sanitize_string(input_str: str) -> str:
    """
    处理字符串：转义单引号，删除换行符及非常规符号

    :param input_str: 原始输入字符串
    :param allowed_chars: 允许保留的正则表达式字符集（默认包含字母、数字、空格、常见标点）
    :return: 处理后的安全字符串
    """
    # 1. 删除换行符和回车符
    no_newlines = input_str.replace('\n', ' ').replace('\r', ' ')

    # 2. 过滤非允许字符（保留字母、数字、空格、常见标点）
    filtered = re.sub(
        r'[^\u4e00-\u9fa5\u3400-\u4dbf'
        r'a-zA-Z0-9\s'
        r',，\.。!！?？|、;:"\'“”‘’《》]',
        '', no_newlines)

    # 3. 转义单引号（' -> \'）
    escaped = filtered.replace("'", "\\'")
    return escaped
