import logging
from typing import Any, Dict, Iterable, List, Tuple, Union

from kbx.datastore.graph.graph_base import BaseGraphDS
from kbx.common.types import GraphDSConfig, KBXError
from kbx.common.logging import logger
from kbx.datastore.graph.graph_helper import graph_if_align, graph_get_prop
from kbx.datastore.graph.graph_helper import graph_override
from kbx.datastore.graph.invert_index import InvertedIndex
from neo4j import GraphDatabase


class Neo4jGraphDS(BaseGraphDS):

    def __init__(self, config: GraphDSConfig, kb_id: str, index_type: str, namespace: str):
        """
        Neo4j 实现的图数据库.
        """
        super().__init__(config, kb_id, index_type, namespace)
        self._host: str = config.connection_kwargs["host"]
        self._port: str = config.connection_kwargs["port"]
        self._username: str = config.connection_kwargs["username"]
        self._password: str = config.connection_kwargs["password"]
        self._label_name = index_type + namespace + kb_id.replace("-", "")
        # self._label_name = "test"
        self._uri = f"neo4j://{self._host}:{self._port}"
        self._driver = None
        # 倒排索引
        self._inverted_index = None

    def _connect(self) -> None:
        self._driver = GraphDatabase.driver(self._uri, auth=(self._username, self._password))
        self._increment_id = 0
        self.__check_label(self._label_name)
        # 查看是否有标签
        all_nodes = self.__get_all_nodes()
        # initialize inverted index.
        self._inverted_index = InvertedIndex()
        self._inverted_index.build(all_nodes)

    def _close(self) -> None:
        self._inverted_index = None
        self._driver = None

    def __execute_query(self, query: str, parameters: Dict = dict()):
        try:
            with self._driver.session() as session:
                result = session.run(query, parameters)
                return list(result)
        except Exception as e:
            logger.info(f"{str(e)}")
            return None

    def __check_label(self, label_name: str):
        """
        查询指定的标签是否存在，如果不存在则创建一个带有该标签的节点。
        """
        # 查询标签是否存在
        res = self.__execute_query(
            """
            CALL db.labels()
            YIELD label
            WHERE label = $label_name
            RETURN COUNT(*) > 0 AS exists
            """,
            {"label_name": label_name}
        )
        return res[0]["exists"]

    def __get_all_nodes(self) -> List[Tuple[int, Dict[str, Any]]]:
        # 不一定有这个label
        if not self.__check_label(self._label_name):
            return []
        query = f"MATCH (n:{self._label_name}) RETURN id(n) as vid, n;"
        return [(record["vid"], record["n"]._properties) for record in self.__execute_query(query)]

    @property
    def node_ids(self) -> Iterable:
        """
        返回当前namespace下的所有node_id.
        """
        return [item[0] for item in self.__get_all_nodes()]

    @property
    def nodes(self) -> Iterable:
        return dict(self.__get_all_nodes())

    @property
    def node_ids(self) -> Iterable:
        """
        返回当前namespace下的所有node_id.
        """
        return [item[0] for item in self.__get_all_nodes()]

    def _insert_nodes(self, nodes: List[Dict]) -> List[int]:
        node_id_list: List[int] = []
        for node in nodes:
            query = f"CREATE (n:{self._label_name} $properties) RETURN id(n) as vid;"
            parameters: Dict[str, Any] = {"label_name": self._label_name, "properties": node}
            res_list = self.__execute_query(query, parameters)
            if res_list is not None:
                node_id = res_list[0]["vid"]
                node_id_list.append(node_id)
                self._inverted_index.update(node, node_id)
            else:
                raise RuntimeError(f"Failed to insert node {node}")
        return node_id_list

    def _update_nodes(self, nodes_dict: Dict[int, Dict], override: bool = True) -> List[KBXError]:
        result_list: List[KBXError] = list()
        for node_id, node in nodes_dict.items():
            try:
                self._inverted_index.delete(node_id)
                ori_node = self._search_node_by_id(node_id)
                node = graph_override(node, ori_node, override)
                query: str = f"MATCH (n:{self._label_name} WHERE id(n) = $node_id)" \
                             f" SET n += $properties RETURN id(n) as vid;"
                parameters = {"node_id": node_id, "properties": node}
                self.__execute_query(query, parameters)
                self._inverted_index.update(node, node_id)
                result_list.append(KBXError())
            except Exception as e:
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e)))
        return result_list

    def _delete_nodes(self, node_ids: List[int]) -> List[KBXError]:
        result_list: List[KBXError] = list()
        for node_id in node_ids:
            try:
                self._inverted_index.delete(node_id)
                query = f"MATCH (n:{self._label_name}) WHERE id(n) = {node_id} DETACH DELETE n;"
                parameters: Dict[str, Any] = dict()
                self.__execute_query(query, parameters)
                result_list.append(KBXError())
            except Exception as e:
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e)))
        return result_list

    def _insert_edges(self, src_dst: List[Tuple], edges: List[Dict]) -> List[int]:
        rank_list = []
        for sd, edge in zip(src_dst, edges):
            src, dst = sd[0], sd[1]
            edge_dict: Dict[int, Dict] = self._search_edge_by_id(src, dst)
            # nebula中rank需要由业务逻辑维护
            if len(edge_dict.keys()) == 0:
                rank = 0
            else:
                rank = max(edge_dict.keys()) + 1
            edge["rank"] = rank
            query: str = f"MATCH (a:{self._label_name}), (b:{self._label_name}) WHERE id(a) = {src} AND id(b) = {dst}" \
                         f" CREATE (a)-[r:{self._label_name} $properties]->(b);"
            self.__execute_query(query, {"properties": edge})
            rank_list.append(rank)
        return rank_list

    def _update_edges(self, src_dst_rank: List[Tuple], edges: List[Dict], override: bool = True) -> None:
        result_list: List[KBXError] = list()
        for sdr, edge in zip(src_dst_rank, edges):
            src, dst, rank = sdr[0], sdr[1], sdr[2]
            ori_edge_dict = self._search_edge_by_id(src, dst)
            error_msg = f"Cannot find edge: {src}->{dst}@{rank}."
            if not ori_edge_dict:
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=error_msg))
                continue
            flag = False
            for ori_rank, ori_edge in ori_edge_dict.items():
                if ori_rank == rank:
                    edge = graph_override(edge, ori_edge, override)
                    set_clause = ", ".join(
                        [f"r.{key} = {value}" if isinstance(value, (int, float)) else f"r.{key} = '{value}'"
                         for key, value in edge.items()])
                    query: str = f"MATCH (v1:{self._label_name})-[r:{self._label_name}" \
                                 f" {{rank: {rank}}}]->(v2:{self._label_name})" \
                                 f" WHERE id(v1) = {src} AND id(v2) = {dst}" \
                                 f" SET {set_clause}" \
                                 f" RETURN r;"
                    try:
                        self.__execute_query(query, dict())
                        flag = True
                    except Exception as e:
                        error_msg = f"UPDATE EDGE FAILED: {src}->{dst}@{rank}. {str(e)}"
                        logger.error(error_msg)
                    finally:
                        break
            if flag:
                result_list.append(KBXError())
            else:
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=error_msg))
        return result_list

    def _delete_edges(self, src_dst_rank_list: List[Tuple]) -> List[KBXError]:
        result_list: List[KBXError] = list()
        for src, dst, rank in src_dst_rank_list:
            query: str = f"MATCH (v1:{self._label_name})-[r:{self._label_name} {{rank: {rank}}}]" \
                         f"->(v2:{self._label_name})" \
                         f"WHERE id(v1) = {src} AND id(v2) = {dst} DELETE r;"
            try:
                self.__execute_query(query, dict())
                result_list.append(KBXError())
            except Exception as e:
                error_msg = f"DELETE EDGE FAILED: {src}->{dst}@{rank}. {str(e)}"
                logger.error(error_msg)
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=error_msg))
        return result_list

    def _search_node_by_id(self, node_id: int) -> Dict:
        query = f"MATCH (n:{self._label_name}) WHERE id(n) = {node_id} RETURN n;"
        parameters: Dict[str, Any] = dict()
        res_list = self.__execute_query(query, parameters)
        if res_list:
            return res_list[0]["n"]._properties
        else:
            return None

    def _search_node_by_ids(self, node_ids: List[int]) -> List[Dict]:
        query = f"MATCH (n:{self._label_name}) WHERE id(n) IN $node_ids RETURN n;"
        parameters: Dict[str, Any] = dict("node_ids", node_ids)
        res_list = self.__execute_query(query, parameters)
        return [item["n"]._properties for item in res_list]

    def _search_node_by_property(self, properties: Dict) -> List[Dict]:
        cross_ids = None
        for attr, val in properties.items():
            index = self._inverted_index.get()
            if attr not in index or val not in index[attr]:
                return []
            node_ids = self._inverted_index.get()[attr][val]
            if not node_ids:
                return []
            if cross_ids is None:
                cross_ids = node_ids
            else:
                cross_ids = cross_ids.intersection(node_ids)
            if not cross_ids:
                return []
        return list(cross_ids)

    def _search_node_complex(self, properties: Dict, edges: List[Tuple[Dict, Dict, Dict]]) -> List[int]:
        node_ids = self._search_node_by_property(properties)
        results = []
        for ind in node_ids:
            candidate_edges = []
            for pred, multi_edges in self._find_predecessor(ind).items():
                for rank, edge in multi_edges.items():
                    candidate_edges.append([self.nodes[pred], edge, self.nodes[ind]])
            for succ, multi_edges in self._find_successor(ind).items():
                for rank, edge in multi_edges.items():
                    candidate_edges.append([self.nodes[ind], edge, self.nodes[succ]])
            edge_all_in_candidate = True
            for edge in edges:
                find_edges = list(filter(lambda ce: graph_if_align(edge[0], ce[0]) \
                                         and graph_if_align(edge[1], ce[1]) \
                                         and graph_if_align(edge[2], ce[2]), candidate_edges))
                if not find_edges:
                    edge_all_in_candidate = False
                    break
            if edge_all_in_candidate:
                results.append(ind)
        return results

    def _merge_node(self, src: int, dst: int) -> None:
        """TODO:暂时先不实现"""
        return

    def _search_edge_by_id(self, src: int, dst: int) -> Dict[int, Dict]:
        edge_dict: Dict[int, Dict] = dict()
        # 一组src-dst中间可能有具有不同rank的多条边: -> (rank, edge_attrs)
        query: str = f"MATCH (v1)-[r]->(v2) WHERE id(v1) = {src} AND id(v2) = {dst} RETURN r;"
        res_list = self.__execute_query(query, dict())
        if res_list:
            for record in res_list:
                edge = record["r"]._properties
                rank = edge["rank"]
                del edge["rank"]
                edge_dict[rank] = edge
        return edge_dict

    def _upsert_node(self,
                     node: Dict,
                     properties_for_search: Dict,
                     align_method: str = 'same_properties',
                     edges_for_alignment: Dict = None,
                     override: bool = True
                     ) -> int:
        node_ids = None
        if align_method == 'same_properties':
            node_ids = self._search_node_by_property(properties_for_search)
        elif align_method == 'same_edges':
            node_ids = self._search_node_complex(properties_for_search, edges_for_alignment)
        if not node_ids:
            node_id = self._insert_node(node)
            return node_id
        if len(node_ids) > 1:
            logging.log(logging.WARN, "More than 1 nodes found while updating.")
            logging.log(logging.WARN, str(node_ids))
        self._update_node(node_ids[0], node, override)
        return node_ids[0]

    def _upsert_edge(self, src: int, dst: int, edge: Dict,
                     edge_properties_for_alignment: Dict,
                     override: bool = True) -> int:
        # rank -> edge_attrs
        edge_dict = self._search_edge_by_id(src, dst)
        if not edge_dict:  # edge_dict is None or Empty.
            return self.insert_edge(src, dst, edge)
        else:
            for rank, old_edge in edge_dict.items():
                if graph_if_align(edge_properties_for_alignment, old_edge):
                    edge = graph_override(edge, old_edge, override)
                    self._update_edge(src, dst, rank, edge)
                    return rank
        return self._insert_edge(src, dst, edge)

    def _collect_triples(self, candidate_nodes: List[int], name_properties: Union[str, List] = '名称') -> List[List[str]]:
        triples = []
        for ent in candidate_nodes:
            attrs = self._find(ent)
            ent_name = graph_get_prop(attrs, name_properties)
            for attr, val in attrs.items():
                triples.append([ent_name, attr, val])
            for nbr, d in self._find_predecessor(ent).items():
                for idx, ee in d.items():
                    dd = list(filter(lambda x: x[0] != '类型' and x[0] != 'id', ee.items()))
                    dd = list(map(lambda x: ':'.join(x), dd))
                    edge_attr_str = ''
                    if dd:
                        edge_attr_str = '(' + ",".join(dd) + ')'
                    triples.append([graph_get_prop(self._find(nbr), name_properties),
                                    ee['类型'] + edge_attr_str, ent_name])
            for nbr, d in self._find_successor(ent).items():
                for idx, ee in d.items():
                    dd = list(filter(lambda x: x[0] != '类型' and x[0] != 'id', ee.items()))
                    dd = list(map(lambda x: ':'.join(x), dd))
                    edge_attr_str = ''
                    if dd:
                        edge_attr_str = '(' + ",".join(dd) + ')'
                    triples.append([ent_name, ee['类型'] + edge_attr_str,
                                    graph_get_prop(self._find(nbr), name_properties)])
        return triples

    def subgraph(self, center_nodes: list,
                 name_properties: list = ["名称", "简称", "英文名称", "英文简称"],
                 max_depth=1,
                 max_children=None,
                 with_property=True,
                 node_filter=None,
                 edge_filter=None) -> dict:
        # TODO:
        return {"nodes": [], "links": []}

    def _delete_ds(self) -> KBXError:
        return KBXError(code=KBXError.Code.SUCCESS)

    @staticmethod
    def get_type() -> str:
        return "Neo4jGraphDS"

    # 返回其{前驱点id->前驱边集合(可能存在多重边)}
    def _find_predecessor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        n_gql: str = f"MATCH (m)-[e]->(n) WHERE id(n) = {node_id} RETURN e, id(m) as vid;"
        res = self.__execute_query(n_gql)
        return self._find_helper(res)

    # 返回其{后继点id->后继边集合(可能存在多重边)}
    def _find_successor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        n_gql: str = f"MATCH (n)-[e]->(m) WHERE id(n) = {node_id} RETURN e, id(m) as vid;"
        res = self.__execute_query(n_gql)
        return self._find_helper(res)

    def _find_helper(self, res) -> Dict[int, Dict[int, Dict[str, Any]]]:
        res_dict = dict()
        for item in res:
            vid = item["vid"]
            edge = item["e"]._properties
            if vid not in res_dict.keys():
                res_dict[vid] = dict()
            rank = edge["rank"]
            del edge["rank"]
            res_dict[vid][rank] = edge
        return res_dict

    def _find(self, node_id) -> Dict:
        n_gql: str = f"MATCH (n) WHERE id(n) = {node_id} RETURN n;"
        res_list = self.__execute_query(n_gql)
        res_list_len = len(res_list)
        if res_list_len != 1:
            logger.error(f"Find unexpected num node: {node_id}, res num: {res_list_len}.")
        else:
            return res_list[0]["n"]._properties
