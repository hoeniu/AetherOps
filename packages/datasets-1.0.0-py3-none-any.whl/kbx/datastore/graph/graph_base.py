from __future__ import annotations

from abc import abstractmethod
from typing import Any, Dict, List, Union, Iterable, Optional, Tuple

from kbx.common.types import KBXError
from kbx.common.types import GraphDSConfig
from kbx.datastore.base_ds import BaseDS, check_connected
from kbx.datastore.path_factory import PathFactory


class BaseGraphDS(BaseDS):

    def __init__(self, config: GraphDSConfig, kb_id: str, index_type: str, namespace: str):
        """
        使用时需要调用者初始化GraphDS的实例，并管理其生命周期.
        需要区分图数据库是否有schema, 配置应该拿KB的配置, 判断datastore是内部还是外部.
        """
        super().__init__(kb_id, index_type, namespace)
        self._config = config
        self._namespace = kb_id  # 图谱的命名空间
        self._path_factory = PathFactory(config, self.tenant_id, self.user_id, kb_id, index_type, namespace)
        self._base_dir = self._path_factory.path_r2a()

    def _connect(self) -> None:
        pass

    def _close(self) -> None:
        pass

    # if only pass, already been implemented in BaseDS.
    # def _flush(self) -> None:
    #     pass

    def __enter__(self) -> BaseGraphDS:
        return super().__enter__()

    def __exit__(self, exc_type: Optional[BaseException], exc_val: Any, exc_tb: Any) -> bool:
        return super().__exit__(exc_type=exc_type, exc_val=exc_val, exc_tb=exc_tb)

    @property
    @abstractmethod
    def node_ids(self) -> Iterable[int]:
        """
        返回实体ID列表或者ID迭代器
        Returns:
            Iterable: 返回实体ID列表或者ID迭代器
        """
        raise NotImplementedError

    def pred(self, node_id: int, edge_filter: Dict[str, str] = None) -> Dict[int, Dict[int, Dict[str, str]]]:
        """
        获取指定节点的所有前驱节点及其边信息

        参数:
            node_id (int): 目标节点ID
            edge_filter (Dict[str, str], optional): 边过滤条件，格式为:
                {
                    边属性键: 边属性值,
                   ...
                }
        返回:
            Dict[int, Dict[int, Dict[str, str]]]: 前驱节点字典，格式为:
                {
                    前驱节点ID: {
                        边排序值: {
                            边属性键: 边属性值,
                            ...
                        },
                        ...
                    },
                    ...
                }
        """
        return self.filter_neighbors(self.find_predecessor(node_id), edge_filter)

    def succ(self, node_id: int, edge_filter: Dict[str, str] = None) -> Dict[int, Dict[int, Dict[str, str]]]:
        """
        获取指定节点的所有后继节点及其边信息

        参数:
            node_id (int): 目标节点ID
            edge_filter (Dict[str, str], optional): 边过滤条件，格式为:
                {
                    边属性键: 边属性值,
                   ...
                }
        返回:
            Dict[int, Dict[int, Dict[str, str]]]: 后继节点字典，格式为:
                {
                    后继节点ID: {
                        边排序值: {
                            边属性键: 边属性值,
                            ...
                        },
                        ...
                    },
                    ...
                }
        """
        return self.filter_neighbors(self.find_successor(node_id), edge_filter)

    @check_connected
    def insert_nodes(self, nodes: List[Dict[str, Any]]) -> List[int]:
        """
        批量插入节点操作:
        1. 本方法为每个待插入的节点分配int类型的vid(调用者不需要传入vid)，并通过返回值返回.
        2. 如果某个节点未插入成功（无论是否为致命性错误），抛出异常；已插入的数据不回滚.
        Args:
            nodes (List[Dict[str, Any]]): 节点列表

        Returns:
            List[int]: 成功插入节点的id列表
        """
        return self._insert_nodes(nodes)

    @abstractmethod
    def _insert_nodes(self, nodes: List[Dict[str, Any]]) -> List[int]:
        raise NotImplementedError

    @check_connected
    def insert_node(self, node: Dict[str, Any]) -> int:
        """
        插入节点操作:
        Args:
            node (Dict): 实体字典, Key为属性名称, Value为属性值

        Returns:
            int: 成功插入节点的id
        """
        return self._insert_node(node)

    def _insert_node(self, node: Dict[str, Any]) -> int:
        return self._insert_nodes([node])[0]

    @check_connected
    def update_nodes(self, nodes: Dict[int, Dict[str, Any]], override: bool = True) -> List[KBXError]:
        """
        批量更新节点操作:
        1. 根据id更新某个节点的属性, nodes描述更新信息id->node_attr的映射
        2. 如果id不存在, 视为更新失败, 在KBXError中返回相关信息
        3. 如果过程中出现致命性错误（如异常），抛出异常，已更新的数据不回滚.
        Args:
            nodes (Dict[int, Dict[str, Any]]): 描述待更新的节点字典, Key为实体ID, Value为实体字典(Key为属性名称, Value为属性值)
            override (str): 如果待更新的节点中某个属性已存在时, True: 覆盖; False: 跳过.

        Returns:
            List[KBXError]: 返回每个节点是否更新成功
        """
        return self._update_nodes(nodes, override)

    @abstractmethod
    def _update_nodes(self, nodes: Dict[int, Dict[str, Any]], override: bool = True) -> List[KBXError]:
        raise NotImplementedError

    @check_connected
    def update_node(self, node_id: int, node_attr: Dict[str, Any], override: bool = True) -> KBXError:
        """
        更新单个节点操作:
        Args:
            node_id (int): 节点id
            node_attr (Dict[str, Any]): 描述节点属性, 用于更新操作, key为属性名称, value为属性值
            override (bool): 如果待更新节点的某个属性已存在时, 是否覆盖.

        Returns:
            KBXError: 返回节点是否更新成功
        """
        return self._update_node(node_id, node_attr, override)

    def _update_node(self, node_id: int, node: Dict[str, Any], override: bool = True) -> KBXError:
        return self._update_nodes({node_id: node}, override)[0]

    @check_connected
    def delete_nodes(self, node_ids: List[int]) -> List[KBXError]:
        """
        批量删除节点操作, 返回值返回操作是否成功
        1. 根据id删除节点, node_ids描述待删除的id列表.
        2. 如果id不存在, 视为删除成功.
        3. 如果操作过程中出现致命性错误（如异常），抛出异常，已删除的数据不回滚.
        Args:
            node_ids (List[int]): 待删除的节点id列表

        Returns:
            List[KBXError]: 对应节点是否删除成功
        """
        return self._delete_nodes(node_ids)

    @abstractmethod
    def _delete_nodes(self, node_ids: List[int]) -> List[KBXError]:
        raise NotImplementedError

    @check_connected
    def delete_node(self, node_id: int) -> KBXError:
        """
        单个删除节点操作, 返回值返回操作是否成功
        Args:
            node_id (int): 实体ID

        Returns:
            List[KBXError]: 对应节点是否删除成功
        """
        return self._delete_node(node_id)

    def _delete_node(self, node_id: int) -> None:
        return self._delete_nodes([node_id])

    @check_connected
    def insert_edges(self, sd_list: List[Tuple[int, int]], attr_list: List[Dict[str, Any]]) -> List[int]:
        """
        批量插入边操作
        1. 根据 src && dst 和 attr 插入边操作.
        2. 该方法必须通过合理的逻辑为待插入的边赋予rank值， 允许多重边. 开发者需要保证rank值的合法性和合理性
        3. 如果插入过程中出现错误，抛出异常；已插入数据不回滚.
        Args:
            sd_list (List[Tuple[int, int]]): 元组内存储边起点id和终点id
            attr_list (List[Dict[str, Any]]): 边属性列表, key为属性名称, value为属性值

        Returns:
            List[int]: 插入边的rank列表
        """
        return self._insert_edges(sd_list, attr_list)

    @abstractmethod
    def _insert_edges(self, sd_list: List[Tuple[int, int]], attr_list: List[Dict[str, Any]]) -> List[int]:
        raise NotImplementedError

    @check_connected
    def insert_edge(self, src: int, dst: int, attr: Dict[str, Any]) -> int:
        """
        插入单条边操作
        Args:
            src (int): 边起点id
            dst (int): 边终点id
            attr (dict): 边属性, key为属性名称, value为属性值

        Returns:
            int: 插入边的rank(src-dst中的第几条边)
        """
        return self._insert_edge(src, dst, attr)

    def _insert_edge(self, src: int, dst: int, edge: Dict) -> int:
        return self._insert_edges([(src, dst)], [edge])[0]

    @check_connected
    def update_edges(self, sdr_list: List[Tuple[int, int, int]],
                     attr_list: List[Dict[str, Any]], override: bool = True) -> None:
        """
        批量更新边操作.
        Args:
            sdr_list (List[Tuple[int, int, int]]): (起点id, 终点id, rank)的列表
            attr_list (List[Dict[str, Any]]): 边属性描述列表, key为属性名称, value为属性值
            override (bool): 如果旧边和新边同时存在一个属性, 是否用属性新值覆盖旧值.

        Returns:
            None
        """
        return self._update_edges(sdr_list, attr_list, override)

    @abstractmethod
    def _update_edges(self, sdr_list: List[Tuple[int, int, int]],
                      attr_list: List[Dict[str, Any]], override: bool = True) -> None:
        raise NotImplementedError

    @check_connected
    def update_edge(self, src: int, dst: int, rank: int, attr: Dict, override: bool = True) -> None:
        """
        更新单条边操作.
        Args:
            src (int): 边起点id
            dst (int): 边终点id
            rank (int): 边排序值. src-dst-rank唯一确定一条边
            attr (Dict): 边属性, key为属性名称, value为属性值
            override (bool): 如果旧边和新边同时存在一个属性, 是否用属性新值覆盖旧值.

        Returns:
            None
        """
        return self._update_edge(src, dst, rank, attr, override)

    def _update_edge(self, src: int, dst: int, rank: int, edge: Dict, override: bool = True) -> None:
        return self._update_edges([(src, dst, rank)], [edge], override)

    @check_connected
    def delete_edges(self, src_dst_rank: List[Tuple[int, int, int]]) -> List[KBXError]:
        """
        批量删除边操作: 根据src, dst, rank删除一条边; 调用方需要确保该边存在.
        如果在删除过程中出现异常，已删除的边不会回滚.
        Args:
            src_dst_rank (List[tuple]): (src节点id, dst节点id, 排序值)列表

        Returns:
            None
        """
        return self._delete_edges(src_dst_rank)

    @abstractmethod
    def _delete_edges(self, src_dst_rank: List[Tuple[int, int, int]]) -> List[KBXError]:
        raise NotImplementedError

    @check_connected
    def delete_edge(self, src: int, dst: int, rank: int) -> None:
        """
        删除边操作: 根据src, dst, rank删除一条边; 调用方需要确保该边存在.
        Args:
            src (int): 源实体
            dst (int): 目标实体
            rank (int): 排序值

        Returns:
            None
        """
        return self._delete_edge(src, dst, rank)

    def _delete_edge(self, src: int, dst: int, rank: int) -> None:
        return self._delete_edges([(src, dst, rank)])

    @check_connected
    def search_node_by_id(self, node_id: int) -> Dict[str, Any]:
        """
        根据id搜索节点: 如果节点存在, 则返回节点的属性Dict; 如果节点不存在, 则返回None.
        Args:
            node_id (int): 待查找的节点id

        Returns:
            Dict: 描述带查找节点的属性, key为属性名称, value为属性值
        """
        return self._search_node_by_id(node_id)

    @abstractmethod
    def _search_node_by_id(self, node_id: int) -> Dict[str, Any]:
        raise NotImplementedError

    @check_connected
    def search_node_by_ids(self, node_ids: List[int]) -> Dict[int, Dict[str, Any]]:
        """
        批量搜索节点: 如果节点存在, 则返回节点的属性Dict; 如果节点不存在, 则返回None.
        Args:
            node_ids (List[int]): 实体ID列表

        Returns:
            List[Dict]: 实体字典列表, Key为属性名称, Value为属性值
        """
        return self._search_node_by_ids(node_ids)

    @abstractmethod
    def _search_node_by_ids(self, node_ids: List[int]) -> Dict[int, Dict[str, Any]]:
        raise NotImplementedError

    @check_connected
    def search_node_by_property(self, properties: Dict[str, Any]) -> List[int]:
        """
        利用节点属性进行检索, 要求检索的目标节点的属性中必须包括properties中的每一个属性，且对应的属性值严格相等.

        Args:
            properties (Dict[str, Any]): key为属性名称, value为属性值

        Returns:
            List[int]: 符合约束条件的节点ID列表
        """
        return self._search_node_by_property(properties)

    @abstractmethod
    def _search_node_by_property(self, properties: Dict[str, Any]) -> List[int]:
        raise NotImplementedError

    @check_connected
    def search_node_complex(self, properties: Dict[str, Any], edges: List[Tuple[Dict, Dict, Dict]]) -> List[int]:
        """
        具有复杂策略搜索节点的逻辑
        Args:
            properties (Dict[str, Any]): 属性字典
            edges (List[Tuple[Dict, Dict, Dict]]): 边列表

        Returns:
            List[int]: 符合约束条件的节点ID列表
        """
        return self._search_node_complex(properties, edges)

    @abstractmethod
    def _search_node_complex(self, properties: Dict, edges: List[Tuple[Dict, Dict, Dict]]) -> List[int]:
        raise NotImplementedError

    @check_connected
    def merge_node(self, src: int, dst: int) -> None:
        """
        合并实体
        Args:
            src (int): 源实体ID
            dst (int): 合并到目标实体ID

        Returns:
            None
        """
        return self._merge_node(src, dst)

    @abstractmethod
    def _merge_node(self, src: int, dst: int) -> None:
        raise NotImplementedError

    @check_connected
    def search_edge_by_id(self, src: int, dst: int) -> Dict[int, Dict[str, Any]]:
        """
        根据边的起点和终点搜索便，如果对应的边不存在，则返回空字典.
        Args:
            src (int): 边起点id
            dst (int): 边终点id

        Returns:
            Dict[int, Dict[str, Any]]: 边字典, key为rank, value为边属性字典
        """
        return self._search_edge_by_id(src, dst)

    @abstractmethod
    def _search_edge_by_id(self, src: int, dst: int) -> Dict[int, Dict[str, Any]]:
        raise NotImplementedError

    @check_connected
    def upsert_node(self,
                    node: Dict,
                    properties_for_search: Dict,
                    align_method: str = 'same_properties',
                    edges_for_alignment: Dict = None,
                    override: bool = True
                    ) -> int:
        """
        插入或者更新实体
        Args:
            node (Dict): 实体字典
            properties_for_search (Dict): 边属性字典
            align_method (str): 'same_properties', 'same_edges'
            edges_for_alignment (Dict): 边属性字典
            override (str): 当属性已存在时, 'skip' or 'update'

        Returns:
            int: 插入或者更新的实体ID
        """
        return self._upsert_node(node, properties_for_search, align_method, edges_for_alignment, override)

    @abstractmethod
    def _upsert_node(self,
                     node: Dict,
                     properties_for_search: Dict,
                     align_method: str = 'same_properties',
                     edges_for_alignment: Dict = None,
                     override: bool = True
                     ) -> int:
        raise NotImplementedError

    @check_connected
    def upsert_edge(self, src: int, dst: int, edge: Dict,
                    edge_properties_for_alignment: Dict,
                    override: bool = True) -> int:
        """
        插入或者更新边
        Args:
            src (int): 源实体ID
            dst (int): 目标实体ID
            edge (Dict): 边字典, Key为属性名称, Value为属性值
            edge_properties_for_alignment (Dict): 边属性字典, 用于边对齐
            override (bool): 当属性已存在时, 是否覆盖

        Returns:
            int: edge rank
        """
        return self._upsert_edge(src, dst, edge,
                                 edge_properties_for_alignment,
                                 override)

    @abstractmethod
    def _upsert_edge(self, src: int, dst: int, edge: Dict,
                     edge_properties_for_alignment: Dict,
                     override: bool = True) -> int:
        raise NotImplementedError

    @check_connected
    def collect_triples(self, candidate_nodes: List[int], name_properties: Union[str, List] = '名称') -> List[List[str]]:
        """
        收集实体三元组
        Args:
            candidate_nodes (List[int]): 候选实体列表
            name_properties (Union[str, List]): 可以指示名称的属性名称, 例如: ["名称", "简称", "全称"]

        Returns:
            List[List[str]]: 三元组列表
        """
        return self._collect_triples(candidate_nodes, name_properties)

    @abstractmethod
    def _collect_triples(self, candidate_nodes: List[int], name_properties: Union[str, List] = '名称') -> List[List[str]]:
        raise NotImplementedError

    @check_connected
    def find_predecessor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        """
        查找指定的id的node的前驱节点，以及连接前驱节点的边

        Args:
            node_id (int): 当前节点id.

        Returns:
            Dict[int, Dict[int, Dict[str, Any]]]:
                1. key: 前驱节点的id, value: 和前驱节点连接的边描述dict
                2. key: 边rank值, value: 边属性dict
                3. key: 属性名称, value: 属性值

        """
        return self._find_predecessor(node_id)

    @abstractmethod
    def _find_predecessor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        raise NotImplementedError

    @check_connected
    def find_successor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        """
        查找指定的id的node的后继节点，以及连接后继节点的边

        Args:
            node_id (int): 当前节点id.

        Returns:
            Dict[int, Dict[int, Dict[str, Any]]]:
                1. key: 后继节点的id, value: 和后继节点连接的边描述dict
                2. key: 边rank值, value: 边属性dict
                3. key: 属性名称, value: 属性值

        """
        return self._find_successor(node_id)

    @abstractmethod
    def _find_successor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        raise NotImplementedError

    def filter_neighbors(self,
                         neighbors: Dict[int, Dict[int, Dict[str, Any]]],
                         edge_filter: Dict[str, str] = None) -> Dict[int, Dict[int, Dict[str, Any]]]:
        """
        过滤邻居节点
        Args:
            edge_filter (Dict[str, str]): 边过滤条件, key为属性名称, value为属性值
        Returns:
            Dict[int, Dict[int, Dict[str, Any]]]:
                1. key: 邻居节点的id, value: 和邻居节点连接的边描述dict
                2. key: 边rank值, value: 边属性dict
                3. key: 属性名称, value: 属性值
        """
        if not neighbors:
            return neighbors
        if edge_filter:
            valid_neighbors = {}
            for node_id, edges in neighbors.items():
                for edge_id, edge in edges.items():
                    if all(edge.get(key, None) == value for key, value in edge_filter.items()):
                        valid_neighbors[node_id] = valid_neighbors.get(node_id, {})
                        valid_neighbors[node_id][edge_id] = edge
            neighbors = valid_neighbors
        return neighbors
