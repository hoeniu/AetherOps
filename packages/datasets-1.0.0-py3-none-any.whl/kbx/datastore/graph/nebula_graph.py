import logging
import time
from typing import Any, Dict, Iterable, List, Tuple, Union

from kbx.datastore.graph.graph_base import BaseGraphDS
from kbx.common.types import GraphDSConfig, KBXError
from kbx.common.logging import logger
from kbx.datastore.graph.graph_helper import convert_schema2nebula_tag, graph_if_align, graph_get_prop
from kbx.datastore.graph.graph_helper import graph_override, sanitize_string
from kbx.datastore.graph.invert_index import InvertedIndex
from nebula3.gclient.net import ConnectionPool
from nebula3.Config import Config
from nebula3.data.ResultSet import ResultSet


def get_value_from_wrapper(value_wrapper):
    if value_wrapper.is_list():
        return value_wrapper.as_list()
    elif value_wrapper.is_map():
        return value_wrapper.as_map()
    else:
        if value_wrapper.is_int():
            return value_wrapper.as_int()
        elif value_wrapper.is_double():
            return value_wrapper.as_double()
        elif value_wrapper.is_string():
            return value_wrapper.as_string()
        else:
            return ""


def result_set_convert(result_set: ResultSet, col: str = "v") -> List[Tuple[int, Dict[str, Any]]]:
    """
    将nebula的ResultSet转换为List[Tuple[int, Dict]]

    Args:
        result_set (ResultSet): nebula的ResultSet
        col (str, optional): 结果集的列名

    Returns:
        List[Tuple[int, Dict]]: 最里层的Dict有可能是Dict[str, Any] 节点相关 或者 Dict[int, Dict[str, Any]] 边相关
    """
    res: List[Tuple[int, Dict[str, Any]]] = list()
    for item in result_set.column_values(col):
        if item.is_vertex():
            node = item.as_node()
            prop = node.properties()
            res.append((node.get_id().as_int(), {k: get_value_from_wrapper(v) for k, v in prop.items()}))
        else:
            logger.error("match return non-vertex data.")
    return res


def result_set_convert2(result_set: ResultSet, col: str = "e", col2: str = "v") -> Dict[int, Dict[int, Dict[str, Any]]]:
    res: Dict[int, Dict[int, Dict[str, Any]]] = dict()
    for item1, item2 in zip(result_set.column_values(col), result_set.column_values(col2)):
        if item1.is_edge() and item2.is_vertex():
            edge = item1.as_relationship()
            edge_prop = edge.properties()
            node = item2.as_node()
            vid = node.get_id().as_int()
            if vid not in res.keys():
                res[vid] = dict()
            res[vid] = {edge.get_ranking(), {k: get_value_from_wrapper(v) for k, v in edge_prop.items()}}
        else:
            logger.error("match return non-edge data.")
    return res


class NebulaGraphDS(BaseGraphDS):

    def __init__(self, config: GraphDSConfig, kb_id: str, index_type: str, namespace: str,
                 schema_info: Dict[str, Any]):
        """
        Nebula 实现的图数据库.
        """
        super().__init__(config, kb_id, index_type, namespace)
        self._host: str = config.connection_kwargs["host"]
        self._port: str = config.connection_kwargs["port"]
        self._username: str = config.connection_kwargs["username"]
        self._password: str = config.connection_kwargs["password"]
        self._nebula3_config: Config = Config()
        self._nebula3_connection_pool: ConnectionPool = ConnectionPool()
        self._schema = schema_info
        # nebula space name 不允许出现 "-"
        self._namespace = index_type + namespace + kb_id.replace("-", "")
        # 测试用namespace
        # self._namespace = "test"
        self._session = None  # nebula 数据库的连接.
        # 倒排索引
        self._inverted_index = None
        # namespace下只有一种tag和一种edge
        self._tag_type = None
        self._edge_type = None

    def _try_ngql_with_sleep(self, n_gql: str):
        sleep_time = 4
        while True:
            time.sleep(sleep_time)  # Create Space是异步创建，不能直接使用
            res = self._session.execute(f"{n_gql}")
            if res.is_succeeded():
                return
            else:
                sleep_time = sleep_time + 4
                if sleep_time > 20:
                    raise RuntimeError(res.error_msg())

    def _connect(self) -> None:
        self._nebula3_config.max_connection_pool_size = 10
        res = self._nebula3_connection_pool.init([(self._host, self._port)], self._nebula3_config)
        if not res:
            raise RuntimeError(f"Nebula Connection Pool is not initialized. host: {self._host}, port: {self._port}")
        self._session = self._nebula3_connection_pool.get_session(self._username, self._password)
        if not self._session:
            raise RuntimeError(f"Nebula session cannot be get. host: {self._username}, port: {self._password}")

        self._increment_id = 0

        self._tag_type, create_tag_nddl, self._edge_type, create_edge_nddl = convert_schema2nebula_tag(self._schema)
        flag: bool = self.__check_space_exists(self._namespace)
        if not flag:
            res = self._session.execute(f"CREATE SPACE IF NOT EXISTS {self._namespace} (vid_type=INT64);")
            if not res.is_succeeded():
                raise RuntimeError(res.error_msg())
            else:
                logger.info(f"Succeed to create space {self._namespace}.")
            # Nebula在创建Space和Tag/Edge后，推荐两个心跳周期(20s)后使用，否则有可能报错; 下同
            self._try_ngql_with_sleep(f"USE {self._namespace};")
            res = self._session.execute(create_tag_nddl)
            if not res.is_succeeded():
                logger.error(create_tag_nddl)
                raise RuntimeError(res.error_msg())
            res = self._session.execute(create_edge_nddl)
            if not res.is_succeeded():
                logger.error(create_edge_nddl)
                raise RuntimeError(res.error_msg())
            self._try_ngql_with_sleep(f"SHOW CREATE TAG {self._tag_type};")
        else:
            res = self._session.execute(f"USE {self._namespace};")
            if not res.is_succeeded():
                raise RuntimeError(res.error_msg())
        all_nodes = self.__get_all_nodes()
        self._increment_id = 0 if len(all_nodes) == 0 else max(dict(all_nodes).keys())
        # initialize inverted index.
        self._inverted_index = InvertedIndex()
        self._inverted_index.build(all_nodes)

    def _close(self) -> None:
        self._inverted_index = None
        self._session = None
        # session doesn't have close method, will be closed before pool closed.
        self._nebula3_connection_pool.close()

    def __check_space_exists(self, space_name: str):
        result = self._session.execute("SHOW SPACES;")
        spaces = result.column_values("Name")
        spaces = [str(item).strip("\"") for item in spaces]
        return space_name in spaces

    def __get_next_id(self) -> int:
        self._increment_id = self._increment_id + 1
        return self._increment_id

    def __get_all_nodes(self) -> List[Tuple[int, Dict[str, Any]]]:
        """
        返回当前namespace下的所有node, 以List[Tuple[vid, attrs]]的形式返回.
        """
        query: str = "MATCH (v) RETURN v;"
        result = self._session.execute(query)
        return result_set_convert(result, "v")

    @property
    def node_ids(self) -> Iterable:
        """
        返回当前namespace下的所有node_id.
        """
        return [item[0] for item in self.__get_all_nodes()]

    @property
    def nodes(self) -> Iterable:
        return dict(self.__get_all_nodes())

    def _insert_nodes(self, nodes: List[Dict]) -> List[int]:
        node_id_list: List[int] = []
        for node in nodes:
            attr_names: str = ", ".join(f"`{attr}`" for attr in node.keys())
            attr_vals: str = ", ".join([f"{val}" if isinstance(val, (int, float))
                                        else f"'{sanitize_string(val)}'" for val in node.values()])
            node_id = self.__get_next_id()
            n_gql: str = f"INSERT VERTEX {self._tag_type} ({attr_names}) " \
                         f"VALUES {node_id}:({attr_vals});"
            # 返回的vid作为node_id, 不需要逻辑生成
            res = self._session.execute(n_gql)
            if not res.is_succeeded():
                raise RuntimeError(f"Failed to insert node {res.error_msg()}, {n_gql}")
            node_id_list.append(node_id)
            self._inverted_index.update(node, node_id)
        return node_id_list

    def _update_nodes(self, nodes_dict: Dict[int, Dict], override: bool = True) -> List[KBXError]:
        result_list: List[KBXError] = list()
        for node_id, node in nodes_dict.items():
            self._inverted_index.delete(node_id)
            ori_node = self._search_node_by_id(node_id)
            node = graph_override(node, ori_node, override)
            set_clause = ", ".join(
                [f"{self._tag_type}.`{key}` = {value}" if isinstance(value, (
                    int, float)) else f"{self._tag_type}.`{key}` = '{sanitize_string(value)}'" for key, value in
                 node.items()])
            n_gql: str = f"UPDATE VERTEX {node_id} SET {set_clause};"
            res = self._session.execute(n_gql)
            if not res.is_succeeded():
                error_msg = f"UPDATE VERTEX node_id: {node_id} Failed. {res.error_msg()}"
                logger.error(error_msg)
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=error_msg))
            else:
                result_list.append(KBXError())
            self._inverted_index.update(node, node_id)
            return result_list

    def _delete_nodes(self, node_ids: List[int]) -> List[KBXError]:
        result_list: List[KBXError] = list()
        for node_id in node_ids:
            self._inverted_index.delete(node_id)
            n_gql: str = f"DELETE VERTEX {node_id} WITH EDGE;"
            res = self._session.execute(n_gql)
            if not res.is_succeeded():
                error_msg = f"DELETE VERTEX node_id: {node_id} Failed. {res.error_msg()}"
                logger.error(error_msg)
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=error_msg))
            else:
                result_list.append(KBXError())
        return result_list

    def _insert_edges(self, src_dst: List[Tuple], edges: List[Dict]) -> List[int]:
        rank_list: List[int] = list()
        for sd, edge in zip(src_dst, edges):
            src, dst = sd[0], sd[1]
            edge_dict: Dict[int, Dict] = self._search_edge_by_id(src, dst)
            # nebula中rank需要由业务逻辑维护
            if len(edge_dict.keys()) == 0:
                rank = 0
            else:
                rank = max(edge_dict.keys()) + 1
            attr_list: str = ", ".join(f"`{attr}`" for attr in edge.keys())
            val_list: str = ", ".join([f"{val}" if isinstance(val, (int, float))
                                       else f"'{val}'" for val in edge.values()])
            n_gql: str = f"INSERT EDGE {self._edge_type} ({attr_list})" \
                         f" VALUES {src} -> {dst}@{rank}: ({val_list});"
            res = self._session.execute(n_gql)
            if not res.is_succeeded():
                logger.error(f"INSERT EDGE FAILED: {src}->{dst}@{rank}. {res.error_msg()}")
            rank_list.append(rank)
        return rank_list

    def _update_edges(self, src_dst_rank: List[Tuple], edges: List[Dict], override: bool = True) -> List[KBXError]:
        result_list: List[KBXError] = list()
        for sdr, edge in zip(src_dst_rank, edges):
            src, dst, rank = sdr[0], sdr[1], sdr[2]
            ori_edge_dict = self._search_edge_by_id(src, dst)
            error_msg = f"Cannot find edge: {src}->{dst}@{rank}."
            if not ori_edge_dict:
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=error_msg))
                continue
            flag = False
            for ori_rank, ori_edge in ori_edge_dict.items():
                if ori_rank == rank:
                    edge = graph_override(edge, ori_edge, override)
                    set_clause = ", ".join(
                        [f"`{key}` = {value}" if isinstance(value, (int, float)) else f"`{key}` = '{value}'"
                         for key, value
                         in edge.items()])
                    n_gql: str = f"UPDATE EDGE {src} -> {dst}@{rank} OF {self._edge_type} SET {set_clause};"
                    res = self._session.execute(n_gql)
                    if not res.is_succeeded():
                        error_msg = f"UPDATE EDGE FAILED: {src}->{dst}@{rank}. {res.error_msg()}"
                        logger.error(error_msg)
                    else:
                        flag = False
            if flag:
                result_list.append(KBXError())
            else:
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=error_msg))
        return result_list

    def _delete_edges(self, src_dst_rank_list: List[Tuple]) -> List[KBXError]:
        result_list: List[KBXError] = list()
        for src, dst, rank in src_dst_rank_list:
            n_gql: str = f"DELETE EDGE {self._edge_type} {src} -> {dst}@{rank};"
            res = self._session.execute(n_gql)
            if not res.is_succeeded():
                error_msg = f"DELETE EDGE FAILED: {src}->{dst}@{rank}. {res.error_msg()}"
                logger.error(error_msg)
                result_list.append(KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=error_msg))
            else:
                result_list.append(KBXError())
        return result_list

    def _search_node_by_id(self, node_id: int) -> Dict[str, Any]:
        query: str = f"MATCH (v) WHERE id(v) == {node_id} RETURN v;"
        result = self._session.execute(query)
        # node_list is a tuple, 0: id; 1: attrs
        node_list: List[Dict[str, Any]] = result_set_convert(result, "v")
        if node_list and len(node_list) == 1:
            return node_list[0][1]
        else:
            return None

    def _search_node_by_ids(self, node_ids: List[int]) -> List[Dict[str, Any]]:
        str_id_list: str = ",".join([str(node_id) for node_id in node_ids])
        query: str = f"MATCH (v) WHERE id(v) IN [{str_id_list}] RETURN v;"
        result = self._session.execute(query)
        node_list: List[Dict[str, Any]] = result_set_convert(result, "v")
        if not node_list:
            return []
        else:
            res: List[Dict[str, Any]] = []
            for item in node_list:
                res.append(item[1])

    def _search_node_by_property(self, properties: Dict) -> List[int]:
        cross_ids = None
        index = self._inverted_index.get()
        for attr, val in properties.items():
            if attr not in index or val not in index[attr]:
                return []
            node_ids = index[attr][val]
            if not node_ids:
                return []
            if cross_ids is None:
                cross_ids = node_ids
            else:
                cross_ids = cross_ids.intersection(node_ids)
            if not cross_ids:
                return []
        return list(cross_ids)

    def _search_node_complex(self, properties: Dict, edges: List[Tuple[Dict, Dict, Dict]]) -> List[int]:
        node_ids = self._search_node_by_property(properties)
        results = []
        for ind in node_ids:
            candidate_edges = []
            for nbr, d in self._find_predecessor(ind).items():
                for idx, dd in d.items():
                    candidate_edges.append([self.nodes[nbr], dd, self.nodes[ind]])
            for nbr, d in self._find_successor(ind).items():
                for idx, dd in d.items():
                    candidate_edges.append([self.nodes[ind], dd, self.nodes[nbr]])
            edge_all_in_candidate = True
            for edge in edges:
                find_edges = list(filter(lambda ce: graph_if_align(edge[0], ce[0]) \
                                         and graph_if_align(edge[1], ce[1]) \
                                         and graph_if_align(edge[2], ce[2]), candidate_edges))
                if not find_edges:
                    edge_all_in_candidate = False
                    break
            if edge_all_in_candidate:
                results.append(ind)
        return results

    def _merge_node(self, src: int, dst: int) -> None:
        """TODO:暂时先不实现"""
        return

    def _search_edge_by_id(self, src: int, dst: int) -> Dict[int, Dict]:
        edge_dict: Dict[int, Dict] = dict()
        # 一组src-dst中间可能有具有不同rank的多条边: -> (rank, edge_attrs)
        n_gql: str = f"MATCH (v1)-[e:{self._edge_type}]->(v2) WHERE id(v1) == {src} AND id(v2) == {dst} RETURN e;"
        res = self._session.execute(n_gql)
        if res.is_succeeded():
            for record in res:
                edge = record.values()[0]
                if edge.is_edge():
                    edge_data = edge.as_relationship()
                    rank = edge_data.ranking()
                    prop = edge_data.properties()
                    edge_dict[rank] = {k: get_value_from_wrapper(v) for k, v in prop.items()}
            return edge_dict
        else:
            logger.error(f"search edge {src}->{dst} failed. {res.error_msg()}")

    def _upsert_node(self,
                     node: Dict,
                     properties_for_search: Dict,
                     align_method: str = 'same_properties',
                     edges_for_alignment: Dict = None,
                     override: bool = True
                     ) -> int:
        node_ids = None
        if align_method == 'same_properties':
            node_ids = self._search_node_by_property(properties_for_search)
        elif align_method == 'same_edges':
            node_ids = self._search_node_complex(properties_for_search, edges_for_alignment)
        if not node_ids:
            node_id = self._insert_node(node)
            return node_id
        if len(node_ids) > 1:
            logging.log(logging.WARN, "More than 1 nodes found while updating.")
            logging.log(logging.WARN, str(node_ids))
        if 0 in node_ids:
            logger.error(properties_for_search)
            logger.error(edges_for_alignment)
            logger.error(node_ids)
        self._update_node(node_ids[0], node, override)
        return node_ids[0]

    def _upsert_edge(self, src: int, dst: int, edge: Dict,
                     edge_properties_for_alignment: Dict,
                     override: bool = True) -> int:
        # rank -> edge_attrs
        edge_dict = self._search_edge_by_id(src, dst)
        if not edge_dict:  # edge_dict is None or Empty.
            return self._insert_edge(src, dst, edge)
        else:
            for rank, old_edge in edge_dict.items():
                if graph_if_align(edge_properties_for_alignment, old_edge):
                    edge = graph_override(edge, old_edge, override)
                    self._update_edge(src, dst, rank, edge, override)
                    return rank
        return self._insert_edge(src, dst, edge)

    def subgraph(self, center_nodes: list,
                 name_properties: list = ["名称", "简称", "英文名称", "英文简称"],
                 max_depth=1,
                 max_children=None,
                 with_property=True,
                 node_filter=None,
                 edge_filter=None) -> dict:
        # TODO:
        return {"nodes": [], "links": []}

    def _collect_triples(self, candidate_nodes: List[int], name_properties: Union[str, List] = '名称') -> List[List[str]]:
        triples = []
        for ent in candidate_nodes:
            attrs = self._find(ent)
            ent_name = graph_get_prop(attrs, name_properties)
            for attr, val in attrs.items():
                triples.append([ent_name, attr, val])
            for nbr, edge_rank_prop in self._find_predecessor(ent).items():
                for rank, prop in edge_rank_prop.items():
                    dd = list(filter(lambda x: x[0] != '类型' and x[0] != 'id', prop.items()))
                    dd = list(map(lambda x: ':'.join(x), dd))
                    edge_attr_str = ''
                    if dd:
                        edge_attr_str = '(' + ",".join(dd) + ')'
                    triples.append([graph_get_prop(self._find(nbr), name_properties),
                                    prop['类型'] + edge_attr_str, ent_name])
            for nbr, edge_rank_prop in self._find_successor(ent).items():
                for rank, prop in edge_rank_prop.items():
                    dd = list(filter(lambda x: x[0] != '类型' and x[0] != 'id', prop.items()))
                    dd = list(map(lambda x: ':'.join(x), dd))
                    edge_attr_str = ''
                    if dd:
                        edge_attr_str = '(' + ",".join(dd) + ')'
                    triples.append([ent_name, prop['类型'] + edge_attr_str,
                                    graph_get_prop(self._find(nbr), name_properties)])
        return triples

    def _delete_ds(self) -> KBXError:
        return KBXError(code=KBXError.Code.SUCCESS)

    @staticmethod
    def get_type() -> str:
        return "nebula"

    def _find_predecessor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        n_gql: str = f"MATCH (m)-[e]->(n) WHERE id(n) == {node_id} WITH RETURN e, m;"
        result_set = self._session.execute(n_gql)
        return result_set_convert2(result_set, "e", "m")

    def _find_successor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        n_gql: str = f"MATCH (n)-[e]->(m) RETURN id(n) == {node_id} WITH RETURN e, m;"
        result_set = self._session.execute(n_gql)
        return result_set_convert2(result_set, "e", "m")

    def _find(self, node_id: int) -> Dict[str, Any]:
        n_gql: str = f"MATCH (v) WHERE id(v) == {node_id} RETURN v;"
        result_set = self._session.execute(n_gql)
        node_list = result_set_convert(result_set, "v")
        if len(node_list) == 1:
            return node_list[0][1]
        else:
            raise RuntimeError(f"node_id:{node_id} find node with illegal num: {len(node_list)}")
