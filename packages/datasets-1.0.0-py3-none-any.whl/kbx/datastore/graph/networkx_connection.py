import os
from typing import Any, Dict
from kbx.common.logging import logger
from kbx.datastore.base_connection import BaseConnection
from kbx.datastore.graph.invert_index import InvertedIndex
import networkx as nx
import shutil


class NetworkxConnection(BaseConnection):

    def __init__(self, args: Dict[str, Any]):
        super().__init__(args)
        self.external_graph_fp = args["graphml_file"]
        self.local_graph_fp = args["persist_file_path"]
        if os.path.exists(self.external_graph_fp) and not os.path.exists(self.local_graph_fp):
            # external graph, not imported
            os.makedirs(os.path.dirname(self.local_graph_fp), exist_ok=True)
            shutil.copy(self.external_graph_fp, self.local_graph_fp)
        if os.path.exists(self.local_graph_fp):
            logger.info("Load from path: {}".format(self.local_graph_fp))
            self.graph = nx.read_graphml(self.local_graph_fp, node_type=int, force_multigraph=True)
        else:
            logger.info("Create a new graph: {}".format(self.local_graph_fp))
            self.graph = nx.MultiDiGraph()
        self.index = InvertedIndex()
        self.index.build_networkx(self.graph)
        self.node_id_dict = {"id": max(self.graph.nodes) if self.graph.nodes else 0}

    def flush(self):
        if self.graph is None:
            logger.warning("Graph is None, cannot flush.")
            return
        if not os.path.exists(os.path.dirname(self.local_graph_fp)):
            os.makedirs(os.path.dirname(self.local_graph_fp), exist_ok=True)
        nx.write_graphml(self.graph, self.local_graph_fp)

    def get(self, key: str = None):
        if key is None or key == "graph":
            return self.graph
        elif key == "index":
            return self.index
        elif key == "node_id_dict":
            return self.node_id_dict
