from typing import Any, Dict, List, Tuple
import networkx as nx


def upper_case(value):
    if isinstance(value, str):
        # 如果是字符串，将其转换为大写形式
        return value.upper()
    # 如果不是字符串，直接返回原输入值
    return value


class InvertedIndex:

    def __init__(self):
        self.nodes: Dict[int, Dict[str, Any]] = None  # node map to record each node info.
        self.index: Dict[str, Dict[str, List[int]]] = None

    def __repr__(self):
        return "index: " + str(self.index) + "\nnodes: " + str(self.nodes)

    def build(self, node_list: List[Tuple[int, Dict[str, Any]]]) -> None:
        self.nodes = dict()
        self.index = dict()
        # 遍历所有节点和它们的属性
        for node_id, node in node_list:
            for attr, val in node.items():
                self.index.setdefault(attr, dict()).setdefault(val, set()).add(node_id)
            self.nodes[node_id] = node.copy()

    def update(self, node: Dict[str, Any], node_id: int) -> None:
        for attr, value in node.items():
            self.index.setdefault(attr, dict()).setdefault(upper_case(value), set()).add(node_id)
        self.nodes[node_id] = node.copy()

    def delete(self, node_id: int) -> None:
        if node_id not in self.nodes.keys():
            return
        for attr, value in self.nodes[node_id].items():
            self.index[attr][upper_case(value)].remove(node_id)
        del self.nodes[node_id]

    def get(self) -> Dict:
        return self.index

    def get_nodes(self) -> Dict:
        return self.nodes

    def build_networkx(self, graph: nx.MultiDiGraph) -> None:
        self.nodes = dict()
        self.index = dict()
        # 遍历所有节点和它们的属性
        for node_id, attrs in graph.nodes(data=True):
            for attr, value in attrs.items():
                self.index.setdefault(attr, dict()).setdefault(upper_case(value), set()).add(node_id)
            self.nodes[node_id] = attrs.copy()
