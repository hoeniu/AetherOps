import queue
import random
import networkx as nx
from typing import Any, Dict, List, Tuple, Union, Iterable
from kbx.datastore.base_ds import DataStoreType
from kbx.datastore.graph.graph_base import BaseGraphDS
from kbx.common.types import GraphDSConfig, KBXError
from kbx.common.lock.mutex_factory import get_mutex
from kbx.common.logging import logger
from kbx.datastore.base_connection import BaseConnection
from kbx.datastore.connection_pool import ConnectionPool
from kbx.datastore.graph.invert_index import InvertedIndex
from kbx.datastore.graph.networkx_connection import NetworkxConnection
from kbx.datastore.base_ds import with_lock


class NetworkxGraphDS(BaseGraphDS):
    """
    图数据库的存储类
    """

    def __init__(self, config: GraphDSConfig, kb_id: str, index_type: str, namespace: str):
        """
        NetworkxGraphDS初始化
        Args:
            config (GraphDSConfig): 配置文件
            kb_id (str): 知识库ID
        """
        super().__init__(config, kb_id, index_type, namespace)
        self.persist_file_path = self._path_factory.path_r2a(kb_id + ".graphml")
        self.graph = None
        self.index: InvertedIndex = None
        args: Dict[str, str] = dict()
        args["graphml_file"] = self._config.connection_kwargs.get('graphml_file', "")
        args["persist_file_path"] = self.persist_file_path
        expired_time = config.connection_kwargs.get("expired_time", 5)
        self._connection_pool: ConnectionPool = ConnectionPool(
            DataStoreType.GRAPH, self._key, args, expired_time, NetworkxConnection)
        self._connection: BaseConnection = None
        self._lock = get_mutex(DataStoreType.GRAPH + "_" + self._key)

    @with_lock
    def _connect(self) -> None:
        # 为了使 node_id 也支持多线程，需要用一个dict存储这个node_id
        self._connection = self._connection_pool.open_connection()
        self.graph = self._connection.get("graph")
        self.index = self._connection.get("index")
        self.node_id_dict = self._connection.get("node_id_dict")

    @with_lock
    def _close(self) -> None:
        self.graph = None
        self.index = None
        self.node_id_dict = None
        self._connection_pool.close_connection()

    def get_next_id(self) -> int:
        auto_id = self.node_id_dict["id"]
        self.node_id_dict["id"] = auto_id + 1
        return auto_id

    @with_lock
    def _flush(self) -> None:
        self._connection.flush()

    def _upper_case(self, value):
        """
        将输入值转换为大写形式，如果输入值是字符串的话。

        Args:
            value: 待转换的值，可以是任意类型。

        Returns:
            如果输入值是字符串，则返回其大写形式；否则返回原输入值。
        """
        # 检查输入值是否为字符串
        if isinstance(value, str):
            # 如果是字符串，将其转换为大写形式
            return value.upper()
        # 如果不是字符串，直接返回原输入值
        return value

    def _insert_nodes(self, nodes: List[Dict]) -> List[int]:
        return [self.insert_node(nodes[i]) for i in range(len(nodes))]

    @with_lock
    def _insert_node(self, node: Dict) -> int:
        node_id = self.get_next_id()
        self.graph.add_node(node_id, **node)
        self.index.update(node, node_id)
        return node_id

    def _update_nodes(self, nodes_dict: Dict[int, Dict], override: bool = True) -> None:
        """
        更新实体列表
        Args:
            nodes_dict (Dict[int, Dict]): 更新的实体字典, Key为实体ID, Value为实体字典(Key为属性名称, Value为属性值)
            override (bool): 如果属性已存在时, 是否覆盖
        Returns:
            None
        """
        for node_id, node in nodes_dict.items():
            self.update_node(node_id, node, override)

    @with_lock
    def _update_node(self, node_id: int, node: Dict, override: bool = True) -> None:
        """
        更新实体
        Args:
            node_id (int): 实体ID
            node (Dict): 更新的实体字典, Key为属性名称, Value为属性值
            override (bool): 如果属性已存在时, 是否覆盖

        Returns:
            None
        """
        self.index.delete(node_id)
        t_attrs = self.graph.nodes[node_id]
        for k, v in t_attrs.items():
            if not override or k not in node:
                node[k] = v
        nx.set_node_attributes(self.graph, {node_id: node})
        self.index.update(node, node_id)

    @with_lock
    def _delete_nodes(self, node_ids: List[int]) -> None:
        for node_id in node_ids:
            self.index.delete(node_id)
        self.graph.remove_nodes_from(node_ids)

    @with_lock
    def _delete_node(self, node_id: int) -> None:
        if node_id not in self.graph.nodes:
            logger.warning(f"Node {node_id} does not exist.")
            return
        self.index.delete(node_id)
        self.graph.remove_node(node_id)

    @with_lock
    def _insert_edges(self, src_dst: List[Tuple], edges: List[Dict]) -> List[int]:
        rank_list = []
        for sd, edge in zip(src_dst, edges):
            rank_list.append(self.graph.add_edge(sd[0], sd[1], **edge))
        return rank_list

    def _update_edges(self, src_dst_rank: List[Tuple], edges: List[Dict], override: bool) -> None:
        for sdr, edge in zip(src_dst_rank, edges):
            self.update_edge(sdr[0], sdr[1], sdr[2], edge, override)

    @with_lock
    def _update_edge(self, src: int, dst: int, rank: int, edge: Dict, override: bool) -> None:
        if not self.graph.has_edge(src, dst):
            raise ValueError("Edge not exists.")
        edge_attrs = self.graph[src][dst]
        for idx, e in edge_attrs.items():
            if idx == rank:
                for k, v in e.items():
                    if not override or k not in edge:
                        edge[k] = v
                attrs = {(src, dst, idx): edge}
                nx.set_edge_attributes(self.graph, attrs)

    def _delete_edges(self, src_dst_rank: List[Tuple]) -> None:
        # 遍历每个(源实体ID, 目标实体ID, 排序值)元组
        for sdr in src_dst_rank:
            # 从图中移除指定的边
            self.graph.remove_edge(sdr[0], sdr[1], sdr[2])

    @property
    def node_ids(self) -> Iterable[int]:
        """
        获取图中所有节点的可迭代对象。

        Returns:
            Iterable[int]: 包含图中所有节点的可迭代对象。
        """
        return [node_id for node_id in self.graph.nodes]

    def _search_node_by_id(self, node_id: int) -> Dict[str, Any]:
        """
        根据给定的节点ID在图中搜索并返回该节点的属性字典。

        Args:
            node_id (int): 要搜索的节点的ID。

        Returns:
            Dict[str, Any]: 包含指定节点所有属性的字典。
        """
        return self.graph.nodes[node_id]

    def _search_node_by_ids(self, node_ids: List[int]) -> List[Dict[str, Any]]:
        """
        根据给定的节点ID列表在图中搜索并返回对应的节点属性字典列表。

        Args:
            node_ids (List[int]): 要搜索的节点的ID列表。

        Returns:
            List[Dict]: 包含指定节点所有属性的字典列表。
        """
        # 遍历节点ID列表，从图中获取每个节点的属性字典
        return {node_id: self.graph.nodes[node_id] for node_id in node_ids}

    def _search_node_by_property(self, properties: Dict[str, Any]) -> List[int]:
        """
        根据给定的属性字典搜索图中的节点。

        Args:
            properties (Dict): 用于搜索的属性字典，键为属性名，值为属性值。

        Returns:
            List[int]: 满足所有给定属性条件的节点ID列表。
        """
        # 生成一个生成器，用于获取每个属性值对应的节点集合
        node_sets = (self.index.get().get(p, {}).get(self._upper_case(v), set()) for p, v in properties.items())
        # 对所有节点集合取交集，并将结果转换为列表返回
        return list(set.intersection(*node_sets))

    def _in_attributes(self, properties: Dict, attrs: Dict) -> bool:
        """
        检查给定的属性字典中的所有键值对是否都存在于目标属性字典中，并且值相等（忽略大小写）。

        Args:
            properties (Dict): 待检查的属性字典，键为属性名，值为属性值。
            attrs (Dict): 目标属性字典，键为属性名，值为属性值。

        Returns:
            bool: 如果所有键值对都存在于目标属性字典中，并且值相等（忽略大小写），则返回 True；否则返回 False。
        """
        # 遍历待检查的属性字典中的每个键值对
        for k, v in properties.items():
            # 检查键是否存在于目标属性字典中，并且对应的值是否相等（忽略大小写）
            if k not in attrs or self._upper_case(v) != self._upper_case(attrs[k]):
                # 如果不满足条件，则返回 False
                return False
        # 如果所有键值对都满足条件，则返回 True
        return True

    def _search_node_complex(self, properties: Dict, edges: List[Tuple[Dict, Dict, Dict]]) -> List[int]:
        """
        根据给定的属性和边的条件进行复杂的节点搜索。

        Args:
            properties (Dict): 用于筛选节点的属性字典，键为属性名，值为属性值。
            edges (List[Tuple[Dict, Dict, Dict]]): 用于筛选节点的边的列表，每个边由三个字典组成，分别代表源节点属性、边属性和目标节点属性。

        Returns:
            List[int]: 满足所有属性和边条件的节点ID列表。
        """
        # 根据属性条件搜索节点ID
        node_ids = self.search_node_by_property(properties)
        # 存储最终满足条件的节点ID
        results = []
        # 遍历所有可能的节点ID
        for ind in node_ids:
            # 存储当前节点的候选边
            candidate_edges = []
            # 遍历当前节点的所有入边
            for nbr, d in self.graph.pred[ind].items():
                # 遍历入边的所有属性
                for idx, dd in d.items():
                    # 将入边信息添加到候选边列表中
                    candidate_edges.append([self.graph.nodes[nbr], dd, self.graph.nodes[ind]])
            # 遍历当前节点的所有出边
            for nbr, d in self.graph.succ[ind].items():
                # 遍历出边的所有属性
                for idx, dd in d.items():
                    # 将出边信息添加到候选边列表中
                    candidate_edges.append([self.graph.nodes[ind], dd, self.graph.nodes[nbr]])
            # 标记是否所有边都在候选边中
            edge_all_in_candidate = True
            # 遍历所有需要匹配的边
            for edge in edges:
                # 过滤出满足属性条件的边
                find_edges = list(filter(lambda ce: self._in_attributes(edge[0], ce[0]) \
                                         and self._in_attributes(edge[1], ce[1]) \
                                         and self._in_attributes(edge[2], ce[2]), \
                                         candidate_edges))
                # 如果没有找到满足条件的边
                if not find_edges:
                    # 标记为不满足条件
                    edge_all_in_candidate = False
                    # 跳出循环
                    break
            # 如果所有边都满足条件
            if edge_all_in_candidate:
                # 将当前节点ID添加到结果列表中
                results.append(ind)
        # 返回满足所有条件的节点ID列表
        return results

    def _merge_node(self, src: int, dst: int) -> None:
        """
        将源节点合并到目标节点。

        Args:
            src (int): 源节点的ID。
            dst (int): 目标节点的ID。

        Returns:
            None
        """
        # 获取源节点的属性
        src_attrs = self.graph.nodes[src]
        # 获取目标节点的属性
        dst_attrs = self.graph.nodes[dst]
        # 遍历源节点的属性
        for k, v in src_attrs.items():
            # 如果目标节点中不存在该属性
            if k not in dst_attrs:
                # 将该属性添加到目标节点的属性中
                dst_attrs[k] = v
        # 更新目标节点的属性
        nx.set_node_attributes(self.graph, {dst: dst_attrs})
        # 更新目标节点的倒排索引
        self._update_index(dst_attrs, dst)
        # 处理源节点的入边
        for nbr, d in self.graph.pred[src].items():
            # 如果目标节点与邻居节点之间不存在边
            if not self.graph.has_edge(nbr, dst):
                # 插入边
                self.insert_edges([(nbr, dst)] * len(d.items()), [dd for _, dd in d.items()])
            else:
                # 获取目标节点与邻居节点之间已存在的边
                exist_edges = self.search_edge_by_id(nbr, dst)
                # 遍历源节点与邻居节点之间的边
                for _, dd in d.items():
                    # 如果该边不在已存在的边列表中
                    if not self._edge_in_list(dd, exist_edges):
                        # 插入边
                        self.insert_edge(nbr, dst, dd)
        # 处理源节点的出边
        for nbr, d in self.graph.succ[src].items():
            # 如果目标节点与邻居节点之间不存在边
            if not self.graph.has_edge(dst, nbr):
                # 插入边
                self.insert_edges([(dst, nbr)] * len(d.items()), [dd for _, dd in d.items()])
            else:
                # 获取目标节点与邻居节点之间已存在的边
                exist_edges = self.search_edge_by_id(dst, nbr)
                # 遍历源节点与邻居节点之间的边
                for _, dd in d.items():
                    # 如果该边不在已存在的边列表中
                    if not self._edge_in_list(dd, exist_edges):
                        # 插入边
                        self.insert_edge(dst, nbr, dd)
        # 删除源节点
        self.delete_node(src)

    def _search_edge_by_id(self, src: int, dst: int) -> Dict[int, Dict]:
        """
        根据源节点ID和目标节点ID搜索图中的边。

        Args:
            src (int): 源节点的ID。
            dst (int): 目标节点的ID。

        Returns:
            Dict[int, Dict]: 包含边的排序值和对应边属性的字典。
        """
        return self.graph[src][dst]

    def _is_same_edge(self, edge: Dict, target_edge: Dict) -> bool:
        """
        检查两条边是否相同。

        Args:
            edge (Dict): 要检查的边，以字典形式表示。
            target_edge (Dict): 目标边，以字典形式表示。

        Returns:
            bool: 如果两条边的字典表示完全相同，则返回 True；否则返回 False。
        """
        return edge == target_edge

    def _could_edge_align_to(self, edge: Dict, target_edge: Dict) -> bool:
        """
        检查一条边是否可以与目标边对齐。

        此方法通过检查给定边的所有键值对是否都存在于目标边中，
        并且对应的值相等来判断两条边是否可以对齐。

        Args:
            edge (Dict): 要检查的边，以字典形式表示，键为属性名，值为属性值。
            target_edge (Dict): 目标边，以字典形式表示，键为属性名，值为属性值。

        Returns:
            bool: 如果给定边的所有键值对都存在于目标边中，并且对应的值相等，则返回 True；否则返回 False。
        """
        # 检查给定边的所有键值对是否都存在于目标边中，并且对应的值相等
        return all(k in target_edge and target_edge[k] == v for k, v in edge.items())

    def _edge_in_list(self, edge: Dict, edge_list: Dict[int, Dict]) -> bool:
        """
        检查指定的边是否存在于边列表中。

        Args:
            edge (Dict): 要检查的边，以字典形式表示。
            edge_list (Dict[int, Dict]): 边列表，字典的键为某种标识，值为边的字典表示。

        Returns:
            bool: 如果指定的边存在于边列表中，则返回 True；否则返回 False。
        """
        # 如果边列表为空，则直接返回 False
        if not edge_list:
            return False
        # 遍历边列表中的每个边，使用 _is_same_edge 方法检查是否与指定边相同
        # 如果找到相同的边，则返回 True，否则返回 False
        return any(self._is_same_edge(e, edge) for e in edge_list.values())

    def _upsert_node(self,
                     node: Dict,
                     properties_for_search: Dict,
                     align_method: str = 'same_properties',
                     edges_for_alignment: List[Tuple[Dict, Dict, Dict]] = None,
                     override: bool = True
                     ) -> int:
        """
        插入或更新节点。如果节点存在，则根据指定的对齐方法更新节点；如果不存在，则插入新节点。

        Args:
            node (Dict): 要插入或更新的节点的属性字典。
            properties_for_search (Dict): 用于搜索现有节点的属性字典。
            align_method (str, optional): 对齐方法，可选值为 'same_properties' 或 'same_edges'。默认为 'same_properties'。
            edges_for_alignment (List[Tuple[Dict, Dict, Dict]], optional): 用于对齐的边的列表，每个边由三个字典组成，
                分别代表源节点属性、边属性和目标节点属性。默认为 None。
            override (bool): 如果属性已存在时, 可以选择False(then will skip)或者True(then will update)

        Returns:
            int: 插入或更新的节点的 ID。
        """
        # 初始化节点 ID 列表
        node_ids = None
        # 根据对齐方法选择不同的搜索方式
        if align_method == 'same_properties':
            # 使用属性搜索节点
            node_ids = self._search_node_by_property(properties_for_search)
        elif align_method == 'same_edges':
            # 使用属性和边的条件进行复杂搜索
            node_ids = self._search_node_complex(properties_for_search, edges_for_alignment)
        # 如果没有找到匹配的节点
        if not node_ids:
            # 插入新节点
            node_id = self._insert_node(node)
            # 返回新节点的 ID
            return node_id
        # 如果找到多个匹配的节点
        if len(node_ids) > 1:
            # 记录警告信息
            logger.warning("More than 1 nodes found while updating.")
            # 记录找到的节点 ID 列表
            logger.warning(str(node_ids))
        # 更新找到的第一个节点
        self.update_node(node_ids[0], node, override)
        # 返回更新的节点的 ID
        return node_ids[0]

    def _upsert_edge(self, src: int, dst: int, edge: Dict,
                     edge_properties_for_alignment: Dict,
                     override: bool = True) -> int:
        """
        插入或更新边。如果边不存在，则插入新边；如果存在，则根据指定的属性对齐并更新边。

        Args:
            src (int): 源节点的ID。
            dst (int): 目标节点的ID。
            edge (Dict): 要插入或更新的边的属性字典。
            edge_properties_for_alignment (Dict): 用于对齐的边属性字典。
            override (bool, optional): 如果属性已存在时，是否覆盖。默认为 True。

        Returns:
            int: 插入或更新的边的排序值。
        """
        # 检查源节点和目标节点之间是否不存在边
        if not self.graph.has_edge(src, dst):
            # 如果不存在边，则插入新边，并返回边的相关信息
            return self.graph.add_edge(src, dst, **edge)
        else:
            # 获取源节点和目标节点之间的所有边的属性
            edge_attrs = self.graph[src][dst]
            # 如果用于对齐的边属性字典为空，则使用要插入或更新的边的属性字典
            if not edge_properties_for_alignment:
                edge_properties_for_alignment = edge
            # 遍历源节点和目标节点之间的所有边
            for idx, e in edge_attrs.items():
                # 检查要插入或更新的边的属性是否可以与当前边对齐
                if self._could_edge_align_to(edge_properties_for_alignment, e):
                    # 遍历当前边的属性
                    for k, v in e.items():
                        # 如果不允许覆盖属性，或者属性不在要插入或更新的边的属性中
                        if not override or k not in edge:
                            # 将当前边的属性添加到要插入或更新的边的属性中
                            edge[k] = v
                    # 构建要更新的边的属性字典
                    attrs = {(src, dst, idx): edge}
                    # 更新边的属性
                    nx.set_edge_attributes(self.graph, attrs)
                    # 返回更新的边的排序值
                    return idx
            # 如果没有找到匹配的边，插入新边
            return self.graph.add_edge(src, dst, **edge)

    def _get_node_name(self, node: Dict, name_properties: Union[str, List] = None) -> str:
        """
        根据指定的属性名称从节点字典中获取节点名称。

        Args:
            node (Dict): 节点的属性字典，包含各种属性键值对。
            name_properties (Union[str, List], optional): 用于获取节点名称的属性名或属性名列表。
                如果为 None，则默认使用 ['名称']。默认为 None。

        Returns:
            str: 节点的名称。如果指定的属性都不存在于节点字典中，则返回 '未知'。
        """
        # 如果未指定属性名称，使用默认的属性名称列表
        if name_properties is None:
            name_properties = ['名称']
        # 如果 name_properties 是一个字符串，直接从节点字典中获取该属性的值
        if isinstance(name_properties, str):
            return node[name_properties]
        # 如果 name_properties 是一个列表，遍历列表中的属性名称
        elif isinstance(name_properties, List):
            for property in name_properties:
                # 如果属性名称存在于节点字典中，返回该属性的值
                if property in node:
                    return node[property]
        # 如果所有指定的属性名称都不存在于节点字典中，返回 '未知'
        return '未知'

    def _find_predecessor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        return self.graph.pred[node_id]

    def _find_successor(self, node_id: int) -> Dict[int, Dict[int, Dict[str, Any]]]:
        return self.graph.succ[node_id]

    def subgraph(self, center_nodes: list,
                 name_properties: list = ["名称", "简称", "英文名称", "英文简称"],
                 max_depth=1,
                 max_children=None,
                 with_property=True,
                 node_filter=None,
                 edge_filter=None) -> dict:
        """
        生成以给定节点为中心的子图

        参数:
            center_nodes (list): 子图的中心节点列表
            name_properties (list): 用于获取节点名称的属性列表，默认为["名称", "简称", "英文名称", "英文简称"]
            max_depth (int): 子图的最大深度，默认为1
            max_children (int): 每个节点的最大子节点数，默认为None
            with_property (bool): 是否包含节点属性，默认为True
            node_filter (list): 节点过滤器，默认为None
            edge_filter (list): 边过滤器，默认为None

        返回:
            dict: 包含子图节点和边的字典
        """
        # 存储子图的节点
        nodes = []
        # 存储子图的边
        links = []
        # 记录边的出现次数，用于设置边的弯曲度
        link_count = {}
        # 最终要返回的子图数据结构，包含节点和边
        graph = {"nodes": [], "links": []}
        # 子图节点的自增ID
        subgraph_auto_increment_id = 0
        # 存储节点ID到子图节点ID的映射
        subgraph_id_map = {}
        # 定义节点颜色列表，用于节点可视化
        colors = ['#FFFFFF', '#000000', '#87CEEB', '#FFFF00', '#FF0000',
                  '#9932CC', '#FFB6C1', '#00FF00', '#C0C0C0', '#00008B',
                  '#FF4500', '#98FB98', '#D8BFD8', '#DAA520', '#FFA500',
                  '#6495ED', '#006400', '#00BFFF', '#FF1493', '#8B4513', ]

        def get_subgraph_node_id(key):
            """
            获取子图节点的唯一ID

            参数:
                key: 节点的键

            返回:
                int: 子图节点的唯一ID
            """
            # 如果节点ID不在映射中，分配一个新的自增ID
            if key not in subgraph_id_map:
                nonlocal subgraph_auto_increment_id
                subgraph_id_map[key] = subgraph_auto_increment_id
                subgraph_auto_increment_id = subgraph_auto_increment_id + 1
            return subgraph_id_map[key]

        def get_default(d, default, *keys):
            """
            获取字典中的默认值

            参数:
                d: 字典
                default: 默认值
                *keys: 键列表

            返回:
                字典中的值或默认值
            """
            dd = d
            # 遍历键列表，查找对应的值
            for k in keys:
                if (not isinstance(dd, dict)) or (k not in dd):
                    return default
                dd = dd[k]
            return dd

        def set_value(d, v, *keys):
            """
            设置字典中的值

            参数:
                d: 字典
                v: 值
                *keys: 键列表
            """
            dd = d
            # 遍历键列表，设置对应的值
            for i in range(len(keys) - 1):
                if keys[i] not in dd:
                    dd[keys[i]] = {}
                dd = dd[keys[i]]
            dd[keys[-1]] = v

        # 计数器
        i = 0
        # 如果存在中心节点
        if center_nodes:
            # 去重
            center_nodes = list(set(center_nodes))
            # 初始化队列，用于广度优先搜索
            nodes_queue = queue.Queue()
            # 记录已访问的节点
            visited = set()
            # 将中心节点加入队列和已访问集合
            for center_node in center_nodes:
                nodes_queue.put((center_node, 0))
                visited.add(center_node)
            # 属性节点的起始ID
            property_index = max(self.graph.nodes) + 1
            # 开始广度优先搜索
            while not nodes_queue.empty():
                # 从队列中取出节点和深度
                (e, depth) = nodes_queue.get()
                # 如果节点不存在属性，跳过
                if not self.graph.nodes[e]:
                    continue
                # 如果节点没有类型属性，跳过
                if '类型' not in self.graph.nodes[e]:
                    continue
                # 将节点添加到子图节点列表
                nodes.append({
                    "id": get_subgraph_node_id(e),
                    "name": self._get_node_name(self.graph.nodes[e]),
                    "symbolSize": 20,
                    "x": (random.random() - 0.5) * 500,
                    "y": (random.random() - 0.5) * 500,
                    "value": self.graph.nodes[e]['类型'],
                    "itemStyle": {
                        "color": colors[hash(self._get_node_name(self.graph.nodes[e])) % len(colors)],
                    }
                })
                i = i + 1
                # 如果需要包含节点属性
                if with_property:
                    # 遍历节点的属性
                    for k, v in self.graph.nodes[e].items():
                        # 将属性节点添加到子图节点列表
                        nodes.append({
                            "id": get_subgraph_node_id(property_index),
                            "name": v,
                            "symbolSize": 20,
                            "x": (random.random() - 0.5) * 500,
                            "y": (random.random() - 0.5) * 500,
                            "value": k,
                            "itemStyle": {
                                "color": colors[hash(v) % len(colors)],
                            }
                        })
                        # 获取边的出现次数
                        c = get_default(link_count, 0, int(e), property_index)
                        # 将属性节点和原节点之间的边添加到子图边列表
                        links.append({
                            "value": k,
                            "source": get_subgraph_node_id(e),
                            "target": get_subgraph_node_id(property_index),
                            "label": {
                                "show": True
                            },
                            "lineStyle": {
                                "curveness": 0 + 0.2 * c
                            }
                        })
                        # 更新边的出现次数
                        set_value(link_count, c + 1, int(e), property_index)
                        property_index += 1
                i = i + 1
                # 如果当前深度小于最大深度
                if depth < max_depth:
                    # 记录子节点数量
                    n_children = 0
                    # 遍历节点的入边
                    for nbr, d in self.graph.pred[e].items():
                        # 如果子节点数量达到最大限制，跳出循环
                        if max_children and n_children >= max_children:
                            break
                        # 如果节点不满足过滤器条件，跳过
                        if node_filter and ('类型' not in self.graph.nodes[nbr] or \
                                            self.graph.nodes[nbr]['类型'] not in node_filter):
                            continue
                        # 标记边是否满足条件
                        edge_flag = False
                        # 遍历入边的属性
                        for idx, dd in d.items():
                            # 如果边不满足过滤器条件，跳过
                            if edge_filter and ('类型' not in dd or dd['类型'] not in edge_filter):
                                continue
                            else:
                                edge_flag = True
                        # 如果边不满足条件，跳过
                        if not edge_flag:
                            continue
                        n_children = n_children + 1
                        # 如果节点未访问过
                        if nbr not in visited:
                            # 将节点加入队列和已访问集合
                            nodes_queue.put((nbr, depth + 1))
                            visited.add(nbr)
                            # 遍历入边的属性
                            for _, dd in d.items():
                                # 获取边的出现次数
                                c = get_default(link_count, 0, int(e), int(nbr))
                                # 将入边添加到子图边列表
                                links.append({
                                    "value": dd['类型'],
                                    "source": get_subgraph_node_id(nbr),
                                    "target": get_subgraph_node_id(e),
                                    "label": {
                                        "show": True
                                    },
                                    "lineStyle": {
                                        "curveness": 0 + 0.2 * c
                                    }
                                })
                                set_value(link_count, c + 1, int(e), int(nbr))
                    n_children = 0
                    for nbr, d in self.graph.succ[e].items():
                        if max_children and n_children >= max_children:
                            break
                        if node_filter and ('类型' not in self.graph.nodes[nbr] or \
                                            self.graph.nodes[nbr]['类型'] not in node_filter):
                            continue
                        edge_flag = False
                        for idx, dd in d.items():
                            if edge_filter and ('类型' not in dd or dd['类型'] not in edge_filter):
                                continue
                            else:
                                edge_flag = True
                        if not edge_flag:
                            continue
                        n_children = n_children + 1
                        if nbr not in visited:
                            nodes_queue.put((nbr, depth + 1))
                            visited.add(nbr)
                            for idx, dd in d.items():
                                c = get_default(link_count, 0, int(e), int(nbr))
                                links.append({
                                    "value": dd['类型'],
                                    "source": get_subgraph_node_id(e),
                                    "target": get_subgraph_node_id(nbr),
                                    "label": {
                                        "show": True
                                    },
                                    "lineStyle": {
                                        "curveness": 0 + 0.2 * c
                                    }
                                })
                                set_value(link_count, c + 1, int(e), int(nbr))
            nodes.sort(key=lambda nd: nd['id'])
            graph = {"nodes": nodes, "links": links}
        return graph

    def _collect_triples(self, center_nodes: list,
                         name_properties: list = ["名称", "简称", "英文名称", "英文简称"],
                         max_depth=1,
                         max_children=None,
                         with_property=True,
                         node_filter=None,
                         edge_filter=None) -> List[List[str]]:
        """
        收集以给定节点为中心的三元组

        参数:
            center_nodes (list): 中心节点列表
            name_properties (list): 用于获取节点名称的属性列表，默认为["名称", "简称", "英文名称", "英文简称"]
            max_depth (int): 子图的最大深度，默认为1
            max_children (int): 每个节点的最大子节点数，默认为None
            with_property (bool): 是否包含节点属性，默认为True
            node_filter (list): 节点过滤器，默认为None
            edge_filter (list): 边过滤器，默认为None

        返回:
            List[List[str]]: 三元组列表，每个三元组包含主语、谓语和宾语
        """
        # 初始化三元组列表
        triples = []
        # 计数器
        i = 0
        # 如果存在中心节点
        if center_nodes:
            # 对中心节点列表去重
            center_nodes = list(set(center_nodes))
            # 初始化队列，用于广度优先搜索
            nodes_queue = queue.Queue()
            # 记录已访问的节点
            visited = set()
            # 将中心节点加入队列和已访问集合
            for center_node in center_nodes:
                nodes_queue.put((center_node, 0))
                visited.add(center_node)
            # 开始广度优先搜索
            while not nodes_queue.empty():
                # 从队列中取出节点和深度
                (e, depth) = nodes_queue.get()
                # 如果节点不存在属性，跳过
                if not self.graph.nodes[e]:
                    continue
                # 如果节点没有类型属性，跳过
                if '类型' not in self.graph.nodes[e]:
                    continue
                # 获取节点的属性
                attr = self.graph.nodes[e]
                # 获取节点的名称
                ent_name = self._get_node_name(attr, name_properties)
                # 如果需要包含节点属性
                if with_property:
                    # 遍历节点的属性
                    for p, v in attr.items():
                        # 将节点属性作为三元组添加到结果列表
                        triples.append([str(ent_name), str(p), str(v)])
                i = i + 1
                # 如果当前深度小于最大深度
                if depth < max_depth:
                    # 记录子节点数量
                    n_children = 0
                    # 遍历节点的入边
                    for nbr, d in self.graph.pred[e].items():
                        # 如果子节点数量达到最大限制，跳出循环
                        if max_children and n_children >= max_children:
                            break
                        # 如果节点不满足过滤器条件，跳过
                        if node_filter and ('类型' not in self.graph.nodes[nbr] or \
                                            self.graph.nodes[nbr]['类型'] not in node_filter):
                            continue
                        # 标记边是否满足条件
                        edge_flag = False
                        # 遍历入边的属性
                        for idx, dd in d.items():
                            # 如果边不满足过滤器条件，跳过
                            if edge_filter and ('类型' not in dd or dd['类型'] not in edge_filter):
                                continue
                            else:
                                edge_flag = True
                        # 如果边不满足条件，跳过
                        if not edge_flag:
                            continue
                        n_children = n_children + 1
                        # 如果节点未访问过
                        if nbr not in visited:
                            # 将节点加入队列和已访问集合
                            nodes_queue.put((nbr, depth + 1))
                            visited.add(nbr)
                        # 遍历入边的属性
                        for idx, ee in d.items():
                            # 过滤掉类型和id属性
                            dd = list(filter(lambda x: x[0] != '类型' and x[0] != 'id', ee.items()))
                            # 将属性键值对转换为字符串
                            dd = list(map(lambda x: ':'.join(x), dd))
                            # 初始化边属性字符串
                            edge_attr_str = ''
                            # 如果存在边属性
                            if dd:
                                # 拼接边属性字符串
                                edge_attr_str = '(' + ",".join(dd) + ')'
                            # 如果边存在类型属性
                            if '类型' in ee:
                                # 将入边信息作为三元组添加到结果列表
                                triples.append([str(self._get_node_name(self.graph.nodes[nbr], name_properties)),
                                                str(ee['类型'] + edge_attr_str), str(ent_name)])
                    # 重置子节点数量计数器
                    n_children = 0
                    # 遍历节点的出边
                    for nbr, d in self.graph.succ[e].items():
                        # 如果子节点数量达到最大限制，跳出循环
                        if max_children and n_children >= max_children:
                            break
                        # 如果节点不满足过滤器条件，跳过
                        if node_filter and ('类型' not in self.graph.nodes[nbr] or \
                                            self.graph.nodes[nbr]['类型'] not in node_filter):
                            continue
                        # 标记边是否满足条件
                        edge_flag = False
                        # 遍历出边的属性
                        for idx, dd in d.items():
                            # 如果边不满足过滤器条件，跳过
                            if edge_filter and ('类型' not in dd or dd['类型'] not in edge_filter):
                                continue
                            else:
                                edge_flag = True
                        # 如果边不满足条件，跳过
                        if not edge_flag:
                            continue
                        n_children = n_children + 1
                        # 如果节点未访问过
                        if nbr not in visited:
                            # 将节点加入队列和已访问集合
                            nodes_queue.put((nbr, depth + 1))
                            visited.add(nbr)
                        # 遍历出边的属性
                        for idx, ee in d.items():
                            # 过滤掉类型和id属性
                            dd = list(filter(lambda x: x[0] != '类型' and x[0] != 'id', ee.items()))
                            # 将属性键值对转换为字符串
                            dd = list(map(lambda x: ':'.join(x), dd))
                            # 初始化边属性字符串
                            edge_attr_str = ''
                            # 如果存在边属性
                            if dd:
                                # 拼接边属性字符串
                                edge_attr_str = '(' + ",".join(dd) + ')'
                            # 如果边存在类型属性
                            if '类型' in ee:
                                # 将出边信息作为三元组添加到结果列表
                                triples.append([str(ent_name), str(ee['类型'] + edge_attr_str),
                                                str(self._get_node_name(self.graph.nodes[nbr], name_properties))])
        # 返回收集到的三元组列表

        return triples

    def _delete_ds(self) -> KBXError:
        """
        删除图数据库存储实例。

        此方法旨在删除当前的图数据库存储实例，
        并返回一个表示操作结果的 KBXError 对象。
        在当前实现中，无论实际操作是否成功，
        都会返回一个表示成功的 KBXError 对象。

        Returns:
            KBXError: 表示操作结果的错误对象，
                      此处返回的是一个表示成功的错误对象。
        """
        self._connection_pool.clear_connection()
        return KBXError(code=KBXError.Code.SUCCESS)

    def get_type(self) -> str:
        """
        获取当前图数据库存储实例的类型。

        此方法用于返回当前图数据库存储实例所使用的类型，
        在本实现中，固定返回 "networkx"，表示使用 NetworkX 作为图数据库的存储方式。

        Returns:
            str: 表示图数据库存储类型的字符串，这里为 "networkx"。
        """
        return "networkx"
