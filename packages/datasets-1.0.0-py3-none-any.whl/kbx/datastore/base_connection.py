from abc import ABC, abstractmethod
from typing import Any, Dict


class BaseConnection(ABC):

    def __init__(self, args: Dict[str, Any] = None):
        """
        因为连接池的作用，构造函数需要创建并打开
        """
        self.args = args

    def __del__(self):
        """
        因为连接池的作用，析构函数并不做任何实质性的关闭
        """
        pass

    def close(self):
        """
        连接池中的连接真正失效时，关闭并清理连接的所有资源
        """
        pass

    def flush(self):
        """
        持久化连接所打开的数据
        """
        pass

    @abstractmethod
    def get(self, key: str = None) -> Any:
        """
        业务逻辑调用get方法获取相应的连接
        """
        raise NotImplementedError
