from __future__ import annotations

from abc import abstractmethod
from typing import Dict, List, Tuple, Any, Optional
from kbx.common.types import KBXError, StructuredDSConfig
from kbx.datastore.base_ds import BaseDS, check_connected
from kbx.datastore.path_factory import PathFactory


class BaseStructuredDS(BaseDS):

    def __init__(self, config: StructuredDSConfig, kb_id: str, index_type: str, namespace: str):
        super().__init__(kb_id, index_type, namespace)
        self._config: StructuredDSConfig = config
        self._path_factory = PathFactory(config, self.tenant_id, self.user_id, kb_id, index_type, namespace)
        self._base_dir = self._path_factory.path_r2a()

    def _connect(self) -> None:
        pass

    def _close(self) -> None:
        pass

    def __enter__(self) -> BaseStructuredDS:
        return super().__enter__()

    def __exit__(self, exc_type: Optional[BaseException], exc_val: Any, exc_tb: Any) -> bool:
        return super().__exit__(exc_type=exc_type, exc_val=exc_val, exc_tb=exc_tb)

    @check_connected
    def create_table(self, table_name: str, attr: Dict[str, Tuple[str, bool, str, str]],
                     key: Dict[str, Any] = None,
                     index: Dict[str, List[str]] = None,
                     comment: str = "") -> KBXError:
        """
        在当前的 namespace 中创建 table.
        要求建表时有长整形自增的id(主键), 如果没有该字段或该字段的type不为长整形自增，会自动添加id属性或变更id为长整型自增类型.

        Args:
            table_name (str): 待创建的 table 名称.
            attr (Dict[str, Tuple(str, bool, str, str)]): 描述表的属性 (attr_name
                -> attr_description (attr_type, is_not_null, default_value, comment))
            key (Dict): 描述主键和外键的特性
                main_key: (key_name, is_auto_increment) 元组.
                foreign_key_list: [(key_name, foreign_table, foreign_table_key)] 列表.
            index (Dict[str, List[str]): 描述表的索引特性 (index_name -> related_column_name_list(column_name))
            comment (str): 表信息的补充性描述

        Returns:
            是否创建成功.

        """
        return self._create_table(table_name, attr, key, index, comment)

    @abstractmethod
    def _create_table(self, table_name: str, attr: Dict[str, Tuple[str, bool, str, str]],
                      key: Dict[str, Any] = None,
                      index: Dict[str, List[str]] = None,
                      comment: str = "") -> KBXError:
        raise NotImplementedError

    @check_connected
    def drop_table(self, table_name: str) -> KBXError:
        """
        在当前的 namespace 中删除 table_name 指定的 table.

        Args:
            table_name (str): 待删除的 table 名称.

        Returns:
            是否删除成功.

        """
        return self._drop_table(table_name)

    @abstractmethod
    def _drop_table(self, table_name: str) -> KBXError:
        raise NotImplementedError

    @check_connected
    def batch_insert(self, item_list: List[Dict], table_name: str) -> KBXError:
        """
        insert方法的batch版本.

        Args:
            item_list (List[Dict]):
            table_name (str):

        Returns:

        """
        return self._batch_insert(item_list, table_name)

    @abstractmethod
    def _batch_insert(self, item_list: List[Dict], table_name: str) -> KBXError:
        raise NotImplementedError

    def insert(self, item: Dict, table_name: str) -> KBXError:
        """
        向table所指向的表中插入一条item表项.

        Args:
            item (Dict): 表项描述.
            table_name (str): 表名称.

        Returns:
            是否插入成功.

        """
        return self.batch_insert([item], table_name)

    @check_connected
    def batch_upsert(self, item_list: List[Dict], table_name: str) -> KBXError:
        """
        upsert方法的batch版本.

        Args:
            item_list (List[Dict]):
            table_name (str):

        Returns:

        """

    @abstractmethod
    def _batch_upsert(self, item_list: List[Dict], table_name: str) -> KBXError:
        raise NotImplementedError

    def upsert(self, item: Dict, table_name: str) -> KBXError:
        """
        向table所指向的表中更新插入一条item表项.

        Args:
            item (Dict): 描述待更新插入的item，其中id字段必须显式给出.
            table_name (str): 表名称.

        Returns:
            是否更新插入成功.
        """
        return self.batch_upsert([item], table_name)

    @check_connected
    def batch_update(self, item_list: List[Dict], table_name: str) -> KBXError:
        """
        update方法的batch版本.

        Args:
            item_list (List[Dict]):
            table_name (str):

        Returns:

        """
        return self._batch_update(item_list, table_name)

    @abstractmethod
    def _batch_update(self, item_list: List[Dict], table_name: str) -> KBXError:
        raise NotImplementedError

    def update(self, item: dict, table_name: str) -> KBXError:
        """
        更新table中的一个item.

        Args:
            item (dict): 描述待更新的item，其中id字段必须显式给出.
            table_name (str): 表名称.

        Returns:
            是否更新成功.

        """
        return self.batch_update([item], table_name)

    @check_connected
    def batch_delete(self, item_ids: List[str], table_name: str) -> KBXError:
        """
        delete方法的batch版本.

        Args:
            item_ids (List[str]): 待删除的id列表.
            table_name (str): 待操作的表名称.

        Returns:

        """
        return self._batch_delete(item_ids, table_name)

    @abstractmethod
    def _batch_delete(self, item_ids: List[str], table_name: str) -> KBXError:
        raise NotImplementedError

    def delete(self, item_id: str, table_name: str) -> KBXError:
        """
        从table_name所示的表中删除item_id所示的表项.
        item_id 为创建表时自动添加的主键id. 即只能依据id(这里id必须为主键)删除.

        Args:
            item_id (str): 待删除的id.
            table_name (str): 待操作的表名称.

        Returns:
            是否删除成功.
        """
        return self.batch_delete([item_id], table_name)

    @check_connected
    def select(self, target_list: List[str], table_name: str, condition_list: List[str]) -> Tuple[List[Dict], KBXError]:
        """
        用于单表查询.

        Args:
            target_list (List[str]):
            table_name (str):
            condition_list (List[str]):

        Returns:
            查询到的表项描述.

        """
        return self._select(target_list, table_name, condition_list)

    @abstractmethod
    def _select(self, target_list: List[str], table_name: str,
                condition_list: List[str]) -> Tuple[List[Dict], KBXError]:
        raise NotImplementedError

    @check_connected
    def select_multi_table(self,
                           target_list: List[str],
                           table_name_list: list[str],
                           each_table_target_list: List[List[str]],
                           each_table_condition_list: List[List[str]]) -> Tuple[List[dict], KBXError]:
        """
        用于关联查询.

        Args:
            target_list (List[str]): 需要查询的最终字段
            table_name_list (List[str]): 需要关联查询的所有table名称.
            each_table_target_list (List[List[str]]): 每个子表中需要提取的字段
            each_table_condition_list (List[List[str]]): 第X个table的查询条件

        Returns:

        """
        return self._select(target_list, table_name_list, each_table_target_list, each_table_condition_list)

    @abstractmethod
    def _select_multi_table(self,
                            target_list: List[str],
                            table_name_list: list[str],
                            each_table_target_list: List[List[str]],
                            each_table_condition_list: List[List[str]]) -> Tuple[List[dict], KBXError]:
        raise NotImplementedError

    @check_connected
    def show_tables(self) -> Tuple[List[str], KBXError]:
        """
        展示当前数据库中所有的表名称.

        Returns:
            表名称构成的列表.

        """
        return self._show_tables()

    @abstractmethod
    def _show_tables(self) -> Tuple[List[str], KBXError]:
        raise NotImplementedError

    @check_connected
    def show_create_table(self, table_name: str) -> Tuple[Tuple[List[Tuple[str, str, bool, str, str]], str], KBXError]:
        """
        展示当前数据库中某个表的构建语句.

        Args:
            table_name (str):

        Returns:
            Tuple(T1, T2)
                T1: Tuple(T11, T12)
                    T11 -> [(attr_name, attr_type, can_be_null, default_value, comment)].
                    T12 -> table_comment.
                T2: KBXError. 如果T1 is None, 检查KBXError来确认错误原因.

        """
        return self._show_create_table(table_name)

    @abstractmethod
    def _show_create_table(self, table_name: str) -> Tuple[Tuple[List[Tuple[str, str, bool, str, str]], str], KBXError]:
        raise NotImplementedError

    @check_connected
    def execute_sql(self, sql: str) -> Tuple[Dict, KBXError]:
        """
        直接执行调用者传入的SQL(StructureQueryLanguage).
        调用者需要捕获可能的异常.
        Args:
            sql (str):

        Returns:
            Tuple(T1, T2)
                T1: Dict [ "data": [ ${item} ] } ] 以select为例，item -> { ${column_name} : ${value} }
                T2: KBXError. { "code": , "msg": "" }
        """
        return self._execute_sql(sql)

    @abstractmethod
    def _execute_sql(self, sql: str) -> Tuple[Dict, KBXError]:
        raise NotImplementedError
