from __future__ import annotations

import os.path
import re
import logging
from typing import Any, Dict, List, Tuple
from sqlalchemy import create_engine, Engine, MetaData, text
from sqlalchemy import Table, Column, UniqueConstraint
from sqlalchemy import SmallInteger, Integer, BigInteger, String, Float, Date, Time, DateTime, Boolean, Text
from sqlalchemy import and_

from kbx.common.types import KBXError
from kbx.common.types import StructuredDSConfig
from kbx.datastore.structured.structured_base import BaseStructuredDS
from kbx.db.session import DBSession
from kbx.db.types import TableCommentORM
from uuid import uuid4

sql_to_sqlalchemy_types = {
    'INT': Integer,
    'INTEGER': Integer,
    'BIGINT': BigInteger,
    'SMALLINT': SmallInteger,
    'VARCHAR': String,
    'CHAR': String,
    'TEXT': Text,
    'FLOAT': Float,
    'DOUBLE': Float,
    'DECIMAL': Float,
    'NUMERIC': Float,
    'DATE': Date,
    'TIME': Time,
    'DATETIME': DateTime,
    'TIMESTAMP': DateTime,
    'BOOLEAN': Boolean,
    'BOOL': Boolean
}


def get_sqlalchemy_type(input_str: str) -> Any:
    input_str = input_str.upper()
    for key in sql_to_sqlalchemy_types.keys():
        # TODO: Date会有问题.
        if input_str.startswith(key):
            if key == "VARCHAR":
                match = re.match(r'VARCHAR\((\d+)\)', input_str, re.IGNORECASE)
                if match:
                    # 提取长度 N
                    length = int(match.group(1))
                    # 返回 SQLAlchemy 的 String 类型
                    return String(length)
                else:
                    raise ValueError(f"Invalid varchar format: {input_str}")
            return sql_to_sqlalchemy_types[key]
    raise ValueError(f"Unsupported SQL Type: {input_str}")


class SqlAlchemyStructuredDS(BaseStructuredDS):
    def __init__(self, config: StructuredDSConfig, kb_id: str, index_type: str, namespace: str):
        super().__init__(config, kb_id, index_type, namespace)
        logging.getLogger('sqlalchemy').setLevel(logging.WARNING)
        self._config = config
        if config.type == "sqlalchemy_sqlite":
            self._is_service = False
            self._is_external = False
            os.makedirs(self._base_dir, exist_ok=True)
            db_file_path = os.path.join(self._base_dir, "sqlite.db")
            self._url = f"sqlite:///{db_file_path}"
        elif config.type == "sqlalchemy_mysql":
            conn_args: Dict[str, Any] = config.connection_kwargs
            temp_url: str = f"mysql+pymysql://{conn_args['username']}:{conn_args['password']}@" \
                            f"{conn_args['host']}:{conn_args['port']}/"
            db_name = f"db_{kb_id.replace('-', '')}"
            engine = create_engine(temp_url)
            check_db_sql = text(f"SHOW DATABASES LIKE '{db_name}';")
            create_db_sql = text(
                f"CREATE DATABASE IF NOT EXISTS {db_name} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
            with engine.connect() as connection:
                # 检查数据库是否存在
                result = connection.execute(check_db_sql)
                if not result.fetchone():
                    connection.execute(create_db_sql)
            self._url: str = f"mysql+pymysql://{conn_args['username']}:{conn_args['password']}@" \
                             f"{conn_args['host']}:{conn_args['port']}/{db_name}"
            self._is_service = True
        else:
            raise RuntimeError(f"Not Supported Type: {config.type}")
        self._engine: Engine = create_engine(self._url, echo=False)

    @staticmethod
    def get_type() -> str:
        return "AlchemyStructuredDS"

    def _delete_ds(self) -> KBXError:
        if self._config.type == "sqlalchemy_sqlite":  # sqlite must save comment in other db.
            table_names: List[str] = self._show_tables()
            for table_name in table_names:
                self.__delete_comment(table_name)
        return KBXError()

    def _connect(self):
        pass

    def _close(self):
        pass

    def _flush(self):
        pass

    def _create_table(self, table_name: str, attr: Dict[str, Tuple[str, bool, str, str]],
                      key: Dict[str, Any] = None,
                      index: Dict[str, List[str]] = dict(),
                      comment: str = "") -> KBXError:
        try:
            # 只是为了兼容sqlite.
            if self._config.type == "sqlalchemy_sqlite":
                attr_comment = dict()
                for k, v in attr.items():
                    if v[3]:
                        attr_comment[k] = v[3]
                    else:
                        attr_comment[k] = ""
                attr_comment["id"] = "main key, v4 format uuid."
                error: KBXError = self.__save_comment(table_name, comment, attr_comment)
                if error.code != KBXError.Code.SUCCESS:
                    return error
            metadata: MetaData = MetaData()
            new_table = Table(table_name, metadata)
            new_table.append_column(Column("id", String(64), primary_key=True))
            # 设置列
            for key, value in attr.items():
                if key == "id":  # 跳过id
                    continue
                sqlalchemy_type = get_sqlalchemy_type(value[0])
                is_nullable = True if not value[1] or value[1] is True else False
                # print(key, value)
                new_table.append_column(
                    Column(name=key, type_=sqlalchemy_type, nullable=is_nullable, default=value[2], comment=value[3]))
            # 设置约束
            for key, value in index.items():
                new_table.append_constraint(
                    UniqueConstraint(*value, name=key))
            new_table.comment = comment
            metadata.create_all(self._engine)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _drop_table(self, table_name: str) -> KBXError:
        try:
            if self._config.type == "sqlalchemy_sqlite":
                error: KBXError = self.__delete_comment(table_name)
                if error.code != KBXError.Code.SUCCESS:
                    return error
            metadata: MetaData = MetaData()
            table = Table(table_name, metadata, autoload_with=self._engine)
            table.drop(self._engine, checkfirst=True)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _batch_insert(self, item_list: List[Dict], table_name: str) -> KBXError:
        try:
            metadata: MetaData = MetaData()
            table: Table = Table(table_name, metadata, autoload_with=self._engine)
            # use uuid4 to generate id.
            for item in item_list:
                item["id"] = uuid4().hex
            insert_stmt = table.insert().values(item_list)
            with self._engine.connect() as conn:
                conn.execute(insert_stmt)
                conn.commit()
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _batch_upsert(self, item_list: List[Dict], table_name: str) -> KBXError:
        try:
            metadata: MetaData = MetaData()
            table: Table = Table(table_name, metadata, autoload_with=self._engine)
            insert_stmt = table.insert().values(item_list)
            for item in item_list:
                if not item["id"]:
                    return False, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg="upsert operation depends on id.")
            item_copy = item.copy()
            del item_copy["id"]
            upsert_stmt = insert_stmt.on_conflict_do_update(
                index_elements=["id"],
                set_=item_copy
            )
            with self._engine.connect() as conn:
                conn.execute(upsert_stmt)
                conn.commit()
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _batch_update(self, item_list: List[Dict], table_name: str) -> KBXError:
        try:
            with self._engine.connect() as conn:
                transaction = conn.begin()
                metadata: MetaData = MetaData()
                table: Table = Table(table_name, metadata, autoload_with=self._engine)
                for item in item_list:
                    item_id: str = item["id"]
                    item_copy = item.copy()
                    del item_copy["id"]
                    update_stmt = table.update() \
                        .where(table.c.id == item_id) \
                        .values(**item_copy)
                    conn.execute(update_stmt)
                transaction.commit()
            return KBXError()
        except Exception as e:
            transaction.rollback()
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _batch_delete(self, item_ids: List[str], table_name: str) -> KBXError:
        try:
            metadata: MetaData = MetaData()
            table: Table = Table(table_name, metadata, autoload_with=self._engine)
            delete_stmt = table.delete().filter(table.c.id.in_(item_ids))
            with self._engine.connect() as conn:
                conn.execute(delete_stmt)
                conn.commit()
            return KBXError()
            # EngineSession = sessionmaker(bind=self._engine)
            # session = EngineSession()
            # rowcount = session.query(table).filter(table.c.id.in_(item_ids)).delete()
            # session.commit()
            # return rowcount == len(item_ids), KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _select(self,
                target_list: List[str],
                table_name: str,
                condition_list: List[str]) -> Tuple[List[Dict], KBXError]:
        try:
            metadata: MetaData = MetaData()
            metadata.reflect(bind=self._engine)
            table: Table = Table(table_name, metadata, autoload_with=self._engine)
            targets = []
            for target in target_list:
                if target == "*":
                    targets = [table.c[col.name] for col in table.c]
                    break
                else:
                    targets.append(table.c[target])
            select_stmt = table.select().with_only_columns(*targets)
            conditions = [text(condition) for condition in condition_list]
            combined_condition = and_(*conditions)
            select_stmt = select_stmt.where(combined_condition)
            with self._engine.connect() as conn:
                result = conn.execute(select_stmt)
            rows_as_dicts = [dict(row) for row in result.mappings()]
            return rows_as_dicts, KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _select_multi_table(self, target: List[str], table_names: List[str], table_target: List[List[str]],
                            conditions: List[List[str]]) -> Tuple[List[Dict], KBXError]:
        raise NotImplementedError

    def _show_tables(self) -> Tuple[List[str], KBXError]:
        try:
            metadata: MetaData = MetaData()
            metadata.reflect(bind=self._engine)
            all_tables: List[str] = list(metadata.tables.keys())
            return all_tables, KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def __clear_column_type(self, column_type: str) -> str:
        return column_type.upper().strip().split(" ")[0].strip()

    def _show_create_table(self, table_name: str) -> Tuple[Tuple[List[Tuple[str, str, bool, str, str]], str], KBXError]:
        try:
            attr_comment: Dict = None
            flag: bool = False  # sqlite
            if self._config.type == "sqlalchemy_sqlite":  # sqlite must save comment in other db.
                flag = True
                comment, attr_comment, error = self.__load_comment(table_name)
                if error.code != KBXError.Code.SUCCESS:
                    return None, error
            metadata: MetaData = MetaData()
            table: Table = Table(table_name, metadata, autoload_with=self._engine)

            """
            column.type 需要clear处理, 为了兼容MYSQL和SQLITE
            """
            column_desc_list = [(column.name, self.__clear_column_type(str(column.type)),
                                 column.nullable, column.default,
                                 attr_comment[column.name] if flag else column.comment) for column in table.columns]
            comment = comment if flag else table.comment
            return (column_desc_list, comment), KBXError()
        except Exception as e:
            return (None, None), KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _execute_sql(self, sql: str) -> Tuple[Dict, KBXError]:
        try:
            with self._engine.connect() as conn:
                result = conn.execute(text(sql))
                """
                SQLite：rowcount返回实际修改的行数. SELECT语句返回-1.
                MySQL：rowcount返回匹配条件的行数, 不一定与实际修改的行数相同. SELECT语句返回实际返回的行数.
                """
                # if result.rowcount == -1:  # select
                rows_as_dicts = [dict(row) for row in result.mappings()]
                return {"data": rows_as_dicts, "desc": list(result.keys()),
                        "row_count": result.rowcount}, KBXError()
                # else:
                #     return {"data": [], "desc": [], "row_count": result.rowcount}, KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def __save_comment(self, table_name: str, table_comment: str, attr_comment: Dict[str, str]) -> KBXError:
        try:
            with DBSession() as db:
                table_comment_orm = TableCommentORM(
                    kb_id=self._kb_id,
                    index_type=self._index_type,
                    namespace=self._namespace,
                    table_name=table_name,
                    table_comment=table_comment,
                    attr_comment=attr_comment
                )
                db.add(table_comment_orm)
                db.commit()
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def __load_record(self, table_name: str) -> TableCommentORM:
        with DBSession() as db:
            record: TableCommentORM = db.query(TableCommentORM).filter(
                TableCommentORM.kb_id == self._kb_id,
                TableCommentORM.index_type == self._index_type,
                TableCommentORM.namespace == self._namespace,
                TableCommentORM.table_name == table_name
            ).first()
            return record
        return None

    def __delete_comment(self, table_name: str) -> KBXError:
        try:
            record = self.__load_record(table_name)
            if record:
                with DBSession() as db:
                    db.delete(record)
                    db.commit()
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def __load_comment(self, table_name: str) -> Tuple[str, Dict[str, str], KBXError]:
        try:
            record = self.__load_record(table_name)
            if record:
                return record.table_comment, record.attr_comment, KBXError()
            else:
                return "", dict(), KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))
