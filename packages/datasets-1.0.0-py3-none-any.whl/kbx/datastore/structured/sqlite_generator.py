import re
from typing import Dict, List, Set, Tuple
from uuid import uuid4
from typing import Optional
from sqlglot import exp, parse_one
from kbx.common.types import KBXError


class SqliteGenerator:

    @staticmethod
    def get_create_table_sql(table_name: str, attr_dict: Dict[str, Tuple[str, bool, str, str]],
                             unique: Dict[str, str], index_dict: Dict[str, List[str]], comment: str) -> str:
        base_template = "CREATE TABLE IF NOT EXISTS {} ({});"
        attr_part = "id VARCHAR(32) PRIMARY KEY"
        for attr_name, attr_desc in attr_dict.items():
            """略过id属性"""
            if attr_name == "id":
                continue
            one_attr = f", {attr_name.lower()} {attr_desc[0]}"
            if attr_desc[1] is True:
                one_attr = one_attr + " NOT NULL"
            if attr_desc[2] is not None:
                one_attr = one_attr + " DEFAULT '" + attr_desc[2] + "'"
            # if attr_desc[3] is not None:
            #     one_attr = one_attr + " COMMENT '" + attr_desc[3] + "'"
            attr_part = attr_part + one_attr
            # warning!!!: sqlite is not support COMMENT at neither table nor attr level.
        for _, index_columns in index_dict.items():
            attr_part += ", UNIQUE ({})".format(",".join(index_columns))
        # if comment is None:
        #     comment = "'default table'"
        return base_template.format(table_name, attr_part)

    @staticmethod
    def get_drop_table_sql(table_name: str) -> str:
        return "DROP TABLE IF EXISTS {};".format(table_name)

    @staticmethod
    def get_batch_insert_sql(table_name: str, item_list: List[Dict]) -> Tuple[str, List[List[str]]]:
        if item_list is None or len(item_list) == 0:
            raise RuntimeError("未能传入有效的数据.")
        key_list: List[str] = list(item_list[0].keys())

        if "id" not in key_list:
            key_list.append("id")

        join_key_list = ",".join(key_list)
        table_template = f"{table_name} ({join_key_list})"

        values: List[List[str]] = []
        for item in item_list:
            value_seg_list: List[str] = list()
            for key in key_list:
                # 由业务逻辑生成全局唯一的uuid.
                if key == "id":
                    value = str(uuid4()).replace("-", "")
                else:
                    value = item[key]
                value_seg_list.append(str(value))
            values.append(value_seg_list)
        placeholders_str = ", ".join(["?"] * len(key_list))
        sql_str = "INSERT INTO {} VALUES ({})".format(table_template, placeholders_str)
        return sql_str, values

    @staticmethod
    def get_batch_upsert_sql(table_name: str, item_list: List[Dict]) -> str:
        if item_list is None or len(item_list) == 0:
            raise RuntimeError("未能传入有效的数据.")
        key_list: List[str] = list(item_list[0].keys())

        # here, we cannot remove id.
        join_key_list = ",".join(key_list)
        table_template = f"{table_name} ({join_key_list})"

        value_list: List[str] = list()
        for item in item_list:
            value_seg_list: List[str] = list()
            for key in key_list:
                value = item[key]
                if type(value) is str:
                    value_seg_list.append(f"'{value}'")
                else:
                    value_seg_list.append(str(value))
            join_value_seg_list = ",".join(value_seg_list)
            value_list.append(f"({join_value_seg_list})")
        values_template = ",".join(value_list)
        sql_str: str = "INSERT OR REPLACE INTO {} VALUES {};".format(table_template, values_template)
        return sql_str

    @staticmethod
    def get_update_sql(table_name: str, item: Dict) -> str:
        set_seg_list: List[str] = list()
        for key, value in item.items():
            if key == "id":
                condition = f"id='{value}'"
            else:
                if type(value) is str:
                    set_seg_list.append(f"{key}='{value}'")
        join_set_seg_list = ",".join(set_seg_list)
        return "UPDATE {} SET {} WHERE {};".format(table_name, join_set_seg_list, condition)

    @staticmethod
    def get_select_sql(table_name: str, target_list: List[str], condition_list: List[str]) -> str:
        targets: str = ",".join(target_list)
        if not condition_list:
            condition_list = ["1=1"]
        conditions: str = " AND ".join(condition_list)
        return "SELECT {} FROM {} WHERE {};".format(targets, table_name, conditions)

    @staticmethod
    def get_select_multi_sql(db_prefix: str, table_name_list: List[str], target_list: List[str]) -> str:
        raise NotImplementedError

    @staticmethod
    def get_batch_delete_sql(table_name: str, item_id_list: List[str]) -> str:

        processed_item_id_list = list()
        for item_id in item_id_list:
            processed_item_id_list.append(f"'{item_id}'")
        return "DELETE FROM {} WHERE id in ({});".format(table_name, ",".join(processed_item_id_list))

    @staticmethod
    def get_show_tables_sql() -> str:
        return "SELECT name FROM sqlite_master WHERE type = 'table';"

    @staticmethod
    def get_show_create_table_sql(table_name: str) -> str:
        return "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = '{}';".format(table_name)

    @staticmethod
    def get_pragma_table_info_sql(table_name: str) -> str:
        return "PRAGMA table_info({});".format(table_name)

    @staticmethod
    def _extract_table_name(sql_statement: str) -> List[str]:
        table_names = []
        # 匹配SELECT语句中的表名
        select_pattern = r"FROM\s+(\w+)"
        select_matches = re.findall(select_pattern, sql_statement, re.IGNORECASE)
        table_names.extend(select_matches)
        # 匹配INSERT语句中的表名
        insert_pattern = r"INSERT\s+INTO\s+(\w+)"
        insert_matches = re.findall(insert_pattern, sql_statement, re.IGNORECASE)
        table_names.extend(insert_matches)
        # 匹配REPLACE语句中的表名
        replace_pattern = r"REPLACE\s+INTO\s+(\w+)"
        replace_matches = re.findall(replace_pattern, sql_statement, re.IGNORECASE)
        table_names.extend(replace_matches)
        # 匹配UPDATE语句中的表名
        update_pattern = r"UPDATE\s+(\w+)"
        update_matches = re.findall(update_pattern, sql_statement, re.IGNORECASE)
        table_names.extend(update_matches)
        # 匹配DELETE语句中的表名
        delete_pattern = r"DELETE\s+FROM\s+(\w+)"
        delete_matches = re.findall(delete_pattern, sql_statement, re.IGNORECASE)
        table_names.extend(delete_matches)
        return list(set(table_names))  # remove duplicated name.

    @staticmethod
    def _transform(node, result_set: Set[str], db_prefix: Optional[str] = None):
        if isinstance(node, exp.Table):
            result_set.add(node.name)
            if db_prefix is not None:
                node.this.args["this"] = db_prefix + "_" + node.name
        elif "table" in node.args:
            result_set.add(node.args["table"].name)
            # print(node.args["table"].name)
            if db_prefix is not None:
                node.args["table"].args["this"] = db_prefix + "_" + node.args["table"].name
        return node

    @staticmethod
    def extract_table_names_v2(sql_statement: str, dialect: Optional[str] = None) -> Tuple[List[str], KBXError]:

        try:
            parsed_sql = parse_one(sql_statement, dialect=dialect)
            table_name_set = set()
            parsed_sql.transform(SqliteGenerator._transform, table_name_set)
            return list(table_name_set), KBXError()
        except Exception as e:
            return [], KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=str(e))

    @staticmethod
    def replace_table_names_v2(sql_statement: str, db_prefix: str, dialect: Optional[str] = None)\
            -> Tuple[str, List[str], KBXError]:

        try:
            parsed_sql = parse_one(sql_statement, dialect=dialect)
            table_name_set = set()
            parsed_sql = parsed_sql.transform(SqliteGenerator._transform, table_name_set, db_prefix)
            return parsed_sql.sql(), list(table_name_set), KBXError()
        except Exception as e:
            return "", [], KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=str(e))
