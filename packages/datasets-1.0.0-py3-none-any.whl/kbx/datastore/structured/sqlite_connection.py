from kbx.datastore.base_connection import BaseConnection
import sqlite3


class SqliteConnection(BaseConnection):

    def __init__(self, args):
        self.args = args
        self.sqlite_client = sqlite3.connect(self.args["db_path"], check_same_thread=False)

    def flush(self):
        self.sqlite_client.commit()

    def get(self, key: str = None):
        return self.sqlite_client
