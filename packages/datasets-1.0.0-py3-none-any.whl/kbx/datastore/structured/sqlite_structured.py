from __future__ import annotations

import os
import sqlite3
from typing import Any, Dict, List, Tuple

from kbx.common.lock.mutex_factory import get_mutex
from kbx.datastore.base_ds import with_lock, DataStoreType
from kbx.datastore.structured.structured_base import BaseStructuredDS
from kbx.datastore.structured.sqlite_connection import SqliteConnection
from kbx.datastore.structured.sqlite_generator import SqliteGenerator
from kbx.datastore.connection_pool import ConnectionPool
from kbx.datastore.base_connection import BaseConnection
from kbx.db.session import DBSession
from kbx.db.types import TableCommentORM
from kbx.common.logging import logger
from kbx.common.types import KBXError, StructuredDSConfig


class SqliteStructuredDS(BaseStructuredDS):

    def __init__(self, config: StructuredDSConfig, kb_id: str, index_type: str, namespace: str):
        super().__init__(config, kb_id, index_type, namespace)
        os.makedirs(self._base_dir, exist_ok=True)
        self._db_path = self._path_factory.path_r2a("sqlite.db")
        self._lock = get_mutex(DataStoreType.STRUCTURED + "_" + self._key)
        args: Dict[str, Any] = dict()
        args["db_path"] = self._db_path
        expired_time = config.connection_kwargs.get("expired_time", 5)
        self._connection_pool: ConnectionPool = ConnectionPool(
            DataStoreType.STRUCTURED, self._key, args, expired_time, SqliteConnection)
        self._connection: BaseConnection = None

    @staticmethod
    def get_type() -> str:
        return "SqliteStructuredDS"

    def _delete_ds(self) -> KBXError:
        self._connection_pool.clear_connection()
        table_name_list, error = self.show_tables()
        if error.code != KBXError.Code.SUCCESS:
            return error
        table_list_delete_unsuccessfully: List[str] = list()
        for table_name in table_name_list:
            error = self.drop_table(table_name)
            if error.code != KBXError.Code.SUCCESS:
                table_list_delete_unsuccessfully.append(table_name)
        self._close()
        if len(table_list_delete_unsuccessfully) == 0:
            return KBXError()
        else:
            tables_exist_str = ",".join(table_list_delete_unsuccessfully)
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=f"Tables: {tables_exist_str} are not deleted.")

    @with_lock
    def _flush(self):
        self._connection.flush()

    @with_lock
    def _connect(self):
        """
        sqlite连接到kb_id路径下的"sqlite.db"
        """
        self._connection = self._connection_pool.open_connection()

    @with_lock
    def _close(self):
        self._connection = None
        self._connection_pool.close_connection()

    @with_lock
    def _create_table(self, table_name: str,
                      attr: Dict[str, Tuple[str, bool, str, str]],
                      key: Dict[str, Any] = None,
                      index: Dict[str, List[str]] = None,
                      comment: str = "") -> KBXError:
        try:
            attr_comment = dict()
            for k, v in attr.items():
                if v[3]:
                    attr_comment[k] = v[3]
                else:
                    attr_comment[k] = ""
            attr_comment["id"] = "main key, v4 format uuid."
            error: KBXError = self.__save_comment(table_name, comment, attr_comment)
            if error.code != KBXError.Code.SUCCESS:
                return error

            sql_str: str = SqliteGenerator.get_create_table_sql(table_name.lower(), attr, key, index,
                                                                comment)
            self._connection.get().execute(sql_str)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _drop_table(self, table_name: str) -> KBXError:
        try:
            sql_str: str = SqliteGenerator.get_drop_table_sql(table_name)
            self._connection.get().execute(sql_str)
            return self.__delete_comment(table_name)
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _batch_insert(self, item_list: List[Dict], table_name: str) -> KBXError:
        try:
            sql_str, values = SqliteGenerator.get_batch_insert_sql(table_name, item_list)
            cursor: sqlite3.Cursor = self._connection.get().executemany(sql_str, values)
            logger.debug(f"{cursor.rowcount} lines data have been inserted.")
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _batch_upsert(self, item_list: List[Dict], table_name: str) -> KBXError:
        try:
            sql_str: str = SqliteGenerator.get_batch_upsert_sql(table_name, item_list)
            self._connection.get().execute(sql_str)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _batch_update(self, item_list: List[dict], table_name: str) -> KBXError:
        for item in item_list:
            try:
                sql_str: str = SqliteGenerator.get_update_sql(table_name, item)
                # print(sql_str)
                self._connection.get().execute(sql_str)
            except Exception as e:
                return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))
        return KBXError()

    @with_lock
    def _batch_delete(self, item_ids: List[str], table_name) -> KBXError:
        try:
            sql_str: str = SqliteGenerator.get_batch_delete_sql(table_name, item_ids)
            # print(sql_str)
            self._connection.get().execute(sql_str)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _select(self,
                target_list: List[str],
                table_name: str,
                condition_list: List[str]) -> (List[Dict], KBXError):
        try:
            key_list = list()
            if "*" in target_list:
                sql_str = SqliteGenerator.get_pragma_table_info_sql(table_name)
                cursor = self._connection.get().execute(sql_str)
                for col in cursor.fetchall():
                    key_list.append(col[1])
            else:
                key_list = target_list

            sql_str: str = SqliteGenerator.get_select_sql(table_name, target_list, condition_list)
            # print(sql_str)
            cursor: sqlite3.Cursor = self._connection.get().execute(sql_str)
            res = list()
            for row in cursor.fetchall():
                # print(key_list, row)
                item = dict()
                for i in range(len(row)):
                    item[key_list[i]] = row[i]
                res.append(item)
            return res, KBXError()
        except Exception as e:
            return list(), KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _select_multi_table(self,
                            target_list: List[str],
                            table_name_list: List[str],
                            each_table_target_list: List[List[str]],
                            each_table_condition_list: List[List[str]]) -> (List[Dict], KBXError):
        sql_str: str = SqliteGenerator.get_select_multi_sql(target_list, table_name_list,
                                                            each_table_target_list, each_table_condition_list)
        if sql_str is None:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg="Cannot generate executed sql.")
        try:
            res: List[Dict] = []
            cursor: sqlite3.Cursor = self._connection.get().execute(sql_str)
            for row in cursor.fetchall():
                # print(key_list, row)
                item = dict()
                for i in range(len(row)):
                    item[target_list[i]] = row[i]
                res.append(item)
            return res, KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _show_tables(self) -> (List[str], KBXError):
        try:
            sql_str: str = SqliteGenerator.get_show_tables_sql()
            cursor: sqlite3.Cursor = self._connection.get().execute(sql_str)
            table_list: List[str] = list()
            for item in cursor.fetchall():
                table_list.append(str(item[0]))
            return table_list, KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _show_create_table(self, table_name: str) -> Tuple[Tuple[List[Tuple[str, str, bool, str, str]], str], KBXError]:
        try:
            comment, attr_comment, error = self.__load_comment(table_name)
            if error.code != KBXError.Code.SUCCESS:
                return None, error
            sql_str: str = SqliteGenerator.get_pragma_table_info_sql(table_name.lower())
            cursor: sqlite3.Cursor = self._connection.get().execute(sql_str)
            table_attr_list: List = list()
            for item in cursor.fetchall():
                table_attr_list.append((item[1], item[2], False if item[3] == 0 else True, item[4],
                                        attr_comment[item[1]] if item[1] in attr_comment else ""))
            # comment: str = ""  # comment is not supported in sqlite.
            return (table_attr_list, comment), KBXError()
        except Exception as e:
            return (None, None), KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _execute_sql(self, sql_statement: str) -> Tuple[Dict, KBXError]:
        """
        执行一条指定的sql语句.

        Args:
            sql_statement (str): 待执行的sql语句.

        Returns:
            dict -> (KBXError, data_list)

        """
        try:
            cursor: sqlite3.Cursor = self._connection.get().execute(sql_statement)
            if cursor.description is None:
                """ non-selection operation """
                return {"data": [], "desc": None, "row_count": cursor.rowcount}, KBXError()
            else:
                """ selection operation """
                return_list: List[Dict] = list()
                key_list: List[Dict] = list()
                for item in list(cursor.description):
                    key_list.append(item[0])
                for item in cursor.fetchall():
                    item_line: Dict = dict()
                    for i in range(len(key_list)):
                        item_line[key_list[i]] = item[i]
                    return_list.append(item_line)
                return {"data": return_list, "desc": cursor.description, "row_count": cursor.rowcount}, KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def __save_comment(self, table_name: str, table_comment: str, attr_comment: Dict[str, str]) -> KBXError:

        try:
            with DBSession() as db:
                table_comment_orm = TableCommentORM(
                    kb_id=self._kb_id,
                    index_type=self._index_type,
                    namespace=self._namespace,
                    table_name=table_name,
                    table_comment=table_comment,
                    attr_comment=attr_comment
                )
                db.add(table_comment_orm)
                db.commit()
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def __load_record(self, table_name: str) -> TableCommentORM:
        with DBSession() as db:
            record: TableCommentORM = db.query(TableCommentORM).filter(
                TableCommentORM.kb_id == self._kb_id,
                TableCommentORM.index_type == self._index_type,
                TableCommentORM.namespace == self._namespace,
                TableCommentORM.table_name == table_name
            ).first()
            return record
        return None

    def __delete_comment(self, table_name: str) -> KBXError:
        try:
            record = self.__load_record(table_name)
            if record:
                with DBSession() as db:
                    db.delete(record)
                    db.commit()
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def __load_comment(self, table_name: str) -> Tuple[str, Dict[str, str], KBXError]:
        try:
            record = self.__load_record(table_name)
            if record:
                return record.table_comment, record.attr_comment, KBXError()
            else:
                return "", dict(), KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))
