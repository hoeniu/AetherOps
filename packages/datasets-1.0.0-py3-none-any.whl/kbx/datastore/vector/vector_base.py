from __future__ import annotations

from abc import abstractmethod
from typing import List, Tuple, Any, Optional

from kbx.common.types import VectorDSConfig, KBXError
from kbx.datastore.base_ds import BaseDS, check_connected
from kbx.datastore.path_factory import PathFactory


class BaseVectorDS(BaseDS):

    def __init__(self, config: VectorDSConfig, kb_id: str, index_type: str, namespace: str):
        """
        使用时需要调用者初始化VectorDS的实例，并管理其生命周期.
        """
        super().__init__(kb_id, index_type, namespace)
        self._config: VectorDSConfig = config
        self._path_factory = PathFactory(config, self.tenant_id, self.user_id, kb_id, index_type, namespace)
        self._base_dir = self._path_factory.path_r2a()

    @staticmethod
    def get_type() -> str:
        return "VectorDS"

    def _connect(self) -> None:
        pass

    def _close(self) -> None:
        pass

    def __enter__(self) -> BaseVectorDS:
        return super().__enter__()

    def __exit__(self, exc_type: Optional[BaseException], exc_val: Any, exc_tb: Any) -> bool:
        return super().__exit__(exc_type=exc_type, exc_val=exc_val, exc_tb=exc_tb)

    @check_connected
    def add(self, chunk_embedding_list: List[Tuple[str, List[float]]]) -> KBXError:
        """
        向VectorDS批量加入(ChunkId, 对应的embedding数据). 即构建索引.

        Args:
            chunk_embedding_list (List[(str, List[float])]): List中的每一个Item是一个元组(chunk_id, chunk_embedding)

        Returns:
            是否添加成功.

        """
        return self._add(chunk_embedding_list)

    @abstractmethod
    def _add(self, chunk_embedding_list: List[Tuple[str, List[float]]]) -> KBXError:
        raise NotImplementedError

    @check_connected
    def if_chunk_id_exists(self, chunk_id: str) -> bool:
        """
        判断DataStore中chunk_id是否存在.

        Args:
            chunk_id (str): add 操作中添加的

        Returns:

        """
        return self._if_chunk_id_exists(chunk_id)

    @abstractmethod
    def _if_chunk_id_exists(self, chunk_id: str) -> bool:
        raise NotImplementedError

    @check_connected
    def delete_by_chunk_ids(self, chunk_ids: List[str]) -> KBXError:
        """
        根据vector从知识库中检索出对应的文本.

        Args:
            chunk_ids (List[str]): 待删除的 chunk_id 列表.

        Returns:

        """
        return self._delete_by_chunk_ids(chunk_ids)

    @abstractmethod
    def _delete_by_chunk_ids(self, chunk_ids: List[str]) -> KBXError:
        raise NotImplementedError

    @check_connected
    def search_by_vector(
        self,
        query_vector: List[float],
        topk: int = 10000,
        selected_chunk_ids: Optional[List[str]] = None
    ) -> Tuple[List[Tuple[str, float]], KBXError]:
        """
        根据 query_vector从知识库中检索出对应的文本.
        Args:
            query_vector (List[float]): 待查询的embedding.
            topk (int): 返回最相似的topk个结果.

        Returns:
            元组:
            T1为返回值列表. 其中元素为(chunk_id, score)元组, score是当前chunk_id的得分.
            T2为错误信息. 当T1 is None时(T1为空列表时为正常返回.)，应查看错误信息.

        """
        return self._search_by_vector(query_vector, topk, selected_chunk_ids)

    @abstractmethod
    def _search_by_vector(
        self,
        query_vector: List[float],
        topk: int,
        selected_chunk_ids: Optional[List[str]] = None
    ) -> Tuple[List[Tuple[str, float]], KBXError]:
        raise NotImplementedError
