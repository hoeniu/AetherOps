from __future__ import annotations

from typing import Any, Dict, List, Tuple, Optional
from chromadb import QueryResult, __version__

from kbx.common.logging import logger
from kbx.common.lock.mutex_factory import get_mutex
from kbx.common.types import VectorDSConfig, KBXError
from kbx.datastore.base_ds import with_lock, DataStoreType
from kbx.datastore.vector.vector_base import BaseVectorDS
from kbx.datastore.connection_pool import ConnectionPool
from kbx.datastore.base_connection import BaseConnection
from kbx.datastore.vector.chroma_connection import ChromaConnection


class ChromaVectorDS(BaseVectorDS):

    def __init__(self, config: VectorDSConfig, kb_id: str, index_type: str, namespace: str):
        super().__init__(config, kb_id, index_type, namespace)
        self._collection_name = self._kb_id  # name must match 3-63 characters.
        self._lock = get_mutex(DataStoreType.VECTOR + "_" + self._key)
        self._args: Dict[str, Any] = dict()
        self._args["base_dir"] = self._base_dir
        self._args["collection_name"] = self._collection_name
        self._args["metadata"] = {"hnsw:space": "cosine"}
        expired_time = config.connection_kwargs.get("expired_time", 5)
        self._connection_pool = ConnectionPool[ChromaConnection](
            DataStoreType.VECTOR, self._key, self._args, expired_time, ChromaConnection)
        self._connection: BaseConnection = None

    @staticmethod
    def get_type() -> str:
        return "ChromaVectorDS"

    @with_lock
    def _connect(self) -> None:
        """open && connect"""
        self._connection = self._connection_pool.open_connection()

    @with_lock
    def _close(self):
        self._connection_pool.close_connection()

    @with_lock
    def _delete_ds(self) -> KBXError:
        try:
            self._connection.get("client").delete_collection(self._collection_name)
            self._collection = None
            self._chroma_client = None
            self._connection_pool.clear_connection()
        except Exception as e:
            # 经过0.6.3和1.0.0的兼容性测试, 大于1.0.0的版本均使用NotFoundError
            collection_not_exist_flag = False
            if __version__ >= "1.0.0":
                from chromadb.errors import NotFoundError
                if isinstance(e, NotFoundError):
                    collection_not_exist_flag = True
            else:
                from chromadb.errors import InvalidCollectionException
                if isinstance(e, InvalidCollectionException):
                    collection_not_exist_flag = True
            if collection_not_exist_flag:
                logger.warn(f"DELETE DS: Collection {self._collection_name} 已删除.")
                return KBXError()
            else:
                logger.warn(f"DELETE DS: Exception: {str(e)}")
                return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

        # NOTE: 对于0.5.20及以上版本的chromadb，delete_collection后，还需手动清理_identifier_to_system中的cache；或者把chromadb降至0.4.14版本
        try:
            from chromadb.api.shared_system_client import SharedSystemClient
            SharedSystemClient._identifier_to_system.pop(self._base_dir)
        except ImportError:
            pass
        return KBXError()

    @with_lock
    def _add(self, chunk_embedding_list: List[Tuple[str, List[float]]]) -> KBXError:
        if len(chunk_embedding_list) == 0:
            return KBXError()
        try:
            ids = []
            embeddings = []
            metadatas = []
            for item in chunk_embedding_list:
                ids.append(item[0])
                embeddings.append(item[1])
                metadatas.append({"chunk_id": item[0]})
            self._connection.get().upsert(embeddings=embeddings, ids=ids, metadatas=metadatas)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=str(e))

    @with_lock
    def _if_chunk_id_exists(self, chunk_id: str) -> bool:
        return len(self._connection.get().get([chunk_id])["ids"]) >= 1

    @with_lock
    def _delete_by_chunk_ids(self, chunk_ids: List[str]) -> KBXError:
        if len(chunk_ids) == 0:
            return KBXError()
        try:
            self._connection.get().delete(ids=chunk_ids)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=str(e))

    @with_lock
    def _search_by_vector(
        self,
        query_vector: List[float],
        topk: int,
        selected_chunk_ids: Optional[List[str]] = None
    ) -> Tuple[List[Tuple[str, float]], KBXError]:
        try:
            where_filter = {"chunk_id": {"$in": selected_chunk_ids}} \
                if selected_chunk_ids else None
            query_result: QueryResult = self._connection.get().query(
                query_embeddings=[query_vector],
                n_results=topk,
                where=where_filter
            )
            ids: List[str] = query_result.get("ids")[0]
            distances: List[float] = query_result.get("distances")[0]
            res = []
            for i in range(len(ids)):
                cosine_similarity = 1 - distances[i]  # cosine similarity: larger is better.
                res.append((ids[i], cosine_similarity))
            return res, KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=str(e))
