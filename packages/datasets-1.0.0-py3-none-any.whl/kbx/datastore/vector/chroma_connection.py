from typing import Any, Dict
from kbx.datastore.base_connection import BaseConnection
import chromadb
from chromadb import Settings, Collection, Client


class ChromaConnection(BaseConnection):

    def __init__(self, args: Dict[str, Any] = None):
        super().__init__(args)
        self._chroma_client: Client = chromadb.PersistentClient(self.args["base_dir"],
                                                                settings=Settings(anonymized_telemetry=False))
        self._chroma_collection: Collection = self._chroma_client.get_or_create_collection(
            name=self.args["collection_name"],
            metadata=self.args["metadata"])

    def flush(self):
        pass

    def get(self, args: str = None):
        if args is None or args == "collection":
            return self._chroma_collection
        elif args == "client":
            return self._chroma_client
        else:
            return self._chroma_collection
