import os.path
from typing import List
from kbx.common.logging import logger
from kbx.common.constants import DEFAULT_INDEX_TYPE, DEFAULT_NAMESPACE
from kbx.common.types import BaseDSConfig, FileDSConfig, DocDSConfig, VectorDSConfig, KeywordDSConfig
from kbx.common.types import GraphDSConfig, StructuredDSConfig
from kbx.datastore.types import DataStoreType


class PathFactory:

    @staticmethod
    def get_ds_type_by_ds_config(ds_config: BaseDSConfig):
        ds_config_type = type(ds_config)
        if ds_config_type is FileDSConfig:
            return DataStoreType.FILE
        elif ds_config_type is DocDSConfig:
            return DataStoreType.DOC
        elif ds_config_type is GraphDSConfig:
            return DataStoreType.GRAPH
        elif ds_config_type is KeywordDSConfig:
            return DataStoreType.KEYWORD
        elif ds_config_type is StructuredDSConfig:
            return DataStoreType.STRUCTURED
        elif ds_config_type is VectorDSConfig:
            return DataStoreType.VECTOR
        else:
            raise RuntimeError

    def __init__(self, ds_config: BaseDSConfig,
                 tenant_id: str, user_id: str, kb_id: str,
                 index_type: str = DEFAULT_INDEX_TYPE,
                 namespace: str = DEFAULT_NAMESPACE):

        self._data_store_type = PathFactory.get_ds_type_by_ds_config(ds_config)
        # print(self._data_store_type)
        self._tenant_id = tenant_id
        self._user_id = user_id
        self._kb_id = kb_id
        self._index_type = index_type  # 可以是index_type或者变量.
        self._namespace = namespace
        from kbx.kbx import KBX
        if KBX.config is not None and KBX.config.work_dir is not None:
            self._workdir = KBX.config.work_dir
        else:
            self._workdir = "."  # 兼容测试, 即使不初始化KBX也允许创建类实例.
        self._workdir_seg = len(self._workdir.split(os.sep))

    def path_r2a(self, relative_path: str = "") -> str:
        """
        用于将文件存储的相对路径转换为绝对路径.

        Args:
            relative_path (str): 外部使用(传入)的文件路径, 隐去work_dir, 文件类型, tenant_id, user_id, kb_id等信息.

        Returns:
            用于内部文件持久化的的绝对路径.

        """
        return self._path_r2a_helper(relative_path)

    def path_r2r(self, relative_path: str = "") -> str:
        """

        Args:
            relative_path (str): 外部使用(传入)的文件路径, 隐去了work_dir, 文件类型, tenant_id, user_id, kb_id等信息.

        Returns:
            str: raw_path, 包含tenant_id, user_id, kb_id信息.
        """
        return self._path_r2r_helper(relative_path)

    def _seg_func(self, path: str, num) -> str:
        segments: List[str] = path.split(os.sep)
        if len(segments) <= num:
            logger.error("Path: %s, %d.", path, num)
            raise RuntimeError("parameter format is not proper, expected:{}, real:{}".format(num, len(segments)))
        for i in range(num):
            del segments[0]
        return os.path.join(*segments)

    def path_a2r(self, absolute_path: str) -> str:
        """
        用于文件存储的绝对路径转换为相对路径.

        Args:
            absolute_path (str): 用于文件存储的内部绝对路径.

        Returns:
            外部传入的用于文件存储的相对路径.

        """
        if self._data_store_type in [DataStoreType.FILE, DataStoreType.DOC]:
            """ +4: ds_type, tenant_id, user_id, kb_id """
            return self._seg_func(absolute_path, self._workdir_seg + 4)
        else:
            """ +6: ds_type, tenant_id, user_id, kb_id, index_type, namespace """
            return self._seg_func(absolute_path, self._workdir_seg + 6)

    def _path_r2a_helper(self, relative_path: str):
        """File和Doc有调用方灵活设置kb_id之后的路径."""
        if self._data_store_type in [DataStoreType.FILE, DataStoreType.DOC]:
            if self._workdir:
                return os.path.join(self._workdir, self._data_store_type, self._tenant_id, self._user_id,
                                    self._kb_id, relative_path)
            else:
                return os.path.join(self._remote_url, self._data_store_type, self._tenant_id, self._user_id,
                                    self._kb_id, relative_path)
        else:
            return os.path.join(self._workdir, self._data_store_type, self._tenant_id, self._user_id,
                                self._kb_id, self._index_type, self._namespace, relative_path)

    def _path_r2r_helper(self, relative_path: str):
        """File和Doc有调用方灵活设置kb_id之后的路径."""
        if self._data_store_type in [DataStoreType.FILE, DataStoreType.DOC]:
            return os.path.join(self._tenant_id, self._user_id, self._kb_id, relative_path)
        else:
            return os.path.join(self._tenant_id, self._user_id, self._kb_id,
                                self._index_type, self._namespace, relative_path)
