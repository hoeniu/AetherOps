import threading
import time


class SafeDict(dict):

    def __init__(self):
        """
        1. 继承自dict的线程安全的dict类
        2. 维护key的引用计数，删除key时只有当引用计数为0时，才进行物理删除
        3. 可以设置timeout_s, 从准备删除到进行删除的延时时间(second)
        4. 在进行删除时，key的引用计数大于0, 则skip本次删除操作.
        """
        super().__init__()
        self._lock: threading.Lock = threading.Lock()
        self._clear_queue = list()
        self._thread = threading.Thread(target=self.clear_timeout_key, args=())
        self._thread.daemon = True  # 设定为守护线程
        self._thread.start()
        self._timeout_s: int = 5

    def __setitem__(self, key, value):
        with self._lock:  # 在设置项时加锁
            if key not in super().keys():
                super().__setitem__(key, (value, 1))
            else:
                value, ref_count = super().get(key)
                super().__setitem__(key, (value, ref_count + 1))

    def __getitem__(self, key):
        with self._lock:  # 在获取项时加锁
            if key not in super().keys():
                raise RuntimeError(f"Failed to find key: {key}")
            value, ref_count = super().__getitem__(key)
            super().set(key, (value, ref_count + 1))
            return value

    def __delitem__(self, key):
        with self._lock:  # 在删除项时加锁
            if key in super().keys():
                value, ref_count = super().__getitem__(key)
                ref_count = ref_count - 1
                super().__setitem__(key, (value, ref_count))
                if ref_count == 0:
                    self._clear_queue.append((time.time(), key))
                elif ref_count == -1:
                    raise RuntimeError(f"Try to delete a non-exist key: {key}")

    def update(self, *args, **kwargs):
        with self._lock:  # 在更新字典时加锁
            super().update(*args, **kwargs)

    def pop(self, key, default=None):
        raise RuntimeError("Forbidden method.")

    def popitem(self):
        raise RuntimeError("Forbidden method.")

    def clear(self):
        with self._lock:  # 在清空字典时加锁
            super().clear()

    def get(self, key, default=None):
        with self._lock:  # 在获取默认值时加锁
            if key not in super().keys():
                raise RuntimeError(f"Failed to find key: {key}")
            value, ref_count = super().get(key, default)
            super().__setitem__(key, (value, ref_count + 1))
            return value

    def setdefault(self, key, default=None):
        with self._lock:  # 在设置默认值时加锁
            raise RuntimeError("Forbidden method.")

    def __contains__(self, key):
        with self._lock:  # 在检查键是否存在时加锁
            return super().__contains__(key)

    def keys(self):
        with self._lock:  # 在获取键列表时加锁
            return super().keys()

    def values(self):
        with self._lock:  # 在获取值列表时加锁
            return super().values()

    def items(self):
        with self._lock:  # 在获取键值对列表时加锁
            return super().items()

    def copy(self):
        with self._lock:  # 在复制字典时加锁
            return super().copy()

    def _delete_with_ref_count_check(self, key: str) -> None:
        if key in super().keys():
            value, ref_count = super().get(key)
            if ref_count == 0:
                value.close()
                super().__delitem__(key)

    def delete_im(self, key: str) -> None:
        with self._lock:
            if key in super().keys():
                super().__delitem__(key)

    def clear_timeout_key(self):
        while True:
            time.sleep(1)
            with self._lock:
                if len(self._clear_queue) > 0:
                    item = self._clear_queue[0]
                    while time.time() - item[0] > self._timeout_s:
                        self._delete_with_ref_count_check(item[1])
                        self._clear_queue.pop(0)
                        if len(self._clear_queue) > 0:
                            item = self._clear_queue[0]
                        else:
                            break

    def set_timeout(self, timeout_s: int):
        self._timeout_s = timeout_s
