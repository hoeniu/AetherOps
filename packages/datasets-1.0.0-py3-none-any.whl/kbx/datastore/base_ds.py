from __future__ import annotations

import os.path
import shutil
from abc import ABC, abstractmethod
from typing import Any, List, Optional
from kbx.common.types import KBXError
from kbx.common.logging import logger
from kbx.datastore.types import DataStoreType
from kbx.db.session import DBSession
from kbx.db.types import KBInfoORM

NOT_CONNECTED_ERROR = "A connection must be established before calling this method."


def extract_list(result_list: List[Any], offset: int, limit: int) -> List[Any]:
    if limit == -1:
        return result_list[offset:None]
    return result_list[offset:offset + limit]


def with_lock(func):
    def wrapper(self, *args, **kwargs):
        if self._lock is None:
            return func(self, *args, **kwargs)
        else:
            with self._lock:
                return func(self, *args, **kwargs)
    return wrapper


def check_connected(func):
    def wrapper(self, *args, **kwargs):
        if self.is_connected:
            return func(self, *args, **kwargs)
        else:
            raise RuntimeError(NOT_CONNECTED_ERROR)
    return wrapper


def return_connected(func):
    """
    function wrapper.
    if self is connected, return; else connect after executing function.
    """
    def wrapper(self, *args, **kwargs):
        if not self.is_connected:
            func(self, *args, **kwargs)
            self._is_connected = True
        else:
            logger.warning(f"{self._kb_id} is connected.")
    return wrapper


def return_not_connected(func):
    """
    function wrapper.
    if self is disconnected, return; else disconnect after executing function.
    """
    def wrapper(self, *args, **kwargs):
        if self.is_connected:
            func(self, *args, **kwargs)
            self._is_connected = False
        else:
            logger.warning(f"{self._kb_id} is not connected.")
    return wrapper


class BaseDS(ABC):

    def __init__(self, kb_id: str, index_type: str, namespace: str, tenant_id: str = None, user_id: str = None):
        """
        构造函数，兼具Create和Open的作用
        如果DataStore已存在, 则Create;
        如果DataStore不存在，则Open.

        Args:
            kb_id (str): KnowledgeBase自身的ID.
            index_type (str): 调用者的index type.
            namespace (str): 用于区分数据用途

        """
        self._kb_id: str = kb_id
        self._is_connected: str = False
        self._namespace: str = namespace
        self._index_type: str = index_type  # 注意，这是上游调用者的index_type, 不是DS本身的type, 索引可以使用不同类型的DS.
        self._is_service: bool = False
        self._is_external: bool = False
        self._base_dir: str = None
        self._key: str = kb_id + "_" + index_type + "_" + namespace

        # 需要注意，如果tenant_id和user_id为not None, 说明是fast_ds调用, 由上层提供user_id和tenant_id.
        if tenant_id is not None and user_id is not None:
            self._user_id: str = user_id
            self._tenant_id: str = tenant_id
        else:
            with DBSession() as db:
                kb_info_orm: KBInfoORM = db.query(KBInfoORM).filter(KBInfoORM.id == kb_id).first()
                if kb_info_orm is None:
                    raise RuntimeError(f"Failed to find kb_id: {kb_id}.")
                self._user_id = kb_info_orm.user_id
                self._tenant_id = kb_info_orm.tenant_id

    @property
    def user_id(self):
        return self._user_id

    @property
    def tenant_id(self):
        return self._tenant_id

    def __del__(self):
        # self.close()
        pass

    def __enter__(self) -> BaseDS:
        self.connect()
        return self

    def __exit__(self, exc_type: Optional[BaseException], exc_val: Any, exc_tb: Any) -> bool:
        try:
            # 如果退出时没有关闭(手动关闭或执行delete_ds)，则关闭.
            if self.is_connected:
                self.close()
        except Exception as e:
            msg = f'Failed to close {self.__class__.__name__} (kb_id = {self._kb_id}): {e}'
            # 这里保证记录到日志中
            logger.error(msg)
            # 然后重新抛出异常，使得外部的异常也能被正常地处理
            raise RuntimeError(msg) from e

        # 这里不需要抑制外部的异常
        return exc_type is None

    @check_connected
    def flush(self) -> None:
        """
        将所有已执行的操作落库.

        Returns:

        """
        self._flush()

    def _flush(self) -> None:
        pass

    @return_connected
    def connect(self) -> None:
        """
        使用成员变量初始化DataStore的连接，使得所有功能函数处于可用状态.

        Returns:

        """
        self._connect()

    @abstractmethod
    def _connect(self) -> None:
        raise NotImplementedError

    @return_not_connected
    def close(self) -> None:
        """
        关闭DataStore连接, 所有功能函数将不可用.

        Returns:

        """
        self._flush()
        self._close()

    @abstractmethod
    def _close(self) -> None:
        raise NotImplementedError

    @property
    def is_connected(self):
        return self._is_connected

    @staticmethod
    def _delete_helper(current_dir: str, level: int = 1) -> KBXError:
        """
        删除当前文件夹下的所有文件；如果上一级文件夹为空，则继续删除上一级文件夹；
        至多向上删除level级, 默认只删除一级。
        Graph, Keyword, Structured, Vector删除三级(kb_id, index_type, namespace)
        File, Doc删除一级(kb_id)

        TODO: 这里需要加一个安全检测: current_dir 至少应该有7级目录，这7级的后面6级中不允许有".."字符
        """
        if not current_dir:  # current_dis is None or len(current_dir) == 0
            return KBXError()
        try:
            for i in range(level):
                # 去掉current_dir结尾的分隔符，避免os.path.dirname()结果不正确.
                if current_dir.endswith(os.sep):
                    current_dir = current_dir.rstrip(os.sep)
                if not os.path.exists(current_dir):
                    break
                parent_dir = os.path.dirname(current_dir)
                shutil.rmtree(current_dir)
                # 上级文件夹不为空，直接跳出
                if len(os.listdir(parent_dir)) != 0:
                    break
                else:
                    current_dir = parent_dir
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def delete_ds(self) -> KBXError:
        """
        删除self._kb_id对应的DataStore. 删除操作和具体的DataStore类型有关.

        Returns:
            是否删除成功.

        """
        if self.is_connected:
            res: KBXError = self._delete_ds()
            self._is_connected = False
            """非服务"""
            if not self._is_service and self._base_dir:
                # 如果self._base_dir 不存在，则不进行删除.
                if not os.path.exists(self._base_dir):
                    return res
                if DataStoreType.FILE in self._base_dir or DataStoreType.DOC in self._base_dir:
                    BaseDS._delete_helper(self._base_dir, 1)
                else:
                    BaseDS._delete_helper(self._base_dir, 3)
            return res
        else:
            raise RuntimeError("DS is not connected, plz check code.")

    @abstractmethod
    def _delete_ds(self) -> KBXError:
        raise NotImplementedError

    @staticmethod
    @abstractmethod
    def get_type() -> str:
        """
        获得当前DS实现类的类型.

        Returns:
            类型名称.

        """
        raise NotImplementedError
