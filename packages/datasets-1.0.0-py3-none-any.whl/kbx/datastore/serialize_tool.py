from pydantic import BaseModel
import json
from kbx.common.types import DocData, Chunk, DocElement


# 自定义 JSON 编码器
class BaseModelEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, BaseModel):
            return obj.dict()  # 将 BaseModel 转换为字典
        return super().default(obj)


# 自定义 JSON 编码器
class BaseModelDecoder(json.JSONDecoder):
    def __init__(self, *args, **kwargs):
        super().__init__(object_hook=self.object_hook, *args, **kwargs)

    def object_hook(self, obj):
        if isinstance(obj, dict):
            key_set = obj.keys()
            if "doc_id" in key_set and "file_path" in key_set and "file_name" in key_set:
                return DocData(**obj)
            elif "text" in key_set and "chunk_id" in key_set and "doc_id" in key_set:
                return Chunk(**obj)
            elif "doc_element_id" in key_set:
                return DocElement(**obj)
        return obj


# 自定义 set 编码器
class SetEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, set):
            return list(obj)
        return super().default(obj)


# 自定义 set 解码器
class SetDecoder(json.JSONDecoder):
    def __init__(self, *args, **kwargs):
        super().__init__(object_hook=self.object_hook, *args, **kwargs)

    def object_hook(self, obj):
        if isinstance(obj, dict):
            for keyword, node_index in obj.items():
                if isinstance(node_index, list):
                    obj[keyword] = set(node_index)
        return obj
