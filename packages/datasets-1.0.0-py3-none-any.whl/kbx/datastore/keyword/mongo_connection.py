from typing import Any, Dict
from kbx.datastore.base_connection import BaseConnection
from pymongo import MongoClient


class MongoConnection(BaseConnection):

    def __init__(self, args: Dict[str, Any]):
        super().__init__(args)
        self._host = self.args["host"]
        self._port = self.args["port"]
        self._username = self.args["username"]
        self._password = self.args["password"]
        self._client = MongoClient(f"mongodb://{self._username}:{self._password}@{self._host}:{self._port}/")
        self._key = self.args["key"]
        self._db = self._client[self._key]  # 数据库名称:w
        self._chunk2keyword = self._db["chunk_keyword_list"]
        self._keyword_count = self._db["keyword_count"]

    def flush(self):
        pass

    def get(self, key: str = None):
        if key is None:
            raise RuntimeError("NanoConnection get needs 'key' parameters.")
        if key == "chunk2keyword":
            return self._chunk2keyword
        elif key == "keyword_count":
            return self._keyword_count
        else:
            raise RuntimeError(f"NanoConnection get has wrong 'key' parameters. {key}.")
