import os
import math
from collections import Counter
from typing import Dict, List, Tuple

from kbx.common.lock.mutex_factory import get_mutex
from kbx.common.logging import logger
from kbx.common.types import KeywordDSConfig, KBXError
from kbx.datastore.base_ds import with_lock, DataStoreType, extract_list
from kbx.datastore.keyword.keyword_base import BaseKeywordDS
from kbx.datastore.connection_pool import ConnectionPool
from kbx.datastore.keyword.mongo_connection import MongoConnection as MongoKeywordConnection


class MongoKeywordDS(BaseKeywordDS):

    def __init__(self, config: KeywordDSConfig, kb_id: str, index_type: str, namespace: str):
        super().__init__(config, kb_id, index_type, namespace)
        os.makedirs(self._base_dir, exist_ok=True)
        self._keyword_idf = dict()
        self._chunks_tfidf = list()
        self._keyword_count = None
        self._chunk2keyword = None
        self._lock = get_mutex(DataStoreType.DOC + "_" + self._key)
        args: Dict[str, str] = dict()
        args["host"] = config.connection_kwargs["host"]
        args["port"] = config.connection_kwargs["port"]
        args["username"] = config.connection_kwargs["username"]
        args["password"] = config.connection_kwargs["password"]
        args["key"] = self._key
        expired_time = config.connection_kwargs.get("expired_time", 5)
        self._connection_pool = ConnectionPool(
            DataStoreType.KEYWORD, self._key, args, expired_time, MongoKeywordConnection)
        self._connection = None

    @with_lock
    def _connect(self) -> None:
        self._connection = self._connection_pool.open_connection()
        self._chunk2keyword = self._connection.get("chunk2keyword")
        self._keyword_count = self._connection.get("keyword_count")
        self._keyword_idf = self._calculate_keyword_idf()
        self._chunks_tfidf = self._calculate_chunks_tfidf()

    @with_lock
    def _close(self) -> None:
        self._connection_pool.close_connection()

    @with_lock
    def _flush(self) -> None:
        self._connection.flush()

    @staticmethod
    def get_type() -> str:
        return type(MongoKeywordDS).__name__

    @with_lock
    def _add(self, keyword_chunk_list: List[Tuple[List[str], str]]) -> KBXError:
        try:
            for keywords, chunk_id in keyword_chunk_list:
                self._chunk2keyword.update_one({"chunk_id": chunk_id},
                                               {"$set": {"chunk_id": chunk_id, "keyword_list": keywords}},
                                               upsert=True)
                for keyword in keywords:
                    self._keyword_count.update_one({"keyword": keyword}, {"$inc": {"count": 1}}, upsert=True)
            self._calculate_keyword_idf()
            self._calculate_chunks_tfidf()

        except Exception as e:
            logger.error("Failed add keyword, %s", e)
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))
        return KBXError()

    def _calculate_keyword_idf(self):
        chunk_keyword_list = list(self._chunk2keyword.find())
        total_chunks = len(chunk_keyword_list)
        self._keyword_idf: Dict[str, float] = {}
        for item in self._keyword_count.find():
            keyword = item["keyword"]
            # calculate include query keywords' documents
            # sum is the chunk number that contains keyword.
            sum = 0
            for item2 in chunk_keyword_list:
                if keyword in item2["keyword_list"]:
                    sum = sum + 1
            # IDF
            self._keyword_idf[keyword] = math.log((1 + total_chunks) / (1 + sum)) + 1
        return self._keyword_idf

    def _calculate_chunks_tfidf(self):
        # calculate all documents' TF-IDF
        self._chunks_tfidf: List[Dict[str, float]] = []
        for chunk_keywords in self._chunk2keyword.find():
            # chunk_id = chunk_keywords["chunk_id"]
            keyword_list = chunk_keywords["keyword_list"]
            keyword_counts = Counter(keyword_list)
            chunk_tfidf = {}
            for keyword, count in keyword_counts.items():
                tf = count
                idf = self._keyword_idf.get(keyword, 0)
                chunk_tfidf[keyword] = tf * idf
            self._chunks_tfidf.append(chunk_tfidf)
        return self._chunks_tfidf

    @with_lock
    def _delete_by_chunk_ids(self, chunk_ids: List[str]) -> KBXError:
        try:
            self._delete_chunk2keyword(chunk_ids)
            self._connection.flush()
        except Exception as e:
            logger.error(f"删除文本块{chunk_ids}时发生错误: {e}")
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))
        return KBXError()

    def _delete_chunk2keyword(self, chunk_ids: List[str]) -> None:
        """删除chunk2keyword中对应的chunk_ids和keywords，并更新相关数据结构"""
        removed_keywords = Counter()
        for chunk_id in chunk_ids:
            condition = {"chunk_id": chunk_id}
            result = self._chunk2keyword.find_one(condition)
            if result:
                removed_keywords.update(result["keyword_list"])
                self._chunk2keyword.delete_one(condition)

        for keyword, freq in removed_keywords.items():
            condition = {"keyword": keyword}
            result = self._keyword_count.find_one(condition)
            if result:
                self._keyword_count.update_one(condition, {"$inc": {"count": -freq}}, upsert=True)
                count = result["count"] - freq
                if count <= 0:
                    self._keyword_count.delete_one(condition)

        self._calculate_keyword_idf()
        self._calculate_chunks_tfidf()

    def _calculate_retrieve_score(self, query_keywords: List[str]):
        query_keyword_counts = Counter(query_keywords)
        query_tfidf = {}

        for keyword, count in query_keyword_counts.items():
            tf = count
            idf = self._keyword_idf.get(keyword, 0)
            query_tfidf[keyword] = tf * idf

        def cosine_similarity(vec1, vec2):
            intersection = set(vec1.keys()) & set(vec2.keys())
            numerator = sum(vec1[x] * vec2[x] for x in intersection)

            sum1 = sum(vec1[x] ** 2 for x in vec1)
            sum2 = sum(vec2[x] ** 2 for x in vec2)
            denominator = math.sqrt(sum1) * math.sqrt(sum2)

            if not denominator:
                return 0.0
            else:
                return float(numerator) / denominator

        similarities: List = list()
        chunk_id_list = [item["chunk_id"] for item in self._chunk2keyword.find()]
        for chunk_id, chunk_tfidf in zip(chunk_id_list, self._chunks_tfidf):
            similarity = cosine_similarity(query_tfidf, chunk_tfidf)
            similarities.append((chunk_id, similarity))

        return similarities

    @with_lock
    def _search(self, keywords: List[str], topk: int) -> Tuple[List[Tuple[str, float]], KBXError]:

        try:
            all_chunk_similarities = self._calculate_retrieve_score(keywords)
            sorted_chunk_indices = sorted(
                all_chunk_similarities,
                key=lambda x: x[1],
                reverse=True
            )
            return extract_list(sorted_chunk_indices, 0, topk), KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _if_chunk_id_exists(self, chunk_id: str) -> bool:
        return True if self._chunk2keyword.find_one({"chunk_id": chunk_id}) else False

    @with_lock
    def _delete_ds(self) -> KBXError:
        self._connection_pool.clear_connection()
        return KBXError()
