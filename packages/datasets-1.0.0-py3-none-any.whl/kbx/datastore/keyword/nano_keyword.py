import os
import math
from collections import Counter
from typing import Dict, List, Tuple

from kbx.common.lock.mutex_factory import get_mutex
from kbx.common.logging import logger
from kbx.common.types import KeywordDSConfig, KBXError
from kbx.datastore.base_ds import with_lock, DataStoreType, extract_list
from kbx.datastore.keyword.keyword_base import BaseKeywordDS
from kbx.datastore.connection_pool import ConnectionPool
from kbx.datastore.keyword.nano_connection import NanoConnection as NanoKeywordConnection


class NanoKeywordDS(BaseKeywordDS):

    def __init__(self, config: KeywordDSConfig, kb_id: str, index_type: str, namespace: str):
        super().__init__(config, kb_id, index_type, namespace)
        os.makedirs(self._base_dir, exist_ok=True)
        self._chunk2keyword_file_path: str = self._path_factory.path_r2a("chunk2keyword.txt")
        self._keyword_idf = dict()
        self._chunks_tfidf = list()
        self._keyword_count = dict()
        self._chunk2keyword = dict()
        self._lock = get_mutex(DataStoreType.DOC + "_" + self._key)
        args: Dict[str, str] = dict()
        args["chunk2keyword_file_path"] = self._chunk2keyword_file_path
        expired_time = config.connection_kwargs.get("expired_time", 5)
        self._connection_pool = ConnectionPool(
            DataStoreType.KEYWORD, self._key, args, expired_time, NanoKeywordConnection)
        self._connection = None

    @with_lock
    def _connect(self) -> None:
        self._connection = self._connection_pool.open_connection()
        self._chunk2keyword = self._connection.get("chunk2keyword")
        self._keyword_count = self._connection.get("keyword_count")
        # print(self._chunk2keyword)
        self._keyword_idf = self._calculate_keyword_idf()
        self._chunks_tfidf = self._calculate_chunks_tfidf()

    @with_lock
    def _close(self) -> None:
        self._connection_pool.close_connection()

    @with_lock
    def _flush(self) -> None:
        self._connection.flush()

    @staticmethod
    def get_type() -> str:
        return "NanoKeywordDS"

    @with_lock
    def _add(self, keyword_chunk_list: List[Tuple[List[str], str]]) -> KBXError:
        """
        保存 keyword -> chunk_id 的映射关系

        Args:
            keyword_chunk_list (list[(list[str], str)]): 传入一个list, list的元素是一个元组,
            元组的第一个元素是keyword列表，第二个元素是对应的ChunkId. (list[keyword], chunk_id)

        Returns:
            是否添加成功.

        """
        try:
            for keyword_chunk in keyword_chunk_list:
                keywords = keyword_chunk[0]
                chunk_id = keyword_chunk[1]
                self._chunk2keyword[chunk_id] = keywords

                for keyword in keywords:
                    self._keyword_count[keyword] = self._keyword_count.get(keyword, 0) + 1

            self._calculate_keyword_idf()
            self._calculate_chunks_tfidf()

        except Exception as e:
            logger.error("Failed add keyword, %s", e)
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))
        return KBXError()

    def _calculate_keyword_idf(self):
        total_chunks = len(self._chunk2keyword)
        self._keyword_idf: Dict[str, float] = {}
        for keyword in self._keyword_count.keys():
            # calculate include query keywords' documents
            doc_count_containing_keyword = sum(1 for doc_keywords in \
                                               self._chunk2keyword.values() if keyword in doc_keywords)
            # IDF
            self._keyword_idf[keyword] = math.log((1 + total_chunks) / (1 + doc_count_containing_keyword)) + 1
        return self._keyword_idf

    def _calculate_chunks_tfidf(self):
        # calculate all documents' TF-IDF
        self._chunks_tfidf: List[Dict[str, float]] = []
        for keyword_list in self._chunk2keyword.values():
            keyword_counts = Counter(keyword_list)
            chunk_tfidf = {}
            for keyword, count in keyword_counts.items():
                tf = count
                idf = self._keyword_idf.get(keyword, 0)
                chunk_tfidf[keyword] = tf * idf
            self._chunks_tfidf.append(chunk_tfidf)
        return self._chunks_tfidf

    @with_lock
    def _delete_by_chunk_ids(self, chunk_ids: List[str]) -> KBXError:
        try:
            self._delete_chunk2keyword(chunk_ids)
            self._connection.flush()
        except Exception as e:
            logger.error(f"删除文本块{chunk_ids}时发生错误: {e}")
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))
        return KBXError()

    def _delete_chunk2keyword(self, chunk_ids: List[str]) -> None:
        """删除chunk2keyword中对应的chunk_ids和keywords，并更新相关数据结构"""
        removed_keywords = Counter()

        for chunk_id in chunk_ids:
            if chunk_id in self._chunk2keyword:
                removed_keywords.update(self._chunk2keyword[chunk_id])
                del self._chunk2keyword[chunk_id]

        for keyword, freq in removed_keywords.items():
            if keyword in self._keyword_count:
                self._keyword_count[keyword] -= freq
                if self._keyword_count[keyword] <= 0:
                    del self._keyword_count[keyword]

        self._calculate_keyword_idf()
        self._calculate_chunks_tfidf()

    def _calculate_retrieve_score(self, query_keywords: List[str]):
        query_keyword_counts = Counter(query_keywords)
        query_tfidf = {}

        for keyword, count in query_keyword_counts.items():
            tf = count
            idf = self._keyword_idf.get(keyword, 0)
            query_tfidf[keyword] = tf * idf

        def cosine_similarity(vec1, vec2):
            intersection = set(vec1.keys()) & set(vec2.keys())
            numerator = sum(vec1[x] * vec2[x] for x in intersection)

            sum1 = sum(vec1[x] ** 2 for x in vec1)
            sum2 = sum(vec2[x] ** 2 for x in vec2)
            denominator = math.sqrt(sum1) * math.sqrt(sum2)

            if not denominator:
                return 0.0
            else:
                return float(numerator) / denominator

        similarities = []
        for chunk_id, chunk_tfidf in zip(self._chunk2keyword.keys(), self._chunks_tfidf):
            similarity = cosine_similarity(query_tfidf, chunk_tfidf)
            similarities.append((chunk_id, similarity))

        return similarities

    @with_lock
    def _search(self, keywords: List[str], topk: int) -> Tuple[List[Tuple[str, float]], KBXError]:

        try:
            all_chunk_similarities = self._calculate_retrieve_score(keywords)
            sorted_chunk_indices = sorted(
                all_chunk_similarities,
                key=lambda x: x[1],
                reverse=True
            )
            return extract_list(sorted_chunk_indices, 0, topk), KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _if_chunk_id_exists(self, chunk_id: str) -> bool:
        return chunk_id in self._chunk2keyword

    @with_lock
    def _delete_ds(self) -> KBXError:
        self._connection_pool.clear_connection()
        try:
            if os.path.exists(self._chunk2keyword_file_path):
                os.remove(self._chunk2keyword_file_path)
        except Exception as e:
            logger.error(f"删除文件时发生错误: {e}")
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))
        return KBXError()
