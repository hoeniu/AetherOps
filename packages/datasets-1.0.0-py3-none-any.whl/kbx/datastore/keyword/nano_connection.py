import json
import os
from typing import Any, Dict, List
from kbx.datastore.base_connection import BaseConnection
from kbx.datastore.serialize_tool import SetDecoder, SetEncoder


class NanoConnection(BaseConnection):

    def __init__(self, args: Dict[str, Any]):
        super().__init__(args)
        self._chunk2keyword: Dict[str, List[str]] = dict()
        self._keyword_count: Dict[str, int] = dict()
        self._load()

    def flush(self):
        with open(self.args["chunk2keyword_file_path"], "w", encoding='utf-8') as f:
            json.dump(self._chunk2keyword, f, cls=SetEncoder, ensure_ascii=False)

    def get(self, key: str = None):
        if key is None:
            raise RuntimeError("NanoConnection get needs 'key' parameters.")
        if key == "chunk2keyword":
            return self._chunk2keyword
        elif key == "keyword_count":
            return self._keyword_count
        else:
            raise RuntimeError(f"NanoConnection get has wrong 'key' parameters. {key}.")

    def _load(self) -> Dict[str, List[str]]:
        if os.path.exists(self.args["chunk2keyword_file_path"]):
            with open(self.args["chunk2keyword_file_path"], "r", encoding='utf-8') as f:
                self._chunk2keyword = json.load(f, cls=SetDecoder)
        for keywords in self._chunk2keyword.values():
            for keyword in keywords:
                self._keyword_count[keyword] = self._keyword_count.get(keyword, 0) + 1
