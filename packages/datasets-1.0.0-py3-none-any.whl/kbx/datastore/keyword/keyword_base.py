from __future__ import annotations

from abc import abstractmethod

from kbx.common.types import KBXError, KeywordDSConfig
from kbx.datastore.base_ds import BaseDS, check_connected
from kbx.datastore.path_factory import PathFactory
from typing import List, Tuple, Any, Optional


class BaseKeywordDS(BaseDS):

    def __init__(self, config: KeywordDSConfig, kb_id: str, index_type: str, namespace: str):
        """
        使用时需要调用者初始化KeywordDS的实例，并管理其生命周期.
        关键词全文搜索的存储体基类
        """
        super().__init__(kb_id, index_type, namespace)
        self._path_factory = PathFactory(config, self.tenant_id, self.user_id, kb_id, index_type, namespace)
        self._base_dir = self._path_factory.path_r2a()

    def _connect(self) -> None:
        pass

    def _close(self) -> None:
        pass

    def __enter__(self) -> BaseKeywordDS:
        return super().__enter__()

    def __exit__(self, exc_type: Optional[BaseException], exc_val: Any, exc_tb: Any) -> bool:
        return super().__exit__(exc_type=exc_type, exc_val=exc_val, exc_tb=exc_tb)

    @check_connected
    def add(self, keyword_chunk_list: List[Tuple[List[str], str]]) -> KBXError:
        """
        保存 keyword -> chunk_id 的映射关系

        Args:
            keyword_chunk_list (list[(list[str], str)]): 传入一个list, list的元素是一个元组,
                元组的第一个元素是keyword列表，第二个元素是对应的ChunkId. (list[keyword], chunk_id)

        Returns:
            KBXError: 执行信息.

        """
        return self._add(keyword_chunk_list)

    @abstractmethod
    def _add(self, keyword_chunk_list: List[Tuple[List[str], str]]) -> KBXError:
        raise NotImplementedError

    @check_connected
    def if_chunk_id_exists(self, chunk_id: str) -> bool:
        return self._if_chunk_id_exists(chunk_id)

    @abstractmethod
    def _if_chunk_id_exists(self, chunk_id: str) -> bool:
        raise NotImplementedError

    @check_connected
    def delete_by_chunk_ids(self, chunk_ids: list[str]) -> KBXError:
        """

        Args:
            chunk_ids (List[str]):

        Returns:
            KBXError: 执行信息.

        """
        return self._delete_by_chunk_ids(chunk_ids)

    @abstractmethod
    def _delete_by_chunk_ids(self, chunk_ids: list[str]) -> KBXError:
        raise NotImplementedError

    @check_connected
    def search(self, keywords: List[str], topk: int = 1000) -> Tuple[List[Tuple[str, int]], KBXError]:
        """

        Args:
            keywords (str): 待查询的keyword列表，本方法需要将所有keyword关联的trunk_id取出,
                            并根据不同trunk_id关联keyword的数量进行倒序排序.
            topk (int): 最大返回结果数量

        Returns:
            List[(str, int)]: chunk_id (str), match_keyword_number (int) (known as 'score')
            KBXError: 执行信息.

        """
        return self._search(keywords=keywords, topk=topk)

    @abstractmethod
    def _search(self, keywords: List[str], topk: int) -> Tuple[List[Tuple[str, int]], KBXError]:
        raise NotImplementedError
