from kbx.common.constants import DEFAULT_NAMESPACE, DEFAULT_TENANT_ID, DEFAULT_USER_ID
from kbx.common.types import FileDSConfig, DocDSConfig
from kbx.common.types import VectorDSConfig, KeywordDSConfig
from kbx.common.types import StructuredDSConfig, GraphDSConfig
from kbx.knowledge_base.types import StructuredIndexConfig, KnowledgeGraphIndexConfig
from kbx.common.types import IndexType
from kbx.datastore.file.file_base import BaseFileDS
from kbx.datastore.doc.doc_base import BaseDocDS
from kbx.datastore.graph.graph_base import BaseGraphDS
from kbx.datastore.keyword.keyword_base import BaseKeywordDS
from kbx.datastore.structured.structured_base import BaseStructuredDS
from kbx.datastore.vector.vector_base import BaseVectorDS


def get_file_datastore(kb_id: str) -> BaseFileDS:
    """

    Args:
        kb_id (str): 知识库id.

    Returns:
        FileDataStore句柄

    """
    from kbx.kbx import KBX
    file_ds_config: FileDSConfig = KBX.config.file_ds
    if file_ds_config.type.startswith("nano_filesystem"):
        from kbx.datastore.file.nano_file import NanoFileDS
        return NanoFileDS(file_ds_config, kb_id)
    else:
        raise NotImplementedError


def get_doc_datastore(kb_id: str) -> BaseDocDS:
    """

    Args:
        kb_id (str): 知识库id.

    Returns:
        DocDataStore 句柄

    """
    from kbx.kbx import KBX
    doc_ds_config: DocDSConfig = KBX.config.doc_ds
    if doc_ds_config.type.startswith("nano_docsystem"):
        from kbx.datastore.doc.nano_doc import NanoDocDS
        return NanoDocDS(doc_ds_config, kb_id)
    elif doc_ds_config.type.startswith("mongo"):
        from kbx.datastore.doc.mongo_doc import MongoDocDS
        return MongoDocDS(doc_ds_config, kb_id)
    else:
        raise NotImplementedError


def get_fast_doc_ds(tenant_id: str = DEFAULT_TENANT_ID, user_id: str = DEFAULT_USER_ID) -> BaseDocDS:
    """
    专门用于获取 FastDocDS 句柄.

    Args:
        tenant_id (str, optional): Defaults to DEFAULT_TENANT_ID.
        user_id (str, optional): Defaults to DEFAULT_USER_ID.

    Returns:
        BaseDocDS: FastDocDS 句柄.
    """
    fake_kb_id = "fast_doc_ds"
    from kbx.kbx import KBX
    doc_ds_config: DocDSConfig = KBX.config.doc_ds
    if doc_ds_config.type.startswith("nano_docsystem"):
        from kbx.datastore.doc.nano_doc import NanoDocDS
        return NanoDocDS(doc_ds_config, fake_kb_id, tenant_id, user_id)
    elif doc_ds_config.type.startswith("mongo"):
        from kbx.datastore.doc.mongo_doc import MongoDocDS
        return MongoDocDS(doc_ds_config, fake_kb_id, tenant_id, user_id)
    else:
        raise NotImplementedError


def get_vector_datastore(kb_id: str, index_type: IndexType = IndexType.VECTOR_KEYWORD,
                         namespace: str = DEFAULT_NAMESPACE) -> BaseVectorDS:
    """

    Args:
        kb_id (str): 知识库id.
        index_type (IndexType): 上游调用端的IndexType, 用于数据隔离.
        namespace (str): 上游调用端指定的namespace, 用于数据隔离.

    Returns:
        VectorDataStore 句柄

    """
    from kbx.kbx import KBX
    vector_ds_config: VectorDSConfig = KBX.config.vector_ds
    if vector_ds_config.type.startswith("chroma"):
        from kbx.datastore.vector.chroma_vector import ChromaVectorDS
        return ChromaVectorDS(vector_ds_config, kb_id, index_type, namespace)
    else:
        raise NotImplementedError


def get_keyword_datastore(kb_id: str,
                          index_type: IndexType = IndexType.VECTOR_KEYWORD,
                          namespace: str = DEFAULT_NAMESPACE) -> BaseKeywordDS:
    """

    Args:
        kb_id (str):
        index_type (IndexType): 上游调用端的IndexType, 用于数据隔离.
        namespace (str): 上游调用端指定的namespace, 用于数据隔离.

    Returns:
        KeywordDataStore 句柄.

    """
    from kbx.kbx import KBX
    keyword_ds_config: KeywordDSConfig = KBX.config.keyword_ds
    if keyword_ds_config.type.startswith("nano"):
        from kbx.datastore.keyword.nano_keyword import NanoKeywordDS
        return NanoKeywordDS(keyword_ds_config, kb_id, index_type, namespace)
    elif keyword_ds_config.type.startswith("mongo"):
        from kbx.datastore.keyword.mongo_keyword import MongoKeywordDS
        return MongoKeywordDS(keyword_ds_config, kb_id, index_type, namespace)
    else:
        raise NotImplementedError


def get_structured_datastore(kb_id: str, index_config: StructuredIndexConfig,
                             index_type: IndexType = IndexType.STRUCTURED,
                             namespace: str = DEFAULT_NAMESPACE) -> BaseStructuredDS:
    """

    Args:
        kb_id (str): 知识库id.
        index_config (StructuredIndexConfig): 判断是否为外部知识库, 并提供外部知识库的配置.
        index_type (IndexType): 上游调用端的IndexType, 用于数据隔离.
        namespace (str): 上游调用端指定的namespace, 用于数据隔离.

    Returns:
        StructuredDataStore 句柄.

    """
    if index_config.external_structured_ds is not None:
        structured_ds_config: StructuredDSConfig = index_config.external_structured_ds
    else:
        from kbx.kbx import KBX
        structured_ds_config: StructuredDSConfig = KBX.config.structured_ds
    if structured_ds_config.type.startswith("sqlite"):
        from kbx.datastore.structured.sqlite_structured import SqliteStructuredDS
        return SqliteStructuredDS(structured_ds_config, kb_id, index_type, namespace)
    elif structured_ds_config.type.startswith("sqlalchemy"):  # support sqlalchemy_sqlite, sqlalchemy_mysql
        from kbx.datastore.structured.sqlalchemy_structured import SqlAlchemyStructuredDS
        return SqlAlchemyStructuredDS(structured_ds_config, kb_id, index_type, namespace)
    else:
        raise NotImplementedError


def get_graph_datastore(kb_id: str, index_config: KnowledgeGraphIndexConfig,
                        index_type: IndexType = IndexType.KNOWLEDGE_GRAPH,
                        namespace: str = DEFAULT_NAMESPACE) -> BaseGraphDS:
    """

    Args:
        kb_id (str): 知识库id.
        index_config (KnowledgeGraphIndexConfig): 判断是否为外部知识库, 并提供外部知识库的配置.
        index_type (IndexType): 上游调用端的IndexType, 用于数据隔离.
        namespace (str): 上游调用端指定的namespace, 用于数据隔离.

    Returns:
        GraphDataStore 句柄.

    """
    if index_config.external_graph_ds is not None:
        graph_ds_config: GraphDSConfig = index_config.external_graph_ds
    else:
        from kbx.kbx import KBX
        graph_ds_config: GraphDSConfig = KBX.config.graph_ds
    if graph_ds_config.type.startswith("networkx"):
        from kbx.datastore.graph.networkx_graph import NetworkxGraphDS
        return NetworkxGraphDS(graph_ds_config, kb_id, index_type, namespace)
    elif graph_ds_config.type.startswith("nebula"):
        from kbx.datastore.graph.nebula_graph import NebulaGraphDS
        return NebulaGraphDS(graph_ds_config, kb_id, index_type, namespace, index_config.schema_dict)
    elif graph_ds_config.type.startswith("neo4j"):
        from kbx.datastore.graph.neo4j_graph import Neo4jGraphDS
        return Neo4jGraphDS(graph_ds_config, kb_id, index_type, namespace)
    else:
        raise NotImplementedError
