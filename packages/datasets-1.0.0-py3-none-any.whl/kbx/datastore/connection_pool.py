from abc import ABC
from typing import Any, Dict, TypeVar, Generic
from kbx.common.lock.shared_thread_mutex import SharedThreadMutex
from kbx.datastore.base_ds import with_lock
from kbx.datastore.types import DataStoreType
from kbx.datastore.safe_dict import SafeDict
from kbx.datastore.base_connection import BaseConnection

ConnectionType = TypeVar("connection_type", bound=BaseConnection)


class ConnectionPool(ABC, Generic[ConnectionType]):
    """
    旨在设计进程内的DS连接池, 为进程内的各个线程提供DS连接服务
    1. 使用时首先实例化连接池, 然后调用open_connection方法获得连接
    2. 每个open_connection必须调用close_connection, 否则资源可能无法正确释放
    3. 即使连接被close, 连接也会存续expired_time(s)后，才被释放, 用于快速重新建立连接
    4. 适配某些不支持多个连接同时存在的服务逻辑，例如sqlite.
    """
    # ds_type -> { key -> (number of connections, connection) }
    connection_pool: Dict[str, SafeDict] = dict()
    connection_pool[DataStoreType.DOC] = SafeDict()
    connection_pool[DataStoreType.FILE] = SafeDict()
    connection_pool[DataStoreType.GRAPH] = SafeDict()
    connection_pool[DataStoreType.KEYWORD] = SafeDict()
    connection_pool[DataStoreType.STRUCTURED] = SafeDict()
    connection_pool[DataStoreType.VECTOR] = SafeDict()

    def __init__(self, ds_type: DataStoreType,
                 key: str,
                 args: Dict[str, Any],
                 expired_time: int, connection_type: ConnectionType):
        """
        初始化连接池。

        Args:
            ds_type: (DataStoreType): 当前连接对应的DS类型
            key (str): DS的唯一标识 kb_id + index_type + namespace
            args (Dict): 连接参数.
            expired_time (int): 连接超时时间(秒)

        Returns:
            None
        """
        self.ds_type: DataStoreType = ds_type
        self.key: str = key
        self.lock_key = self.ds_type + "_" + self.key + "_connection"
        self.expired_time: int = expired_time
        # 为了应对key完全相同的connection, 线程级别的共享锁应该是make sense的
        self._lock: SharedThreadMutex = SharedThreadMutex(self.lock_key)
        if self.ds_type not in ConnectionPool.connection_pool.keys():
            raise RuntimeError(f"错误的ds_type: {self.ds_type}.")
        self.pool: SafeDict = ConnectionPool.connection_pool[self.ds_type]
        self.pool.set_timeout(self.expired_time)
        self.args = args
        self.connection_type = connection_type

    @with_lock
    def open_connection(self) -> ConnectionType:
        """
        创建一个新的连接。

        Returns:
            Any: 返回创建的连接对象, 子类中需要明确连接对象的定义, 调用方需要对连接对象的使用负责.
        """
        if self.key in self.pool.keys():
            # logger.info("从pool中获取连接")
            connection = self.pool.get(self.key)
        else:
            # logger.info("创建新连接")
            connection = self._open_connection()
            self.pool[self.key] = connection
        return connection

    @with_lock
    def close_connection(self) -> None:
        """
        1. 关闭当前连接.
        2. 检测连接池中是否是最后一个连接.
        """
        if self.key not in self.pool.keys():
            raise RuntimeError(f"Try to close a non-exist connection. {self.ds_type}, {self.key}")
        del self.pool[self.key]

    @with_lock
    def clear_connection(self) -> None:
        """
        1. 立即从连接池中移除连接
        2. 如果连接池内不存在该链接，按删除成功处理（应对并发删除的情形）
        """
        if self.key not in self.pool.keys():
            return
        self.pool.delete_im(self.key)

    def _open_connection(self) -> ConnectionType:
        """
        初始化连接的具体实现。
        """
        return self.connection_type(self.args)
