from __future__ import annotations

import enum


class FileType(str, enum.Enum):
    RAW_DOC_FILES = "raw_doc_files"
    EXTRA_DOC_ELEMENTS = "extra_doc_elements"
    GRAPH_SCHEMA = "graph_schema"


class DataStoreType(str, enum.Enum):
    EMTPY = ""
    FILE = "filesystem"
    DOC = "doc_data"
    KEYWORD = "keyword"
    VECTOR = "vector"
    STRUCTURED = "structured"
    GRAPH = "graph"
