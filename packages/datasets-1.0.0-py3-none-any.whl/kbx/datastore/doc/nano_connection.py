import os
import json
from typing import Any, Dict
from kbx.common.types import IndexType, DocData, Chunk
from kbx.datastore.base_connection import BaseConnection
from kbx.datastore.doc.doc_base import fill_doc_element_item


class NanoConnection(BaseConnection):

    def __init__(self, args: Dict[str, Any]):
        super().__init__(args)
        self.index_type_list = list(IndexType)
        self._doc_data = dict()
        self._doc_element_dict = dict()
        self._chunk_data = dict()
        self._doc_id2chunk_id = dict()
        if os.path.exists(self.args["doc_file"]):
            with open(self.args["doc_file"], 'r', encoding='utf-8') as file_handler:
                doc_data_temp = json.load(file_handler)
                self._doc_data = {key: DocData.model_validate_json(value) for key, value in doc_data_temp.items()}
                for doc_data_ins in self._doc_data.values():
                    fill_doc_element_item(self._doc_element_dict, doc_data_ins)
        for i in range(len(self.args["chunk_files"])):
            if not os.path.exists(self.args["chunk_files"][i]):
                self._chunk_data[self.index_type_list[i]] = dict()
            else:
                with open(self.args["chunk_files"][i], 'r', encoding='utf-8') as file_handler:
                    chunk_data_temp = json.load(file_handler)
                    self._chunk_data[self.index_type_list[i]] = {key: Chunk.model_validate_json(value)
                                                                 for key, value in chunk_data_temp.items()}
        if os.path.exists(self.args["id_map_file"]):
            with open(self.args["id_map_file"], 'r', encoding='utf-8') as file_handler:
                self._doc_id2chunk_id = json.load(file_handler)

    def flush(self):
        with open(self.args["doc_file"], 'w', encoding='utf-8') as file_handler:
            pure_dict = {key: value.model_dump_json() for key, value in self._doc_data.items()}
            json.dump(pure_dict, file_handler, ensure_ascii=False)
        for i in range(len(self.args["chunk_files"])):
            with open(self.args["chunk_files"][i], 'w') as file_handler:
                chunk_dict: Dict[str, Chunk] = self._chunk_data[self.index_type_list[i]]
                pure_dict = {key: value.model_dump_json() for key, value in chunk_dict.items()}
                json.dump(pure_dict, file_handler)
        with open(self.args["id_map_file"], 'w') as file_handler:
            json.dump(self._doc_id2chunk_id, file_handler)

    def get(self, key: str = None) -> Any:
        if key is None or key == "doc_data":
            return self._doc_data
        elif key == "chunk_data":
            return self._chunk_data
        elif key is None or key == "doc_id2chunk_id":
            return self._doc_id2chunk_id
        elif key == "doc_element":
            return self._doc_element_dict
        else:
            return self._chunk_data
