from typing import Any, Dict
from kbx.common.types import IndexType
from kbx.datastore.base_connection import BaseConnection
from pymongo import MongoClient


class MongoConnection(BaseConnection):

    def __init__(self, args: Dict[str, Any]):
        super().__init__(args)
        self._host = self.args["host"]
        self._port = self.args["port"]
        self._username = self.args["username"]
        self._password = self.args["password"]
        self._client = MongoClient(f"mongodb://{self._username}:{self._password}@{self._host}:{self._port}/")
        self._key = self.args["key"]
        self._db = self._client[self._key]  # 数据库名称
        self._doc_data = self._db["doc_data"]  # collection of doc_data
        self._chunk_data = dict()
        for index_type in list(IndexType):
            self._chunk_data[index_type] = self._db[f"chunk_data_{index_type}"]  # collection of chunk_data
        self._id_map = self._db["id_map"]  # collection of id_map

    def flush(self):
        pass

    def get(self, key: str = None) -> Any:
        if key is None or key == "doc_data":
            return self._doc_data
        elif key == "chunk_data":
            return self._chunk_data
        elif key == "id_map":
            return self._id_map
        elif key == "db":
            return self._db
        elif key == "client":
            return self._client
        else:
            return None
