from __future__ import annotations

from abc import abstractmethod

from typing import Any, Dict, List, Tuple, Optional, Union
from kbx.common.types import DocData, DocElement, Chunk, DocDSConfig, KBXError, IndexType
from kbx.datastore.base_ds import BaseDS, check_connected
from kbx.datastore.path_factory import PathFactory
from kbx.common.logging import logger


def init_doc_element_result_dict(doc_element_id_list: List[str]) -> Dict[str, Union[DocElement, KBXError]]:
    return {
        doc_element_id: KBXError(code=KBXError.Code.NOT_FOUND_ERROR,
                                 msg=f"Failed to find doc_element_id {doc_element_id}.")
        for doc_element_id in doc_element_id_list
    }


def fill_doc_element_item(doc_element_dict: Dict[str, DocElement], doc_data: DocData):
    for doc_element in doc_data.doc_elements:
        doc_element_dict[doc_element.doc_element_id] = doc_element


def remove_doc_element_item(doc_element_dict: Dict[str, DocElement], doc_data: DocData):
    for doc_element in doc_data.doc_elements:
        if doc_element.doc_element_id in doc_element_dict:
            del doc_element_dict[doc_element.doc_element_id]


class BaseDocDS(BaseDS):

    def __init__(self, config: DocDSConfig, kb_id: str, tenant_id: str = None, user_id: str = None):
        """
        管理 DocData和Chunk的基类, 维护 id->DocData, id->Chunk的映射关系 以及 DocData, Chunk数据本身.
        对于下面所有操作，如果未能成功(无论任何原因)，需要抛出对应异常告知调用者.

        FileDS不区分index_type和namespace, 方便调用者灵活配置路径.
        """
        super().__init__(kb_id=kb_id, index_type="", namespace="", tenant_id=tenant_id, user_id=user_id)
        self._config: DocDSConfig = config
        self._path_factory = PathFactory(config, self.tenant_id, self.user_id, kb_id)
        self._base_dir = self._path_factory.path_r2a()

    def __enter__(self) -> BaseDocDS:
        return super().__enter__()

    def __exit__(self, exc_type: Optional[BaseException], exc_val: Any, exc_tb: Any) -> bool:
        return super().__exit__(exc_type=exc_type, exc_val=exc_val, exc_tb=exc_tb)

    def _connect(self) -> None:
        pass

    def _close(self) -> None:
        pass

    def _flush(self) -> None:
        pass

    @check_connected
    def save_chunk(self, chunk: Chunk, index_type: IndexType) -> KBXError:
        """
        保存 chunk_id -> Chunk 的键值对到DataStore, 用于维护 Chunk.

        Args:
            chunk (Chunk): 文本块。
            index_type (IndexType): 索引类型，可在同一知识库内区分不同index用途的chunk数据子集。

        Returns:
            KBXError: 方法执行返回值和错误信息.

        """
        return self._save_chunk(chunk, index_type)

    @abstractmethod
    def _save_chunk(self, chunk: Chunk, index_type: IndexType) -> KBXError:
        raise NotImplementedError

    @check_connected
    def save_doc_data(self, doc_data: DocData) -> KBXError:
        """
        保存 doc_id -> DocData 的键值对到DataStore, 用于维护 DocData。

        Args:
            doc_data (DocData): 文本内容数据

        Returns:
            KBXError: 方法执行返回值和错误信息.

        """
        return self._save_doc_data(doc_data)

    @abstractmethod
    def _save_doc_data(self, doc_data: DocData) -> KBXError:
        raise NotImplementedError

    @check_connected
    def load_chunk(self, chunk_id: str, index_type: IndexType) -> Tuple[Chunk, KBXError]:
        """
        根据 chunk_id 获得对应的 Chunk.

        Args:
            chunk_id (str): chunk_id。
            index_type (IndexType): 索引类型，可在同一知识库内区分不同index用途的chunk数据子集。

        Returns:
            Chunk 返回的文本块实例
            KBXError: 方法执行返回值和错误信息.

        """
        return self._load_chunk(chunk_id, index_type)

    @abstractmethod
    def _load_chunk(self, chunk_id: str, index_type: IndexType) -> Tuple[Chunk, KBXError]:
        raise NotImplementedError

    @check_connected
    def load_doc_data(self, doc_id: str) -> Tuple[DocData, KBXError]:
        """
        根据 doc_id 获得对应的 DocData.

        Args:
            doc_id (str): doc_id。

        Returns:
            DocData: DocData实例.
            KBXError: 方法执行返回值和错误信息.
        """
        return self._load_doc_data(doc_id)

    @abstractmethod
    def _load_doc_data(self, doc_id: str) -> Tuple[DocData, KBXError]:
        raise NotImplementedError

    @check_connected
    def delete_chunk(self, chunk_id: str, index_type: IndexType) -> KBXError:
        """
        根据 chunk_id 删除对应的 Chunk.

        Args:
            chunk_id (str): chunk_id。
            index_type (IndexType): 索引类型，可在同一知识库内区分不同index用途的chunk数据子集。

        Returns:
            KBXError: 方法执行返回值和错误信息.

        """
        return self._delete_chunk(chunk_id, index_type)

    @abstractmethod
    def _delete_chunk(self, chunk_id: str, index_type: IndexType) -> KBXError:
        raise NotImplementedError

    @check_connected
    def delete_doc_data(self, doc_id: str) -> KBXError:
        """
        根据 doc_id 删除对应的 DocData

        Args:
            doc_id (str): doc_id.

        Returns:
            KBXError: 方法执行返回值和错误信息.

        """
        return self._delete_doc_data(doc_id)

    @abstractmethod
    def _delete_doc_data(self, doc_id: str) -> KBXError:
        raise NotImplementedError

    @check_connected
    def list_chunk_ids_by_doc_id(self, doc_id: str, index_type: IndexType,
                                 offset: int = 0, limit: int = -1) -> Tuple[List[str], KBXError, int]:
        """
        根据doc_id返回关联的chunk_ids.

        Args:
            doc_id (str): 系统中的文档id.
            index_type (IndexType): 子类型id.

        Returns:
            List[str]: doc_id关联的index_type类型的chunk_id列表.
            KBXError: 方法执行返回值和错误信息.
            int: 满足约束条件的chunk_id的总数

        """
        return self._list_chunk_ids_by_doc_id(doc_id, index_type, offset, limit)

    @abstractmethod
    def _list_chunk_ids_by_doc_id(self, doc_id: str, index_type: IndexType,
                                  offset: int = 0, limit: int = -1) -> Tuple[List[str], KBXError, int]:
        raise NotImplementedError

    @check_connected
    def list_doc_ids(self, offset: int = 0, limit: int = -1) -> Tuple[List[str], KBXError]:
        """
        返回当前doc_ds中所有的doc_ids.

        Args:

        Returns:
            List[str]: 当前知识库内所有的doc_id列表.
            KBXError: 方法执行返回值和错误信息.

        """
        return self._list_doc_ids()

    @abstractmethod
    def _list_doc_ids(self, offset: int = 0, limit: int = -1) -> Tuple[List[str], KBXError]:
        raise NotImplementedError

    @check_connected
    def get_doc_element_by_id(self, doc_element_id: str) -> Tuple[DocElement, KBXError]:
        """

        Args:
            doc_element_id (str): 需要查找的doc_element_id.

        Returns:
            DocElement: doc_element_id 对应的 doc_element 实例，如果没有找到，返回None.
            KBXError: 方法执行返回值和错误信息.

        """
        return self._get_doc_element_by_id(doc_element_id)

    @abstractmethod
    def _get_doc_element_by_id(self, doc_element_id: str) -> Tuple[DocElement, KBXError]:
        raise NotImplementedError

    @check_connected
    def get_doc_element_by_ids(self, doc_id: str, doc_element_id_list: List[str]) \
            -> Dict[str, Union[DocElement, KBXError]]:
        """
        get_doc_element_by_id的批量版版本

        Args:
            doc_id (str): 需要查找的doc_element的doc_id, 所有doc_element_id均需要属于doc_id.
            doc_element_id_list (List[str]): 需要查找的doc_element的doc_element_id列表.

        Returns:
            Dict[str, Union[DocElement, KBXError]]: 返回的doc_element_id -> doc_element 字典
                如果值为DocElement, 则说明对应的id找到了正确的结果;
                如果值为KBXError, 则说明查找过程中发生了错误，需要调用方判断程序是否正常运行;
        """
        return self._get_doc_element_by_ids(doc_id, doc_element_id_list)

    def _get_doc_element_by_ids(self, doc_id: str, doc_element_id_list: List[str]) \
            -> Dict[str, Union[DocElement, KBXError]]:
        result_dict: Dict[str, Union[DocElement, KBXError]] = dict()
        for doc_element_id in doc_element_id_list:
            try:
                doc_element, error = self._get_doc_element_by_id(doc_element_id=doc_element_id)
                if error.code == KBXError.Code.SUCCESS:
                    if doc_element is not None:
                        result_dict[doc_element_id] = doc_element  # 查找成功
                    else:
                        result_dict[doc_element_id] = KBXError(msg=f"Failed to find {doc_element_id}.")  # 没有找到
                else:
                    result_dict[doc_element_id] = error  # 查找过程中发生错误.
            except Exception as e:
                error_msg = f"Got an exception from getting doc_element_id: {doc_element_id}"
                logger.error(error_msg)
                raise e  # 抛出异常
        return result_dict
