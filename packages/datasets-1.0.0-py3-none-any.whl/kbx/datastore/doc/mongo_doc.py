from typing import Any, Dict, List, Tuple, Union
from kbx.common.types import DocData, DocElement, Chunk, DocDSConfig, KBXError, IndexType
from kbx.datastore.types import DataStoreType
from kbx.datastore.base_ds import extract_list
from kbx.datastore.doc.doc_base import BaseDocDS, init_doc_element_result_dict
from kbx.datastore.connection_pool import ConnectionPool
from kbx.datastore.doc.mongo_connection import MongoConnection


class MongoDocDS(BaseDocDS):

    def __init__(self, config: DocDSConfig, kb_id: str, tenant_id: str = None, user_id: str = None):
        super().__init__(config=config, kb_id=kb_id, tenant_id=tenant_id, user_id=user_id)
        args: Dict[str, Any] = dict()
        args["host"] = config.connection_kwargs["host"]
        args["port"] = config.connection_kwargs["port"]
        args["username"] = config.connection_kwargs["username"]
        args["password"] = config.connection_kwargs["password"]
        args["key"] = self._key
        expired_time = config.connection_kwargs.get("expired_time", 5)
        self._connection_pool: ConnectionPool = ConnectionPool(
            DataStoreType.DOC, self._key, args, expired_time, MongoConnection)
        self._connection: MongoConnection = None
        self._doc_data = None
        self._chunk_data = None
        self._id_map = None

    @staticmethod
    def get_type() -> str:
        return type(MongoDocDS).__name__

    def _connect(self) -> None:
        self._connection = self._connection_pool.open_connection()
        self._doc_data = self._connection.get("doc_data")
        self._chunk_data = self._connection.get("chunk_data")
        self._id_map = self._connection.get("id_map")

    def _close(self) -> None:
        self._doc_data = None
        self._chunk_data = None
        self._id_map = None

    def _flush(self) -> None:
        self._connection.flush()

    def _delete_ds(self) -> KBXError:
        self._doc_data.delete_many({})
        for index_type, chunk_data in self._chunk_data.items():
            chunk_data.delete_many({})
        self._id_map.delete_many({})
        db = self._connection.get("client")
        db.drop_database(self._key)
        self._connection.flush()
        return KBXError()

    def _save_chunk(self, chunk: Chunk, index_type: IndexType) -> KBXError:
        try:
            chunk_id: str = chunk.chunk_id
            doc_id: str = chunk.doc_id
            self._chunk_data[index_type].update_one({"chunk_id": chunk_id}, {"$set": chunk.model_dump()},
                                                    upsert=True)
            # 如果插入chunk的时候还没有插入doc，需要下面的逻辑
            self.__update_chunk_id_list(doc_id, index_type, chunk_id, True)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _save_doc_data(self, doc_data: DocData) -> KBXError:
        try:
            self._doc_data.update_one({"doc_id": doc_data.doc_id}, {"$set": doc_data.model_dump()}, upsert=True)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _load_chunk(self, chunk_id: str, index_type: IndexType) -> Tuple[Chunk, KBXError]:
        try:
            result = self._chunk_data[index_type].find_one({"chunk_id": chunk_id}, {"_id": 0})
            if result:
                return Chunk(**result), KBXError()
            return None, KBXError(code=KBXError.Code.RUNTIME_ERROR,
                                  msg=f"chunk_id: {chunk_id} doesn't exist in doc ds.")
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _load_doc_data(self, doc_id: str) -> Tuple[DocData, KBXError]:
        try:
            result = self._doc_data.find_one({"doc_id": doc_id}, {"_id": 0})
            if result:
                return DocData(**result), KBXError()
            return None, KBXError(code=KBXError.Code.RUNTIME_ERROR,
                                  msg=f"Failed to find doc_id: {doc_id}")
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _delete_chunk(self, chunk_id: str, index_type: IndexType) -> KBXError:
        """
        删除chunk时, 不会删除任何doc, 但是要维护doc_id对应的chunk_id列表.
        """
        try:
            chunk_data = self._chunk_data[index_type]
            condition = {"chunk_id": chunk_id}
            chunk_dict: Dict[str, Any] = chunk_data.find_one(condition, {"_id": 0})
            if chunk_dict:
                chunk: Chunk = Chunk.model_validate(chunk_dict)
                doc_id = chunk.doc_id
                chunk_data.delete_one(condition)
                self.__update_chunk_id_list(doc_id, index_type, chunk_id, False)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _delete_doc_data(self, doc_id: str) -> KBXError:
        """
        根据doc_id删除doc, 删除doc关联的所有chunks, 删除doc_id对应的chunk_id列表.
        """
        try:
            condition = {"doc_id": doc_id}
            self._doc_data.delete_one(condition)
            self.__delete_doc_id_from_id_map(doc_id)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _list_chunk_ids_by_doc_id(self, doc_id: str, index_type: IndexType,
                                  offset: int = 0, limit: int = -1) -> Tuple[List[str], KBXError, int]:
        try:
            result = self._id_map.find_one({"doc_id": doc_id, "index_type": index_type},
                                           {"_id": 0})
            if result:
                chunk_id_list = result["chunk_id_list"]
                return extract_list(chunk_id_list, offset, limit), KBXError(), len(chunk_id_list)
            else:
                return [], KBXError(), 0
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e)), 0

    def _list_doc_ids(self, offset: int = 0, limit: int = 1000) -> Tuple[List[str], KBXError]:
        try:
            return [doc["doc_id"] for doc in self._doc_data.find().skip(offset).limit(limit)], KBXError()
        except Exception as e:
            return list(), KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _get_doc_element_by_id(self, doc_element_id: str) -> Tuple[DocElement, KBXError]:
        try:
            result = self._doc_data.find_one({"doc_elements.elements.doc_element_id": doc_element_id},
                                             {"doc_elements.elements.$": 1, "_id": 0})
            if not result:
                return None, KBXError(code=KBXError.Code.RUNTIME_ERROR,
                                      msg=f"Failed  to find doc_element_id: {doc_element_id}")
            else:
                result = result["doc_elements"]["elements"][0]
                return DocElement(**result), KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def _get_doc_element_by_ids(self, doc_id: str, doc_element_id_list: List[str]) -> \
            Dict[str, Union[DocElement, KBXError]]:
        result_dict = init_doc_element_result_dict(doc_element_id_list)
        doc_data = self._doc_data.find_one(
            {"doc_id": doc_id},
            {"doc_elements": 1, "_id": 0})
        if not doc_data:
            return result_dict
        for item in doc_data["doc_elements"]["elements"]:
            doc_element_id = item["doc_element_id"]
            if doc_element_id in doc_element_id_list:
                result_dict[doc_element_id] = DocElement(**item)
        return result_dict

    def __delete_doc_id_from_id_map(self, doc_id: str):
        for index_type in list(IndexType):
            result = self._id_map.find_one({"doc_id": doc_id, "index_type": index_type}, {"_id": 0})
            if result:
                for chunk_id in result["chunk_id_list"]:
                    self._chunk_data[index_type].delete_one({"chunk_id": chunk_id})
            self._id_map.delete_one({"doc_id": doc_id, "index_type": index_type})

    def __update_chunk_id_list(self, doc_id: str, index_type: IndexType, chunk_id: str, is_add: bool = True):
        condition = {"doc_id": doc_id, "index_type": index_type}
        result = self._id_map.find_one(condition, {"_id": 0})
        chunk_id_list: List[str] = result["chunk_id_list"] if result else list()
        chunk_id_list = list(filter(lambda c_id: c_id != chunk_id, chunk_id_list))
        if is_add:
            chunk_id_list.append(chunk_id)
        self._id_map.update_one(condition, {"$set": {"chunk_id_list": chunk_id_list}}, upsert=True)
