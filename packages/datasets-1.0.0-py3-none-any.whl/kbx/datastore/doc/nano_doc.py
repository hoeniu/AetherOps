import os
import copy
from typing import Any, Dict, List, Tuple, Union

from kbx.common.lock.mutex_factory import get_mutex
from kbx.common.types import DocData, DocElement, Chunk, DocDSConfig, KBXError, IndexType
from kbx.datastore.base_ds import with_lock, DataStoreType, extract_list
from kbx.datastore.doc.doc_base import BaseDocDS, fill_doc_element_item, remove_doc_element_item
from kbx.datastore.doc.doc_base import init_doc_element_result_dict
from kbx.datastore.connection_pool import ConnectionPool
from kbx.datastore.base_connection import BaseConnection
from kbx.datastore.doc.nano_connection import NanoConnection as NanoDocConnection


class NanoDocDS(BaseDocDS):
    index_type_list: List[str] = list(IndexType)

    def __init__(self, config: DocDSConfig, kb_id: str, tenant_id: str = None, user_id: str = None):
        super().__init__(config=config, kb_id=kb_id, tenant_id=tenant_id, user_id=user_id)
        os.makedirs(self._base_dir, exist_ok=True)
        self._doc_file: str = self._path_factory.path_r2a("doc_data.json")
        self._chunk_files: List[str] = [self._path_factory.path_r2a(f"{item.value}.json")
                                        for item in NanoDocDS.index_type_list]
        self._id_map_file = self._path_factory.path_r2a("id_map.json")
        self._doc_data: Dict[str, DocData] = None  # {doc_id -> doc}
        self._chunk_data: Dict[str, Dict[str, Chunk]] = None  # {index_type -> {chunk_id -> chunk}}
        self._doc_id2chunk_id: Dict[str, Dict[str, List[str]]] = None  # {doc_id->{index_type->chunk_id_list}}
        self._doc_element: Dict[str, DocElement] = None  # {doc_element_id -> doc_element}
        self._lock = get_mutex(DataStoreType.DOC + "_" + self._key)
        args: Dict[str, Any] = dict()
        args["doc_file"] = self._doc_file
        args["chunk_files"] = self._chunk_files
        args["id_map_file"] = self._id_map_file
        expired_time = config.connection_kwargs.get("expired_time", 5)
        self._connection_pool: ConnectionPool = ConnectionPool(
            DataStoreType.DOC, self._key, args, expired_time, NanoDocConnection)
        self._connection: BaseConnection = None

    @staticmethod
    def get_type() -> str:
        return type(NanoDocDS).__name__

    @with_lock
    def _connect(self) -> None:
        self._connection = self._connection_pool.open_connection()
        self._doc_data = self._connection.get("doc_data")
        self._chunk_data = self._connection.get("chunk_data")
        self._doc_id2chunk_id = self._connection.get("doc_id2chunk_id")
        self._doc_element = self._connection.get("doc_element")

    @with_lock
    def _close(self) -> None:
        self._connection_pool.close_connection()

    @with_lock
    def _flush(self) -> None:
        self._connection.flush()

    @with_lock
    def _delete_ds(self) -> KBXError:
        self._connection_pool.clear_connection()
        return KBXError()

    @with_lock
    def _save_chunk(self, chunk: Chunk, index_type: IndexType) -> KBXError:
        try:
            chunk_id: str = chunk.chunk_id
            doc_id: str = chunk.doc_id
            self._chunk_data[index_type][chunk_id] = chunk
            # 如果插入chunk的时候还没有插入doc，需要下面的逻辑
            if doc_id not in self._doc_id2chunk_id.keys():
                self._doc_id2chunk_id[doc_id] = dict()
                self._doc_id2chunk_id[doc_id][index_type] = list()
            if chunk_id not in self._doc_id2chunk_id[doc_id][index_type]:
                self._doc_id2chunk_id[doc_id][index_type].append(chunk_id)
            return KBXError()
        except Exception as e:
            raise e
            # return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _save_doc_data(self, doc_data: DocData) -> KBXError:
        try:
            doc_id: str = doc_data.doc_id
            self._doc_data[doc_data.doc_id] = doc_data
            if doc_id not in self._doc_id2chunk_id.keys():
                self._doc_id2chunk_id[doc_id] = dict()
                for index_type in NanoDocDS.index_type_list:
                    self._doc_id2chunk_id[doc_id][index_type] = list()
            fill_doc_element_item(self._doc_element, doc_data)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _load_chunk(self, chunk_id: str, index_type: IndexType) -> Tuple[Chunk, KBXError]:
        try:
            if index_type not in self._chunk_data:
                return None, KBXError(code=KBXError.Code.RUNTIME_ERROR,
                                      msg=f"index_type: {index_type} doesn't exist in doc ds.")
            elif chunk_id not in self._chunk_data[index_type]:
                return None, KBXError(code=KBXError.Code.RUNTIME_ERROR,
                                      msg=f"chunk_id: {chunk_id} doesn't exist in doc ds.")
            else:
                return self._chunk_data[index_type][chunk_id], KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _load_doc_data(self, doc_id: str) -> Tuple[DocData, KBXError]:
        try:
            if doc_id not in self._doc_data:
                return None, KBXError(code=KBXError.Code.RUNTIME_ERROR,
                                      msg=f"doc_id: {doc_id} doesn't exist in doc ds.")
            else:
                return self._doc_data[doc_id], KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    def __delete_chunk_helper(self, chunk_id: str, index_type: IndexType):
        chunk: Chunk = self._chunk_data[index_type][chunk_id]
        doc_id = chunk.doc_id
        del self._chunk_data[index_type][chunk_id]
        if chunk_id in self._doc_id2chunk_id[doc_id][index_type]:
            self._doc_id2chunk_id[doc_id][index_type].remove(chunk_id)

    @with_lock
    def _delete_chunk(self, chunk_id: str, index_type: IndexType) -> KBXError:
        """
        删除chunk时, 不会删除任何doc, 但是要维护doc_id对应的chunk_id列表.
        """
        try:
            self.__delete_chunk_helper(chunk_id, index_type)
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _delete_doc_data(self, doc_id: str) -> KBXError:
        """
        根据doc_id删除doc, 删除doc关联的所有chunks, 删除doc_id对应的chunk_id列表.
        """
        try:
            if doc_id in self._doc_data:
                doc_data = self._doc_data[doc_id]
                remove_doc_element_item(self._doc_element, doc_data)
                del self._doc_data[doc_id]
            if doc_id in self._doc_id2chunk_id:
                for index_type, chunk_id_list in self._doc_id2chunk_id[doc_id].items():
                    for chunk_id in chunk_id_list:
                        self.__delete_chunk_helper(chunk_id, index_type)
                del self._doc_id2chunk_id[doc_id]
            return KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _list_chunk_ids_by_doc_id(self, doc_id: str, index_type: IndexType,
                                  offset: int = 0, limit: int = -1) -> Tuple[List[str], KBXError, int]:
        try:
            if doc_id not in self._doc_id2chunk_id:
                return [], KBXError(), 0
            index_type2ids: Dict[str, List[str]] = self._doc_id2chunk_id[doc_id]
            if index_type in index_type2ids:
                chunk_id_list: List[str] = copy.deepcopy(index_type2ids[index_type])
                return extract_list(chunk_id_list, offset, limit), KBXError(), len(chunk_id_list)
            else:
                return [], KBXError(), 0
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e)), 0

    @with_lock
    def _list_doc_ids(self, offset: int = 0, limit: int = -1) -> Tuple[List[str], KBXError]:
        try:
            return extract_list(copy.deepcopy(list(self._doc_id2chunk_id.keys())), offset, limit), KBXError()
        except Exception as e:
            return KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _get_doc_element_by_id(self, doc_element_id: str) -> Tuple[DocElement, KBXError]:
        try:
            if doc_element_id in self._doc_element:
                return self._doc_element[doc_element_id], KBXError()
            else:
                return None, KBXError()
        except Exception as e:
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=str(e))

    @with_lock
    def _get_doc_element_by_ids(self, doc_id: str, doc_element_id_list: List[str]) \
            -> Dict[str, Union[DocElement, KBXError]]:
        res: Dict[str, Union[DocElement, KBXError]] = init_doc_element_result_dict(doc_element_id_list)
        if doc_id in self._doc_data.keys():
            doc_data: DocData = self._doc_data[doc_id]
            for doc_element_id in res.keys():
                try:
                    res[doc_element_id] = doc_data.doc_elements[doc_element_id]
                except Exception as e:
                    res[doc_element_id] = KBXError(code=KBXError.Code.RUNTIME_ERROR,
                                                   msg=f"{doc_element_id} not exist in doc {doc_id} {str(e)}")
        return res
