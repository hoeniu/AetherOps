import os
from abc import ABC
from pathlib import Path
from typing import List, Dict, Union, Optional, Tuple, Iterator, Any, Callable
import json
try:
    from celery import Celery
except ImportError:
    pass
import traceback
from kbx.knowledge_base.types import KBCreationConfig, QueryConfig, DocInfo, QueryResults, RetrievalStepMessage, DocType
from kbx.knowledge_base.knowledge_base import KnowledgeBase
from kbx.parser.types import DocParseConfig
from kbx.common.types import DocData, KBXGlobalConfig, UserInfo, TenantInfo, KBXError
from kbx.common.logging import logger, set_logger
from kbx.common.utils import generate_new_id
from kbx.ai_model.types import BaseAIModelConfig, AIModelBundle, AIModelType
from kbx.ai_model.base_client import BaseAIModelClient
from kbx.ai_model.ai_model_factory import get_ai_model_client_cls
from kbx.db.types import UserORM, TenantORM, AIModelConfigORM, KBInfoORM
from kbx.db.session import init_kbx_db, DBSession, close_kbx_db
from kbx.common.constants import DEFAULT_TENANT_NAME, DEFAULT_TENANT_ID, DEFAULT_USER_NAME, DEFAULT_USER_ID
from kbx.datastore.ds_factory import get_fast_doc_ds
from kbx.datastore.types import DataStoreType
from kbx.common.utils import read_yaml_with_env_replace
from kbx.common.otel import record_func_metrics, get_tracer


tracer = get_tracer(__name__)


class KBX(ABC):
    config: Optional[KBXGlobalConfig] = None
    celery_app: Optional[Celery] = None

    def __init__(self, *args, **kwargs) -> None:
        raise RuntimeError('Can not initialize a KBX instance.')

    @classmethod
    def is_initialized(cls) -> bool:
        return cls.config is not None

    @classmethod
    def init(cls, config: Union[KBXGlobalConfig, str]) -> None:
        """KBX的顶层数据结构类型，提供知识库增删改查等各项功能汇总

        Args:
            config (Union[KBXGlobalConfig, str]): 初始化配置，可以是KBXGlobalConfig对象，也可以是json或yaml文件路径
        """
        if cls.config is not None:
            raise RuntimeError('KBX has already been initialized, can not call init again.')

        if isinstance(config, str):
            if config.endswith('.json'):
                import json
                with open(config, 'r') as fd:
                    config_dict = json.load(fd)
            elif config.endswith('.yaml') or config.endswith('.yml'):
                # import yaml
                # """兼容不同的环境，指定文件的编码格式"""
                # with open(config, 'r', encoding='utf-8') as fd:
                #     config_dict = yaml.safe_load(fd)
                config_dict = read_yaml_with_env_replace(config)
            else:
                raise RuntimeError(f'Unknown kbx config file: {config}')
            cls.config = KBXGlobalConfig(**config_dict)
        elif isinstance(config, KBXGlobalConfig):
            cls.config = config
        else:
            raise ValueError(f'Expect config to be a yaml/json file path or a KBXGlobalConfig instance, given {config}')

        # 线程数初始化
        if cls.config.num_threads is None or cls.config.num_threads <= 0:
            cpu_count = os.cpu_count()
            if cpu_count is None:
                # 如果无法获取CPU核心数，默认设置为8
                cpu_count = 8
            cls.config.num_threads = cpu_count * 2
        assert cls.config.num_threads > 0, \
            f'Expect num_threads to be greater than 0, given {cls.config.num_threads}'

        # 确保获得work_dir绝对路径
        if not os.path.isabs(cls.config.work_dir):
            from kbx.common.utils import get_default_base_dir
            cls.config.work_dir = os.path.abspath(os.path.join(get_default_base_dir(), cls.config.work_dir))
        os.makedirs(cls.config.work_dir, exist_ok=True)

        if not os.path.isabs(cls.config.cache_dir):
            # 如果cache_dir是相对路径，使用work_dir进行拼接
            cls.config.cache_dir = os.path.join(cls.config.work_dir, cls.config.cache_dir)
        os.makedirs(cls.config.cache_dir, exist_ok=True)

        # 日志初始化
        if not os.path.isabs(cls.config.log_file):
            # 如果log_file是相对路径，使用work_dir进行拼接
            cls.config.log_file = os.path.join(cls.config.work_dir, cls.config.log_file)
        os.makedirs(os.path.dirname(cls.config.log_file), exist_ok=True)
        set_logger(log_file=cls.config.log_file, level=cls.config.log_level)
        if isinstance(config, str):
            logger.info(f'Initializing KBX with config file: {config}')
        logger.info(f'KBX settings:\n{cls.config.model_dump_json(indent=4)}')

        # NOTE: 文件存储初始化，主要是为了文件服务能够正常启动
        # TODO: 当前实现与FileDS本身的初始化脱离，是否需要考虑FileDS添加此类初始化接口？
        os.makedirs(os.path.join(cls.config.work_dir, DataStoreType.FILE.value), exist_ok=True)

        # 系统DB初始化
        if not cls.config.system_db:
            logger.fatal("No system_db config found in KBX global config!")
        else:
            connection_kwargs = cls.config.system_db.connection_kwargs.copy()
            # TODO: 是否有更优雅的方式对sqlite这种本地文件型数据库进行相对路径支持？
            if cls.config.system_db.type == 'sqlite' and 'db_path' in connection_kwargs:
                db_path = connection_kwargs['db_path']
                if not os.path.isabs(db_path):
                    db_path = os.path.join(cls.config.work_dir, db_path)
                url = f'sqlite:///{db_path}'
                connection_kwargs.pop('db_path')
            else:
                url = connection_kwargs.get('url')
                connection_kwargs.pop('url')
            init_kbx_db(url=url, **connection_kwargs)
            with DBSession() as db:
                # 做一次测试判断是否连接成功
                db.commit()

                logger.info(f'Connect to kbx db "{url}" succeeded.')

                # NOTE: 如果当前是全新部署，需要添加默认的租户、用户
                # TODO: 待未来进行优化、完善，目前仅用于满足核心功能实验需求
                admin_tenant = db.query(TenantORM).filter(TenantORM.name == DEFAULT_TENANT_NAME).first()
                if admin_tenant is None:
                    db.add(TenantORM(name=DEFAULT_TENANT_NAME, id=DEFAULT_TENANT_ID))
                    db.commit()
                    admin_tenant = db.query(TenantORM).filter(TenantORM.name == DEFAULT_TENANT_NAME).first()
                if admin_tenant is None:
                    raise RuntimeError(f'Failed to add default tenant to kbx db: {DEFAULT_TENANT_NAME}.')
                admin_user = db.query(UserORM).filter(UserORM.name == DEFAULT_USER_NAME).first()
                if admin_user is None:
                    db.add(UserORM(name=DEFAULT_USER_NAME, id=DEFAULT_USER_ID, tenant=admin_tenant))
                    db.commit()

        # celery初始化
        if cls.config.celery is None:
            logger.info('Celery is disabled.')
        else:
            if cls.config.celery.type == 'sqlite':
                # broker_url: celery.db
                # result_backend: celery.db
                # broker_url: sqla+sqlite:///volumes/celery.db
                # result_backend: db+sqlite:///volumes/celery.db
                broker_url = cls.config.celery.broker_url
                result_backend = cls.config.celery.result_backend
                if not os.path.isabs(broker_url):
                    broker_url = os.path.join(cls.config.work_dir, broker_url)
                if not os.path.isabs(result_backend):
                    result_backend = os.path.join(cls.config.work_dir, result_backend)
                cls.config.celery.broker_url = f'sqla+sqlite:////{broker_url}'
                cls.config.celery.result_backend = f'db+sqlite:////{result_backend}'
            cls.celery_app = Celery(
                main='kbx',
                broker=cls.config.celery.broker_url,
                backend=cls.config.celery.result_backend,
                include=['kbx.tasks'],
                task_track_started=True,
            )
            logger.info(f'Celery broker_url: {cls.config.celery.broker_url}')
            logger.info(f'Celery result_backend: {cls.config.celery.result_backend}')

        if not cls.config.file_ds:
            logger.fatal("No file_ds config found in KBX global config!")
        if not cls.config.doc_ds:
            logger.fatal("No doc_ds config found in KBX global config!")

        if not cls.config.keyword_ds:
            logger.error("No keyword_ds config found in KBX global config!")
        if not cls.config.vector_ds:
            logger.error("No vector_ds config found in KBX global config!")
        if not cls.config.graph_ds:
            logger.error("No graph_ds config found in KBX global config!")
        if not cls.config.structured_ds:
            logger.error("No structured_ds config found in KBX global config!")

        # 一些系统限制参数
        if cls.config.upload_file_batch_limit <= 0:
            raise ValueError(
                'Expect upload_file_batch_limit greater than 0, '
                f'given {cls.config.upload_file_batch_limit}'
            )

        if isinstance(cls.config.upload_file_size_limit, str):
            # 当前实现现状：
            #   1. 数值部分只支持整数
            #   2. 单位部分只支持B/KB/MB/GB以及不带单位的情况，后者默认理解为B
            file_size_str = cls.config.upload_file_size_limit
            if file_size_str.endswith('KB'):
                cls.config.upload_file_size_limit = int(file_size_str[:-2]) * 1024
            elif file_size_str.endswith('MB'):
                cls.config.upload_file_size_limit = int(file_size_str[:-2]) * 1024 * 1024
            elif file_size_str.endswith('GB'):
                cls.config.upload_file_size_limit = int(file_size_str[:-2]) * 1024 * 1024 * 1024
            elif file_size_str.endswith('B'):
                cls.config.upload_file_size_limit = int(file_size_str[:-1])
            elif file_size_str.isdigit():
                cls.config.upload_file_size_limit = int(file_size_str)
            else:
                raise ValueError(f'Invalid upload_file_size_limit: {file_size_str}')
        elif isinstance(cls.config.upload_file_size_limit, int):
            pass
        else:
            raise ValueError(f'Invalid upload_file_size_limit: {cls.config.upload_file_size_limit}')

    @classmethod
    def close(cls) -> None:
        if cls.config is not None:
            logger.info('Closing KBX...')
            close_kbx_db()
            cls.config = None
            cls.celery_app = None

    @classmethod
    def add_tenant(cls, tenant_name: str, desired_tenant_id: Optional[str] = None) -> str:
        """添加一个新的租户

        Args:
            tenant_name (str): 租户名称，注意，租户名称需要全局唯一
            desired_tenant_id (Optional[str]): 期望新创建租户使用的唯一id，默认为None，即自动分配，如果手动指定，需要保证唯一

        Returns:
            str: 实际分配的租户id
        """
        with DBSession() as db:
            # 检查是否已经存在同名租户
            previous_tenant_orm = db.query(TenantORM).filter(TenantORM.name == tenant_name).first()
            if previous_tenant_orm:
                raise ValueError(f'Tenant {tenant_name} already exists.')
            if desired_tenant_id:
                # 如果期望的租户id不为空，检查是否已经存在
                previous_tenant_orm = db.query(TenantORM).filter(TenantORM.id == desired_tenant_id).first()
                if previous_tenant_orm:
                    raise ValueError(f'Tenant id {desired_tenant_id} already exists.')
            else:
                desired_tenant_id = generate_new_id()
            db.add(TenantORM(name=tenant_name, id=desired_tenant_id))
            db.commit()
            return desired_tenant_id

    @classmethod
    def get_tenant_info(cls, tenant_id: Optional[str] = None, tenant_name: Optional[str] = None) -> TenantInfo:
        """获取一个已经存在的租户详情

        Args:
            tenant_id (Optional[str]): 租户唯一id，和tenant_name至少指定一个
            tenant_name (Optional[str]): 租户名称，和tenant_id至少指定一个

        Returns:
            TenantInfo: 租户信息
        """
        filter_kwargs = {}
        if tenant_id:
            filter_kwargs['id'] = tenant_id
        if tenant_name:
            filter_kwargs['name'] = tenant_name
        if len(filter_kwargs) == 0:
            raise ValueError(f'Please provide valid tenant_id or tenant_name, given "{tenant_id}" and "{tenant_name}".')

        with DBSession() as db:
            # 检查是否已经存在
            tenant_orm = db.query(TenantORM).filter_by(**filter_kwargs).first()
            if tenant_orm is None:
                raise ValueError(f'Tenant ({filter_kwargs}) doesn\'t exists.')
            return tenant_orm.to_pydantic()

    @classmethod
    def update_tenant_info(cls, tenant_id: str, tenant_name: str) -> TenantInfo:
        """更新租户信息（目前仅允许改名）

        Args:
            tenant_id (str): 租户唯一id
            tenant_name (str): 租户名称

        Returns:
            TenantInfo: 租户信息
        """
        with DBSession() as db:
            # 检查是否已经存在
            tenant_orm = db.query(TenantORM).filter(TenantORM.id == tenant_id).first()
            if tenant_orm is None:
                raise ValueError(f'Tenant {tenant_id} doesn\'t exists.')

            # 检查是否已经存在同名租户
            previous_tenant_orm = db.query(TenantORM).filter(TenantORM.name == tenant_name).first()
            if previous_tenant_orm:
                raise ValueError(f'Tenant {tenant_name} already exists.')

            # 更新租户名称
            tenant_orm.name = tenant_name
            db.commit()
            return tenant_orm.to_pydantic()

    @classmethod
    def list_tenants(cls, offset: int = 0, limit: int = 20) -> List[TenantInfo]:
        """获取所有租户的列表

        Args:
            offset (int): 分页偏移量，也就是从第几个租户开始查询，默认从0开始
            limit (int): 分页大小限制，也就是本次查询最多返回多少个租户

        Returns:
            List[TenantInfo]: 指定分页参数范围内的租户的id和名称列表，如果已经没有更多租户，返回空列表
        """
        with DBSession() as db:
            # 根据分页参数查询对应的租户列表
            tenants = db.query(TenantORM).offset(offset).limit(limit).all()
            return [tenant.to_pydantic() for tenant in tenants]

    @classmethod
    def remove_tenant(cls, tenant_id: str) -> None:
        """删除一个租户，注意，如果此租户下存在用户，用户下存在知识库，则此次调用会将其一并删除

        Args:
            tenant_id (str): 租户唯一id
        """

        if not isinstance(tenant_id, str):
            raise ValueError(f'tenant_id must be a string, given {tenant_id}')

        # 先删除该租户下的所有用户
        offset = 0
        limit = 20
        while True:
            users_info = cls.list_users(tenant_id=tenant_id, offset=offset, limit=limit)
            for user_info in users_info:
                cls.remove_user(user_id=user_info.id)

            if len(users_info) < limit:
                break
            else:
                offset += len(users_info)

        # 再删除租户
        with DBSession() as db:
            # 检查是否已经存在
            previous_tenant_orm = db.query(TenantORM).filter(TenantORM.id == tenant_id).first()
            if previous_tenant_orm is None:
                raise ValueError(f'Tenant {tenant_id} doesn\'t exists.')
            db.delete(previous_tenant_orm)
            db.commit()

    @classmethod
    def add_user(cls, user_name: str, tenant_id: str, desired_user_id: Optional[str] = None) -> str:
        """添加一个新的用户

        Args:
            user_name (str): 用户名称，注意，用户名称需要保证在指定租户内唯一
            tenant_id (str): 租户唯一id
            desired_user_id (Optional[str], optional): 期望的用户id，默认为None，即自动分配，如果手动指定，需要保证全局唯一

        Returns:
            str: 实际分配的用户id
        """
        with DBSession() as db:
            # 检查租户是否存在
            tenant_orm = db.query(TenantORM).filter(TenantORM.id == tenant_id).first()
            if tenant_orm is None:
                raise ValueError(f'Tenant {tenant_id} doesn\'t exists.')

            # 检查是否已经存在同名用户
            previous_user_orm = db.query(UserORM).filter_by(tenant_id=tenant_id, name=user_name).first()
            if previous_user_orm:
                raise ValueError(f'User {user_name} already exists.')
            if desired_user_id:
                # 如果期望的用户id不为空，检查是否已经存在
                previous_user_orm = db.query(UserORM).filter_by(id=desired_user_id).first()
                if previous_user_orm:
                    raise ValueError(f'User id {desired_user_id} already exists.')
            else:
                # 如果未指定期望的用户id，自动生成
                desired_user_id = generate_new_id()

            db.add(UserORM(name=user_name, id=desired_user_id, tenant_id=tenant_id))
            db.commit()
            return desired_user_id

    @classmethod
    def get_user_info(
        cls,
        user_id: Optional[str] = None,
        user_name: Optional[str] = None,
        tenant_id: Optional[str] = None
    ) -> UserInfo:
        """查询特定用户id或name的详情信息

        Args:
            user_id (Optional[str]): 用户唯一id，和user_name至少指定一个
            user_name (Optional[str]): 用户名称，和user_id至少指定一个
            tenant_id (Optional[str]): 租户唯一id，可选参数

        Returns:
            UserInfo: 用户信息
        """
        filter_kwargs = {}
        if tenant_id:
            filter_kwargs['tenant_id'] = tenant_id
        if user_id:
            filter_kwargs['id'] = user_id
        if user_name:
            filter_kwargs['name'] = user_name
        if len(filter_kwargs) == 0:
            raise ValueError(f'Please provide valid user_id or user_name, given "{user_id}" and "{user_name}".')

        with DBSession() as db:
            # 检查是否已经存在
            user_orm = db.query(UserORM).filter_by(**filter_kwargs).first()
            if user_orm is None:
                raise ValueError(f'User ({filter_kwargs}) doesn\'t exists.')
            return user_orm.to_pydantic()

    @classmethod
    def update_user_info(cls, user_id: str, user_name: str) -> UserInfo:
        """更新用户信息，目前只支持修改用户名称

        Args:
            user_id (str): 用户唯一id
            user_name (str): 新的用户名称

        Returns:
            UserInfo: 用户信息
        """

        with DBSession() as db:
            # 检查是否已经存在
            previous_user_orm = db.query(UserORM).filter(UserORM.id == user_id).first()
            if previous_user_orm is None:
                raise ValueError(f'User {user_id} doesn\'t exists.')

            # 检查是否已经存在同名用户
            same_name_user_orm = db.query(UserORM).filter_by(
                tenant_id=previous_user_orm.tenant_id,
                name=user_name,
            ).first()
            if same_name_user_orm:
                raise ValueError(f'User name "{user_name}" already exists.')

            # 更新用户名称
            previous_user_orm.name = user_name
            db.commit()
            return previous_user_orm.to_pydantic()

    @classmethod
    def list_users(cls, tenant_id: str, offset: int = 0, limit: int = 20) -> List[UserInfo]:
        """获取指定租户下的所有用户

        Args:
            tenant_id (str): 租户唯一id
            offset (int): 分页偏移量，也就是从第几个用户开始查询，默认从0开始
            limit (int): 分页大小限制，也就是本次查询最多返回多少个用户

        Returns:
            List[UserInfo]: 指定分页参数范围内的用户的id和名称列表，如果已经没有更多用户，返回空列表
        """
        with DBSession() as db:
            # 检查租户是否存在
            tenant_orm = db.query(TenantORM).filter(TenantORM.id == tenant_id).first()
            if tenant_orm is None:
                raise ValueError(f'Tenant {tenant_id} doesn\'t exists.')

            # 根据分页参数查询对应的用户列表
            users = db.query(UserORM).filter(UserORM.tenant_id == tenant_id).offset(offset).limit(limit).all()
            return [user.to_pydantic() for user in users]

    @classmethod
    def remove_user(cls, user_id: str) -> None:
        """删除指定租户下一个现有用户，注意，如果此用户下存在知识库，则此次调用会将其一并删除

        Args:
            user_id (str): 用户唯一id
        """

        if not isinstance(user_id, str):
            raise ValueError(f'user_id must be a string, given {user_id}')

        # 先删除该用户下的所有知识库
        offset = 0
        limit = 20
        while True:
            kb_ids = [kb.kb_id for kb in cls.list_kbs(user_id=user_id, offset=offset, limit=limit)[0]]

            for kb_id in kb_ids:
                cls.remove_kb(kb_id=kb_id, user_id=user_id)

            if len(kb_ids) < limit:
                break
            else:
                offset += len(kb_ids)

        # 再删除用户
        with DBSession() as db:
            # 检查是否已经存在
            previous_user_orm = db.query(UserORM).filter_by(id=user_id).first()
            if previous_user_orm is None:
                raise ValueError(f'User {user_id} doesn\'t exists.')
            db.delete(previous_user_orm)
            db.commit()

    @classmethod
    def register_ai_models_from_conf(
        cls,
        model_configs: Union[str, List[Dict]],
        overwrite: bool = False,
        user_id: str = DEFAULT_USER_ID
    ) -> None:
        """从配置文件(yaml或者json)或者配置字典列表中注册AI模型

        Args:
            model_configs (Union[str, List[Dict]]): yaml或者json文件路径，yaml或者json字典列表
            overwrite (bool, optional): 如果已经存在同名模型，是否覆盖
            user_id (str): 用户唯一id
        """
        if isinstance(model_configs, str):
            yaml_path = Path(model_configs)
            if yaml_path.exists() and yaml_path.is_file():
                if yaml_path.suffix.lower() == '.yaml' or yaml_path.suffix.lower() == '.yml':
                    import yaml
                    with open(model_configs, 'r', encoding='utf-8') as fd:
                        data = yaml.safe_load(fd)
                else:
                    import json
                    with open(model_configs, 'r', encoding='utf-8') as fd:
                        data = json.load(fd)
        else:
            data = model_configs
        if isinstance(data, Dict):
            data = [data]

        from pydantic import ValidationError
        for model_dict in data:
            backend = model_dict.get('backend', None)
            if not backend:
                raise RuntimeError(f'Backend can not be empty in ai model config: {model_dict}')

            # 更新user_id信息
            model_dict['user_id'] = user_id

            model_client_cls = get_ai_model_client_cls(backend=backend)
            model_config_cls = model_client_cls.config_class()
            try:
                # 不要因为一个模型配置错误，导致整个模型注册失败
                # TODO: 目前此接口没有返回值，无法知道具体哪个模型配置错误
                config = model_config_cls(**model_dict)
            except ValidationError as e:
                logger.error(f'Failed to create ai model config: {model_dict}, error: {e}')
                continue

            cls.register_ai_model(config=config, overwrite=overwrite, user_id=user_id)

    @classmethod
    def register_ai_model(
        cls,
        config: BaseAIModelConfig,
        overwrite: bool = False,
        user_id: str = DEFAULT_USER_ID
    ) -> None:
        """注册一个新的AI模型

        Args:
            config (AIModelConfig): 模型配置
            overwrite (bool, optional): 如果已经存在同名模型，是否覆盖
            user_id (str): 用户唯一id
        """
        # TODO: 校验Config是否合法

        # 强制更新user_id
        config.user_id = user_id

        with DBSession() as db:
            # 检查user_id/tenant_id
            user = db.query(UserORM).filter(UserORM.id == user_id).first()
            if user is None:
                raise RuntimeError(f'User id {user_id} does not exists.')
            tenant_id = user.tenant_id

            previous_config = db.query(AIModelConfigORM).filter_by(
                user_id=user_id, tenant_id=tenant_id, name=config.name).first()
            if previous_config:
                # 如果之前有同名配置，先进行删除
                if overwrite:
                    db.delete(previous_config)
                else:
                    raise RuntimeError(
                        f'AIModelConfig {config.name} already exists, did you forget to set overwrite=True ?')
            db.add(AIModelConfigORM.from_pydantic(config=config, user_id=user_id, tenant_id=tenant_id))
            db.commit()

    @classmethod
    def get_ai_model_config(cls, name: str, user_id: str = DEFAULT_USER_ID) -> BaseAIModelConfig:
        """给定name，获取一个AI模型的配置

        Args:
            name (str): 模型名称
            user_id (str): 用户唯一id

        Returns:
            BaseAIModelConfig: 模型配置
        """
        with DBSession() as db:
            previous_config = db.query(AIModelConfigORM).filter_by(user_id=user_id, name=name).first()
        if previous_config:
            return previous_config.to_pydantic()
        else:
            raise RuntimeError(f'AIModelConfig {name} doesn\'t exists for user {user_id}.')

    @classmethod
    def get_ai_model_client(cls, config: BaseAIModelConfig) -> type[BaseAIModelClient]:
        """给定模型配置，获取可用于AI模型调用的客户端类

        Args:
            config (BaseAIModelConfig): AI模型配置

        Returns:
            type[BaseAIModelClient]: 客户端类
        """
        return get_ai_model_client_cls(config.backend)

    @classmethod
    def get_ai_model_config_and_client(
        cls,
        name: str,
        user_id: str = DEFAULT_USER_ID
    ) -> Tuple[BaseAIModelConfig, type[BaseAIModelClient]]:
        """给定模型名称，获取模型配置和模型调用类，典型使用方法如下

            config, model = KBX.get_ai_model_config_and_cls('qwen2.5-72b-instruct')
            answer = model.chat(
                config,
                messages=[
                    {"role": "user", "content": "你知道太阳的直径是多少吗？"},
                    {"role": "assistant", "content": "太阳的直径约为1392000公里。"}
                ],
            )

        Args:
            name (str): 模型名称
            user_id (str): 用户唯一id

        Returns:
            Tuple[BaseAIModelConfig, type[BaseAIModelClient]]: 一个包含模型config和模型调用类的元组
        """
        config = cls.get_ai_model_config(name=name, user_id=user_id)
        return config, cls.get_ai_model_client(config=config)

    @classmethod
    def delete_ai_model(cls, name: str, user_id: str = DEFAULT_USER_ID) -> None:
        """删除指定名称的AI模型配置信息

        Args:
            name (str): 模型名称
            user_id (str): 用户唯一id
        """
        with DBSession() as db:
            db.query(AIModelConfigORM).filter_by(name=name, user_id=user_id).delete()
            db.commit()

    @classmethod
    def list_ai_models(cls, user_id: str = DEFAULT_USER_ID,
                       offset: int = 0, limit: int = 20,
                       type: Optional[AIModelType] = None,
                       backend: Optional[str] = None) -> Tuple[List[BaseAIModelConfig], int]:
        """根据类型查询当前所有注册过的AI模型配置信息，支持通过type参数指定模型类型进行过滤。

        Args:
            offset (int): 分页偏移量，也就是从第几个item开始查询，默认从0开始
            limit (int): 分页大小限制，也就是本次查询最多返回多少个item
            type (Optional[AIModelType]): 模型类型，不指定时返回所有类型的模型
            backend (Optional[str]): 模型后端，不指定时返回所有后端的模型
            user_id (str): 用户唯一id

        Returns:
            Tuple[List[BaseAIModelConfig], int]: 一个包含模型列表和模型总数量的元组
        """
        config_dict = {}
        with DBSession() as db:
            query = db.query(AIModelConfigORM).filter_by(user_id=user_id)
            if type is not None:
                query = query.filter_by(type=type.value)
            if backend is not None:
                query = query.filter_by(backend=backend)
            total_count = query.count()
            query = query.offset(offset).limit(limit)
            for config_orm in query.all():
                config_dict[config_orm.name] = config_orm.to_pydantic()
        return config_dict, total_count

    @classmethod
    @tracer.start_as_current_span("kbx.create_new_kb")
    def create_new_kb(
        cls,
        kb_config: KBCreationConfig,
        user_id: str = DEFAULT_USER_ID,
        desired_kb_id: Optional[str] = None,
        auto_create_user_tenant: bool = False,
        tenant_id: Optional[str] = None,
    ) -> KnowledgeBase:
        """为指定用户新建一个知识库

        Args:
            kb_config (KBCreationConfig): 知识库创建参数
            user_id (str): 该知识库所属用户的user_id
            desired_kb_id (Optional[str]): 期望新创建知识库使用的唯一id，默认为空，此时会自动生成一个新的kb_id
            auto_create_user_tenant (bool): 如果设置为True，则在用户or租户不存在时尝试自动创建，如果设置为False，则会直接抛出异常
            tenant_id (Optional[str]): 如果设置auto_create_user_tenant为True，则必须提供对应的tenant_id

        Returns:
            KnowledgeBase: 知识库实例
        """
        # NOTE: 可在此处进行鉴权、资源限制检查或其他前处理

        if auto_create_user_tenant:
            if not tenant_id:
                raise ValueError('tenant_id must be provided if auto_create_user_tenant is True.')

            has_tenant: bool = False
            with DBSession() as db:
                tenant_info_orm = db.query(TenantORM).filter_by(id=tenant_id).first()
                has_tenant = tenant_info_orm is not None
            if not has_tenant:
                cls.add_tenant(tenant_name="tenant_" + tenant_id, desired_tenant_id=tenant_id)

            has_user: bool = False
            with DBSession() as db:
                user_info_orm = db.query(UserORM).filter_by(id=user_id).first()
                has_user = user_info_orm is not None
                if user_info_orm and user_info_orm.tenant_id != tenant_id:
                    # 如果用户已经存在，检查其租户id是否一致
                    raise ValueError(
                        f'User {user_id} already exists in tenant {user_info_orm.tenant_id}, '
                        f'can not create again in tenant {tenant_id}.'
                    )
            if not has_user:
                cls.add_user(user_name='user_' + user_id, tenant_id=tenant_id, desired_user_id=user_id)

        return KnowledgeBase.create_new_kb(kb_config=kb_config, user_id=user_id, desired_kb_id=desired_kb_id)

    @classmethod
    @tracer.start_as_current_span("kbx.get_existed_kb")
    def get_existed_kb(
        cls,
        kb_id: Optional[str] = None,
        kb_name: Optional[str] = None,
        user_id: str = DEFAULT_USER_ID
    ) -> KnowledgeBase:
        """给定一个已经存在的知识库唯一id或name，从数据库中读取相关信息，然后初始化对应的实例
        如果kb_id不存在，会直接抛出异常

        Args:
            kb_id (Optional[str]): 知识库唯一id，与kb_name至少提供一个
            kb_name (Optional[str]): 知识库名称，与kb_id至少提供一个
            user_id (str): 该知识库所属用户的user_id

        Returns:
            KnowledgeBase: 知识库实例
        """
        return KnowledgeBase.get_existed_kb(kb_id=kb_id, kb_name=kb_name, user_id=user_id)

    @classmethod
    def if_kb_exists(
        cls,
        kb_id: Optional[str] = None,
        kb_name: Optional[str] = None,
        user_id: str = DEFAULT_USER_ID,
    ) -> bool:
        """判断指定kb_id/kb_name的知识库是否存在

        Args:
            kb_id (Optional[str]): 知识库唯一id，与kb_name至少提供一个
            kb_name (Optional[str]): 知识库名称，与kb_id至少提供一个
            user_id (str): 该知识库所属用户的user_id

        Returns:
            bool: 指定知识库是否存在
        """
        return KnowledgeBase.if_kb_exists(kb_id=kb_id, kb_name=kb_name, user_id=user_id)

    @classmethod
    @record_func_metrics
    def list_kbs(cls, user_id: str = DEFAULT_USER_ID, offset: int = 0,
                 limit: int = 50) -> Tuple[List[Dict[str, Any]], int]:
        """获取所有知识库的信息列表，包括知识库id、名称、描述、创建时间

        Args:
            user_id (str): 用户唯一id
            offset (int): 分页偏移量，也就是从第几个item开始查询，默认从0开始
            limit (int): 分页大小限制，也就是本次查询最多返回多少个item

        Returns:
            Tuple[List[Dict[str, Any]], int]: 一个包含知识库列表和知识库总数量的元组
        """
        with DBSession() as db:
            query = db.query(KBInfoORM).filter_by(user_id=user_id)
            results = query.offset(offset).limit(limit).all()
            kb_list = [result.to_pydantic() for result in results]
            total_count = query.count()
        return kb_list, total_count

    @classmethod
    def get_kb_config(cls, kb_id: str, user_id: str = DEFAULT_USER_ID) -> KBCreationConfig:
        """获取指定kb_id对应的知识库信息
        TODO: 返回值类型不应该只是KBCreationConfig，而是一个更加全面的KBMetaConfig，可以包含诸如文档数量等额外信息

        Args:
            kb_id (str): 知识库id
            user_id (str): 用户唯一id

        Returns:
            KBCreationConfig: 知识库信息
        """
        with DBSession() as db:
            config_orm = db.query(KBInfoORM).filter_by(user_id=user_id, id=kb_id).first()
            if config_orm:
                return KBCreationConfig(**json.loads(config_orm.creation_config_json))
            else:
                raise RuntimeError(f'Knowledge base {kb_id} does not exists (user_id = {user_id}).')

    @classmethod
    @tracer.start_as_current_span("kbx.remove_kb")
    def remove_kb(cls, kb_id: str, user_id: str = DEFAULT_USER_ID) -> None:
        """删除指定kb_id对应的知识库

        Args:
            kb_id (str): 知识库id
            user_id (str): 用户唯一id
        """
        kb = KnowledgeBase.get_existed_kb(kb_id=kb_id, user_id=user_id)
        kb.remove_kb()

    @classmethod
    @tracer.start_as_current_span("kbx.insert_single_doc_to_kb")
    def insert_single_doc_to_kb(
        cls,
        kb_id: str,
        file_path: str,
        doc_parse_config: Optional[DocParseConfig] = None,
        save_dir: str = "",
        user_id: str = DEFAULT_USER_ID
    ) -> DocInfo:
        """对一个本地文档文件进行知识库导入，包括如下步骤

        - 存入文件存储
        - 调用parser解析成DocData
        - 建立索引

        Args:
            kb_id (str): 知识库id
            file_path (str): 文档（本地）路径
            doc_parse_config (Optional[DocParseConfig]): 本次插入文档的专用解析配置参数，默认为None，表示使用知识库中的同样解析器配置
            save_dir (str): 文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下
                           支持两种格式，如"/project/docs"和"project/docs"，两者等价
            user_id (str): 用户唯一id

        Returns:
            DocInfo: 各文档的入库结果，长度与输入的file_list相同，对应每个文件在插入后的相关状态信息
                注意，如果某文档对应的DocInfo.doc_status为UPLOAD_FAILED，表明该文档未成功上传，不会在本系统中留下记录，
                如果成功插入或在其他环节出错，均会在本系统中留下（持久化）记录。
        """
        return cls.get_existed_kb(kb_id=kb_id, user_id=user_id).insert_single_doc(
            file_path=file_path,
            doc_parse_config=doc_parse_config,
            save_dir=save_dir
        )

    @classmethod
    @tracer.start_as_current_span("kbx.insert_docs_to_kb")
    def insert_docs_to_kb(
        cls,
        kb_id: str,
        file_list: Union[str, List[str]],
        doc_parse_config: Optional[DocParseConfig] = None,
        save_dir: str = "",
        user_id: str = DEFAULT_USER_ID
    ) -> List[DocInfo]:
        """对一系列本地文档文件进行入库，包括如下步骤

        - 存入文件存储
        - 调用parser解析成DocData
        - 建立索引

        注意，如果输入文件列表存在重名的文件会直接报错

        Args:
            kb_id (str): 知识库id
            file_list (Union[str, List[str]]): 文档（本地）路径列表
            doc_parse_config (Optional[DocParseConfig]): 本次插入文档的专用解析配置参数，默认为None，表示使用知识库中的同样解析器配置
            save_dir (str): 文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下
                           支持两种格式，如"/project/docs"和"project/docs"，两者等价
            user_id (str): 用户唯一id

        Returns:
            List[DocInfo]: 各文档的入库结果，长度与输入的file_list相同，对应每个文件在插入后的相关状态信息
                注意，如果某文档对应的DocInfo.doc_status为UPLOAD_FAILED，表明该文档未成功上传，不会在本系统中留下记录，
                如果成功插入或在其他环节出错，均会在本系统中留下（持久化）记录。
        """
        return cls.get_existed_kb(kb_id=kb_id, user_id=user_id).insert_docs(
            file_list=file_list,
            doc_parse_config=doc_parse_config,
            save_dir=save_dir
        )

    @classmethod
    def list_kb_document_ids(
        cls,
        kb_id: str,
        user_id: str = DEFAULT_USER_ID,
        offset: int = 0,
        limit: int = 20,
        doc_type_filter: Optional[List[DocType]] = None
    ) -> Tuple[List[str], int]:
        """列出指定知识库中的文档

        Args:
            kb_id (str): 知识库id
            user_id (str): 用户唯一id
            offset (int): 分页偏移量，也就是从第几个item开始查询，默认从0开始
            limit (int): 分页大小限制，也就是本次查询最多返回多少个item
            doc_type_filter (Optional[List[DocType]]): 文档类型过滤列表，默认为None，表示不进行过滤

        Returns:
            Tuple[List[str], int]: 知识库所包含的文档doc_id列表和总数量
        """
        return cls.get_existed_kb(kb_id=kb_id, user_id=user_id).list_doc_ids(
            offset=offset,
            limit=limit,
            doc_type_filter=doc_type_filter
        )

    @classmethod
    def get_doc_data(cls, kb_id: str, doc_id: str, user_id: str = DEFAULT_USER_ID) -> DocData:
        """获取指定的文档数据DocData格式

        Args:
            kb_id (str): 知识库id
            doc_id (str): 文档id
            user_id (str): 用户唯一id

        Returns:
            DocData: 文档数据（DocData格式）
        """
        return cls.get_existed_kb(kb_id=kb_id, user_id=user_id).get_doc_data(doc_id=doc_id)

    @classmethod
    def _wrap_retrieve_func(cls, retrieve_function: Callable, query: QueryConfig, user_id: str = DEFAULT_USER_ID):
        if query.deep_think and query.deep_think.deep_searcher and query.deep_think.hierarchy == 'KBX':
            from kbx.common.utils import inject_user_ctx
            from kbx.common.types import UserContext
            from kbx.agent.types import SearchAgentConfig
            import functools
            user_info = cls.get_user_info(user_id=user_id)
            rag_agent_config = inject_user_ctx(
                config=SearchAgentConfig(
                    agent_name=query.deep_think.deep_searcher,
                    max_iter=query.deep_think.max_iter,
                    llm_model=query.deep_think.llm_model
                ),
                user_ctx=UserContext(user_id=user_id, tenant_id=user_info.tenant_id),
                recursive=True,
            )
            from .agent.agent_factory import get_agent
            rag_agent = get_agent(rag_agent_config)
            from .agent.search.base_searcher import BaseSearcher
            assert isinstance(rag_agent, BaseSearcher)
            return functools.partial(rag_agent.retrieve, retrieve_function=retrieve_function)
        else:
            return retrieve_function

    @classmethod
    def _retrieve(
        cls,
        query: QueryConfig,
        kb_ids: List[str],
        user_id: str = DEFAULT_USER_ID
    ) -> Iterator[QueryResults]:
        if isinstance(kb_ids, str):
            kb_ids = [kb_ids]

        if query.deep_think:
            # 如果本次查询开启了agent增强，需要确保对模型参数进行自动填充

            if not query.ai_model_bundle or len(query.ai_model_bundle.bundles) == 0:
                # 如果query中没有提供ai_model_bundle，则尝试从知识库中获取
                for kb_id in kb_ids:
                    # 搜索所有知识库，找到第一个有ai model bundle的
                    kb = cls.get_existed_kb(kb_id=kb_id, user_id=user_id)
                    if kb.kb_config.ai_model_bundle and len(kb.kb_config.ai_model_bundle.bundles) > 0:
                        query.ai_model_bundle = kb.kb_config.ai_model_bundle.model_copy(deep=True)
                        break

            if query.ai_model_bundle.bundles:
                # 如果有非空的ai model bundle，则进行自动填充更新
                query.deep_think.update_with_model_bundle(query.ai_model_bundle)

        # 创建QueryResults实例用于流式返回
        results = QueryResults()

        if query.deep_think and query.deep_think.kb_selector and query.deep_think.llm_model:
            from kbx.common.utils import select_kbs
            try:
                logger.info(f"Select kbs: {kb_ids}")
                intent_response = select_kbs(query, kb_ids, user_id)
                intent_json = json.loads(intent_response)
                logger.debug(f'intent json: {intent_json}')

                def _intent_to_markdown(intent_json: Dict) -> str:
                    """将意图分析结果转换为适合直接在前端展示的markdown格式"""
                    if intent_json.get("name") == "direct_response":
                        return "当前用户问题和知识库无关，直接使用LLM进行回答"
                    elif intent_json.get("name") == "search_knowledge_base":
                        markdown_str = ""
                        if intent_json.get('arguments').get('query') != query.text:
                            markdown_str += f"当前查询的问题为：{intent_json.get('arguments').get('query')}\n\n"
                        select_kb_ids = intent_json.get('arguments', {}).get('kb_ids', [])
                        kbs_info, _ = cls.list_kbs(user_id=user_id)
                        kb_dict = {item.kb_id: item.name for item in kbs_info}
                        name_list = [kb_dict[id] for id in select_kb_ids]
                        markdown_str += f"需要查询的知识库列表：{'、'.join(name_list)}\n\n"
                        return markdown_str

                # 将意图分析结果作为智能体步骤消息返回
                results.append(RetrievalStepMessage(
                    step_name="Query分析与知识库选择",
                    content=_intent_to_markdown(intent_json)
                ))
                if query.stream:
                    yield QueryResults(step_messages=results.step_messages[-1])

                if intent_json.get("name") == "direct_response":
                    results.is_final = True
                    yield results
                    return
                elif intent_json.get("name") == "search_knowledge_base" or intent_json.get("name") == "retrieve_media":
                    # 查询改写
                    query.text = intent_json['arguments'].get('query')
                    kb_ids = intent_json['arguments'].get('kb_ids')
            except Exception as e:
                logger.error(f"select_kbs error: {e}, retrieve all kbs.")
        else:
            # NOTE: 如果query没有text，则使用messages中的最后一个消息的content作为query的text
            if not query.text and query.messages:
                last_msg = query.messages[-1]
                last_msg_content = last_msg.get('content')

                if last_msg_content is None:
                    query.text = ''
                elif isinstance(last_msg_content, str):
                    query.text = last_msg_content
                elif isinstance(last_msg_content, list):
                    # 处理 OpenAI 风格的数组类型 content，只保留text类型的msg parts，并拼接成一个字符串
                    text_list = []
                    for item in last_msg_content:
                        if isinstance(item, dict):
                            if item.get('type') == 'text':
                                text_list.append(item.get('text', ''))
                    query.text = '\n'.join(text_list)
                else:
                    query.text = str(last_msg_content)

        def retrieve_function(query: QueryConfig) -> Iterator[QueryResults]:
            retrieve_results = QueryResults()
            # logger.info(f"Call retrieve_function: {query}, {kb_ids}")
            for kb_id in kb_ids:
                kb = cls.get_existed_kb(kb_id=kb_id, user_id=user_id)
                if query.stream:
                    for res in kb.retrieve(query=query):
                        if not res.is_final:  # 避免results重复返回
                            yield res
                        else:
                            retrieve_results.extend(res)
                else:
                    retrieve_results.extend(kb.retrieve(query=query))
            retrieve_results.is_final = True
            # logger.info(f"{retrieve_results}")
            yield retrieve_results
        # 智能体检索
        if query.deep_think and query.deep_think.deep_searcher:
            # 自动设置层级为KBX
            query.deep_think.hierarchy = 'KBX'
        retrieve_func = cls._wrap_retrieve_func(retrieve_function=retrieve_function, query=query, user_id=user_id)
        for res in retrieve_func(query=query):
            if not res.is_final:  # 避免results重复返回
                if query.stream:
                    yield res
            else:
                results.extend(res)
        results.is_final = True
        if len(kb_ids) > 1:
            from kbx.agent.search.deepsearcher import DeepSearcher
            results.results = DeepSearcher.deduplicate_results(results.results)
        results.results = sorted(results.results, key=lambda x: x.score, reverse=True)
        if query.top_k > 0:
            results.results = results.results[:query.top_k]
        # logger.info(f"{results}")
        yield results

    @classmethod
    @record_func_metrics
    @tracer.start_as_current_span("kbx.retrieve")
    def retrieve(
        cls,
        query: QueryConfig,
        kb_ids: List[str],
        user_id: str = DEFAULT_USER_ID
    ) -> Union[QueryResults, Iterator[QueryResults]]:
        """在指定的一个或多个知识库中进行查询

        Args:
            query (QueryConfig): 查询参数
            kb_ids (List[str]): 一个或多个知识库的id列表
            user_id (str): 用户唯一id

        Returns:
            Union[QueryResults, Iterator[QueryResults]]: 返回中间结果以及查询结果，支持流式/非流式输出格式
        """
        if query.stream:
            return cls._retrieve(query, kb_ids, user_id)
        else:
            return next(cls._retrieve(query, kb_ids, user_id))

    @classmethod
    @tracer.start_as_current_span("kbx.reindex")
    def reindex(
        cls,
        kb_id: str,
        doc_ids: List[str],
        reparse: bool = False,
        user_id: str = ""
    ) -> List[Tuple[str, str]]:
        """重新索引整个知识库
        在重新索引的过程中，可能会
        Args:
            kb_id (str): 知识库id.
            doc_ids (List[str]): 文档id列表.
            reparse (bool): 是否重新解析doc.
            user_id (str): 获取kb所需的user_id, 参考get_existed_kb接口定义.

        Returns:
            List[Tuple[str, str]]: 每个doc_id及解析结果.
        """
        kb: KnowledgeBase = cls.get_existed_kb(kb_id=kb_id, user_id=user_id)
        res: Dict[str, str] = kb.reindex(doc_ids=doc_ids, reparse=reparse)
        return [(k, v) for k, v in res.items()]

    @classmethod
    @tracer.start_as_current_span("kbx.parse_fast_doc")
    def parse_fast_doc(cls, doc_file_path: str, model_bundle: AIModelBundle, user_id: str) -> Tuple[str, KBXError]:
        """执行一个快速文档解析任务
        如果解析失败，返回的doc_id为空字符串，额外包含错误信息
        如果解析成功，返回的doc_id为有效、唯一的文档id

        注意：
        - 此函数不做文档重复校验，如果多次调用相同文件，会重复解析，且返回的doc_id不同

        Args:
            doc_file_path (str): 文件路径（本地）
            model_bundle (AIModelBundle): 一套默认的AI模型选择配置
            user_id (str): 用户id

        Returns:
            Tuple[str, KBXError]: doc_id和错误信息
        """
        if not os.path.exists(doc_file_path):
            raise ValueError(f'File {doc_file_path} does not exist.')
        from kbx.parser.types import ImageEmbeddingStrategy, ImageStrategyConfig, PdfOcrStrategyConfig, \
            AudioEmbeddingStrategy, AudioStrategyConfig, VideoEmbeddingStrategy, VideoStrategyConfig
        from kbx.common.utils import inject_user_ctx
        from kbx.common.types import UserContext

        # 检查user是否存在
        user_info = cls.get_user_info(user_id=user_id)

        # 生成默认的解析配置
        image_strategy = ImageStrategyConfig(
            type=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,
            vision_model=model_bundle.vlm,
        ) if model_bundle.vlm else None
        audio_strategy = AudioStrategyConfig(
            type=AudioEmbeddingStrategy.SPEECH2TEXT_TEXT_EMBEDDING,
            voice_model=model_bundle.speech2text,
            refinement_model=model_bundle.llm if model_bundle.llm else "",
        ) if model_bundle.speech2text else None
        video_strategy = VideoStrategyConfig(
            type=VideoEmbeddingStrategy.VIDEO2TEXT_TEXT_EMBEDDING,
            vision_model=model_bundle.vlm,
        ) if model_bundle.vlm else None
        # NOTE: Fast Doc解析不进行代码summary增强
        # code_strategy = CodeStrategyConfig(
        #     code_summarizer=model_bundle.llm,
        # ) if model_bundle.llm else None
        code_strategy = None
        doc_parse_config = DocParseConfig(
            save_external_data=False,
            enable_layout_recognition=True,
            image_strategy=image_strategy,
            audio_strategy=audio_strategy,
            video_strategy=video_strategy,
            code_strategy=code_strategy,
            pdf_ocr_strategy=PdfOcrStrategyConfig()
        )
        doc_parse_config.update_with_model_bundle(model_bundle)
        inject_user_ctx(
            doc_parse_config,
            user_ctx=UserContext(user_id=user_id, tenant_id=user_info.tenant_id),
            recursive=True
        )

        # 调用文档解析
        from kbx.parser.parser_factory import get_parser
        from kbx.common.utils import generate_new_id
        doc_id = generate_new_id()
        err = KBXError()
        doc_data = None
        try:
            # 优先使用doc_info中的doc_parse_config，如果没有则使用kb_config中的doc_parse_config
            if cls.celery_app is None:
                # 如果没有配置celery，直接在当前进程中解析
                parser = get_parser(config=doc_parse_config)
                doc_data = parser.parse(file_path=doc_file_path, doc_id=doc_id)
            else:
                # 如果配置了celery，使用celery异步解析
                result = KBX.celery_app.send_task(
                    'kbx.tasks.document_parse_task.parse_document_file',
                    kwargs={
                        'file_path': doc_file_path,
                        'doc_id': doc_id,
                        'doc_parse_config_json_str': doc_parse_config.model_dump_json(),
                        'kb_id': None,
                    }
                )
                # https://docs.celeryq.dev/en/latest/userguide/tasks.html#avoid-launching-synchronous-subtasks
                doc_data = result.get(disable_sync_subtasks=False)
                assert doc_data is not None
                assert isinstance(doc_data, DocData)
        except Exception as e:
            doc_id = ''
            err = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f"Document \"{doc_file_path}\" parse failed: {e}\n\n{traceback.format_exc()}"
            )
            return doc_id, err

        # 获取用户级别的fast_doc_ds，然后进行保存
        with get_fast_doc_ds(user_id=user_id, tenant_id=user_info.tenant_id) as fast_doc_ds:
            err = fast_doc_ds.save_doc_data(doc_data)
            fast_doc_ds.flush()

        return doc_id, err

    @classmethod
    def list_fast_doc_ids(cls, user_id: str) -> List[str]:
        """获取指定用户所有fast doc的doc_id列表

        Args:
            user_id (str): 用户id

        Returns:
            List[str]: 文档id列表
        """
        user_info = cls.get_user_info(user_id=user_id)
        with get_fast_doc_ds(user_id=user_id, tenant_id=user_info.tenant_id) as fast_doc_ds:
            doc_ids, err = fast_doc_ds.list_doc_ids()
            if err.code != KBXError.Code.SUCCESS:
                raise RuntimeError(f"Failed to list doc ids for user {user_id}: {err.msg}")
            return doc_ids

    @classmethod
    @tracer.start_as_current_span("kbx.get_fast_doc_data")
    def get_fast_doc_data(cls, doc_ids: List[str], user_id: str) -> List[Tuple[Optional[DocData], KBXError]]:
        """批量获取一批已解析完成文档的数据
        注意：
        - 如果user_id非法，会抛出ValueError
        - 如果某个doc_id无法正常获取到对应DocData数据，函数不会抛出异常，但对应返回结果Tuple包含None和错误信息

        Args:
            doc_ids (List[str]): 文档id列表
            user_id (str): 用户id

        Returns:
            List[Tuple[Optional[DocData], KBXError]]: 各个文档的数据和错误信息
        """
        user_info = cls.get_user_info(user_id=user_id)
        # 批量获取DocData
        results = []
        with get_fast_doc_ds(user_id=user_id, tenant_id=user_info.tenant_id) as fast_doc_ds:
            for doc_id in doc_ids:
                doc_data, err = fast_doc_ds.load_doc_data(doc_id)
                results.append((doc_data, err))
        return results

    @classmethod
    @tracer.start_as_current_span("kbx.remove_fast_docs")
    def remove_fast_docs(cls, doc_ids: List[str], user_id: str) -> List[KBXError]:
        """批量删除一批已解析完成文档的数据

        注意: 目前删除不存在的文档doc_id不会抛异常或返回出错的KBXError（@dingdong）

        Args:
            doc_ids (List[str]): 文档id列表
            user_id (str): 用户id

        Returns:
            List[KBXError]: 各个文档删除的成功失败信息
        """
        user_info = cls.get_user_info(user_id=user_id)
        # 批量删除DocData
        results = []
        with get_fast_doc_ds(user_id=user_id, tenant_id=user_info.tenant_id) as fast_doc_ds:
            for doc_id in doc_ids:
                err = fast_doc_ds.delete_doc_data(doc_id)
                results.append(err)

        return results

    @classmethod
    @tracer.start_as_current_span("kbx.insert_docs_folder_to_kb")
    def insert_docs_folder_to_kb(
        cls,
        kb_id: str,
        folder_path: str,
        doc_parse_config: Optional[DocParseConfig] = None,
        recursive: bool = True,
        include_patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        max_files_per_batch: int = 20,
        save_dir: str = "",
        user_id: str = DEFAULT_USER_ID
    ) -> Dict[str, List[DocInfo]]:
        """递归遍历本地文件夹，并按文件夹结构将文件分批插入到知识库中

        该函数会遍历指定文件夹及其所有子文件夹，将找到的文件按照其相对路径结构插入到知识库中。
        例如，如果本地有文件"/path/to/project/docs/api.md"，且folder_path为"/path/to/project"，
        则该文件会被插入到知识库的"docs"目录下，保持原有的目录结构，例如"docs/api.md"。

        如果指定了save_dir参数，则所有文件会被插入到save_dir指定的目录下，保持原有的相对路径结构。
        例如，如果save_dir为"project"，则"/path/to/project/docs/api.md"会被插入到"project/docs/api.md"。

        Args:
            kb_id (str): 知识库id
            folder_path (str): 要遍历的本地文件夹路径
            doc_parse_config (Optional[DocParseConfig]): 本次插入文档的专用解析配置参数，默认为None，表示使用知识库中的同样解析器配置
            recursive (bool): 是否递归处理子文件夹，默认为True
            include_patterns (Optional[List[str]]): 要包含的文件匹配模式列表，支持通配符，如["*.md", "docs/*.pdf", "api/**/*.txt"]
                                                  默认为None表示包含所有文件
            exclude_patterns (Optional[List[str]]): 要排除的文件匹配模式列表，支持通配符，如["*.tmp", "temp/*", "**/draft_*"]
                                                  默认为None表示不排除任何文件
            max_files_per_batch (int): 每批处理的最大文件数，默认为20
            save_dir (str): 文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下
                           支持两种格式，如"/project"和"project"，两者等价
            user_id (str): 用户唯一id

        Returns:
            Dict[str, List[DocInfo]]: 各文件夹的文档入库结果，键为相对路径，值为该路径下的文档入库结果列表
                                    根目录（当前目录）的结果使用'.'作为键
        """
        return cls.get_existed_kb(kb_id=kb_id, user_id=user_id).insert_docs_folder(
            folder_path=folder_path,
            doc_parse_config=doc_parse_config,
            recursive=recursive,
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
            max_files_per_batch=max_files_per_batch,
            save_dir=save_dir
        )
