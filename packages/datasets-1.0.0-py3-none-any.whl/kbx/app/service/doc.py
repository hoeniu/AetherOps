from typing import Optional, List, Dict, Any, Union
import shutil
from kbx.kbx import KBX
from kbx.parser.types import DocParseConfig
from kbx.common.utils import generate_new_id
import os
from fastapi import HTTPException, UploadFile
import aiofiles
from kbx.common.constants import DEFAULT_USER_ID
from kbx.knowledge_base.types import DocType


class DocService:
    def insert_docs(
        self,
        user_id: str,
        files: List[UploadFile],
        kb_id: str,
        doc_parse_config: Optional[DocParseConfig] = None,
        save_dir: str = '',
        doc_patterns: Optional[List[str]] = None,
        only_upload: bool = False,
        keep_rel_path: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        插入多个文档
        :param user_id: 租户ID
        :param files: 上传的文件列表
        :param kb_id: 知识库ID
        :param doc_parse_config: 文档解析配置
        :param save_dir: 文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下
        :param doc_patterns: 指定“普通文档”文件名规则列表，当doc_type=None时将根据doc_patterns确定文档类型，例如
                - 指定一种或多种文件名后缀，例如["*.md", "*.docx", "*.csv"]
                - 指定一个或多个文件命名规则，例如["index.html", "index.md"]
                如果设置为None，则使用本项目默认的DEFAULT_NORMAL_DOC_FILE_PATTERNS
        :param only_upload: 是否只进行上传，稍后再进行解析和索引，默认为False，表示上传后直接进行解析和索引
        :param keep_rel_path: 是否保留UploadFile文件filename属性可能存在的相对路径，默认为True，表示保留
        :return: 文档信息
        """
        try:
            tmp_id = generate_new_id()
            # 所有文件都先临时写到这个目录下，注意要保持相对路径
            tmp_save_dir = os.path.join(KBX.config.cache_dir, f"uploads/{user_id}/{tmp_id}")
            os.makedirs(tmp_save_dir, exist_ok=True)
            for file in files:
                try:
                    # 注意file.filename有可能有相对路径
                    filename = file.filename
                    if not keep_rel_path:
                        filename = os.path.basename(filename)
                    tmp_save_path = os.path.join(tmp_save_dir, filename)
                    os.makedirs(os.path.dirname(tmp_save_path), exist_ok=True)
                    # 如果文件内容为空，则标记上传失败
                    first_chunk = file.file.read(1)
                    if not first_chunk:
                        raise HTTPException(status_code=500, detail="UPLOAD_FAILED")
                    with open(tmp_save_path, 'wb') as f:
                        f.write(first_chunk)
                        while chunk := file.file.read(8192):
                            f.write(chunk)
                except Exception as e:
                    if os.path.exists(tmp_save_path):
                        os.remove(tmp_save_path)
                    if os.path.exists(tmp_save_dir):
                        os.rmdir(tmp_save_dir)
                    raise e

            # 获取知识库实例
            kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)
            doc_infos = kb.insert_docs_folder(
                folder_path=tmp_save_dir,
                doc_parse_config=doc_parse_config,
                recursive=True,
                save_dir=save_dir,
                doc_patterns=doc_patterns,
                only_upload=only_upload,
            )

            rets = []
            for _, folder_doc_infos in doc_infos.items():
                rets.extend([doc_info.model_dump(mode="json") for doc_info in folder_doc_infos])

            return rets
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        finally:
            # 确保清理所有临时文件
            if os.path.exists(tmp_save_dir):
                shutil.rmtree(tmp_save_dir)

    async def insert_docs_async(
        self,
        user_id: str,
        files: List[UploadFile],
        kb_id: str,
        doc_parse_config: Optional[DocParseConfig] = None,
        save_dir: str = '',
        doc_patterns: Optional[List[str]] = None,
        only_upload: bool = False,
        keep_rel_path: bool = True,
    ):
        """
        异步插入多个文档
        :param user_id: 租户ID
        :param files: 上传的文件列表
        :param kb_id: 知识库ID
        :param doc_parse_config: 文档解析配置
        :param save_dir: 文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下
        :param doc_patterns: 指定“普通文档”文件名规则列表，当doc_type=None时将根据doc_patterns确定文档类型，例如
                - 指定一种或多种文件名后缀，例如["*.md", "*.docx", "*.csv"]
                - 指定一个或多个文件命名规则，例如["index.html", "index.md"]
                如果设置为None，则使用本项目默认的DEFAULT_NORMAL_DOC_FILE_PATTERNS
        :param only_upload: 是否只进行上传，稍后再进行解析和索引，默认为False，表示上传后直接进行解析和索引
        :param keep_rel_path: 是否保留UploadFile文件filename属性可能存在的相对路径，默认为True，表示保留
        """
        from kbx.app.task.insert_doc import async_insert_docs_folder_to_kb

        results: List[Dict[str, Any]] = []
        tmp_id = generate_new_id()
        # 所有文件都先临时写到这个目录下，注意要保持相对路径
        tmp_save_dir = os.path.join(KBX.config.cache_dir, f"uploads/{user_id}/{tmp_id}")
        os.makedirs(tmp_save_dir, exist_ok=True)
        for file in files:
            try:
                filename = file.filename
                if not keep_rel_path:
                    filename = os.path.basename(filename)
                tmp_save_path = os.path.join(tmp_save_dir, filename)
                os.makedirs(os.path.dirname(tmp_save_path), exist_ok=True)
                # 写入文件
                async with aiofiles.open(tmp_save_path, 'wb') as f:
                    while chunk := await file.read(8192):
                        await f.write(chunk)
                status = "UPLOAD_SUCCESS"
            except Exception:
                # 记录上传失败，不中断循环
                status = "UPLOAD_FAILED"
            results.append({"name": filename, "status": status})
        # 针对成功上传的文件触发后台异步解析
        if tmp_save_dir:
            await async_insert_docs_folder_to_kb.kiq(
                kb_id=kb_id,
                user_id=user_id,
                folder_path=tmp_save_dir,
                doc_parse_config=doc_parse_config,
                save_dir=save_dir,
                doc_patterns=doc_patterns,
                only_upload=only_upload
            )
        return results

    def list_doc_ids(
        self,
        kb_id: str,
        offset: int,
        limit: int,
        doc_type_filter: Optional[List[DocType]] = None,
        user_id: str = DEFAULT_USER_ID,
    ):
        # 获取所有文档ID
        doc_ids, total_count = KBX.list_kb_document_ids(
            kb_id=kb_id,
            user_id=user_id,
            offset=offset,
            limit=limit,
            doc_type_filter=doc_type_filter,
        )
        return {
            "total": total_count,
            "data": doc_ids
        }

    def list_docs_info(
        self,
        kb_id: str,
        offset: int,
        limit: int,
        doc_type_filter: Optional[List[DocType]] = None,
        user_id: str = DEFAULT_USER_ID,
    ):
        # 获取知识库实例
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)

        # 获取所有文档
        docs, total_count = kb.list_docs_info(
            offset=offset,
            limit=limit,
            doc_type_filter=doc_type_filter,
        )
        docs = [doc.model_dump(mode="json") for doc in docs]
        return {
            "total": total_count,
            "data": docs
        }

    def list_chunks(
        self,
        offset: int,
        limit: int,
        kb_id: str,
        doc_id: str,
        user_id: str = DEFAULT_USER_ID,
    ):
        # 获取知识库实例
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)
        # 获取chunks
        chunks, total_count = kb.list_chunks(doc_id=doc_id, offset=offset, limit=limit)
        return {
            "total": total_count,
            "data": [chunk.model_dump(mode="json", context={"fill_all_formats": True})
                     if chunk else err.model_dump(mode='json') for chunk, err in chunks]
        }

    def insert_docs_folder(
        self,
        folder_path: str,
        doc_parse_config: Optional[DocParseConfig] = None,
        recursive: bool = True,
        include_patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        max_files_per_batch: int = 20,
        save_dir: str = '',
        doc_patterns: Optional[List[str]] = None,
        only_upload: bool = False,
        user_id: str = DEFAULT_USER_ID,
        kb_id: str = '',
    ):
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)
        rets = kb.insert_docs_folder(
            folder_path=folder_path,
            doc_parse_config=doc_parse_config,
            recursive=recursive,
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
            max_files_per_batch=max_files_per_batch,
            save_dir=save_dir,
            doc_patterns=doc_patterns,
            only_upload=only_upload,
        )
        return rets

    def get_doc_info(
        self,
        kb_id: str,
        doc_id: str,
        user_id: str = DEFAULT_USER_ID,
    ):
        # 获取知识库实例
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)

        # 获取文档信息
        doc_info = kb.get_doc_info(doc_id=doc_id)
        return doc_info.model_dump(mode="json")

    def remove_docs(
        self,
        kb_id: str,
        doc_ids: Union[str, List[str]],
        user_id: str = DEFAULT_USER_ID,
    ):
        # 获取知识库实例
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)
        # 删除文档
        if isinstance(doc_ids, str):
            doc_ids = [doc_ids]
        errs = kb.remove_docs(doc_ids)
        if errs:
            raise HTTPException(status_code=500, detail=str(errs))
        return {
            "kb_id": kb.kb_id,
            "message": f"The following documents have been removed successfully: {doc_ids}"
        }

    def get_doc_data(
        self,
        kb_id: str,
        doc_id: str,
        user_id: str = DEFAULT_USER_ID,
    ):
        # 获取知识库实例
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)
        # 获取文档信息
        doc_data = kb.get_doc_data(doc_id=doc_id)
        return doc_data.model_dump(mode="json", context={"fill_all_formats": True})
