from typing import Any, List, Optional, Dict, Union
from fastapi import HTTPException
from kbx.kbx import KBX
from kbx.common.types import KBXError
from kbx.knowledge_base.types import KBCreationConfig


class KnowledgeBaseService:
    """
    Service layer for Knowledge Base operations, encapsulating KBX interactions.
    """

    def create_kb(
        self,
        kb_creation_config: KBCreationConfig,
        desired_kb_id: Optional[str],
        auto_create_user_tenant: bool,
        user_id: str
    ) -> Dict[str, Any]:
        # Validate schema_dict
        if kb_creation_config.kg_config and kb_creation_config.kg_config.schema_dict:
            if not isinstance(kb_creation_config.kg_config.schema_dict, dict):
                raise HTTPException(status_code=422, detail="schema_dict should be a valid dict")
        # Create knowledge base
        kb = KBX.create_new_kb(
            kb_config=kb_creation_config,
            user_id=user_id,
            desired_kb_id=desired_kb_id,
            auto_create_user_tenant=auto_create_user_tenant,
        )
        return {
            'user_id': user_id,
            'kb_id': kb.kb_id,
            'kb_name': kb.kb_name,
        }

    def remove_kb(self, kb_id: str, user_id: str) -> Dict[str, Any]:
        # Remove knowledge base
        KBX.remove_kb(kb_id=kb_id, user_id=user_id)
        return {
            'user_id': user_id,
            'kb_id': kb_id,
            'message': f"Knowledge base {kb_id} removed successfully"
        }

    def modify_kb_config(
        self,
        new_config: KBCreationConfig,
        kb_id: str,
        user_id: str
    ) -> Dict[str, Any]:
        # Modify knowledge base configuration
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)
        err = kb.modify_kb_config(new_config)
        if err.code == KBXError.Code.SUCCESS:
            return {
                'kb_id': kb.kb_id,
                'user_id': kb.user_id,
                'kb_config': kb.kb_config,
            }
        else:
            raise HTTPException(status_code=500, detail=str(err.msg))

    def list_kbs(
        self,
        user_id: str,
        offset: int = 0,
        limit: int = 100
    ) -> Dict[str, Union[int, List[Dict[str, Any]]]]:
        # List knowledge bases
        kb_list, total_count = KBX.list_kbs(user_id=user_id, offset=offset, limit=limit)
        return {
            'total': total_count,
            'data': [kb.model_dump(mode="json") for kb in kb_list]
        }

    def get_kb_detail(self, kb_id: str, user_id: str) -> Dict[str, Any]:
        # Get knowledge base details
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)
        return {
            'kb_id': kb.kb_id,
            'user_id': kb.user_id,
            'kb_config': kb.kb_config,
        }
