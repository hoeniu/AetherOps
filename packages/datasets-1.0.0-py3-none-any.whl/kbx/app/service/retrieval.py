import os
from typing import List, Dict, Any, Union, Iterator
from fastapi import HTTPException
from kbx.kbx import KBX
from kbx.common.constants import DEFAULT_TENANT_ID, DEFAULT_USER_ID
from kbx.db.session import DBSession
from kbx.db.types import DocInfoORM
from kbx.knowledge_base.types import QueryConfig, QueryResults


class RetrievalService:
    """
    Service layer for Retrieval operations, encapsulating KBX interactions.
    """

    def dify_retrieval(self, user_id: str, request: Any) -> List[Dict[str, Any]]:
        # Perform Dify-compatible retrieval
        try:
            raw_results = KBX.retrieve(
                query=QueryConfig(
                    text=request.query,
                    top_k=request.retrieval_setting.top_k,
                    score_threshold=request.retrieval_setting.score_threshold,
                ),
                kb_ids=[request.knowledge_id],
                user_id=user_id
            )
            records: List[Dict[str, Any]] = []
            with DBSession() as db:
                for r in raw_results:
                    if r.doc_id:
                        orm = db.query(DocInfoORM).filter_by(
                            user_id=DEFAULT_USER_ID,
                            tenant_id=DEFAULT_TENANT_ID,
                            kb_id=request.knowledge_id,
                            id=r.doc_id,
                        ).first()
                        title = os.path.basename(orm.file_path) if orm else "Unknown"
                    else:
                        title = "Unknown"
                    records.append({
                        "content": r.try_get_content_as_str(),
                        "score": r.score,
                        "title": title,
                        "metadata": {},
                    })
            return records
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    def retrieve(self, user_id: str, request: QueryConfig,
                 kb_ids: List[str]) -> Union[QueryResults, Iterator[QueryResults]]:
        results = KBX.retrieve(query=request, kb_ids=kb_ids, user_id=user_id)
        return results
