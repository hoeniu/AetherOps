
from typing import Optional
from kbx.common.types import UserInfo
from kbx.kbx import KBX


class UserService:
    def get_user_info(self, user_id: Optional[str] = None,
                      user_name: Optional[str] = None, tenant_id: Optional[str] = None) -> UserInfo:
        return KBX.get_user_info(user_id=user_id, user_name=user_name, tenant_id=tenant_id)

    def create_user(self, user_name: str, tenant_id: str, desired_user_id: Optional[str] = None):
        return KBX.add_user(user_name=user_name, tenant_id=tenant_id, desired_user_id=desired_user_id)

    def update_user_info(self, user_id: str, user_name: str) -> UserInfo:
        return KBX.update_user_info(user_id=user_id, user_name=user_name)

    def list_users(self, tenant_id: str, offset: int = 0, limit: int = 20) -> list[UserInfo]:
        return KBX.list_users(tenant_id=tenant_id, offset=offset, limit=limit)

    def remove_user(self, user_id: str):
        KBX.remove_user(user_id=user_id)
