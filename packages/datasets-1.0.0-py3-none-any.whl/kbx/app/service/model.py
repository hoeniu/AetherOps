# -*- coding: utf-8 -*-
from typing import Any, List, Optional, Dict, Union, Literal
from kbx.kbx import KBX
from kbx.ai_model.types import AIModelType
from kbx.common.constants import DEFAULT_USER_ID
import numpy as np


class ModelService:
    """
    Service layer for AI Model operations, encapsulating KBX interactions.
    """

    def register_ai_models(
        self,
        model_configs: List[Dict[str, Any]],
        overwrite: bool,
        user_id: str
    ) -> Dict[str, Any]:
        # Register AI models
        KBX.register_ai_models_from_conf(
            model_configs=model_configs,
            overwrite=overwrite,
            user_id=user_id
        )
        return {}

    def list_ai_models(
        self,
        user_id: str,
        offset: int,
        limit: int,
        type: Optional[AIModelType] = None,
        backend: Optional[Literal["openai", "volcengine", "tongyi", "jina"]] = None
    ) -> Dict[str, Union[int, List[Dict[str, Any]]]]:
        # List AI models with optional filters
        models, total_count = KBX.list_ai_models(
            user_id=user_id,
            offset=offset,
            limit=limit,
            type=type,
            backend=backend
        )
        ai_models_list: List[Dict[str, Any]] = []
        for name, cfg in models.items():
            ai_models_list.append({
                "model_name": name,
                "model_backend": cfg.backend,
                "model_type": cfg.type,
            })
        return {"total": total_count, "data": ai_models_list}

    def delete_ai_model(self, name: str, user_id: str) -> Dict[str, Any]:
        # Delete an AI model
        KBX.delete_ai_model(name=name, user_id=user_id)
        return {}

    def get_ai_model_detail(self, name: str, user_id: str) -> Dict[str, Any]:
        # Get AI model configuration details
        model_detail = KBX.get_ai_model_config(name=name, user_id=user_id)
        return model_detail.model_dump(mode="json")

    def embedding_score(
        self,
        text1: str,
        text2: str,
        model: str = '',
        user_id: str = DEFAULT_USER_ID,
    ):
        config, client = KBX.get_ai_model_config_and_client(
            name=model,
            user_id=user_id
        )

        embedding1, embedding2 = client.text_embedding_batch(
            config,
            texts=[text1, text2]
        )

        # 归一化
        embedding1 = embedding1 / np.linalg.norm(embedding1)
        embedding2 = embedding2 / np.linalg.norm(embedding2)

        # 计算余弦相似度，归一化到[0, 1]
        # score = np.dot(embedding1, embedding2) / 2 + 0.5
        # NOTE: 当前Embedding特征似乎直接计算余弦相似度已经在[0, 1]，不需要额外归一化
        score = np.dot(embedding1, embedding2)

        return {
            # "text1": request.text1,
            # "text2": request.text2,
            # "model": request.model,
            "score": score
        }
