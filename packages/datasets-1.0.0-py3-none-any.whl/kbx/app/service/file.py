from fastapi import HTTPException, UploadFile
from kbx.ai_model.types import AIModelBundle, AIModelType
from kbx.app.core.errors import BaseError
from kbx.app.core.filepath import upload_file_dir, get_file_path
from kbx.common.types import KBXError, DocData
from kbx.common.utils import generate_new_id
from kbx.kbx import KBX
import os
from typing import Any, Dict, List, Optional, Tuple


class FileService:
    def upload(self, user_id: str, file: UploadFile) -> str:
        """
        上传文件
        :param save_dir: 文件存储的相对路径文件夹
        :param file: 上传的文件
        """
        file_id = generate_new_id()
        save_dir = upload_file_dir(user_id, file_id)
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, os.path.basename(file.filename))
        with open(save_path, 'wb') as f:
            while True:
                chunk = file.file.read(8192)
                if not chunk:
                    break
                f.write(chunk)
        return file_id

    def parse(self, user_id: str, file_id: str, model_bundle: Dict[str, str]) -> Dict[str, Any]:
        model_bundles = {key: value for key, value in model_bundle.items() if key in [e.value for e in AIModelType]}
        try:
            if not model_bundles:
                model_bundles = {
                    AIModelType.LLM: "volcengine-deepseek-v3",
                    AIModelType.VLM: "doubao-1.5-vision-pro-32k",
                    AIModelType.TEXT_EMBEDDING: "jina-embeddings-v3",
                    AIModelType.RERANK: "BAAI/bge-reranker-v2-m3",
                }
            doc_file_path = get_file_path(user_id, file_id)
            doc_id, err = KBX.parse_fast_doc(doc_file_path, AIModelBundle(bundles=model_bundles), user_id)
            if err.code == KBXError.Code.SUCCESS:
                return {"doc_id": doc_id}
            else:
                raise HTTPException(status_code=500, detail=str(err.msg))
        except BaseError as e:
            raise HTTPException(status_code=e.code, detail=e.message)

    def list_parsed_attachment(self, user_id: str, doc_ids: List[str]) -> List[Tuple[Optional[DocData], KBXError]]:
        try:
            return KBX.get_fast_doc_data(doc_ids, user_id)
        except BaseError as e:
            raise HTTPException(status_code=e.code, detail=e.message)

    def delete_parsed_attachment(self, user_id: str, doc_ids: List[str]) -> List[KBXError]:
        try:
            return KBX.remove_fast_docs(doc_ids, user_id)
        except BaseError as e:
            raise HTTPException(status_code=e.code, detail=e.message)
