from typing import Optional, List
from kbx.common.types import TenantInfo
from kbx.kbx import KBX


class TenantService:
    def get_tenant_info(self, tenant_id: Optional[str] = None, tenant_name: Optional[str] = None) -> TenantInfo:
        return KBX.get_tenant_info(tenant_id=tenant_id, tenant_name=tenant_name)

    def create_tenant(self, tenant_name: str, desired_tenant_id: Optional[str] = None) -> str:
        return KBX.add_tenant(tenant_name=tenant_name, desired_tenant_id=desired_tenant_id)

    def update_tenant_info(self, tenant_id: str, tenant_name: str) -> TenantInfo:
        return KBX.update_tenant_info(tenant_id=tenant_id, tenant_name=tenant_name)

    def list_tenants(self, offset: int = 0, limit: int = 20) -> List[TenantInfo]:
        return KBX.list_tenants(offset=offset, limit=limit)

    def remove_tenant(self, tenant_id: str) -> None:
        KBX.remove_tenant(tenant_id=tenant_id)
