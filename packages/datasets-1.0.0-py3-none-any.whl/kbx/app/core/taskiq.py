from taskiq_redis import RedisAsyncResultBackend, ListQueueBroker
from taskiq import InMemoryBroker
from kbx.kbx import KBX
from kbx.common.logging import logger
from kbx.common.utils import locate_kbx_settings_yaml


# 初始化配置
config_file = locate_kbx_settings_yaml()
#
if KBX.config is None:
    KBX.init(config_file)

if KBX.config.redis is not None:
    logger.info("Using redis broker")
    REDIS_URL = f"redis://:{KBX.config.redis['password']}@{KBX.config.redis['host']}:{KBX.config.redis['port']}"

    result_backend = RedisAsyncResultBackend(
        redis_url=REDIS_URL,
    )

    # Or you can use PubSubBroker if you need broadcasting
    # Or ListQueueBroker if you don't want acknowledges
    broker = ListQueueBroker(
        url=REDIS_URL,
    ).with_result_backend(result_backend)
else:
    logger.info("Using in-memory broker")
    broker = InMemoryBroker()
