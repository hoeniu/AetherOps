class BaseError(Exception):
    """Base error class for all exceptions."""
    code: int
    message: str

    def __init__(self, message: str = None):
        super().__init__(message or self.message)
        if message:
            self.message = message


class NotFoundError(BaseError):
    """Raised when a resource is not found."""
    code = 404
    message = "not found"


class InvalidRequestError(BaseError):
    """Raised when a request is invalid."""
    code = 400
    message = "invalid request"
