import os

from kbx.kbx import KBX

TREE_PATH = "tree_structure"

UPLOAD_PATH = "uploads"


def upload_file_dir(user_id, file_id):
    return os.path.join(KBX.config.work_dir, f"{UPLOAD_PATH}/{user_id}/{file_id}")


def get_file_path(user_id, file_id):
    dir_path = upload_file_dir(user_id, file_id)
    if not os.path.exists(dir_path):
        raise ValueError("path dose not exists")
    files = os.listdir(dir_path)
    if not files:
        raise ValueError("no files found")
    return os.path.join(dir_path, files[0])
