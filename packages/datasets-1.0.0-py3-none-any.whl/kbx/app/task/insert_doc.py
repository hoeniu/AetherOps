from kbx.app.core.taskiq import broker
from kbx.kbx import KBX
import os
import shutil
from kbx.parser.types import DocParseConfig
from typing import Optional, Dict, Any, Union, List
from fastapi import HTTPException


# 定义异步任务
@broker.task
async def async_insert_docs_to_kb(kb_id: str, user_id: str, save_file_paths: Union[str, List[str]],
                                  doc_parse_config: Optional[DocParseConfig] = None,
                                  save_dir: str = '',
                                  doc_patterns: Optional[List[str]] = None,
                                  only_upload: bool = False,
                                  ) -> List[Dict[str, Any]]:
    try:
        # 获取知识库实例
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)
        # 插入文档
        doc_infos = kb.insert_docs(
            file_list=save_file_paths,
            doc_parse_config=doc_parse_config,
            save_dir=save_dir,
            doc_patterns=doc_patterns,
            only_upload=only_upload,
        )
        # 删除临时文件
        for save_file_path in save_file_paths:
            if os.path.exists(save_file_path):
                os.remove(save_file_path)
                os.rmdir(os.path.dirname(save_file_path))
        return [doc_info.model_dump(mode="json") for doc_info in doc_infos]
    except Exception as e:
        # 删除临时文件
        for save_file_path in save_file_paths:
            if os.path.exists(save_file_path):
                os.remove(save_file_path)
                os.rmdir(os.path.dirname(save_file_path))
        raise HTTPException(status_code=500, detail=str(e))


@broker.task
async def async_insert_docs_folder_to_kb(
    kb_id: str,
    user_id: str,
    folder_path: str,
    doc_parse_config: Optional[DocParseConfig] = None,
    recursive: bool = True,
    include_patterns: Optional[List[str]] = None,
    exclude_patterns: Optional[List[str]] = None,
    max_files_per_batch: int = 20,
    save_dir: str = '',
    doc_patterns: Optional[List[str]] = None,
    only_upload: bool = False,
) -> List[Dict[str, Any]]:
    try:
        # 获取知识库实例
        kb = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id)
        # 插入文档
        doc_infos = kb.insert_docs_folder(
            folder_path=folder_path,
            doc_parse_config=doc_parse_config,
            recursive=recursive,
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
            max_files_per_batch=max_files_per_batch,
            save_dir=save_dir,
            doc_patterns=doc_patterns,
            only_upload=only_upload,
        )
        rets = []
        for _, folder_doc_infos in doc_infos.items():
            rets.extend([doc_info.model_dump(mode="json") for doc_info in folder_doc_infos])
        return rets
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        # 删除临时文件夹
        if os.path.exists(folder_path):
            shutil.rmtree(folder_path)
