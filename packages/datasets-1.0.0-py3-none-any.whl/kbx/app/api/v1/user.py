from typing import Optional, List
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from kbx.app.service.user import UserService
from kbx.common.types import UserInfo

router = APIRouter(prefix="/tenants/{tenant_id}/users", tags=["User"])


class UserCreate(BaseModel):
    name: str
    desired_user_id: Optional[str] = None


class UserUpdate(BaseModel):
    name: str


@router.get("/", response_model=List[UserInfo], summary="获取用户列表")
def list_users(tenant_id: str, offset: int = 0, limit: int = 20):
    return UserService().list_users(tenant_id=tenant_id, offset=offset, limit=limit)


@router.get("/{user_id}", response_model=UserInfo, summary="获取用户详情")
def get_user(tenant_id: str, user_id: str):
    try:
        return UserService().get_user_info(user_id=user_id, tenant_id=tenant_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/", response_model=str, status_code=status.HTTP_201_CREATED, summary="创建用户")
def create_user(tenant_id: str, user: UserCreate):
    try:
        return UserService().create_user(user_name=user.name, tenant_id=tenant_id, desired_user_id=user.desired_user_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{user_id}", response_model=UserInfo, summary="更新用户信息")
def update_user(user_id: str, user: UserUpdate):
    try:
        return UserService().update_user_info(user_id=user_id, user_name=user.name)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT, summary="删除用户")
def delete_user(user_id: str):
    try:
        UserService().remove_user(user_id=user_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
