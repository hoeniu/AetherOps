from typing import Optional, List
from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from pydantic import Field
from typing import Annotated, Dict, Any, Union
from fastapi import Query, Body

from kbx.common.utils import get_user_id
from kbx.app.service.doc import DocService
from kbx.common.types import KBXBaseModel
from kbx.parser.types import DocParseConfig
from kbx.common.logging import logger
from kbx.knowledge_base.types import DocType

router = APIRouter(prefix="", tags=["Document"])


class InsertDocRequest(KBXBaseModel):
    doc_parse_config: Optional[DocParseConfig] = Field(None, description="文档解析配置")
    save_dir: str = Field(default='', description="文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下")
    doc_patterns: Optional[List[str]] = Field(
        default=None,
        description="指定“普通文档”文件名规则列表，当doc_type=None时将根据doc_patterns确定文档类型，例如"
        "- 指定一种或多种文件名后缀，例如['*.md', 'docs/*.pdf', 'api/**/*.txt']"
        "- 指定一个或多个文件命名规则，例如['index.html', 'index.md']"
    )
    only_upload: bool = Field(default=False, description="是否只进行上传，稍后再进行解析和索引，默认为False，表示上传后直接进行解析和索引")
    keep_rel_path: bool = Field(default=True, description="是否保留UploadFile文件filename属性可能存在的相对路径（文件夹上传模式），默认为True，表示保留")


# 异步插入文档
@router.post(
    "/docs/{kb_id}/async",
    response_model=List[Dict[str, Any]],
    summary="异步插入多个文档",
    description="向知识库中异步插入多个文档，并返回插入结果，注意，当前仅支持客户端和服务端在同一存储上使用绝对路径进行调用，暂不支持跨存储调用。"
)
async def insert_docs_async(
    kb_id: str,
    files: Annotated[List[UploadFile], File(..., description="上传的文件列表")],
    request: InsertDocRequest = Depends(),
    user_id=Depends(get_user_id),
):
    try:
        logger.info(f"insert_docs_async: {files}")
        return await DocService().insert_docs_async(
            user_id=user_id,
            files=files,
            kb_id=kb_id,
            doc_parse_config=request.doc_parse_config,
            save_dir=request.save_dir,
            doc_patterns=request.doc_patterns,
            only_upload=request.only_upload,
            keep_rel_path=request.keep_rel_path,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 插入文档
@router.post(
    "/docs/{kb_id}",
    response_model=List[Dict[str, Any]],
    summary="插入多个文档",
    description="向知识库中插入多个文档，并返回插入结果，注意，当前仅支持客户端和服务端在同一存储上使用绝对路径进行调用，暂不支持跨存储调用。"
)
def insert_docs(
    kb_id: str,
    files: Annotated[List[UploadFile], File(..., description="上传的文件列表")],
    request: InsertDocRequest = Depends(),
    user_id=Depends(get_user_id),
):
    try:
        return DocService().insert_docs(
            user_id=user_id,
            files=files,
            kb_id=kb_id,
            doc_parse_config=request.doc_parse_config,
            save_dir=request.save_dir,
            doc_patterns=request.doc_patterns,
            only_upload=request.only_upload,
            keep_rel_path=request.keep_rel_path,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 文档id列表
@router.get(
    "/doc_ids",
    response_model=Dict[str, Union[int, List[Dict]]],
    summary="列出所有文档",
    description="返回一个包含所有文档ID列表。"
)
def list_doc_ids(
        kb_id: str = Query(..., description="知识库ID"),
        offset: int = Query(0, description="偏移量"),
        limit: int = Query(20, description="返回数量"),
        page_no: Optional[int] = Query(None, description="分页页码"),
        doc_type_filter: Optional[List[DocType]] = Query(None, description="文档类型过滤器"),
        user_id=Depends(get_user_id),
):
    try:
        if page_no:
            offset = (page_no - 1) * limit

        # 获取所有文档ID
        return DocService().list_doc_ids(
            kb_id=kb_id,
            offset=offset,
            limit=limit,
            doc_type_filter=doc_type_filter,
            user_id=user_id,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 文档列表
@router.get(
    "/docs_info",
    response_model=Dict[str, Union[int, List[Dict]]],
    summary="列出所有文档",
    description="返回一个包含所有文档的列表。"
)
def list_docs_info(
        kb_id: str = Query(..., description="知识库ID"),
        offset: int = Query(0, description="偏移量"),
        limit: int = Query(20, description="返回数量"),
        page_no: Optional[int] = Query(None, description="分页页码"),
        doc_type_filter: Optional[List[DocType]] = Query(None, description="文档类型过滤器"),
        user_id=Depends(get_user_id),
):
    try:
        if page_no:
            offset = (page_no - 1) * limit

        return DocService().list_docs_info(
            kb_id=kb_id,
            offset=offset,
            limit=limit,
            doc_type_filter=doc_type_filter,
            user_id=user_id,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 获取chunks
@router.get(
    "/list_chunks",
    response_model=Dict[str, Union[int, List[Dict]]],
    summary="列出指定文档所包含的chunks",
    description="返回一个包含多个Chunk的列表"
)
def list_chunks(
    offset: int = Query(0, description="偏移量"),
    limit: int = Query(20, description="返回数量"),
    page_no: Optional[int] = Query(None, description="分页页码"),
    kb_id: str = Query(..., description="知识库ID"),
    doc_id: str = Query(..., description="文档ID"),
    user_id=Depends(get_user_id),
):
    try:
        if page_no:
            offset = (page_no - 1) * limit

        return DocService().list_chunks(offset, limit, kb_id, doc_id, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class InsertDocsFolderRequest(KBXBaseModel):
    kb_id: str = Field(..., description="知识库ID")
    folder_path: str = Field(..., description="文件夹绝对路径")
    doc_parse_config: Optional[DocParseConfig] = Field(None, description="文档解析配置")
    recursive: bool = Field(default=True, description="是否递归处理子文件夹，默认为True")
    include_patterns: Optional[List[str]] = Field(
        default=None,
        description="要包含的文件匹配模式列表，支持通配符，如['*.md', 'docs/*.pdf', 'api/**/*.txt']"
    )
    exclude_patterns: Optional[List[str]] = Field(
        default=None,
        description="要排除的文件匹配模式列表，支持通配符，如['*.tmp', 'temp/*', '**/draft_*']"
    )
    max_files_per_batch: int = Field(default=20, description="每批处理的最大文件数，默认为20")
    save_dir: str = Field(default='', description="文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下")


# 插入文档文件夹
@router.post(
    "/insert_docs_folder",
    response_model=Dict[str, Any],
    summary="插入文档文件夹",
    description="向知识库中插入一个文档文件夹，并返回插入结果。"
)
def insert_docs_folder(
    request: InsertDocsFolderRequest = Body(..., description="插入文档文件夹请求参数"),
    user_id=Depends(get_user_id),
):
    try:
        return DocService().insert_docs_folder(
            folder_path=request.folder_path,
            doc_parse_config=request.doc_parse_config,
            recursive=request.recursive,
            include_patterns=request.include_patterns,
            exclude_patterns=request.exclude_patterns,
            max_files_per_batch=request.max_files_per_batch,
            save_dir=request.save_dir,
            user_id=user_id,
            kb_id=request.kb_id,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 文档详情
@router.get(
    "/doc_info",
    response_model=Dict[str, Any],
    summary="列出文档详情",
    description="返回一个文档的详情信息。"
)
def get_doc_info(
        kb_id: str = Query(..., description="知识库ID"),
        doc_id: str = Query(..., description="文档ID"),
        user_id=Depends(get_user_id),
):
    try:
        return DocService().get_doc_info(kb_id, doc_id, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 删除文档
@router.post(
    "/remove_docs",
    response_model=Dict[str, Any],
    summary="删除文档",
    description="删除指定ID的文档，返回操作结果。",
)
def remove_docs(
    kb_id: str = Query(..., description="知识库ID"),
    doc_ids: Union[str, List[str]] = Query(..., description="文档ID"),
    user_id=Depends(get_user_id),
):
    try:
        return DocService().remove_docs(kb_id, doc_ids, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 文档切片内容对应数据详情
@router.get(
    "/doc_data",
    response_model=Dict[str, Any],
    summary="列出文档切片内容对应数据详情",
    description="返回一个文档切片内容的数据详情信息。"
)
def get_doc_data(
        kb_id: str = Query(..., description="知识库ID"),
        doc_id: str = Query(..., description="文档ID"),
        user_id=Depends(get_user_id),
):
    try:
        return DocService().get_doc_data(kb_id, doc_id, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
