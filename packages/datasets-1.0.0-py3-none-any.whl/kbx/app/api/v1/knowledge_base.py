from typing import Any, List, Optional, Dict, Union
from fastapi import Depends, HTTPException, Query, Body, APIRouter
from kbx.knowledge_base.types import KBCreationConfig
from kbx.common.utils import get_user_id
from kbx.app.service.knowledge_base import KnowledgeBaseService


router = APIRouter(prefix="", tags=["KnowledgeBase"])


# 创建知识库
@router.post(
    "/create_kb",
    response_model=Dict[str, Any],
    summary="创建知识库",
    description="创建一个新的知识库，并返回其ID。",
)
def create_kb(
    kb_creation_config: KBCreationConfig = Body(..., description="新的知识库配置"),
    desired_kb_id: str = Query(None, description="期望的知识库ID"),
    auto_create_user_tenant: bool = Query(False, description="是否自动创建用户租户"),
    user_id: str = Depends(get_user_id),
):
    try:
        return KnowledgeBaseService().create_kb(
            kb_creation_config,
            desired_kb_id,
            auto_create_user_tenant,
            user_id,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 删除知识库
@router.post(
    "/remove_kb",
    response_model=Dict[str, Any],
    summary="删除知识库",
    description="删除指定ID的知识库，返回操作结果。",
)
def remove_kb(
    kb_id: str = Query(..., description="知识库ID"),
    user_id: str = Depends(get_user_id),
):
    try:
        return KnowledgeBaseService().remove_kb(kb_id, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 修改知识库配置
@router.post(
    "/modify_kb_config",
    response_model=Dict[str, Any],
    summary="修改知识库配置",
    description="修改指定知识库的配置，返回更新后的配置信息。",
)
def modify_kb_config(
    new_config: KBCreationConfig = Body(..., description="新的知识库配置"),
    kb_id: str = Query(..., description="知识库ID"),
    user_id: str = Depends(get_user_id),
):
    try:
        return KnowledgeBaseService().modify_kb_config(new_config, kb_id, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 列出所有知识库
@router.get(
    "/list_kbs",
    response_model=Dict[str, Union[int, List[Dict]]],
    summary="列出所有知识库",
    description="返回知识库总数以及包含所有知识库信息的列表。"
)
def list_kbs(
    user_id: str = Depends(get_user_id),
    offset: int = Query(0, description="分页偏移量"),
    limit: int = Query(-1, description="分页大小限制"),
    page_no: Optional[int] = Query(None, description="分页页码")
):
    try:
        if page_no:
            offset = (page_no - 1) * limit
        return KnowledgeBaseService().list_kbs(user_id, offset, limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# 查询知识库详情
@router.get(
    "/kb_detail",
    response_model=Dict[str, Any],
    summary="查询知识库详情",
    description="返回某个知识库的详情信息。"
)
def get_kb_detail(
    kb_id: str = Query(..., description="知识库ID"),
    user_id: str = Depends(get_user_id),
):
    try:
        return KnowledgeBaseService().get_kb_detail(kb_id, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
