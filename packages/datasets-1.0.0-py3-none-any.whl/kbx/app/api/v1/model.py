from typing import Any, List, Optional, Dict, Union, Literal
from pydantic import Field
from fastapi import Depends, HTTPException, Query, APIRouter
from kbx.common.types import KBXBaseModel
from kbx.ai_model.types import AIModelType
from kbx.common.utils import get_user_id
from kbx.app.service.model import ModelService

router = APIRouter(prefix="", tags=["AIModel"])
service = ModelService()


class AIModelRegistrationRequest(KBXBaseModel):
    configs: List[Dict] = Field(default_factory=list, description="模型配置列表")
    overwrite: bool = Field(default=False, description="是否覆盖已存在的模型配置")


class EmbeddingScoreRequest(KBXBaseModel):
    text1: str = Field(..., description="第一个文本")
    text2: str = Field(..., description="第二个文本")
    model: str = Field(..., description="Embedding模型名称")


@router.post(
    "/register_ai_models",
    response_model=Dict[str, Any],
    summary="注册AI模型",
    description="注册一个或多个AI模型配置",
)
def register_ai_models(
    request: AIModelRegistrationRequest,
    user_id: str = Depends(get_user_id),
):
    try:
        return ModelService().register_ai_models(request.configs, request.overwrite, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/list_ai_models",
    response_model=Dict[str, Union[int, List[Dict]]],
    summary="列出所有AI模型",
    description="返回当前用户所有已注册的AI模型数量及列表，支持通过type、backend参数指定模型类型或后端进行过滤",
)
def list_ai_models(
    user_id: str = Depends(get_user_id),
    offset: int = Query(0, description="分页偏移量"),
    limit: int = Query(-1, description="分页大小限制"),
    page_no: Optional[int] = Query(None, description="分页页码"),
    type: Optional[AIModelType] = Query(
        None,
        description="模型类型，可选值：llm, vlm, text_embedding, vision_embedding, rerank, speech2text, tts"
    ),
    backend: Optional[Literal["openai", "volcengine", "tongyi", "jina"]] = Query(
        None,
        description="模型后端，可选值：openai, volcengine, tongyi, jina"
    )
):
    try:
        if page_no:
            offset = (page_no - 1) * limit
        return ModelService().list_ai_models(user_id, offset, limit, type, backend)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/delete_ai_model",
    response_model=Dict[str, Any],
    summary="删除AI模型",
    description="根据模型名称删除指定的AI模型",
)
def delete_ai_model(
    name: str = Query(..., description="模型名称"),
    user_id: str = Depends(get_user_id),
):
    try:
        return ModelService().delete_ai_model(name, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/ai_model_detail",
    response_model=Dict[str, Any],
    summary="获取AI模型详情",
    description="返回指定AI模型的详细配置信息",
)
def get_ai_model_detail(
    name: str = Query(..., description="模型名称"),
    user_id: str = Depends(get_user_id),
):
    try:
        return ModelService().get_ai_model_detail(name, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/embedding_score",
    summary="计算文本embedding相似度",
    description="计算两个文本在指定模型下的embedding相似度（归一化到[0, 1]）",
)
def embedding_score(
    request: EmbeddingScoreRequest,
    user_id=Depends(get_user_id),
):
    try:
        return ModelService().embedding_score(request.text1, request.text2, request.model, user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
