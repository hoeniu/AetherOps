from fastapi import APIRouter

router = APIRouter(prefix="", tags=["Health"])


@router.get(
    "/health",
    summary="健康检查",
    description="用于检查服务是否正常运行",
)
def health_check():
    return {"status": "healthy"}
