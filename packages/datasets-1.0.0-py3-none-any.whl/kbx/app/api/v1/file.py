from typing import List, Dict, Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile
from kbx.app.service.file import FileService
from kbx.common.types import KBXError, DocData
from kbx.common.utils import get_user_id


router = APIRouter()


class DocDataResponse(BaseModel):
    doc_data: Optional[DocData]
    error: KBXError


class ParseRequest(BaseModel):
    file_id: str = Field(..., example="001")
    file_name: str = Field(..., example="2025年中央一号文件.txt")
    model_bundle: Optional[Dict[str, str]] = Field(
        ...,
        example={
            "llm": "volcengine-deepseek-v3",
            "vlm": "doubao-1.5-vision-pro-32k",
            "text_embedding": "jina-embeddings-v3",
            "rerank": "BAAI/bge-reranker-v2-m3"
        }
    )


@router.post("/upload")
def upload(file: UploadFile, user_id: str = Depends(get_user_id)):
    try:
        file_id = FileService().upload(user_id, file)
        return {"id": file_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post('/attachment_parser')
def parse(
    request: ParseRequest,
    user_id: str = Depends(get_user_id),
):
    model_bundle = request.model_bundle
    file_id = request.file_id
    return FileService().parse(user_id, file_id, model_bundle)


@router.get('/attachment_parser', response_model=List[DocDataResponse])
def list_parsed_attachment(
    doc_ids: str = Query(..., description="被解析的文档ID列表，以逗号分隔"),
    user_id: str = Depends(get_user_id),
):
    doc_data_list = FileService().list_parsed_attachment(user_id, doc_ids.split(','))
    return [DocDataResponse(doc_data=doc_data, error=err) for doc_data, err in doc_data_list]


@router.delete('/attachment_parser')
def delete_parsed_attachment(
    doc_ids: List[str],
    user_id: str
):
    return FileService().delete_parsed_attachment(user_id, doc_ids)
