from typing import List, Optional, Dict
from pydantic import Field
from fastapi import Depends, Query, Body, APIRouter
from kbx.app.service.retrieval import RetrievalService
from kbx.common.types import KBXBaseModel
from kbx.knowledge_base.types import QueryConfig
from kbx.common.utils import get_user_id
import json
from fastapi.responses import JSONResponse, StreamingResponse


router = APIRouter(prefix="", tags=["Retrieval"])
service = RetrievalService()


# 定义请求体模型
class RetrievalSettingDify(KBXBaseModel):
    top_k: int = Field(default=3, ge=1, le=100, description="本次检索返回的最大结果数量")
    score_threshold: float = Field(default=0.0, ge=0, lt=1, description="本次检索返回结果的最小分数阈值")


class RetrievalRequestDify(KBXBaseModel):
    knowledge_id: str = Field(default="", description="知识库ID")
    query: str = Field(default="", description="查询字符串")
    retrieval_setting: Optional[RetrievalSettingDify] = Field(default_factory=RetrievalSettingDify,
                                                              description="检索设置")


# 定义响应体模型
class RetrievalRecordDify(KBXBaseModel):
    """用于表示一条检索结果"""
    content: str = Field(default="", description="包含本条查询结果的文本分块")
    score: float = Field(default=0.0, description="本条结果的置信度，范围：0~1")
    title: str = Field(default="", description="本条结果来源于的文档名称")
    metadata: Dict[str, str] = Field(
        default_factory=dict,
        description="可以包含本条检索结果相关的更多元信息"
    )


class RetrievalResponseDify(KBXBaseModel):
    """用于表示一次检索的结果，可能包含k条记录
    结构字段定义请参考Dify官方文档：https://docs.dify.ai/guides/knowledge-base/external-knowledge-api-documentation#response-elements
    """
    records: List[RetrievalRecordDify] = Field(default_factory=list, description="检索结果列表")


@router.post(
    "/dify/retrieval",
    response_model=RetrievalResponseDify,
    summary="兼容Dify的知识检索接口",
    description="根据用户提供的查询和检索设置，从指定的知识库中检索相关文档，遵循Dify外部知识库API文档中的规范。",
)
def dify_retrieval(
        request: RetrievalRequestDify,
        user_id: str = Depends(get_user_id),
):
    records = service.dify_retrieval(user_id, request)
    return RetrievalResponseDify(records=records)


@router.post(
    "/retrieval",
    summary="KBX知识检索接口",
    description="根据用户提供的查询和检索设置，从指定的知识库中检索相关文档，返回对应QueryResult。",
)
def retrieval(
        request: QueryConfig = Body(..., description="查询配置"),
        kb_ids: List[str] = Query(..., description="知识库ID列表"),
        user_id=Depends(get_user_id),
):
    if request.stream:
        def event_generator():
            # NOTE: 这里不使用try-except，如果出错直接抛异常
            for result in service.retrieve(
                user_id=user_id,
                request=request,
                kb_ids=kb_ids
            ):
                result_json = json.dumps(result.model_dump(mode="json", context={"fill_all_formats": True}),
                                         ensure_ascii=False)
                yield f'data: {result_json}\n\n'

        return StreamingResponse(
            event_generator(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
                "Content-Type": "text/event-stream",
            }
        )
    else:
        # NOTE: 这里不使用try-except，如果出错直接抛异常
        results = service.retrieve(user_id, request, kb_ids)
        return JSONResponse(
            content=results.model_dump(mode="json", context={"fill_all_formats": True}),
            media_type="application/json"
        )
