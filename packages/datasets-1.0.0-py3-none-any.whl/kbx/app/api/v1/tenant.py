from typing import Optional, List
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from kbx.app.service.tenant import TenantService
from kbx.common.types import TenantInfo

router = APIRouter(prefix="/tenants", tags=["Tenant"])


class TenantCreate(BaseModel):
    name: str
    desired_tenant_id: Optional[str] = None


class TenantUpdate(BaseModel):
    name: str


@router.get("/", response_model=List[TenantInfo], summary="获取租户列表")
def list_tenants(offset: int = 0, limit: int = 20):
    return TenantService().list_tenants(offset=offset, limit=limit)


@router.get("/{tenant_id}", response_model=TenantInfo, summary="获取租户详情")
def get_tenant(tenant_id: str):
    try:
        return TenantService().get_tenant_info(tenant_id=tenant_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/", response_model=str, status_code=status.HTTP_201_CREATED, summary="创建租户")
def create_tenant(tenant: TenantCreate):
    try:
        return TenantService().create_tenant(tenant_name=tenant.name, desired_tenant_id=tenant.desired_tenant_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{tenant_id}", response_model=TenantInfo, summary="更新租户信息")
def update_tenant(tenant_id: str, tenant: TenantUpdate):
    try:
        return TenantService().update_tenant_info(tenant_id=tenant_id, tenant_name=tenant.name)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.delete("/{tenant_id}", status_code=status.HTTP_204_NO_CONTENT, summary="删除租户")
def delete_tenant(tenant_id: str):
    try:
        TenantService().remove_tenant(tenant_id=tenant_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
