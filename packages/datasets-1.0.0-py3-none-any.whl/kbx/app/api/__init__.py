from fastapi import APIRouter
from kbx.app.api.v1 import user, tenant, doc, knowledge_base, model, retrieval, health, file

api_router = APIRouter()
api_router.include_router(user.router, prefix="", tags=["用户"])
api_router.include_router(tenant.router, prefix="", tags=["租户"])
api_router.include_router(doc.router, prefix="", tags=["文档"])
api_router.include_router(knowledge_base.router, prefix="", tags=["知识库"])
api_router.include_router(model.router, prefix="", tags=["模型"])
api_router.include_router(retrieval.router, prefix="", tags=["检索"])
api_router.include_router(health.router, prefix="", tags=["健康检查"])
api_router.include_router(file.router, prefix="/files", tags=["文件管理"])
