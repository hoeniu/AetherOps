from celery import shared_task
from typing import Optional
from kbx.common.types import DocData
from kbx.parser.types import DocParseConfig
from kbx.parser.parser_factory import SmartParser
from kbx.datastore.ds_factory import get_file_datastore


@shared_task(queue='document_parse')
def parse_document_file(
    file_path: str,
    doc_id: str,
    doc_parse_config_json_str: str,
    kb_id: Optional[str] = None,
) -> DocData:
    """用于文档解析的Celery任务

    Args:
        file_path (str): 文档原始文件（在文件存储中的）路径
        doc_id (str): 指定的文档id
        parser_name (str): 解析器名称
        doc_parse_config_json_str (str): 文档解析参数的json字符串
        kb_id (Optional[str]): 知识库id，默认为None，表示不使用知识库

    Returns:
        DocData: 文档解析结果
    """
    doc_parse_config = DocParseConfig.model_validate_json(doc_parse_config_json_str)
    if kb_id:
        file_ds = get_file_datastore(kb_id=kb_id)
    else:
        file_ds = None
    parser = SmartParser(config=doc_parse_config, file_ds=file_ds)
    return parser.parse(file_path=file_path, doc_id=doc_id)
