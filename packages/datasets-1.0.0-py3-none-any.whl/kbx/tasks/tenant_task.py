from celery import shared_task
from kbx.kbx import KBX


@shared_task(queue='tenant')
def remove_tenant(tenant_id: str):
    try:
        KBX.remove_tenant(tenant_id=tenant_id)
        return {
            "status": "success",
            "message": "Tenant removed successfully"
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }


@shared_task(queue='tenant')
def remove_user(user_id: str):
    try:
        KBX.remove_user(user_id=user_id)
        return {
            "status": "success",
            "message": "User removed successfully"
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }
