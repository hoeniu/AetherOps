from kbx.ai_model.base_client import BaseAIModelClient


def get_ai_model_client_cls(backend: str) -> type[BaseAIModelClient]:
    """给定一个AIModel的backend名称，获取对应的AIModelClient类

    Args:
        backend (str): 模型backend名称，如openai

    Returns:
        type[BaseAIModelClient]: 对应的AI模型Client类，可用于后续的模型API调用
    """
    if backend == '':
        raise KeyError('AI model backend can not be empty.')
    elif backend == 'openai':
        from kbx.ai_model.openai import OpenAIModelClient
        return OpenAIModelClient
    elif backend == 'volcengine':
        from kbx.ai_model.volcengine import VolcengineModelClient
        return VolcengineModelClient
    elif backend == 'tongyi':
        from kbx.ai_model.tongyi import TongyiModelClient
        return TongyiModelClient
    elif backend == 'jina':
        from kbx.ai_model.jina import JinaModelClient
        return JinaModelClient
    else:
        raise KeyError(f'Unknown ai model backend: {backend}')
