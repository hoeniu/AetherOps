from typing import Callable, Union, Iterator
import re
import time
from kbx.common.logging import logger
from kbx.ai_model.types import ChatResponse, ChatResponseChunk


def retry_decorator(func: Callable):
    """retry装饰器"""
    def wrapper(*args, **kwargs):
        # 获取cls和config
        cls = args[0]
        config = kwargs.get("model_config") if "model_config" in kwargs else args[1]
        other_args = args[1:]

        max_retries = getattr(config, "max_retries", 0)
        retry_delay = getattr(config, "retry_delay", 1)
        for attempt in range(1 + max_retries):
            try:
                return func(cls, *other_args, **kwargs)
            except Exception as e:
                logger.warning(f"请求失败 (第 {attempt + 1} 次尝试): {e}")
                if attempt < max_retries:
                    sleep_time = retry_delay * (2**attempt)
                    logger.warning(f"等待 {sleep_time} 秒后重试...")
                    time.sleep(sleep_time)
                else:
                    # 如果是最后一次尝试，仍然失败，则抛出异常
                    raise e
    return wrapper


def postprocess_reasoning_content(
    response: Union[ChatResponse, Iterator[ChatResponseChunk]]
) -> Union[ChatResponse, Iterator[ChatResponseChunk]]:
    """DeepSeek R1风格的Reasoning LLM思考内容后处理
    把content中可能包含的<think>...</think>标签内容提取出来，
    放到与content平级的reasoning_content字段中，并返回新的ChatResponse对象

    兼容两种样式：
      1. <think>reasoning_content</think>content
      2. reasoning_content</think>content

    如果content中不包含</think>标签或已经有和content平级的reasoning_content字段，则不处理直接返回

    Args:
        response (ChatResponse): 原始的ChatResponse对象

    Returns:
        ChatResponse: 新的ChatResponse对象，包含reasoning_content字段
    """
    from openai.types.chat.chat_completion import ChatCompletion as OpenAIChatCompletion
    if isinstance(response, (ChatResponse, OpenAIChatCompletion)):
        for choice in response.choices:
            if getattr(choice.message, "reasoning_content", None):
                # 如果已经存在非空的reasoning_content字段，说明服务端已经处理过，直接返回
                # 注意，vllm等框架有可能在message中存在reasoning_content=None的值，
                # 但content中仍然包含</think>标签，因此不能直接通过hasattr判断
                return response

            if "</think>" in choice.message.content:
                # 检查content中是否包含</think>标签，如果有的话，尝试拆分成reasoning_content和content
                pattern = r"(?s)(?:<think>)?(.*?)</think>(.*)"
                groups = re.search(pattern, choice.message.content)
                if groups:
                    choice.message.reasoning_content = groups.group(1).strip()
                    choice.message.content = groups.group(2).strip()
        return response
    elif isinstance(response, Iterator):
        # 流式处理
        need_process = True
        reach_content = False

        def process_chunk(chunk: ChatResponseChunk) -> ChatResponseChunk:
            # NOTE: 这里需要使用nonlocal，否则reach_content会被当做局部变量处理
            nonlocal reach_content
            nonlocal need_process
            if not need_process:
                # 如果不需要处理，则直接返回
                return chunk
            for choice in chunk.choices:
                if getattr(choice.delta, "reasoning_content", None):
                    # 只要有一个chunk填充了reasoning_content，就说明服务端已经有对应处理，
                    # 本次和之后均可直接原样返回
                    need_process = False
                    return chunk

                if "<think>" in choice.delta.content:
                    # 如果content中包含<think>标签，直接replace删除（通常是第一个chunk）
                    choice.delta.content = choice.delta.content.replace("<think>", "")
                    choice.delta.reasoning_content = ''

                    # 注意，此时不能立即continue，仍需继续后续处理

                if "</think>" in choice.delta.content:
                    # 如果content中包含</think>标签，说明已经到达了reasoning_content与content的边界
                    reach_content = True
                    # 获取</think>前的内容作为reasoning_content，之后的内容作为content
                    pattern = r"(?s)(.*?)</think>(.*)"
                    groups = re.search(pattern, choice.delta.content)
                    if groups:
                        choice.delta.reasoning_content = groups.group(1).strip()
                        choice.delta.content = groups.group(2).strip()
                else:
                    if reach_content:
                        # 如果已经到达了content的边界，则content不需要再进行处理
                        choice.delta.reasoning_content = ''
                        continue
                    else:
                        # 如果还没有到达content边界，则此时的content一律作为reasoning_content
                        choice.delta.reasoning_content = choice.delta.content
                        choice.delta.content = ""
                        continue
            return chunk

        # 使用生成器来处理流式数据，尽可能的使得返回值类型为Iterator[ChatResponseChunk]
        def process_stream() -> Iterator[ChatResponseChunk]:
            for chunk in response:
                yield process_chunk(chunk)

        return process_stream()
    else:
        raise ValueError(f"Expected ChatResponse or Iterator[ChatResponseChunk], but got {type(response)}")
