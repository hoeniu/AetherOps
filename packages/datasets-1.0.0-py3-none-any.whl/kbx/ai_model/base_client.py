from typing import List, Tuple, Optional, IO, Iterable, Union, Iterator, overload
from abc import ABC
from kbx.ai_model.types import BaseAIModelConfig, AIModelType, ChatMessage, ChatResponse, ChatResponseChunk
from kbx.ai_model.utils import retry_decorator
from kbx.ai_model.limiter import AIModelLimiterFactory


class BaseAIModelClient(ABC):
    """AI大模型客户端，提供chat/embedding/rerank/speech2text等各类API接口。

    - 使用时无需创建对应实例，直接以classmethod调用所需要的API接口即可
    - 函数命名如果没有async等特殊标识，均为同步函数（即调用时会阻塞直至完成）
    - 函数命名如果没有_batch后缀，每次均只能处理一个样本，否则则可以一次性处理多个
    """

    LEGAL_CHAT_MODEL_TYPES = set(
        [
            AIModelType.LLM,
            AIModelType.REASONING_LLM,
            AIModelType.VLM,
            AIModelType.REASONING_VLM,
        ]
    )

    @staticmethod
    def config_class() -> type[BaseAIModelConfig]:
        """获取与本Client类关联的AI模型配置类

        Returns:
            type[BaseAIModelConfig]: BaseAIModelConfig
        """
        return BaseAIModelConfig

    @classmethod
    @overload
    @retry_decorator
    def chat(
        cls,
        model_config: BaseAIModelConfig,
        messages: Iterable[ChatMessage],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        top_p: float = 1.0,
        stream: bool = False,
        **kwargs
    ) -> ChatResponse:
        ...

    @classmethod
    @overload
    @retry_decorator
    def chat(
        cls,
        model_config: BaseAIModelConfig,
        messages: Iterable[ChatMessage],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        top_p: float = 1.0,
        stream: bool = True,
        **kwargs
    ) -> Iterator[ChatResponseChunk]:
        ...

    @classmethod
    @retry_decorator
    def chat(
        cls,
        model_config: BaseAIModelConfig,
        messages: Iterable[ChatMessage],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        top_p: float = 1.0,
        stream: bool = False,
        **kwargs
    ) -> Union[ChatResponse, Iterator[ChatResponseChunk]]:
        """chat模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            messages (Iterable[Message]): 历史消息，可以包含1个或多个消息记录，与openai风格的messages参数一致，例如
                [
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": "What is the capital of the moon?"},
                ]
            temperature (float): 控制随机程度的温度参数，范围为[0, 2]，数值越大随机性越强
            max_tokens (Optional[int]): 生成文本的最大token数量
            top_p (float): 同样用于控制文本生成时的多样性，范围(0, 1]，数值越大，多样性越强
            stream (bool): 是否启用流式输出，默认为False

        Returns:
            Union[ChatResponse, Iterator[ChatResponseChunk]]: 生成的回答内容字符串或流式结果
        """
        if model_config.type not in BaseAIModelClient.LEGAL_CHAT_MODEL_TYPES:
            raise RuntimeError(f"AIModel \"{model_config.name}\" (type={model_config.type}) 模型不支持chat接口")

        # 使用限流器对预测函数进行包装
        fn_chat = cls._chat
        if model_config.user_id:
            # 仅在能够获取有效user_id的情况下才启用限流器
            fn_limiter = AIModelLimiterFactory.get_limiter_decorator(model_config)
            fn_chat = fn_limiter(cls._chat)

        return fn_chat(
            model_config=model_config,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            stream=stream,
            **kwargs
        )

    @classmethod
    @overload
    def _chat(
        cls,
        model_config: BaseAIModelConfig,
        messages: Iterable[ChatMessage],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        top_p: float = 1.0,
        stream: bool = False,
        **kwargs
    ) -> ChatResponse:
        ...

    @classmethod
    @overload
    def _chat(
        cls,
        model_config: BaseAIModelConfig,
        messages: Iterable[ChatMessage],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        top_p: float = 1.0,
        stream: bool = True,
        **kwargs
    ) -> Iterator[ChatResponseChunk]:
        ...

    @classmethod
    def _chat(
        cls,
        model_config: BaseAIModelConfig,
        messages: Iterable[ChatMessage],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        top_p: float = 1.0,
        stream: bool = False,
        **kwargs
    ) -> Union[ChatResponse, Iterator[ChatResponseChunk]]:
        # 子类需要实现此方法
        raise NotImplementedError

    @classmethod
    @retry_decorator
    def text_embedding(
        cls,
        model_config: BaseAIModelConfig,
        text: str,
        **kwargs
    ) -> List[float]:
        """文本embedding模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            text (str): 需要提取embedding的文本字符串

        Returns:
            List[float]: 提取出的embedding向量
        """
        if model_config.type != AIModelType.TEXT_EMBEDDING:
            raise RuntimeError(f"{model_config.type}模型不支持text_embedding接口")

        # 使用限流器对预测函数进行包装
        fn_text_embedding = cls._text_embedding
        if model_config.user_id:
            # 仅在能够获取有效user_id的情况下才启用限流器
            fn_limiter = AIModelLimiterFactory.get_limiter_decorator(model_config)
            fn_text_embedding = fn_limiter(cls._text_embedding)

        return fn_text_embedding(
            model_config=model_config,
            text=text,
            **kwargs
        )

    @classmethod
    def _text_embedding(
        cls,
        model_config: BaseAIModelConfig,
        text: str,
        **kwargs
    ) -> List[float]:
        # 子类需要实现此方法
        raise NotImplementedError

    @classmethod
    @retry_decorator
    def text_embedding_batch(
        cls,
        model_config: BaseAIModelConfig,
        texts: List[str],
        **kwargs
    ) -> List[List[float]]:
        """文本embedding模型调用接口（批量）

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            texts (List[str]): 需要提取embedding的文本字符串list

        Returns:
            List[List[float]]: 提取出的embedding向量list
        """
        if model_config.type != AIModelType.TEXT_EMBEDDING:
            raise RuntimeError(f"{model_config.type}模型不支持text_embedding_batch接口")

        # 使用限流器对预测函数进行包装
        fn_text_embedding_batch = cls._text_embedding_batch
        if model_config.user_id:
            # 仅在能够获取有效user_id的情况下才启用限流器
            fn_limiter = AIModelLimiterFactory.get_limiter_decorator(model_config)
            fn_text_embedding_batch = fn_limiter(cls._text_embedding_batch)

        return fn_text_embedding_batch(
            model_config=model_config,
            texts=texts,
            **kwargs
        )

    @classmethod
    def _text_embedding_batch(
        cls,
        model_config: BaseAIModelConfig,
        texts: List[str],
        **kwargs
    ) -> List[List[float]]:
        raise NotImplementedError

    @classmethod
    @retry_decorator
    def vision_embedding(
        cls,
        model_config: BaseAIModelConfig,
        image_b64: str,
        **kwargs
    ) -> List[float]:
        """视觉embedding模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            image_b64 (str): 图像数据的base64编码

        Returns:
            List[float]: 提取出的embedding向量
        """
        if model_config.type != AIModelType.VISION_EMBEDDING:
            raise RuntimeError(f"{model_config.type}模型不支持vision_embedding接口")

        # 使用限流器对预测函数进行包装
        fn_vision_embedding = cls._vision_embedding
        if model_config.user_id:
            # 仅在能够获取有效user_id的情况下才启用限流器
            fn_limiter = AIModelLimiterFactory.get_limiter_decorator(model_config)
            fn_vision_embedding = fn_limiter(cls._vision_embedding)

        return fn_vision_embedding(
            model_config=model_config,
            image_b64=image_b64,
            **kwargs
        )

    @classmethod
    def _vision_embedding(
        cls,
        model_config: BaseAIModelConfig,
        image_b64: str,
        **kwargs
    ) -> List[float]:
        raise NotImplementedError

    @classmethod
    @retry_decorator
    def rerank(
        cls,
        model_config: BaseAIModelConfig,
        query: str,
        texts: List[str],
        top_n: Optional[int] = None,
        score_threshold: Optional[float] = None,
        **kwargs
    ) -> List[Tuple[int, str, float]]:
        """文本Rerank模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            query (str): 查询query字符串
            texts (List[str]): 需要排序的多个文本内容
            top_n (Optional[int]): 返回top n个分数最高的结果
            score_threshold (Optional[float], optional): 分数阈值，如果低于此阈值则会直接过滤，默认为None，表示不做过滤

        Returns:
            List[Tuple[int, str, float]]: 排序后的结果列表，格式为[(index, text, score), ......]
        """
        if model_config.type != AIModelType.RERANK:
            raise RuntimeError(f"{model_config.type}模型不支持rerank接口")

        # 使用限流器对预测函数进行包装
        fn_rerank = cls._rerank
        if model_config.user_id:
            # 仅在能够获取有效user_id的情况下才启用限流器
            fn_limiter = AIModelLimiterFactory.get_limiter_decorator(model_config)
            fn_rerank = fn_limiter(cls._rerank)

        return fn_rerank(
            model_config=model_config,
            query=query,
            texts=texts,
            top_n=top_n,
            score_threshold=score_threshold,
            **kwargs
        )

    @classmethod
    def _rerank(
        cls,
        model_config: BaseAIModelConfig,
        query: str,
        texts: List[str],
        top_n: Optional[int] = None,
        score_threshold: Optional[float] = None,
        **kwargs
    ) -> List[Tuple[int, str, float]]:
        raise NotImplementedError

    @classmethod
    @retry_decorator
    def speech2text(
        cls,
        model_config: BaseAIModelConfig,
        audio_file: IO[bytes],
        language: Optional[str] = None,
        **kwargs
    ) -> str:
        """语音识别模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            audio_file (IO[bytes]): 音频文件打开后的file对象
            language (Optional[str], optional): 语言，默认为None

        Returns:
            str: 从音频中识别出的文本字符串
        """
        if model_config.type != AIModelType.SPEECH2TEXT:
            raise RuntimeError(f"{model_config.type}模型不支持speech2text接口")

        # 使用限流器对预测函数进行包装
        fn_speech2text = cls._speech2text
        if model_config.user_id:
            # 仅在能够获取有效user_id的情况下才启用限流器
            fn_limiter = AIModelLimiterFactory.get_limiter_decorator(model_config)
            fn_speech2text = fn_limiter(cls._speech2text)

        return fn_speech2text(
            model_config=model_config,
            audio_file=audio_file,
            language=language,
            **kwargs
        )

    @classmethod
    def _speech2text(
        cls,
        model_config: BaseAIModelConfig,
        audio_file: IO[bytes],
        language: Optional[str] = None,
        **kwargs
    ) -> str:
        raise NotImplementedError
