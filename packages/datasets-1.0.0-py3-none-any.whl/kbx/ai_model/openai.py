from typing import List, Optional, Tuple, IO, Iterable, Union, Iterator
import requests
from openai import OpenAI
from pydantic import field_validator, Field, model_validator
from kbx.ai_model.types import BaseAIModelConfig, AIModelType, ChatMessage, ChatResponse, ChatResponseChunk
from kbx.ai_model.base_client import BaseAIModelClient
from agno.models.openai.like import OpenAILike


class OpenAIModelConfig(BaseAIModelConfig):
    """OpenAI协议的AI模型配置"""
    api_key: str = Field(default='', description='OpenAI API key')
    base_url: str = Field(default="https://api.openai.com/v1", description="OpenAI API base URL")

    model: str = Field(default=None, description='实际传给openai接口的model参数，如果为空则按照name字段的值进行设置')
    backend: str = Field(default='openai', pattern='^openai$', description='后端类型，必须为openai')

    @model_validator(mode='after')
    def set_default_model(self):
        if not self.model and self.name:
            self.model = self.name
        if not self.name and self.model:
            self.name = self.model
        if not self.name and not self.model:
            raise ValueError(f'Expect either model or name to be set, given {self.model_dump()}')
        return self

    @field_validator("backend")
    def validate_backend(cls, backend: str):
        if backend != 'openai':
            raise ValueError(f'{cls.__repr_name__} only supports backend "openai" right now, given {backend}')
        return backend

    def agno_model(self) -> OpenAILike:
        if self.type != AIModelType.LLM:
            raise ValueError(f"Agno model type should be LLM, {self.type} is given. ")
        return OpenAILike(id=self.name,
                          name=self.name,
                          api_key=self.api_key,
                          base_url=self.base_url)


def get_openai_sync_client(model_config: OpenAIModelConfig) -> OpenAI:
    return OpenAI(
        api_key=model_config.api_key,
        base_url=model_config.base_url,
        timeout=model_config.timeout,
        max_retries=0,  # 这里不重试，统一由上层实现
    )


class OpenAIModelClient(BaseAIModelClient):
    @staticmethod
    def config_class() -> type[OpenAIModelConfig]:
        """获取与本Client类关联的AI模型配置类

        Returns:
            type[OpenAIModelConfig]: OpenAIModelConfig
        """
        return OpenAIModelConfig

    @classmethod
    def _chat(
        cls,
        model_config: OpenAIModelConfig,
        messages: Iterable[ChatMessage],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        top_p: float = 1.0,
        stream: bool = False,
        **kwargs
    ) -> Union[ChatResponse, Iterator[ChatResponseChunk]]:
        """chat模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            messages (Iterable[Message]): 历史消息，可以包含1个或多个消息记录，与openai风格的messages参数一致，例如
                [
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": "What is the capital of the moon?"},
                ]
            temperature (float): 控制随机程度的温度参数，范围为[0, 2]，数值越大随机性越强
            max_tokens (Optional[int]): 生成文本的最大token数量，默认为None，表示使用模型默认值
            top_p (float): 同样用于控制文本生成时的多样性，范围(0, 1]，数值越大，多样性越强

        Returns:
            Union[ChatResponse, Iterator[ChatResponseChunk]]: 生成的回答内容字符串
        """
        client = get_openai_sync_client(model_config=model_config)

        if max_tokens is None or max_tokens <= 0:
            max_tokens = model_config.max_tokens

        response = client.chat.completions.create(
            model=model_config.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            timeout=model_config.timeout,
            stream=stream,
            **kwargs
        )

        if model_config.type in [AIModelType.REASONING_LLM, AIModelType.REASONING_VLM]:
            from kbx.ai_model.utils import postprocess_reasoning_content
            from typing import cast
            # 把原始openai的ChatCompletion对象转换为ChatResponse对象
            return postprocess_reasoning_content(cast(ChatResponse, response))
        else:
            # 非reasoning_llm类型，直接返回原始response
            return response

    @classmethod
    def _text_embedding(
        cls,
        model_config: OpenAIModelConfig,
        text: str,
        **kwargs
    ) -> List[float]:
        """文本embedding模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            text (str): 需要提取embedding的文本字符串

        Returns:
            List[float]: 提取出的embedding向量
        """
        client = get_openai_sync_client(model_config=model_config)
        response = client.embeddings.create(
            model=model_config.model,
            input=text,
            encoding_format=kwargs.get("embedding_type", "float"),
            timeout=model_config.timeout,
        )
        return response.data[0].embedding

    @classmethod
    def _text_embedding_batch(
        cls,
        model_config: OpenAIModelConfig,
        texts: List[str],
        **kwargs
    ) -> List[List[float]]:
        """文本embedding模型调用接口（批量）

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            texts (List[str]): 需要提取embedding的文本字符串list

        Returns:
            List[List[float]]: 提取出的embedding向量list
        """
        client = get_openai_sync_client(model_config=model_config)
        response = client.embeddings.create(
            model=model_config.model,
            input=texts,
            encoding_format=kwargs.get("embedding_type", "float"),
            timeout=model_config.timeout,

        )
        return [dp.embedding for dp in response.data]

    @classmethod
    def _rerank(
        cls,
        model_config: OpenAIModelConfig,
        query: str,
        texts: List[str],
        top_n: int,
        score_threshold: Optional[float] = None,
        **kwargs
    ) -> List[Tuple[int, str, float]]:
        """文本Rerank模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            query (str): 查询query字符串
            texts (List[str]): 需要排序的多个文本内容
            top_n (Optional[int]): 返回top n个分数最高的结果
            score_threshold (Optional[float], optional): 分数阈值，如果低于此阈值则会直接过滤，默认为None，表示不做过滤

        Returns:
            List[Tuple[int, str, float]]: 排序后的结果列表，格式为[(index, text, score), ......]
        """
        # OpenAI的Python SDK目前不支持rerank
        url = model_config.base_url.rstrip('/') + '/rerank'
        payload = {
            "model": model_config.model,
            "query": query,
            "documents": texts,
            "top_n": top_n,
            "return_documents": False,
        }
        if "max_chunks_per_doc" in kwargs:
            payload["max_chunks_per_doc"] = kwargs["max_chunks_per_doc"]
        if "overlap_tokens" in kwargs:
            payload["overlap_tokens"] = kwargs["overlap_tokens"]

        headers = {
            "Authorization": f"Bearer {model_config.api_key}",
            "Content-Type": "application/json"
        }

        # NOTE: requests的超时区分连接超时和调用超时
        timeout = (model_config.timeout, model_config.timeout)
        response = requests.request("POST", url, json=payload, headers=headers, timeout=timeout)
        data = response.json()

        results = []
        for result in data.get("results", []):
            index = result.get("index")
            document = result.get("document")
            text = document.get("text", texts[index]) if document else texts[index]
            score = result.get("relevance_score")

            if score_threshold is None or score >= score_threshold:
                results.append((index, text, score))

        results.sort(key=lambda x: x[2], reverse=True)

        return results

    @classmethod
    def _speech2text(
        cls,
        model_config: OpenAIModelConfig,
        audio_file: IO[bytes],
        language: Optional[str] = None,
        **kwargs
    ) -> str:
        """语音识别模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            audio_file (IO[bytes]): 音频文件打开后的file对象
            language (Optional[str], optional): 语言，默认为None

        Returns:
            str: 从音频中识别出的文本字符串
        """
        client = get_openai_sync_client(model_config=model_config)
        response = client.audio.transcriptions.create(
            file=audio_file,
            model=model_config.model,
            language=language,
            timeout=model_config.timeout,
        )
        return response.text
