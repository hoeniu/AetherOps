'''把reasoning_content字段添加到ChatCompletionMessage中，并更新所有更上级的类型'''

from typing import Optional, List
from pydantic import Field
from openai.types.chat.chat_completion import ChatCompletion as OpenAIChatCompletion, \
    Choice as OpenAIChatCompletionChoice
from openai.types.chat.chat_completion_message import ChatCompletionMessage as OpenAIChatCompletionMessage


class ChatCompletionMessage(OpenAIChatCompletionMessage):
    reasoning_content: Optional[str] = Field(default=None, description="DeepSeek R1风格的Reasoning LLM思考内容")


class Choice(OpenAIChatCompletionChoice):
    message: ChatCompletionMessage


class ChatCompletion(OpenAIChatCompletion):
    choices: List[Choice]
