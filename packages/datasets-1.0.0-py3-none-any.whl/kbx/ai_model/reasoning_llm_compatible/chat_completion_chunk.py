'''把reasoning_content字段添加到ChoiceDelta中，并更新所有更上级的类型'''

from typing import Optional, List
from pydantic import Field
from openai.types.chat.chat_completion_chunk import ChatCompletionChunk as OpenAIChatCompletionChunk, \
    ChoiceDelta as OpenAIChatCompletionChunkChoiceDelta, Choice as OpenAIChatCompletionChunkChoice


class ChoiceDelta(OpenAIChatCompletionChunkChoiceDelta):
    reasoning_content: Optional[str] = Field(default=None, description="DeepSeek R1风格的Reasoning LLM思考内容")


class Choice(OpenAIChatCompletionChunkChoice):
    delta: ChoiceDelta


class ChatCompletionChunk(OpenAIChatCompletionChunk):
    choices: List[Choice]
