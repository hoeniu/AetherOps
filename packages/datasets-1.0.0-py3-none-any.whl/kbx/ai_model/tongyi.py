from pydantic import field_validator
from kbx.ai_model.openai import OpenAIModelConfig, OpenAIModelClient


class TongyiAIModelConfig(OpenAIModelConfig):
    """通义千问AI模型配置"""
    backend: str = 'tongyi'
    base_url: str = 'https://dashscope.aliyuncs.com/compatible-mode/v1'

    @field_validator("backend")
    def validate_backend(cls, backend: str):
        if backend != 'tongyi':
            raise ValueError(f'{cls.__repr_name__} only supports backend "tongyi" right now, given {backend}')
        return backend


class TongyiModelClient(OpenAIModelClient):
    @staticmethod
    def config_class() -> type[TongyiAIModelConfig]:
        """获取与本Client类关联的AI模型配置类

        Returns:
            type[TongyiAIModelConfig]: TongyiAIModelConfig
        """
        return TongyiAIModelConfig
