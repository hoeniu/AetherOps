from typing import List
import requests
from pydantic import field_validator, Field, model_validator
from kbx.ai_model.types import BaseAIModelConfig, AIModelType
from kbx.ai_model.base_client import BaseAIModelClient


class JinaModelConfig(BaseAIModelConfig):
    """Jina官方的AI模型配置"""
    api_key: str = Field(default='', description='Jina API key')
    base_url: str = Field(default="https://api.jina.ai/v1", description="Jina API base URL")

    model: str = Field(default=None, description='实际传给调用请求的model参数，如果为空则按照name字段的值进行设置')
    backend: str = Field(default='jina', pattern='^jina$', description='后端类型，必须为jina')

    @model_validator(mode='after')
    def set_default_model(self):
        if not self.model and self.name:
            self.model = self.name
        if not self.name and self.model:
            self.name = self.model
        if not self.name and not self.model:
            raise ValueError(f'Expect either model or name to be set, given {self.model_dump()}')
        return self

    @field_validator("backend")
    def validate_backend(cls, backend: str):
        if backend != 'jina':
            raise ValueError(f'{cls.__repr_name__} only supports backend "jina" right now, given {backend}')
        return backend

    @field_validator("type")
    def validate_type(cls, type: str):
        if type != AIModelType.TEXT_EMBEDDING:
            raise ValueError(f'{cls.__repr_name__} only supports type "text_embedding" right now, given {type}')
        return type


class JinaModelClient(BaseAIModelClient):
    @staticmethod
    def config_class() -> type[JinaModelConfig]:
        """获取与本Client类关联的AI模型配置类

        Returns:
            type[JinaModelConfig]: JinaModelConfig
        """
        return JinaModelConfig

    @classmethod
    def _text_embedding(
        cls,
        model_config: JinaModelConfig,
        text: str,
        **kwargs
    ) -> List[float]:
        """文本embedding模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如JinaModelConfig）
            text (str): 需要提取embedding的文本字符串

        Returns:
            List[float]: 提取出的embedding向量
        """
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {model_config.api_key}"
        }

        data = {
            "model": model_config.model,
            "embedding_type": kwargs.get("embedding_type", "float"),
            "input": [text]
        }

        try:
            response = requests.post(
                f"{model_config.base_url.rstrip('/')}/embeddings",
                headers=headers,
                json=data
            )
            response.raise_for_status()
            return response.json()["data"][0]["embedding"]
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Failed to get embedding from Jina API: {str(e)}")

    @classmethod
    def _text_embedding_batch(
        cls,
        model_config: JinaModelConfig,
        texts: List[str],
        **kwargs
    ) -> List[List[float]]:
        """文本embedding模型调用接口（批量）

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如JinaModelConfig）
            texts (List[str]): 需要提取embedding的文本字符串list

        Returns:
            List[List[float]]: 提取出的embedding向量list
        """
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {model_config.api_key}"
        }

        data = {
            "model": model_config.model,
            "embedding_type": kwargs.get("embedding_type", "float"),
            "input": texts
        }

        try:
            response = requests.post(
                f"{model_config.base_url.rstrip('/')}/embeddings",
                headers=headers,
                json=data
            )
            response.raise_for_status()
            return [item["embedding"] for item in response.json()["data"]]
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Failed to get batch embeddings from Jina API: {str(e)}")
