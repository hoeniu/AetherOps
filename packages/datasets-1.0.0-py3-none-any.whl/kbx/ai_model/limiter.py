from __future__ import annotations
from contextlib import AbstractContextManager
import time
from typing import Optional, Type, Callable, Any, List, Tuple
from threading import Lock, Condition
from functools import partial
from itertools import count
from heapq import heappush, heappop
from types import TracebackType
from kbx.ai_model.types import BaseAIModelConfig


class SimpleLimiter(AbstractContextManager):
    __slots__ = (
        "max_rate",
        "time_period",
        "_rate_per_sec",
        "_level",
        "_last_check",
        "_lock",
        "_cond",
        "_waiters",
        "_next_count",
    )

    def __init__(self, max_rate: float, time_period: float = 60) -> None:
        """参考https://github.com/mjpieters/aiolimiter实现的一个限流器

        NOTE: 目前仅支持多线程，无法在多进程或分布式环境下使用

        A leaky bucket rate limiter.
        This is a context manager; when used with 'with', entering the context acquires capacity.

            limiter = Limiter(10)
            for foo in bar:
                with limiter:
                    # process foo elements at 10 items per minute

        Args:
            max_rate (float): Allow up to `max_rate` / `time_period` acquisitions before blocking.
            time_period (float, optional): duration, in seconds, of the time period in which to limit the rate.
                Note that up to `max_rate` acquisitions are allowed within this time period in a burst.
        """

        if max_rate <= 0:
            raise ValueError(f"max_rate must be greater than 0, given {max_rate}")

        self.max_rate = max_rate
        self.time_period = time_period
        self._rate_per_sec = max_rate / time_period
        self._level = 0.0
        self._last_check = time.monotonic()

        self._lock = Lock()
        self._cond = Condition(self._lock)

        # (amount, order, is_active) 元组的最小堆，is_active 用于标记请求是否仍在等待
        self._waiters: List[Tuple[float, int, bool]] = []
        self._next_count = partial(next, count())

    def _leak(self) -> None:
        """Drip out capacity from the bucket."""
        now = time.monotonic()
        if self._level:
            # drip out enough level for the elapsed time since
            # we last checked
            elapsed = now - self._last_check
            decrement = elapsed * self._rate_per_sec
            self._level = max(self._level - decrement, 0)
        self._last_check = now

    def has_capacity(self, amount: float = 1) -> bool:
        """Check if there is enough capacity remaining in the limiter

        :param amount: How much capacity you need to be available.

        """
        with self._lock:
            self._leak()
            return self._level + amount <= self.max_rate

    def _get_wait_time(self, amount: float) -> float:
        """计算需要等待的时间

        Returns:
            float: 需要等待的秒数，如果无需等待返回0
        """
        if self._level + amount <= self.max_rate:
            return 0

        needed = self._level + amount - self.max_rate
        return needed / self._rate_per_sec

    def _clean_waiters(self) -> None:
        """清理已完成的等待者"""
        while self._waiters and not self._waiters[0][2]:  # not is_active
            heappop(self._waiters)

    def _is_next_waiter(self, order: int) -> bool:
        """检查给定order的请求是否是下一个应该被处理的"""
        self._clean_waiters()
        return self._waiters and self._waiters[0][1] == order

    def acquire(self, amount: float = 1) -> None:
        """Acquire capacity in the limiter.

        If the limit has been reached, blocks until enough capacity has been
        freed before returning.

        :param amount: How much capacity you need to be available.
        :exception: Raises :exc:`ValueError` if `amount` is greater than
           :attr:`max_rate`.
        """
        if amount > self.max_rate:
            raise ValueError(f"Can't acquire more than the maximum capacity: {amount} vs {self.max_rate}")

        with self._lock:
            self._leak()
            # 如果当前有足够容量，直接获取
            if self._level + amount <= self.max_rate:
                self._level += amount
                return

            # 将请求加入等待队列
            order = self._next_count()
            waiter = (amount, order, True)
            heappush(self._waiters, waiter)

            while True:
                # 如果不是队列头部的请求，就等待被通知
                if not self._is_next_waiter(order):
                    self._cond.wait()
                    continue

                self._leak()
                wait_time = self._get_wait_time(amount)

                if wait_time <= 0:
                    # 可以获取容量了，更新状态并退出
                    self._level += amount
                    waiter = (amount, order, False)  # 标记为非活跃
                    heappop(self._waiters)  # 移除自己
                    self._cond.notify_all()  # 通知其他等待者
                    break

                # 等待指定时间后重试
                self._cond.wait(timeout=wait_time)

    def __repr__(self) -> str:
        with self._lock:
            return (f"<RateLimiter(max_rate={self.max_rate!r}, "
                    f"time_period={self.time_period!r}) at {id(self):#x} "
                    f"[level: {self._level:f}, waiters: {len(self._waiters)}]>")

    def __enter__(self) -> SimpleLimiter:
        self.acquire()
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> bool:
        with self._lock:
            self._cond.notify_all()
        return False


class TpmRpmLimiter:
    def __init__(self, rpm: Optional[float] = None, tpm: Optional[float] = None):
        self._rpm_limiter: Optional[SimpleLimiter] = None
        self._tpm_limiter: Optional[SimpleLimiter] = None

        if rpm and rpm > 0:
            self._rpm_limiter = SimpleLimiter(max_rate=rpm, time_period=60.0)
        if tpm and tpm > 0:
            self._tpm_limiter = SimpleLimiter(max_rate=tpm, time_period=60.0)

    def acquire(self, num_tokens: int = 1) -> None:
        if self._rpm_limiter:
            self._rpm_limiter.acquire()
        if self._tpm_limiter:
            self._tpm_limiter.acquire(num_tokens)

    def __repr__(self) -> str:
        return f"<TpmRpmRateLimiter {id(self)}(tpm_limiter={self._tpm_limiter!r}, rpm_limiter={self._rpm_limiter!r})>"

    def __enter__(self) -> TpmRpmLimiter:
        self.acquire()
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> bool:
        if self._tpm_limiter:
            self._tpm_limiter.__exit__(exc_type=exc_type, exc=exc, tb=tb)
        if self._rpm_limiter:
            self._rpm_limiter.__exit__(exc_type=exc_type, exc=exc, tb=tb)
        return False


class AIModelLimiterFactory:
    lock = Lock()
    limiter_map = {}

    @classmethod
    def get_limiter(cls, model_config: BaseAIModelConfig) -> TpmRpmLimiter:
        """给定模型配置，返回一个限流器

        NOTE: 目前仅支持多线程，无法在多进程或分布式环境下使用

        Args:
            model_config (BaseAIModelConfig): AI模型配置

        Returns:
            TpmRpmRateLimiter: 限流器
        """

        with cls.lock:
            key = f"{model_config.user_id}-{model_config.name}"
            if key not in cls.limiter_map:
                # 如果之前没有，新创建一个
                cls.limiter_map[key] = TpmRpmLimiter(rpm=model_config.rpm, tpm=model_config.tpm)
            return cls.limiter_map[key]

    @classmethod
    def get_limiter_decorator(cls, model_config: BaseAIModelConfig) -> Callable:
        """给定模型配置，返回一个限流器装饰器

        Args:
            model_config (BaseAIModelConfig): AI模型配置

        Returns:
            Callable: 限流器装饰器
        """

        def decorator(func: Callable):
            def wrapper(*args, **kwargs) -> Any:
                with cls.get_limiter(model_config):
                    # logger.debug(f'acquire limiter {limiter!r}')
                    return func(*args, **kwargs)
            return wrapper

        return decorator
