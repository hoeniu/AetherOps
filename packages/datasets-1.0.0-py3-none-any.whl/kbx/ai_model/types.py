import enum
from pydantic import Field, model_validator
from typing import Optional, TypeAlias, Optional, Dict
from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam
from kbx.ai_model.reasoning_llm_compatible.chat_completion import ChatCompletion
from kbx.ai_model.reasoning_llm_compatible.chat_completion_chunk import ChatCompletionChunk
from kbx.common.types import KBXBaseModel


# 直接使用openai的Message和返回值类型，避免重复定义
# 注意：这里进行了别名定义是为了以防万一，例如未来需要更改本项目的Message、Response类型定义，可以在这里统一进行修改
ChatMessage: TypeAlias = ChatCompletionMessageParam
ChatResponse: TypeAlias = ChatCompletion
ChatResponseChunk: TypeAlias = ChatCompletionChunk


class AIModelType(enum.Enum):
    '''AI大模型类别'''
    LLM = "llm"
    REASONING_LLM = "reasoning_llm"
    VLM = "vlm"
    REASONING_VLM = "reasoning_vlm"
    TEXT_EMBEDDING = "text_embedding"
    VISION_EMBEDDING = "vision_embedding"
    RERANK = "rerank"
    SPEECH2TEXT = "speech2text"
    TTS = "tts"


class BaseAIModelConfig(KBXBaseModel):
    name: str = Field(default='', description='模型的显示、索引名称，需要保证在同一个用户下唯一（可以与之后接口调用时的名称不同）')
    type: AIModelType = Field(default=AIModelType.LLM, description="AI模型类型")

    backend: str = Field(default='openai', min_length=1, description='此模型的后端实现类型，如openai等')

    user_id: Optional[str] = Field(default=None, description="此模型所属用户ID，不需要从外部配置，在注册时自动设置")

    max_context_len: int = Field(default=32768, description="最大上下文长度，即模型一次处理的最大tokens数量（输入+输出）")
    max_tokens: int = Field(default=4096, description='最大输出tokens数量')

    rpm: int = Field(default=-1, description='requests-per-minute，每分钟请求数量限制')
    tpm: int = Field(default=-1, description='tokens-per-minute，每分钟tokens数量限制')

    timeout: Optional[float] = Field(default=None, description="请求超时时间（秒）")
    max_retries: int = Field(default=2, description="最大重试次数")
    retry_delay: float = Field(default=1, description="重试延迟时间（秒）")

    def agno_model(self):
        raise NotImplementedError

    @model_validator(mode='after')
    def check_valid(self):
        if self.type is None:
            raise ValueError(f'Expect type to be set, given {self.model_dump()}')
        return self


class AIModelBundle(KBXBaseModel):
    '''可作为用户默认的一套模型选择方案，类似于Dify的系统模型配置'''
    bundles: Dict[AIModelType, str] = Field(
        default_factory=dict,
        description="模型选择方案字典，字典中key为模型类型，value为模型名称"
    )

    @property
    def llm(self) -> str:
        # NOTE: 如果标准llm不存在，尝试使用reasoning_llm替代
        if AIModelType.LLM in self.bundles:
            return self.bundles[AIModelType.LLM]
        else:
            return self.reasoning_llm

    @property
    def reasoning_llm(self) -> str:
        return self.bundles.get(AIModelType.REASONING_LLM, '')

    @property
    def vlm(self) -> str:
        # NOTE: 如果标准vlm不存在，尝试使用reasoning_vlm替代
        if AIModelType.VLM in self.bundles:
            return self.bundles[AIModelType.VLM]
        else:
            return self.reasoning_vlm

    @property
    def reasoning_vlm(self) -> str:
        return self.bundles.get(AIModelType.REASONING_VLM, '')

    @property
    def text_embedding(self) -> str:
        return self.bundles.get(AIModelType.TEXT_EMBEDDING, '')

    @property
    def vision_embedding(self) -> str:
        return self.bundles.get(AIModelType.VISION_EMBEDDING, '')

    @property
    def rerank(self) -> str:
        return self.bundles.get(AIModelType.RERANK, '')

    @property
    def speech2text(self) -> str:
        return self.bundles.get(AIModelType.SPEECH2TEXT, '')

    @property
    def tts(self) -> str:
        return self.bundles.get(AIModelType.TTS, '')
