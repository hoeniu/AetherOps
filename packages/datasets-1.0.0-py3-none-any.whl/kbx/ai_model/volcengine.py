from typing import List, Optional, Tuple, IO, Iterable, Union, Iterator
from pydantic import field_validator, model_validator, Field
from kbx.ai_model.openai import OpenAIModelConfig, OpenAIModelClient
from kbx.ai_model.types import ChatMessage, ChatResponse, ChatResponseChunk


class VolcengineAIModelConfig(OpenAIModelConfig):
    """火山引擎的AI模型配置"""
    endpoint: str = Field(min_length=1, description='火山引擎中模型的endpoint id，也是实际传给openai接口的model参数')

    model: str = ''
    backend: str = Field(default='volcengine', pattern='^volcengine$', description='后端类型，必须为volcengine')

    @model_validator(mode='after')
    def set_default_model(self):
        # 强制设置OpenAI风格的model参数为endpoint
        if not self.endpoint:
            raise ValueError(f'Expect endpoint to be set for VolcengineAIModelConfig, given {self.model_dump()}')
        self.model = self.endpoint

        super().set_default_model()
        return self

    @field_validator("backend")
    def validate_backend(cls, backend: str):
        if backend != 'volcengine':
            raise ValueError(f'{cls.__repr_name__} only supports backend "volcengine" right now, given {backend}')
        return backend

    def agno_model(self):
        from agno.models.openai.like import OpenAILike
        return OpenAILike(id=self.endpoint,
                          name=self.name,
                          api_key=self.api_key,
                          base_url=self.base_url)


class VolcengineModelClient(OpenAIModelClient):
    @staticmethod
    def config_class() -> type[VolcengineAIModelConfig]:
        """获取与本Client类关联的AI模型配置类

        Returns:
            type[VolcengineAIModelConfig]: VolcengineAIModelConfig
        """
        return VolcengineAIModelConfig

    @staticmethod
    def get_oai_model_config(model_config: VolcengineAIModelConfig) -> OpenAIModelClient:
        if not isinstance(model_config, VolcengineAIModelConfig):
            raise ValueError(f'Expect type of model_config to be VolcengineAIModelConfig, given {type(model_config)}')

        mc_dict = model_config.model_dump()
        mc_dict['name'] = model_config.endpoint
        mc_dict.pop('endpoint')
        mc_dict['backend'] = 'openai'

        return OpenAIModelConfig(**mc_dict)

    @classmethod
    def _chat(
        cls,
        model_config: VolcengineAIModelConfig,
        messages: Iterable[ChatMessage],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        top_p: float = 1.0,
        stream: bool = False,
        **kwargs
    ) -> Union[ChatResponse, Iterator[ChatResponseChunk]]:
        """chat模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            messages (Iterable[Message]): 历史消息，可以包含1个或多个消息记录，与openai风格的messages参数一致，例如
                [
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": "What is the capital of the moon?"},
                ]
            temperature (float): 控制随机程度的温度参数，范围为[0, 2]，数值越大随机性越强
            max_tokens (Optional[int]): 生成文本的最大token数量
            top_p (float): 同样用于控制文本生成时的多样性，范围(0, 1]，数值越大，多样性越强

        Returns:
            Union[ChatResponse, Iterator[ChatResponseChunk]]: 生成的回答内容字符串
        """
        oai_config = cls.get_oai_model_config(model_config=model_config)
        return super()._chat(
            oai_config,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            stream=stream,
            **kwargs
        )

    @classmethod
    def _text_embedding(
        cls,
        model_config: VolcengineAIModelConfig,
        text: str,
        **kwargs
    ) -> List[float]:
        """文本embedding模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            text (str): 需要提取embedding的文本字符串

        Returns:
            List[float]: 提取出的embedding向量
        """
        oai_config = cls.get_oai_model_config(model_config=model_config)
        return super()._text_embedding(oai_config, text=text, **kwargs)

    @classmethod
    def _text_embedding_batch(
        cls,
        model_config: VolcengineAIModelConfig,
        texts: List[str],
        **kwargs
    ) -> List[List[float]]:
        """文本embedding模型调用接口（批量）

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            texts (List[str]): 需要提取embedding的文本字符串list

        Returns:
            List[List[float]]: 提取出的embedding向量list
        """
        oai_config = cls.get_oai_model_config(model_config=model_config)
        return super()._text_embedding_batch(oai_config, texts=texts, **kwargs)

    @classmethod
    def _rerank(
        cls,
        model_config: VolcengineAIModelConfig,
        query: str,
        texts: List[str],
        top_n: int,
        score_threshold: Optional[float] = None,
        **kwargs
    ) -> List[Tuple[int, str, float]]:
        """文本Rerank模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            query (str): 查询query字符串
            texts (List[str]): 需要排序的多个文本内容
            top_n (Optional[int]): 返回top n个分数最高的结果
            score_threshold (Optional[float], optional): 分数阈值，如果低于此阈值则会直接过滤，默认为None，表示不做过滤

        Returns:
            List[Tuple[int, str, float]]: 排序后的结果列表，格式为[(index, text, score), ......]
        """
        oai_config = cls.get_oai_model_config(model_config=model_config)
        return super()._rerank(
            oai_config,
            query=query,
            texts=texts,
            top_n=top_n,
            score_threshold=score_threshold,
            **kwargs
        )

    @classmethod
    def _speech2text(
        cls,
        model_config: VolcengineAIModelConfig,
        audio_file: IO[bytes],
        language: Optional[str] = None,
        **kwargs
    ) -> str:
        """语音识别模型调用接口

        Args:
            model_config (AIModelConfig): 需要调用的AI大模型配置，
                对于某种特定的模型backend（如openai），应该传入对应类型的配置参数（如OpenAIModelConfig）
            audio_file (IO[bytes]): 音频文件打开后的file对象
            language (Optional[str], optional): 语言，默认为None

        Returns:
            str: 从音频中识别出的文本字符串
        """
        oai_config = cls.get_oai_model_config(model_config=model_config)
        return super()._speech2text(oai_config, audio_file=audio_file, language=language, **kwargs)
