from __future__ import annotations

import os
from typing import Dict, List, Optional
import json
from datetime import datetime
from sqlalchemy import ForeignKey, func, CheckConstraint, UniqueConstraint
from sqlalchemy import String, BigInteger, Text, Enum, VARCHAR, JSON
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column
from sqlalchemy.orm import relationship
from kbx.common.types import KBXError, FileInfo, UserInfo, TenantInfo
from kbx.knowledge_base.types import DocInfo, DocStatus, KBInfo, KBCreationConfig, DocType
from kbx.parser.types import DocParseConfig
from kbx.common.utils import generate_new_id
from kbx.ai_model.types import BaseAIModelConfig
from kbx.ai_model.ai_model_factory import get_ai_model_client_cls


'''
所有需要作为KBX业务数据落库的类型定义
注意，所有ORM类在命名上均以ORM结尾

TODO: 表结构设计待优化 @dingdong
'''


class BaseORM(DeclarativeBase):
    pass


class TenantORM(BaseORM):
    """租户类"""
    __tablename__ = "tenant_account"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_new_id)

    name: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    users: Mapped[List["UserORM"]] = relationship(
        back_populates="tenant", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"Tenant(id={self.id!r}, name={self.name!r})"

    @classmethod
    def from_pydantic(cls, tenant: TenantInfo) -> TenantORM:
        return cls(
            id=tenant.id,
            name=tenant.name,
        )

    def to_pydantic(self) -> TenantInfo:
        return TenantInfo(
            id=self.id,
            name=self.name,
        )


class UserORM(BaseORM):
    """用户类"""
    __tablename__ = "user_account"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_new_id)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenant_account.id"))

    name: Mapped[str] = mapped_column(String(30), nullable=False)
    tenant: Mapped["TenantORM"] = relationship(back_populates="users")

    kbs: Mapped[List["KBInfoORM"]] = relationship(
        back_populates="user", cascade="all, delete-orphan",
    )
    ai_model_configs: Mapped[List["AIModelConfigORM"]] = relationship(
        back_populates="user", cascade="all, delete-orphan",
    )

    __table_args__ = (
        UniqueConstraint('name', 'tenant_id', name='user_name_unique'),
    )

    def __repr__(self) -> str:
        return f"User(id={self.id!r}, name={self.name!r})"

    @classmethod
    def from_pydantic(cls, user: UserInfo, tenant_id: str) -> UserORM:
        return cls(
            id=user.id,
            name=user.name,
            tenant_id=tenant_id,
        )

    def to_pydantic(self) -> UserInfo:
        return UserInfo(
            id=self.id,
            name=self.name,
            tenant_id=self.tenant_id,
        )


class KBInfoORM(BaseORM):
    __tablename__ = "knowledge_base_info"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_new_id)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenant_account.id"), nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("user_account.id"), nullable=False)

    name: Mapped[str] = mapped_column(String(30), nullable=False)
    description: Mapped[str] = mapped_column(String(500), nullable=True)
    creation_time: Mapped[datetime] = mapped_column(default=func.now(), nullable=False)

    creation_config_json: Mapped[str] = mapped_column(Text, nullable=False)

    user: Mapped["UserORM"] = relationship(back_populates="kbs")

    docs: Mapped[List["DocInfoORM"]] = relationship(back_populates="kb_info", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint('name', 'tenant_id', 'user_id', name='kb_name_unique'),
    )

    def __repr__(self) -> str:
        return f"KBInfo(id={self.id!r}, name={self.name!r})"

    @classmethod
    def from_pydantic(cls, kb_info: KBInfo, kb_creation_config: KBCreationConfig,
                      user_id: str, tenant_id: str) -> KBInfoORM:
        return KBInfoORM(
            id=kb_info.kb_id,
            tenant_id=tenant_id,
            user_id=user_id,
            name=kb_info.name,
            desciption=kb_info.description,
            creation_time=kb_info.creation_time,
            creation_config_json=kb_creation_config.model_dump_json()
        )

    def to_pydantic(self) -> KBInfo:
        return KBInfo(
            kb_id=self.id,
            name=self.name,
            description=self.description,
            creation_time=self.creation_time
        )


class DocInfoORM(BaseORM):
    __tablename__ = "doc_info"

    # 租户-用户-知识库-文件路径 联合唯一
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenant_account.id"), nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("user_account.id"), nullable=False)
    kb_id: Mapped[str] = mapped_column(ForeignKey("knowledge_base_info.id"), nullable=False)
    file_path: Mapped[str] = mapped_column(VARCHAR(512), nullable=False)

    # doc_id选择uuid，保证全局唯一，但不直接作为主键
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_new_id)

    kb_info: Mapped["KBInfoORM"] = relationship(back_populates="docs")

    doc_parse_config_json: Mapped[str] = mapped_column(Text, nullable=True)

    doc_type: Mapped[DocType] = mapped_column(
        Enum(DocType),
        default=DocType.NORMAL,
        server_default=DocType.NORMAL.value,
        nullable=True
    )

    raw_file_info: Mapped["FileInfoORM"] = relationship(
        "FileInfoORM",
        back_populates="doc_info_raw_file",
        foreign_keys="[FileInfoORM.doc_id_if_raw_doc_file]",
        cascade="all, delete-orphan"
    )
    extra_files_info: Mapped[List["FileInfoORM"]] = relationship(
        "FileInfoORM",
        back_populates="doc_info_extra_files",
        foreign_keys="[FileInfoORM.doc_id_if_extra_file]",
        cascade="all, delete-orphan"
    )

    err_code: Mapped[KBXError.Code] = mapped_column(Enum(KBXError.Code), nullable=False)
    err_msg: Mapped[str] = mapped_column(Text, nullable=True)
    doc_status: Mapped[DocStatus] = mapped_column(Enum(DocStatus), nullable=True)

    __table_args__ = (
        UniqueConstraint('file_path', 'tenant_id', 'user_id', 'kb_id', name='doc_file_path_unique'),
    )

    def __repr__(self) -> str:
        return f"DocInfo(id={self.id!r}, file_path={self.file_path!r})"

    @classmethod
    def from_pydantic(cls, doc_info: DocInfo, kb_id: str, user_id: str, tenant_id: str) -> DocInfoORM:
        return DocInfoORM(
            id=doc_info.doc_id,
            tenant_id=tenant_id,
            user_id=user_id,
            kb_id=kb_id,
            doc_parse_config_json=doc_info.doc_parse_config.model_dump_json() if doc_info.doc_parse_config else "",
            doc_type=doc_info.doc_type,
            file_path=doc_info.raw_file_info.file_path if doc_info.raw_file_info else "",
            err_code=doc_info.err_info.code,
            err_msg=doc_info.err_info.msg,
            doc_status=doc_info.doc_status,
        )

    def to_pydantic(self) -> DocInfo:
        doc_parse_config = None
        if self.doc_parse_config_json:
            doc_parse_config = DocParseConfig(**json.loads(self.doc_parse_config_json))
        return DocInfo(
            doc_id=self.id,
            raw_file_info=self.raw_file_info.to_pydantic(),
            extra_files_info=[efi.to_pydantic() for efi in self.extra_files_info],
            doc_parse_config=doc_parse_config,
            doc_type=self.doc_type,
            err_info=KBXError(code=self.err_code, msg=self.err_msg),
            doc_status=self.doc_status,
        )


class FileInfoORM(BaseORM):
    __tablename__ = "file_info"

    # 添加约束条件，确保doc_id_if_raw_doc_file和doc_id_if_extra_file不能同时有值
    __table_args__ = (
        CheckConstraint(
            '(doc_id_if_raw_doc_file IS NULL OR doc_id_if_extra_file IS NULL) AND '
            '(doc_id_if_raw_doc_file IS NOT NULL OR doc_id_if_extra_file IS NOT NULL)',
            name='only_one_doc_association_allowed'
        ),
        UniqueConstraint('file_path', 'tenant_id', 'user_id', 'kb_id', name='kb_file_path_unique'),
    )

    # 租户-用户-知识库-文件路径 联合唯一
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenant_account.id"), nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("user_account.id"), nullable=False)
    kb_id: Mapped[str] = mapped_column(ForeignKey("knowledge_base_info.id"), nullable=False)
    file_path: Mapped[str] = mapped_column(VARCHAR(512), nullable=False)
    file_raw_path: Mapped[str] = mapped_column(VARCHAR(512), nullable=False)
    file_url: Mapped[str] = mapped_column(VARCHAR(512), nullable=False)

    # file_id选择uuid，保证全局唯一，但不直接作为主键
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_new_id)

    file_size: Mapped[int] = mapped_column(BigInteger, nullable=True)
    upload_date: Mapped[datetime] = mapped_column(default=func.now(), nullable=True)

    doc_id_if_raw_doc_file: Mapped[str] = mapped_column(String(36), ForeignKey("doc_info.id"), nullable=True)
    doc_id_if_extra_file: Mapped[str] = mapped_column(String(36), ForeignKey("doc_info.id"), nullable=True)

    doc_info_raw_file: Mapped[Optional["DocInfoORM"]] = relationship(
        "DocInfoORM",
        back_populates="raw_file_info",
        foreign_keys=[doc_id_if_raw_doc_file]
    )
    doc_info_extra_files: Mapped[Optional["DocInfoORM"]] = relationship(
        "DocInfoORM",
        back_populates="extra_files_info",
        foreign_keys=[doc_id_if_extra_file]
    )

    def __repr__(self) -> str:
        return f"FileInfo(id={self.id!r}, file_path={self.file_path!r})"

    @classmethod
    def from_pydantic(
        cls,
        file_info: FileInfo,
        kb_id: str,
        user_id: str,
        tenant_id: str,
        doc_id_if_raw_doc_file: str = None,
        doc_id_if_extra_file: str = None
    ) -> FileInfoORM:
        return FileInfoORM(
            file_path=file_info.file_path,
            file_raw_path=file_info.file_raw_path,
            file_url=file_info.file_url,
            file_size=file_info.file_size,
            upload_date=file_info.upload_date,
            doc_id_if_raw_doc_file=doc_id_if_raw_doc_file,
            doc_id_if_extra_file=doc_id_if_extra_file,
            user_id=user_id,
            tenant_id=tenant_id,
            kb_id=kb_id,
        )

    def to_pydantic(self) -> FileInfo:
        return FileInfo(
            file_path=self.file_path,
            file_raw_path=self.file_raw_path,
            file_url=self.file_url,
            file_name=os.path.basename(self.file_path),
            file_size=self.file_size,
            upload_date=self.upload_date,
        )


class AIModelConfigORM(BaseORM):
    __tablename__ = 'ai_model_config'

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_new_id)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenant_account.id"))
    user_id: Mapped[str] = mapped_column(ForeignKey("user_account.id"))

    name: Mapped[str] = mapped_column(String(100))
    type: Mapped[str] = mapped_column(String(20))
    backend: Mapped[str] = mapped_column(String(20))
    config_json: Mapped[str] = mapped_column(Text)

    user: Mapped["UserORM"] = relationship(back_populates="ai_model_configs")

    @classmethod
    def from_pydantic(cls, config: BaseAIModelConfig, user_id: str, tenant_id: str) -> AIModelConfigORM:
        return cls(
            name=config.name,
            type=config.type.value,
            backend=config.backend,
            user_id=user_id,
            tenant_id=tenant_id,
            config_json=config.model_dump_json()
        )

    def to_pydantic(self) -> BaseAIModelConfig:
        client_cls = get_ai_model_client_cls(self.backend)
        config_cls = client_cls.config_class()
        return config_cls(**json.loads(self.config_json))


class TableCommentORM(BaseORM):
    """ only used for comment of sqlite implementation """

    __tablename__ = "table_comment_orm"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_new_id)
    kb_id: Mapped[str] = mapped_column(String(36), nullable=False)
    index_type: Mapped[str] = mapped_column(String(20), nullable=False)
    namespace: Mapped[str] = mapped_column(String(20), nullable=False)
    table_name: Mapped[str] = mapped_column(String(64), nullable=False)
    table_comment: Mapped[str] = mapped_column(String(128), nullable=False)
    attr_comment: Mapped[Dict[str, str]] = mapped_column(JSON, nullable=False)

    __table_args__ = (
        UniqueConstraint('kb_id', 'index_type', 'namespace', 'table_name', name='table_name_unique'),
    )

    def __repr__(self) -> str:
        return f"table_comment_orm(id={self.id!r}, kb_id={self.kb_id!r}, " \
               f"index_type={self.index_type}, namespace={self.namespace!r}), table_name={self.table_name!r}"
