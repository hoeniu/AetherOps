"""change doc status COMPLETE to INDEX_SUCCESS

Revision ID: 791a8656db66
Revises: e06be9703d9f
Create Date: 2025-05-21 16:09:34.338954

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from kbx.knowledge_base.types import DocStatus

# revision identifiers, used by Alembic.
revision: str = '791a8656db66'
down_revision: Union[str, None] = 'e06be9703d9f'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 把DocInfoORM中的doc_status从COMPLETE修改为INDEX_SUCCESS
    try:
        op.execute(
            sa.text("""
                UPDATE doc_info 
                SET doc_status = :new_status 
                WHERE doc_status = :old_status
            """).bindparams(
                new_status=DocStatus.INDEX_SUCCESS.value,
                old_status='COMPLETE'
            )
        )
    except Exception as e:
        print(f"Migration failed: {e}")
        raise
    # ### end Alembic commands ###


def downgrade() -> None:
    # 把DocInfoORM中的doc_status从INDEX_SUCCESS修改回COMPLETE
    try:
        op.execute(
            sa.text("""
                UPDATE doc_info 
                SET doc_status = :new_status 
                WHERE doc_status = :old_status
            """).bindparams(
                new_status='COMPLETE',
                old_status=DocStatus.INDEX_SUCCESS.value
            )
        )
    except Exception as e:
        print(f"Rollback failed: {e}")
        raise
    # ### end Alembic commands ###
