from sqlalchemy import create_engine, Engine
from sqlalchemy.orm import sessionmaker, Session
from kbx.db.types import BaseORM


# DB的全局变量
engine: Engine = None
db_session: sessionmaker = None


def init_kbx_db(url: str, pool_size: int = 5, pool_recycle: int = -1, echo: bool = False, **kwargs):
    """用于初始化KBX系统DB的函数

    TODO: 是否需要添加其他用于创建db engine的参数？

    Args:
        url (str): 连接DB的URL
        pool_size (int): 数据库的连接池大小
        pool_recycle (int): 每个连接的默认回收时间，默认-1表示不会超时回收
        echo (bool, optional): 是否打印每次的sql命令执行消息
    """
    global engine, db_session

    if engine is not None:
        raise RuntimeError('DB engine has already been initialized, can not init it again !')

    engine = create_engine(
        url=url,
        pool_size=pool_size,
        pool_recycle=pool_recycle,
        echo=echo,
        **kwargs
    )

    # 创建所有定义的表
    BaseORM.metadata.create_all(engine)

    db_session = sessionmaker(engine)


def close_kbx_db():
    """用于关闭KBX系统DB的函数
    """
    global engine, db_session
    if engine is not None:
        engine.dispose()
        engine = None
        db_session = None


def DBSession() -> Session:
    """获取KBX业务数据库Session对象，之后即可进行各类数据库操作，例如

    ```
    with DBSession() as db:
        db.query(...)
        db.commit()
    ```

    这里函数名大写开头主要是为了模拟Sqlalchemy原版的Session类型调用风格

    Returns:
        Session: 数据库Session对象
    """
    global db_session
    return db_session()
