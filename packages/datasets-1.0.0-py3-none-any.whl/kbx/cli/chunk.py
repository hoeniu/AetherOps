"""KBX CLI chunk commands."""
from kbx.cli.client import KBXClient
from termcolor import colored
import os


def list_chunks(args) -> None:
    """List chunks for a knowledge base."""
    client: KBXClient = args.client
    chunks = client.list_chunks(kb_id=args.kb_id, doc_id=args.doc_id, offset=args.offset, limit=args.limit)['data']

    if len(chunks) == 0:
        print(f'No chunk in knowledge base {colored(args.kb_id, "green")}')
        return

    print(
        f"Listing chunks for KB={colored(args.kb_id, 'green')} doc_id={colored(args.doc_id, 'blue')}"
        f" from {args.offset} to {args.offset + args.limit}"
    )
    for k, chunk in enumerate(chunks):
        index = args.offset + k
        print(f"-------------------------------------------Chunk {index}-------------------------------------------")
        if 'code' in chunk:
            print(f'Get chunk error: {chunk["msg"]}')
        else:
            print(f"chunk_id={colored(chunk['chunk_id'], 'red')}:")
            print("------------------------------------------")
            print(f"text=\"{chunk['text']}\"")
            print("------------------------------------------")
            print(f"meta_data={chunk['meta_data']}")
        print("------------------------------------------------------------------------------------------------")


def setup_chunk_parser(subparsers) -> None:
    """Setup chunk subcommands."""
    parser = subparsers.add_parser("chunk", help="Chunk operations")
    chunk_subparsers = parser.add_subparsers(dest="chunk_command", required=True)

    # List chunks command
    ls_parser = chunk_subparsers.add_parser("ls", help="List chunks")
    ls_parser.add_argument(
        "--kb-id",
        type=str,
        default=os.getenv("KBX_DEFAULT_KB_ID"),
        required='KBX_DEFAULT_KB_ID' not in os.environ,
        help="Knowledge base ID(s). Multiple IDs can be specified with comma separation (e.g., kb_id1,kb_id2,...). "
             "If not provided, KBX_DEFAULT_KB_ID environment variable will be used if set."
    )
    ls_parser.add_argument(
        "--doc-id",
        required=True,
        help="Document ID"
    )
    ls_parser.add_argument("--offset", type=int, default=0, help="Offset for pagination")
    ls_parser.add_argument("--limit", type=int, default=20, help="Limit for pagination")
    ls_parser.set_defaults(func=list_chunks)
