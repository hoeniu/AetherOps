import os
from argparse import Namespace
from kbx.common.constants import DEFAULT_USER_ID
from kbx.common.utils import get_user_id_from_jwt_header, parse_jwt_token
from pathlib import Path

# 保存 token 的文件路径
CONFIG_DIR = Path.home() / ".kbx"
TOKEN_FILE = CONFIG_DIR / "auth_token"


def generate_auth(args: Namespace) -> None:
    """Generate and print a JWT authentication token."""
    token = get_user_id_from_jwt_header(user_id=args.user_id, expires_in=args.expires_in)
    # 确保配置目录存在并保存 token
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(token)
    print(token)


def show_auth_info(args: Namespace) -> None:
    """Parse and print JWT token payload using token from CLI, env or file."""
    import json, os
    # Determine auth token and record its source
    if getattr(args, 'auth_token', None) is not None:
        token = args.auth_token
        source = "CLI flag"
    else:
        env_token = os.getenv("KBX_AUTH_TOKEN", "")
        if env_token:
            token = env_token
            source = "environment variable KBX_AUTH_TOKEN"
        elif TOKEN_FILE.exists():
            token = TOKEN_FILE.read_text().strip()
            source = f"token file {TOKEN_FILE}"
        else:
            print("No token provided. Please via --auth-token, set KBX_AUTH_TOKEN env, or run 'kbx auth generate'.")
            return
    # Show which source provided the token
    print(f"Using token from {source}")
    try:
        claims = parse_jwt_token(token)
        print(json.dumps(claims, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"Invalid token: {e}")


def setup_auth_parser(subparsers) -> None:
    """Setup authentication subcommand for JWT operations."""
    parser = subparsers.add_parser(
        "auth",
        help="JWT authentication operations"
    )
    auth_sub = parser.add_subparsers(dest="auth_command", required=True)
    # generate subcommand
    gen = auth_sub.add_parser(
        "generate", help="Generate JWT authentication token"
    )
    gen.add_argument(
        "--user-id", type=str,
        default=os.getenv("KBX_USER_ID", DEFAULT_USER_ID),
        help="User ID for the token (default from KBX_USER_ID env)"
    )
    gen.add_argument(
        "--expires-in", type=int,
        default=3600,
        help="Token expiration time in seconds (default: 3600)"
    )
    gen.set_defaults(func=generate_auth)
    # info subcommand: 展示已保存的 token 信息
    info = auth_sub.add_parser(
        "info", help="Display saved JWT token payload"
    )
    info.set_defaults(func=show_auth_info)
