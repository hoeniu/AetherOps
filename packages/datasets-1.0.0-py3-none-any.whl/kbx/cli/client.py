"""KBX REST API client."""
from typing import Dict, Any, List, Union, Optional, Literal
import json
import requests
from kbx.common.types import DocData
from kbx.knowledge_base.types import DocInfo, DeepThinkConfig
from kbx.ai_model.types import AIModelType


class KBXClient:
    def __init__(self, server: str, auth_token: str) -> None:
        """初始化KBX客户端，设置服务器连接信息和认证信息。

        Args:
            server (str): KBX服务器地址（主机名或IP）
            auth_token (str): 用于认证的JWT令牌

        Raises:
            requests.exceptions.RequestException: 如果无法连接到KBX服务器
        """
        self.base_url = f"{server}/api/v1"
        if not self.base_url.startswith("http://") and not self.base_url.startswith("https://"):
            self.base_url = f"http://{self.base_url}"
        self.headers = {
            "Authorization": f"Bearer {auth_token}",
            "Content-Type": "application/json",
        }

        # 健康检查
        try:
            response = requests.get(
                f"{self.base_url}/health",
                headers=self.headers
            )
            self._error_handler(response)
        except requests.exceptions.RequestException as e:
            raise requests.exceptions.RequestException(f"Can not connect the KBX server: {self.base_url}") from e

    def _error_handler(self, response: requests.Response) -> None:
        """统一处理HTTP响应错误，解析并抛出详细的错误信息。

        Args:
            response (requests.Response): HTTP响应对象

        Raises:
            requests.exceptions.HTTPError: 当响应状态码表示错误时抛出
            json.JSONDecodeError: 当无法解析响应体为JSON时抛出
        """
        try:
            if not response.ok:
                error_detail = response.json()
                error_msg = f"Request failed with status {response.status_code}\n"
                error_msg += f"{error_detail.get('type', 'Unknown error')}: \"{error_detail.get('details', '')}\"\n"
                if 'traceback' in error_detail:
                    error_msg += f"\nTraceback: {error_detail['traceback']}"
                raise requests.exceptions.HTTPError(error_msg)
        except json.JSONDecodeError:
            # 如果响应不是JSON格式，使用默认的错误处理
            response.raise_for_status()

    def create_kb(self, config: Dict[str, Any], desired_kb_id: str = None) -> Dict[str, Any]:
        """创建一个新的知识库。

        Args:
            config (Dict[str, Any]): 知识库创建配置，包含知识库名称、描述等信息，对应KBCreationConfig数据结构
            desired_kb_id (str): 期望的知识库ID，如果为None，则由服务端自动生成

        Returns:
            Dict[str, Any]: 包含新创建知识库详细信息的字典，包括知识库ID、名称等

        Raises:
            requests.exceptions.HTTPError: 如果创建请求失败
        """
        response = requests.post(
            f"{self.base_url}/create_kb",
            json=config,
            params={
                "desired_kb_id": desired_kb_id,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def list_kbs(self) -> Dict[str, Union[int, List[Dict[str, Any]]]]:
        """获取当前用户的所有知识库列表。

        Returns:
            Dict[str, Union[int, List[Dict[str, Any]]]]: 包含知识库总数和知识库列表的字典

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/list_kbs",
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def get_kb_detail(self, kb_id: str) -> Dict[str, Any]:
        """获取指定知识库的详细信息。

        Args:
            kb_id (str): 要查询的知识库ID

        Returns:
            Dict[str, Any]: 包含知识库详细信息的字典，包括配置、状态等

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/kb_detail",
            params={
                "kb_id": kb_id,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def remove_kb(self, kb_id: str) -> Dict[str, Any]:
        """删除指定的知识库。

        Args:
            kb_id (str): 要删除的知识库ID

        Returns:
            Dict[str, Any]: 包含删除操作状态的字典

        Raises:
            requests.exceptions.HTTPError: 如果删除请求失败
        """
        response = requests.post(
            f"{self.base_url}/remove_kb",
            params={
                "kb_id": kb_id,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def update_kb(self, kb_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """更新指定知识库的配置。

        Args:
            kb_id (str): 要更新的知识库ID
            config (Dict[str, Any]): 新的知识库配置，对应KBCreationConfig数据结构

        Returns:
            Dict[str, Any]: 包含更新后知识库详细信息的字典

        Raises:
            requests.exceptions.HTTPError: 如果更新请求失败
        """
        response = requests.post(
            f"{self.base_url}/modify_kb_config",
            json=config,
            params={
                "kb_id": kb_id,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def insert_doc(self, kb_id: str, file_path: str, save_dir: str = '') -> DocInfo:
        """将文档插入到指定的知识库中。

        Args:
            kb_id (str): 要插入文档的知识库ID
            file_path (str): 要插入的文档文件路径
            save_dir (str): 文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下

        Returns:
            DocInfo: 包含文档详细信息的对象，对应DocInfo数据结构
        """
        # headers 去掉"Content-Type": "application/json"
        # 因为文件上传时需要使用 multipart/form-data
        headers = {k: v for k, v in self.headers.items() if k != "Content-Type"}
        response = requests.post(
            f"{self.base_url}/docs/{kb_id}",
            params={
                "save_dir": save_dir,
            },
            files={"files": open(file_path, "rb")},
            headers=headers
        )
        self._error_handler(response)
        data = response.json()
        # 如果返回的是列表，则取第一个元素
        if isinstance(data, list):
            if not data:
                raise ValueError("上传后返回的文档信息列表为空")
            data = data[0]
        return DocInfo(**data)

    def insert_docs_folder(
        self,
        kb_id: str,
        folder_path: str,
        recursive: bool = True,
        include_patterns: List[str] = [],
        exclude_patterns: List[str] = [],
        max_files_per_batch: int = 20,
        save_dir: str = '',
    ) -> Dict[str, Any]:
        """将指定文件夹中的文档插入到指定的知识库中。

        Args:
            kb_id (str): 要插入文档的知识库ID
            folder_path (str): 要插入文档的文件夹路径
            recursive (bool): 是否递归处理子文件夹，默认为True
            include_patterns (List[str]): 要包含的文件匹配模式列表，支持通配符，如['*.md', 'docs/*.pdf', 'api/**/*.txt']
            exclude_patterns (List[str]): 要排除的文件匹配模式列表，支持通配符，如['*.tmp', 'temp/*', '**/draft_*']
            max_files_per_batch (int): 每批处理的最大文件数，默认为20
            save_dir (str): 文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下

        Returns:
            Dict[str, Any]: 包含插入结果的字典
        """
        response = requests.post(
            f"{self.base_url}/insert_docs_folder",
            json={
                "kb_id": kb_id,
                "folder_path": folder_path,
                "recursive": recursive,
                "include_patterns": include_patterns,
                "exclude_patterns": exclude_patterns,
                "max_files_per_batch": max_files_per_batch,
                "save_dir": save_dir,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def list_docs(self, kb_id: str, offset: int = 0, limit: int = 20) -> List[Dict[str, Any]]:
        """获取指定知识库中的文档列表。

        Args:
            kb_id (str): 要查询的知识库ID
            offset (int): 分页偏移量，默认从0开始
            limit (int): 每页最大返回数量，默认为20

        Returns:
            List[Dict[str, Any]]: 包含文档信息的字典列表

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/docs_info",
            params={
                "kb_id": kb_id,
                "offset": offset,
                "limit": limit
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def list_chunks(self, kb_id: str, doc_id: str, offset: int = 0, limit: int = 20) -> List[Dict[str, Any]]:
        """获取指定知识库中的文档列表。
        Args:
            kb_id (str): 要查询的知识库ID
            offset (int): 分页偏移量，默认从0开始
            limit (int): 每页最大返回数量，默认为20
        Returns:
            List[Dict[str, Any]]: 包含文档信息的字典列表
        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/list_chunks",
            params={
                "kb_id": kb_id,
                "doc_id": doc_id,
                "offset": offset,
                "limit": limit
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def remove_docs(self, kb_id: str, doc_ids: List[str]) -> Dict[str, Any]:
        """从指定知识库中删除多个文档。

        Args:
            kb_id (str): 要删除文档的知识库ID
            doc_ids (List[str]): 要删除的文档ID列表

        Returns:
            Dict[str, Any]: 包含删除操作状态的字典

        Raises:
            requests.exceptions.HTTPError: 如果删除请求失败
        """
        response = requests.post(
            f"{self.base_url}/remove_docs",
            params={
                "kb_id": kb_id,
                "doc_ids": doc_ids,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def get_doc_data(self, kb_id: str, doc_id: str) -> DocData:
        """获取指定文档的内容数据。

        Args:
            kb_id (str): 文档所在的知识库ID
            doc_id (str): 要获取内容的文档ID

        Returns:
            DocData: 包含文档内容数据的对象

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/doc_data",
            params={
                "kb_id": kb_id,
                "doc_id": doc_id,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return DocData(**response.json())

    def get_doc_info(self, kb_id: str, doc_id: str) -> Dict[str, Any]:
        """获取指定文档的详细信息。

        Args:
            kb_id (str): 文档所在的知识库ID
            doc_id (str): 要获取信息的文档ID

        Returns:
            Dict[str, Any]: 包含文档详细信息的字典，对应DocInfo数据结构

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/doc_info",
            params={
                "kb_id": kb_id,
                "doc_id": doc_id
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def register_ai_models(self, model_configs: List[Dict], overwrite: bool = False) -> Dict[str, Any]:
        """注册一个或多个AI模型配置。

        Args:
            model_configs (List[Dict]): 模型配置列表
            overwrite (bool): 是否覆盖已存在的模型配置，默认为False

        Returns:
            Dict[str, Any]: 包含操作结果的字典

        Raises:
            requests.exceptions.HTTPError: 如果注册请求失败
        """
        response = requests.post(
            f"{self.base_url}/register_ai_models",
            json={
                "configs": model_configs,
                "overwrite": overwrite,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def list_ai_models(self, type: Optional[AIModelType] = None,
                       backend: Literal["openai", "volcengine", "tongyi", "jina"] = None
                       ) -> Dict[str, Union[int, List[Dict]]]:
        """获取当前用户所有已注册的AI模型数量及列表，支持通过type参数指定模型类型进行过滤。

        Returns:
            Dict[str, Union[int, List[Dict]]]: 包含模型数量以及模型名称、模型backend和模型type的列表

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/list_ai_models",
            headers=self.headers,
            params={
                "type": type,
                "backend": backend
            }
        )
        self._error_handler(response)
        return response.json()

    def delete_ai_model(self, name: str) -> Dict[str, Any]:
        """删除指定的AI模型。

        Args:
            name (str): 要删除的模型名称

        Returns:
            Dict[str, Any]: 包含删除操作结果的字典

        Raises:
            requests.exceptions.HTTPError: 如果删除请求失败
        """
        response = requests.post(
            f"{self.base_url}/delete_ai_model",
            params={
                "name": name,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def get_ai_model_detail(self, name: str) -> Dict[str, Any]:
        """获取指定AI模型的详细配置信息。

        Args:
            name (str): 要查询的模型名称

        Returns:
            Dict[str, Any]: 包含模型详细配置信息的字典

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/ai_model_detail",
            params={
                "name": name,
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()

    def embedding_score(self, text1: str, text2: str, model: str) -> float:
        """计算两个文本在指定模型下的embedding相似度。

        Args:
            text1 (str): 第一个文本
            text2 (str): 第二个文本
            model (str): 使用的embedding模型名称

        Returns:
            float: 两个文本的相似度分数，范围[-1, 1]

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.post(
            f"{self.base_url}/embedding_score",
            json={
                "text1": text1,
                "text2": text2,
                "model": model
            },
            headers=self.headers
        )
        self._error_handler(response)
        return response.json()["score"]

    def query_kb(
        self,
        kb_ids: Union[str, List[str]],
        query: str,
        top_k: int = 3,
        score_threshold: float = 0.0,
        stream: bool = False,
        max_tokens: int = 32 * 1024,
        keyword_similarity_weight: float = 0.0,
        deep_think: Optional[DeepThinkConfig] = None,
    ) -> List[Dict[str, Any]]:
        """在指定知识库中执行查询。

        Args:
            kb_ids (Union[str, List[str]]): 要查询的知识库ID或ID列表
            query (str): 查询字符串
            top_k (int): 返回结果的最大数量，默认为3
            score_threshold (float): 结果分数阈值，默认为0.0
            max_tokens (int): 结果内容上限，默认为32 * 1024
            keyword_similarity_weight (float): 关键词相似度权重，默认为0.0
            deep_think (Optional[DeepThinkConfig]): 深度思考智能体配置，默认为None
        Returns:
            List[Dict[str, Any]]: 包含查询结果的字典列表，每个字典对应一个匹配的文档片段

        Raises:
            requests.exceptions.HTTPError: 如果查询请求失败
        """
        if isinstance(kb_ids, str):
            kb_ids = [kb_ids]
        response = requests.post(
            f"{self.base_url}/retrieval",
            json={
                "text": query,
                "top_k": top_k,
                "score_threshold": score_threshold,
                "stream": stream,
                "vector_dynamic_kwargs": {
                    "keyword_similarity_weight": keyword_similarity_weight,
                },
                "max_tokens": max_tokens,
                "deep_think": deep_think.model_dump() if deep_think else None
            },
            params={
                "kb_ids": kb_ids,
            },
            headers=self.headers,
            stream=stream
        )

        self._error_handler(response)
        return response if stream else response.json()

    def create_tenant(self, name: str, desired_tenant_id: str = None) -> str:
        """创建一个新的租户。

        Args:
            name (str): 租户名称
            desired_tenant_id (str): 期望的租户ID，如果为None则由服务端自动生成

        Returns:
            str: 新创建的租户ID

        Raises:
            requests.exceptions.HTTPError: 如果创建请求失败
        """
        response = requests.post(
            f"{self.base_url}/tenants/",
            json={
                "name": name,
                "desired_tenant_id": desired_tenant_id
            }
        )
        self._error_handler(response)
        return response.json()

    def list_tenants(self, offset: int = 0, limit: int = 20) -> List[Dict[str, Any]]:
        """获取租户列表。

        Returns:
            List[Dict[str, Any]]: 租户列表，每个租户包含id和name字段

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/tenants/",
            params={
                "offset": offset,
                "limit": limit
            }
        )
        self._error_handler(response)
        return response.json()

    def get_tenant(self, tenant_id: str) -> Dict[str, Any]:
        """获取指定租户的详细信息。

        Args:
            tenant_id (str): 要查询的租户ID

        Returns:
            Dict[str, Any]: 包含租户id和name的字典

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/tenants/{tenant_id}"
        )
        self._error_handler(response)
        return response.json()

    def update_tenant(self, tenant_id: str, name: str) -> Dict[str, Any]:
        """更新指定租户的信息。

        Args:
            tenant_id (str): 要更新的租户ID
            name (str): 新的租户名称

        Returns:
            Dict[str, Any]: 更新后的租户信息，包含id和name字段

        Raises:
            requests.exceptions.HTTPError: 如果更新请求失败
        """
        response = requests.put(
            f"{self.base_url}/tenants/{tenant_id}",
            json={
                "name": name
            }
        )
        self._error_handler(response)
        return response.json()

    def delete_tenant(self, tenant_id: str) -> None:
        """删除指定的租户。

        Args:
            tenant_id (str): 要删除的租户ID

        Raises:
            requests.exceptions.HTTPError: 如果删除请求失败
        """
        response = requests.delete(
            f"{self.base_url}/tenants/{tenant_id}"
        )
        self._error_handler(response)

    def create_user(self, tenant_id: str, name: str, desired_user_id: str = None) -> str:
        """创建一个新的用户。

        Args:
            tenant_id (str): 所属租户ID
            name (str): 用户名称
            desired_user_id (str): 期望的用户ID，如果为None则由服务端自动生成

        Returns:
            str: 新创建的用户ID

        Raises:
            requests.exceptions.HTTPError: 如果创建请求失败
        """
        response = requests.post(
            f"{self.base_url}/tenants/{tenant_id}/users/",
            json={
                "name": name,
                "desired_user_id": desired_user_id
            }
        )
        self._error_handler(response)
        return response.json()

    def list_users(self, tenant_id: str, offset: int = 0, limit: int = 20) -> List[Dict[str, Any]]:
        """获取指定租户下的用户列表。

        Args:
            tenant_id (str): 租户ID

        Returns:
            List[Dict[str, Any]]: 用户列表，每个用户包含id、name和tenant_id字段

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/tenants/{tenant_id}/users/",
            params={
                "offset": offset,
                "limit": limit
            }
        )
        self._error_handler(response)
        return response.json()

    def get_user(self, tenant_id: str, user_id: str) -> Dict[str, Any]:
        """获取指定用户的详细信息。

        Args:
            tenant_id (str): 用户所属的租户ID
            user_id (str): 要查询的用户ID

        Returns:
            Dict[str, Any]: 包含用户id、name和tenant_id的字典

        Raises:
            requests.exceptions.HTTPError: 如果请求失败
        """
        response = requests.get(
            f"{self.base_url}/tenants/{tenant_id}/users/{user_id}"
        )
        self._error_handler(response)
        return response.json()

    def update_user(self, tenant_id: str, user_id: str, name: str) -> Dict[str, Any]:
        """更新指定用户的信息。

        Args:
            tenant_id (str): 用户所属的租户ID
            user_id (str): 要更新的用户ID
            name (str): 新的用户名称

        Returns:
            Dict[str, Any]: 更新后的用户信息，包含id、name和tenant_id字段

        Raises:
            requests.exceptions.HTTPError: 如果更新请求失败
        """
        response = requests.put(
            f"{self.base_url}/tenants/{tenant_id}/users/{user_id}",
            json={
                "name": name
            }
        )
        self._error_handler(response)
        return response.json()

    def delete_user(self, tenant_id: str, user_id: str) -> None:
        """删除指定的用户。

        Args:
            tenant_id (str): 用户所属的租户ID
            user_id (str): 要删除的用户ID

        Raises:
            requests.exceptions.HTTPError: 如果删除请求失败
        """
        response = requests.delete(
            f"{self.base_url}/tenants/{tenant_id}/users/{user_id}"
        )
        self._error_handler(response)

    def reindex(self,
                kb_id: str,
                doc_ids: List[str],
                reparse: bool = False) -> str:
        """重新构建某个知识库的索引

        Args:
            kb_id (str): 知识库ID
            doc_ids (List[str]): 构建索引的id列表
            reparse (bool, optional): 是否重新解析文档

        Returns:
            str: 重构索引的结果信息
        """
        response = requests.post(
            f"{self.base_url}/reindex",
            params={
                "kb_id": kb_id,
                "doc_ids": doc_ids,
                "reparse": reparse,
            },
            headers=self.headers,
        )
        self._error_handler(response)
        return response.json()
