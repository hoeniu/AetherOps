"""Document management commands."""
import os
from typing import Dict, List
from argparse import Namespace
import requests
from kbx.common.utils import doc_data_to_markdown, toc_tree_to_string
from kbx.common.types import KBXError
from kbx.knowledge_base.types import DocInfo
from termcolor import colored


def add_doc(args: Namespace):
    """Add single document file or folder to knowledge base."""
    if os.path.isdir(args.path):
        add_docs_folder(args)
    else:
        add_single_doc(args)


def add_single_doc(args: Namespace):
    """Add document to knowledge base."""
    if not os.path.isfile(args.path):
        raise RuntimeError(f"File {args.path} does not exist")
    print(f"Adding document {args.path} to knowledge base {args.kb_id}")
    try:
        doc_info: DocInfo = args.client.insert_doc(
            kb_id=args.kb_id,
            file_path=os.path.abspath(args.path),
            save_dir=args.save_dir
        )
        if doc_info.err_info.code != KBXError.Code.SUCCESS:
            print(f"Failed to add document: {doc_info.err_info.msg}")
            return
        doc_id_str = colored(doc_info.doc_id, "blue")
        print(f'Added document: "{doc_id_str}"')
        print(f'file_path: "{doc_info.raw_file_info.file_path}"')
        print(f'file_size: {doc_info.raw_file_info.file_size}')
        print(f'upload_date: {doc_info.raw_file_info.upload_date}')
        print(f'status: {doc_info.doc_status}')
    except requests.exceptions.RequestException as e:
        print(f"Failed to add document: {str(e)}")


def add_docs_folder(args: Namespace):
    """Add documents from folder to knowledge base."""
    if not os.path.isdir(args.path):
        raise RuntimeError(f"Folder {args.path} does not exist")
    print(f"Adding documents from folder {args.path} to knowledge base {args.kb_id}")
    try:
        include_patterns = args.include_patterns.split(',') if args.include_patterns else []
        exclude_patterns = args.exclude_patterns.split(',') if args.exclude_patterns else []
        print(
            f'Try to insert docs folder "{args.path}" (recursive={args.recursive}) with '
            f'include_patterns {include_patterns} and exclude_patterns {exclude_patterns}'
        )
        rets: Dict[str, Dict[str, List[Dict]]] = args.client.insert_docs_folder(
            kb_id=args.kb_id,
            folder_path=os.path.abspath(args.path),
            recursive=args.recursive,
            save_dir=args.save_dir,
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
            max_files_per_batch=args.max_files_per_batch
        )
        for rel_path, doc_infos in rets.items():
            print('-------------------------------------------------------------------')
            print(f'Added documents from folder "{rel_path}":')
            for doc_info in doc_infos:
                print('--------------------------------')
                doc_id_str = colored(doc_info["doc_id"], "blue")
                print(f'Added document: "{doc_id_str}"')
                print(f'file_path: "{doc_info["raw_file_info"]["file_path"]}"')
                print(f'file_size: {doc_info["raw_file_info"]["file_size"]}')
                print(f'upload_date: {doc_info["raw_file_info"]["upload_date"]}')
                print(f'status: {doc_info["doc_status"]}')
            print('-------------------------------------------------------------------')
    except requests.exceptions.RequestException as e:
        print(f"Failed to add documents from folder: {str(e)}")


def list_docs(args: Namespace):
    """List documents in knowledge base."""
    try:
        docs_info = args.client.list_docs(kb_id=args.kb_id, offset=args.offset, limit=args.limit)['data']
        kb_id_str = colored(args.kb_id, "green")
        if len(docs_info) == 0:
            print(f'No document in knowledge base {kb_id_str}')
            return
        print(
            f"Listing documents in knowledge base {kb_id_str} "
            f"from {args.offset} to {min(args.limit, len(docs_info) + args.offset)}"
        )
        print("-------------------------------------------------------------------")
        for doc_info in docs_info:
            doc_id_str = colored(doc_info["doc_id"], "blue")
            print(f'doc_id: "{doc_id_str}"')
            print(f'\tfile_name: "{doc_info["raw_file_info"]["file_name"]}"')
            print(f'\tfile_size: {doc_info["raw_file_info"]["file_size"]}')
            print(f'\tfile_raw_path: "{doc_info["raw_file_info"]["file_raw_path"]}"')
            print(f'\tfile_url: "{doc_info["raw_file_info"]["file_url"]}"')
            print(f'\tupload_date: {doc_info["raw_file_info"]["upload_date"]}')
            print(f'\tstatus: {doc_info["doc_status"]}')
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to get knowledge base detail: {str(e)}")


def remove_doc(args: Namespace):
    """Remove one or more documents from knowledge base."""
    try:
        # Split doc_ids by comma and strip whitespace
        doc_ids = [doc_id.strip() for doc_id in args.doc_id.split(',')]

        for doc_id in doc_ids:
            try:
                result = args.client.remove_docs(kb_id=args.kb_id, doc_ids=[doc_id])
                print(f"Removed document {colored(doc_id, 'blue')}: {result}")
            except requests.exceptions.RequestException as e:
                print(f"Failed to remove document {colored(doc_id, 'red')}: {str(e)}")
                continue
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def show_doc(args: Namespace):
    """Show document content."""
    print(
        f"Showing content of document {colored(args.doc_id, 'blue')} "
        f"in knowledge base {colored(args.kb_id, 'green')}"
    )
    try:
        doc_data = args.client.get_doc_data(kb_id=args.kb_id, doc_id=args.doc_id)
        print(f'file_path: "{doc_data.file_path}"')
        print(f'file_raw_path: "{doc_data.file_raw_path}"')
        print(f'file_url: "{doc_data.file_url}"')
        print(f'summary: "{doc_data.doc_toc.summary}"')
        print('------------------------- file content -------------------------')
        if args.format == 'raw':
            print(doc_data.doc_elements)
        else:
            print(doc_data_to_markdown(doc_data, mode="summary", prepend_file_name=False))
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to get document data: {str(e)}")


def toc_doc(args: Namespace):
    """Show document toc."""
    print(
        f"Showing toc of document {colored(args.doc_id, 'blue')} "
        f"in knowledge base {colored(args.kb_id, 'green')}"
    )
    try:
        doc_data = args.client.get_doc_data(kb_id=args.kb_id, doc_id=args.doc_id)
        print(f'file_name: "{doc_data.file_name}"')
        print('------------------------- TOC -------------------------')
        if doc_data.doc_toc:
            print(toc_tree_to_string(doc_data.doc_toc))
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to get document data: {str(e)}")


def setup_doc_parser(subparsers):
    """Setup document subcommands."""
    parser = subparsers.add_parser("doc", help="Document management")
    doc_subparsers = parser.add_subparsers(dest="doc_command", required=True)

    # Add command
    add_parser = doc_subparsers.add_parser("add", help="Add document to knowledge base")
    add_parser.add_argument(
        "--kb-id",
        type=str,
        default=os.getenv("KBX_DEFAULT_KB_ID"),
        required='KBX_DEFAULT_KB_ID' not in os.environ,
        help="Knowledge base ID(s). Multiple IDs can be specified with comma separation (e.g., kb_id1,kb_id2,...). "
             "If not provided, KBX_DEFAULT_KB_ID environment variable will be used if set."
    )
    add_parser.add_argument("--path", required=True, help="Path to document file")
    add_parser.add_argument("--save-dir", type=str, default='', help="Save directory for document")
    add_parser.add_argument(
        "--recursive",
        type=lambda x: x.lower() == 'true',
        choices=[True, False],
        default=True,
        help="Recursive for folder insert, true or false"
    )
    add_parser.add_argument(
        "--include-patterns",
        type=str,
        default='',
        help=(
            "Include patterns for document, use \",\" to separate "
            "multiple patterns. Only works when --path is a folder"
        )
    )
    add_parser.add_argument(
        "--exclude-patterns",
        type=str,
        default='',
        help=(
            "Exclude patterns for document, use \",\" to separate "
            "multiple patterns. Only works when --path is a folder"
        )
    )
    add_parser.add_argument("--max-files-per-batch", type=int, default=20, help="Max files per batch")
    add_parser.set_defaults(func=add_doc)

    # List command
    list_parser = doc_subparsers.add_parser("ls", help="List documents in knowledge base")
    list_parser.add_argument(
        "--kb-id",
        type=str,
        default=os.getenv("KBX_DEFAULT_KB_ID"),
        required='KBX_DEFAULT_KB_ID' not in os.environ,
        help="Knowledge base ID(s). Multiple IDs can be specified with comma separation (e.g., kb_id1,kb_id2,...). "
             "If not provided, KBX_DEFAULT_KB_ID environment variable will be used if set."
    )
    list_parser.add_argument("--offset", type=int, default=0, help="Offset for pagination")
    list_parser.add_argument("--limit", type=int, default=20, help="Limit for pagination")
    list_parser.set_defaults(func=list_docs)

    # Remove command
    remove_parser = doc_subparsers.add_parser("rm", help="Remove document from knowledge base")
    remove_parser.add_argument(
        "--kb-id",
        type=str,
        default=os.getenv("KBX_DEFAULT_KB_ID"),
        required='KBX_DEFAULT_KB_ID' not in os.environ,
        help="Knowledge base ID(s). Multiple IDs can be specified with comma separation (e.g., kb_id1,kb_id2,...). "
             "If not provided, KBX_DEFAULT_KB_ID environment variable will be used if set."
    )
    remove_parser.add_argument("--doc-id", required=True, help="Document ID, use \",\" to separate multiple IDs")
    remove_parser.set_defaults(func=remove_doc)

    # Show command
    show_parser = doc_subparsers.add_parser("show", help="Show document content")
    show_parser.add_argument(
        "--kb-id",
        type=str,
        default=os.getenv("KBX_DEFAULT_KB_ID"),
        required='KBX_DEFAULT_KB_ID' not in os.environ,
        help="Knowledge base ID(s). Multiple IDs can be specified with comma separation (e.g., kb_id1,kb_id2,...). "
             "If not provided, KBX_DEFAULT_KB_ID environment variable will be used if set."
    )
    show_parser.add_argument("--doc-id", required=True, help="Document ID")
    show_parser.add_argument(
        "--format",
        choices=['raw', 'md'],
        default='md',
        help="Output format for document content (raw or md)"
    )
    show_parser.set_defaults(func=show_doc)

    # Toc command
    toc_parser = doc_subparsers.add_parser("toc", help="Show document toc")
    toc_parser.add_argument("--kb-id", required=True, help="Knowledge base ID")
    toc_parser.add_argument("--doc-id", required=True, help="Document ID")
    toc_parser.set_defaults(func=toc_doc)
