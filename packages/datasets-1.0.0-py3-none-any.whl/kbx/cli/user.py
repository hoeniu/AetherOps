"""User management commands."""
import requests
from argparse import Namespace
from termcolor import colored


def create_user(args: Namespace) -> None:
    """Create a new user."""
    try:
        result = args.client.create_user(
            tenant_id=args.tenant_id,
            name=args.name,
            desired_user_id=args.desired_user_id
        )
        print(f"Created user: {colored(result, 'green')}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to create user: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def list_users(args: Namespace) -> None:
    """List all users in a tenant."""
    try:
        users = args.client.list_users(tenant_id=args.tenant_id, offset=args.offset, limit=args.limit)
        if len(users) == 0:
            print("No users found.")
            return

        print('Listing all users:')
        print("-------------------------------------------------------------------")
        for user in users:
            print(f"{colored(user['id'], 'green')}: \"{user['name']}\"")
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to list users: {str(e)}")


def remove_user(args: Namespace) -> None:
    """Remove one or more users."""
    try:
        # Split user_ids by comma and strip whitespace
        user_ids = [user_id.strip() for user_id in args.user_id.split(',')]

        for user_id in user_ids:
            try:
                args.client.delete_user(tenant_id=args.tenant_id, user_id=user_id)
                print(f"Removed user: {colored(user_id, 'green')}")
            except requests.exceptions.RequestException as e:
                print(f"Failed to remove user {colored(user_id, 'red')}: {str(e)}")
                continue
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def show_user_info(args: Namespace) -> None:
    """Show user information."""
    try:
        detail = args.client.get_user(tenant_id=args.tenant_id, user_id=args.user_id)
        print(f"user_id: {colored(detail['id'], 'green')}")
        print(f"tenant_id: {colored(detail['id'], 'yellow')}")
        print(f"name: {colored(detail['name'], 'yellow')}")
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to get user detail: {str(e)}")


def update_user(args: Namespace) -> None:
    """Update user information."""
    try:
        result = args.client.update_user(user_id=args.user_id, name=args.name)
        print(f"Updated user: {colored(result['user_id'], 'green')}")
        print(f"New name: {colored(result['name'], 'yellow')}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to update user: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def setup_user_parser(subparsers) -> None:
    """Setup user subcommands."""
    parser = subparsers.add_parser("user", help="User management")
    user_subparsers = parser.add_subparsers(dest="user_command", required=True)

    # Create command
    create_parser = user_subparsers.add_parser("create", help="Create a new user")
    create_parser.add_argument("--tenant-id", required=True, help="Tenant ID")
    create_parser.add_argument("--name", required=True, help="User name")
    create_parser.add_argument(
        "--desired-user-id",
        type=str,
        default='',
        help="Desired user ID. If not provided, the server will automatically generate one."
    )
    create_parser.set_defaults(func=create_user)

    # List command
    list_parser = user_subparsers.add_parser("ls", help="List all users in a tenant")
    list_parser.add_argument("--tenant-id", required=True, help="Tenant ID")
    list_parser.add_argument(
        "--offset",
        type=int,
        default=0,
        help="Offset for pagination"
    )
    list_parser.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Limit for pagination"
    )
    list_parser.set_defaults(func=list_users)

    # Remove command
    remove_parser = user_subparsers.add_parser("rm", help="Remove one or more users")
    remove_parser.add_argument("--tenant-id", required=True, help="Tenant ID")
    remove_parser.add_argument(
        "--user-id",
        type=str,
        required=True,
        help="User ID(s). Multiple IDs can be specified with comma separation (e.g., user_id1,user_id2,...)."
    )
    remove_parser.set_defaults(func=remove_user)

    # Info command
    info_parser = user_subparsers.add_parser("info", help="Show user information")
    info_parser.add_argument("--tenant-id", required=True, help="Tenant ID")
    info_parser.add_argument("--user-id", required=True, help="User ID")
    info_parser.set_defaults(func=show_user_info)

    # Update command
    update_parser = user_subparsers.add_parser("update", help="Update user information")
    update_parser.add_argument("--user-id", required=True, help="User ID")
    update_parser.add_argument("--name", required=True, help="New user name")
    update_parser.set_defaults(func=update_user)
