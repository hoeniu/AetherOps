"""Tenant management commands."""
import requests
from argparse import Namespace
from termcolor import colored


def create_tenant(args: Namespace) -> None:
    """Create a new tenant."""
    try:
        result = args.client.create_tenant(
            name=args.name,
            desired_tenant_id=args.desired_tenant_id if args.desired_tenant_id else None
        )
        print(f"Created tenant: {colored(result, 'green')}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to create tenant: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def list_tenants(args: Namespace) -> None:
    """List all tenants."""
    try:
        tenants = args.client.list_tenants(offset=args.offset, limit=args.limit)
        if len(tenants) == 0:
            print("No tenants found.")
            return

        print('Listing all tenants:')
        print("-------------------------------------------------------------------")
        for tenant in tenants:
            print(f"{colored(tenant['id'], 'green')}: \"{tenant['name']}\"")
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to list tenants: {str(e)}")


def remove_tenant(args: Namespace) -> None:
    """Remove one or more tenants."""
    try:
        # Split tenant_ids by comma and strip whitespace
        tenant_ids = [tenant_id.strip() for tenant_id in args.tenant_id.split(',')]

        for tenant_id in tenant_ids:
            try:
                args.client.delete_tenant(tenant_id)
                print(f"Removed tenant: {colored(tenant_id, 'green')}")
            except requests.exceptions.RequestException as e:
                print(f"Failed to remove tenant {colored(tenant_id, 'red')}: {str(e)}")
                continue
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def show_tenant_info(args: Namespace) -> None:
    """Show tenant information."""
    try:
        detail = args.client.get_tenant(tenant_id=args.tenant_id)
        print(f"tenant_id: {colored(detail['id'], 'green')}")
        print(f"name: {colored(detail['name'], 'yellow')}")
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to get tenant detail: {str(e)}")


def update_tenant(args: Namespace) -> None:
    """Update tenant information."""
    try:
        result = args.client.update_tenant(tenant_id=args.tenant_id, name=args.name)
        print(f"Updated tenant: {colored(result['id'], 'green')}")
        print(f"New name: {colored(result['name'], 'yellow')}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to update tenant: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def setup_tenant_parser(subparsers) -> None:
    """Setup tenant subcommands."""
    parser = subparsers.add_parser("tenant", help="Tenant management")
    tenant_subparsers = parser.add_subparsers(dest="tenant_command", required=True)

    # Create command
    create_parser = tenant_subparsers.add_parser("create", help="Create a new tenant")
    create_parser.add_argument("--name", required=True, help="Tenant name")
    create_parser.add_argument(
        "--desired-tenant-id",
        type=str,
        default='',
        help="Desired tenant ID. If not provided, the server will automatically generate one."
    )
    create_parser.set_defaults(func=create_tenant)

    # List command
    list_parser = tenant_subparsers.add_parser("ls", help="List all tenants")
    list_parser.add_argument(
        "--offset",
        type=int,
        default=0,
        help="Offset for pagination"
    )
    list_parser.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Limit for pagination"
    )
    list_parser.set_defaults(func=list_tenants)

    # Remove command
    remove_parser = tenant_subparsers.add_parser("rm", help="Remove one or more tenants")
    remove_parser.add_argument(
        "--tenant-id",
        type=str,
        required=True,
        help="Tenant ID(s). Multiple IDs can be specified with comma separation (e.g., tenant_id1,tenant_id2,...)."
    )
    remove_parser.set_defaults(func=remove_tenant)

    # Info command
    info_parser = tenant_subparsers.add_parser("info", help="Show tenant information")
    info_parser.add_argument(
        "--tenant-id",
        type=str,
        required=True,
        help="Tenant ID"
    )
    info_parser.set_defaults(func=show_tenant_info)

    # Update command
    update_parser = tenant_subparsers.add_parser("update", help="Update tenant information")
    update_parser.add_argument(
        "--tenant-id",
        type=str,
        required=True,
        help="Tenant ID"
    )
    update_parser.add_argument(
        "--name",
        type=str,
        required=True,
        help="New tenant name"
    )
    update_parser.set_defaults(func=update_tenant)
