"""KBX CLI main entry point."""
import argparse
import os
from pathlib import Path
from kbx.cli.client import KBXClient
from kbx.version import __version__


def main() -> None:
    parser = argparse.ArgumentParser(description="KBX command line interface")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show program's version number and exit"
    )
    parser.add_argument(
        "--auth-token",
        default=os.getenv("KBX_AUTH_TOKEN", None),
        help="Authentication token (CLI > KBX_AUTH_TOKEN > ~/.kbx/auth_token)"
    )
    parser.add_argument(
        "--server",
        default=os.getenv("KBX_SERVER", "127.0.0.1:30018"),
        help="KBX backend server address (default: 127.0.0.1:30018)"
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # Import and setup subcommands
    from kbx.cli.kb import setup_kb_parser
    setup_kb_parser(subparsers)

    from kbx.cli.doc import setup_doc_parser
    setup_doc_parser(subparsers)

    from kbx.cli.query import setup_query_parser
    setup_query_parser(subparsers)

    from kbx.cli.chunk import setup_chunk_parser
    setup_chunk_parser(subparsers)

    from kbx.cli.model import setup_model_parser
    setup_model_parser(subparsers)

    from kbx.cli.auth import setup_auth_parser
    setup_auth_parser(subparsers)

    from kbx.cli.tenant import setup_tenant_parser
    setup_tenant_parser(subparsers)

    from kbx.cli.user import setup_user_parser
    setup_user_parser(subparsers)

    args = parser.parse_args()
    # Determine auth_token: priority CLI > KBX_AUTH_TOKEN env > ~/.kbx/auth_token
    if args.auth_token is None:
        env_token = os.getenv("KBX_AUTH_TOKEN", "")
        if env_token:
            args.auth_token = env_token
        else:
            token_file = Path.home() / ".kbx" / "auth_token"
            if token_file.exists():
                args.auth_token = token_file.read_text().strip()

    # Skip auth_token validation for auth subcommand
    if args.command != 'auth':
        if not args.auth_token:
            raise ValueError("Empty auth_token! Please set env KBX_AUTH_TOKEN or by --auth-token.")
        args.client = KBXClient(
            server=args.server,
            auth_token=args.auth_token,
        )
    args.func(args)


if __name__ == "__main__":
    main()
