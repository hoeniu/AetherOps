"""AI model management commands."""
import requests
import json
from argparse import Namespace
import yaml
from termcolor import colored


def register_model(args: Namespace) -> None:
    """Register AI model configurations."""
    try:
        if args.config.endswith('.yaml') or args.config.endswith('.yml'):
            with open(args.config, 'r', encoding='utf-8') as f:
                config_dict = yaml.safe_load(f)
        elif args.config.endswith('.json'):
            with open(args.config, 'r', encoding='utf-8') as f:
                config_dict = json.load(f)
        else:
            raise ValueError(f"Invalid config file \"{args.config}\". Please provide a YAML or JSON file.")

        if not isinstance(config_dict, list):
            config_dict = [config_dict]

        args.client.register_ai_models(model_configs=config_dict, overwrite=args.overwrite)
        print(f"Successfully registered {len(config_dict)} model(s)")
    except yaml.YAMLError as e:
        print(f"Failed to parse YAML config file: {str(e)}")
    except json.JSONDecodeError as e:
        print(f"Failed to parse JSON config file: {str(e)}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to register models: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def list_models(args: Namespace) -> None:
    """List all registered AI models."""
    try:
        models = args.client.list_ai_models(type=args.type, backend=args.backend)['data']
        if len(models) == 0:
            print("No models found.")
            return

        print('Listing all registered models:')
        print("-------------------------------------------------------------------")
        for model in models:
            print(f"{colored(model['model_name'], 'green')} ({model['model_backend']}) --{model['model_type']}")
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to list models: {str(e)}")


def show_model_info(args: Namespace) -> None:
    """Show detailed information of a specific model."""
    try:
        detail = args.client.get_ai_model_detail(args.name)
        print(f"Model: {colored(args.name, 'green')}")
        print("-------------------------------------------------------------------")
        if args.format == 'yaml':
            print(yaml.dump(detail, default_flow_style=False, allow_unicode=True))
        elif args.format == 'json':
            print(json.dumps(detail, indent=4, ensure_ascii=False))
        else:
            raise NotImplementedError(f'Unsupported format: {args.format}')
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to get model detail: {str(e)}")


def remove_model(args: Namespace) -> None:
    """Remove a registered model."""
    try:
        args.client.delete_ai_model(args.name)
        print(f"Removed model: {colored(args.name, 'green')}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to remove model: {str(e)}")


def embedding_score(args: Namespace) -> None:
    """Calculate embedding similarity score between two texts."""
    try:
        score = args.client.embedding_score(args.text1, args.text2, args.model)
        print(f"Similarity score: {score:.4f}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to calculate embedding score: {str(e)}")


def setup_model_parser(subparsers) -> None:
    """Setup model management subcommands."""
    parser = subparsers.add_parser("model", help="AI model management")
    model_subparsers = parser.add_subparsers(dest="model_command", required=True)

    # Register command
    register_parser = model_subparsers.add_parser("register", help="Register AI model configurations")
    register_parser.add_argument("--config", required=True, help="Path to YAML/JSON config file")
    register_parser.add_argument("--overwrite", action="store_true", help="Overwrite existing models")
    register_parser.set_defaults(func=register_model)

    # List command
    list_parser = model_subparsers.add_parser("ls", help="List all registered models")
    list_parser.add_argument("--type", required=False, help="Model type")
    list_parser.add_argument("--backend", required=False, help="Model backend")
    list_parser.set_defaults(func=list_models)

    # Info command
    info_parser = model_subparsers.add_parser("info", help="Show model information")
    info_parser.add_argument("--name", required=True, help="Model name")
    info_parser.add_argument(
        "--format",
        choices=['json', 'yaml'],
        default='yaml',
        help="Output format for model config (json or yaml)"
    )
    info_parser.set_defaults(func=show_model_info)

    # Remove command
    remove_parser = model_subparsers.add_parser("rm", help="Remove a registered model")
    remove_parser.add_argument("--name", required=True, help="Model name")
    remove_parser.set_defaults(func=remove_model)

    # Embedding score command
    score_parser = model_subparsers.add_parser("embed_score", help="Calculate embedding similarity score")
    score_parser.add_argument("--text1", required=True, help="First text")
    score_parser.add_argument("--text2", required=True, help="Second text")
    score_parser.add_argument("--model", required=True, help="Model name")
    score_parser.set_defaults(func=embedding_score)
