"""Knowledge base management commands."""
import os
import requests
import json
from argparse import Namespace
import json
import yaml
from termcolor import colored


def create_kb(args: Namespace) -> None:
    """Create a new knowledge base."""
    try:
        if args.config.endswith('.yaml') or args.config.endswith('.yml'):
            # Read and parse YAML config file
            with open(args.config, 'r', encoding='utf-8') as f:
                config_dict = yaml.safe_load(f)
        elif args.config.endswith('.json'):
            # Read and parse JSON config file
            with open(args.config, 'r', encoding='utf-8') as f:
                config_dict = json.load(f)
        else:
            raise ValueError(f"Invalid config file \"{args.config}\". Please provide a YAML or JSON file.")

        # Create knowledge base with parsed config
        result = args.client.create_kb(config=config_dict, desired_kb_id=args.desired_kb_id)
        print(f"Created knowledge base: {colored(result['kb_id'], 'green')}")
    except yaml.YAMLError as e:
        print(f"Failed to parse YAML config file: {str(e)}")
    except json.JSONDecodeError as e:
        print(f"Failed to parse JSON config file: {str(e)}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to create knowledge base: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def list_kbs(args: Namespace) -> None:
    """List all knowledge bases."""
    try:
        kbs = args.client.list_kbs()['data']
        if len(kbs) == 0:
            print("No knowledge bases found.")
            return

        print('Listing all knowledge bases:')
        print("-------------------------------------------------------------------")
        for kb_info in kbs:
            print(f"{colored(kb_info['kb_id'], 'green')}: \"{kb_info['name']}\"")
        print("-------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to list knowledge bases: {str(e)}")


def remove_kb(args: Namespace) -> None:
    """Remove one or more knowledge bases."""
    try:
        # Split kb_ids by comma and strip whitespace
        kb_ids = [kb_id.strip() for kb_id in args.kb_id.split(',')]

        for kb_id in kb_ids:
            try:
                result = args.client.remove_kb(kb_id)
                print(f"Removed knowledge base: {colored(result['kb_id'], 'green')}")
            except requests.exceptions.RequestException as e:
                print(f"Failed to remove knowledge base {colored(kb_id, 'red')}: {str(e)}")
                continue
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def show_kb_info(args: Namespace) -> None:
    """Show knowledge base information."""
    try:
        detail = args.client.get_kb_detail(args.kb_id)
        print(f"kb_id: {colored(detail['kb_id'], 'green')}")
        print(f"user_id: {colored(detail['user_id'], 'yellow')}")
        print("kb_creation_config:")
        print("-------------------------------------------------------------------")
        if args.format == 'yaml':
            print(yaml.dump(detail['kb_config'], default_flow_style=False, allow_unicode=True))
        elif args.format == 'json':
            print(json.dumps(detail['kb_config'], indent=4, ensure_ascii=False))
        else:
            raise NotImplementedError(f'Unsupported format: {args.format}')
        print("-------------------------------------------------------------------")

        # Save config to file if --save is specified
        if args.save:
            save_path = args.save
            try:
                if save_path.endswith('.yaml') or save_path.endswith('.yml'):
                    with open(save_path, 'w', encoding='utf-8') as f:
                        yaml.dump(detail['kb_config'], f, default_flow_style=False, allow_unicode=True)
                elif save_path.endswith('.json'):
                    with open(save_path, 'w', encoding='utf-8') as f:
                        json.dump(detail['kb_config'], f, indent=4, ensure_ascii=False)
                else:
                    raise ValueError(
                        f"Unsupported save path: \"{save_path}\". Please use .yaml, .yml or .json extension."
                    )
                print(f"Config saved to: {colored(save_path, 'green')}")
            except Exception as e:
                print(f"Failed to save config to file: {colored(str(e), 'red')}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to get knowledge base detail: {str(e)}")


def update_kb(args: Namespace) -> None:
    """Update knowledge base configuration."""
    try:
        if args.config.endswith('.yaml') or args.config.endswith('.yml'):
            # Read and parse YAML config file
            with open(args.config, 'r') as f:
                config_dict = yaml.safe_load(f)
        elif args.config.endswith('.json'):
            # Read and parse JSON config file
            with open(args.config, 'r') as f:
                config_dict = json.load(f)
        else:
            # Assume it's a dict
            raise ValueError(f"Invalid config file \"{args.config}\". Please provide a YAML or JSON file.")

        # Update knowledge base with parsed config
        result = args.client.update_kb(kb_id=args.kb_id, config=config_dict)
        print(f"Updated knowledge base: {colored(result['kb_id'], 'green')}")
    except yaml.YAMLError as e:
        print(f"Failed to parse YAML config file: {str(e)}")
    except json.JSONDecodeError as e:
        print(f"Failed to parse JSON config file: {str(e)}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to update knowledge base: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"An error occurred: {str(e)}")


def setup_kb_parser(subparsers) -> None:
    """Setup knowledge base subcommands."""
    parser = subparsers.add_parser("kb", help="Knowledge base management")
    kb_subparsers = parser.add_subparsers(dest="kb_command", required=True)

    # Create command
    create_parser = kb_subparsers.add_parser("create", help="Create a new knowledge base")
    create_parser.add_argument("--config", required=True, help="Path to YAML config file")
    create_parser.add_argument(
        "--desired-kb-id",
        type=str,
        default='',
        help="Desired knowledge base ID. If not provided, the server will automatically generate one."
    )
    create_parser.set_defaults(func=create_kb)

    # List command
    list_parser = kb_subparsers.add_parser("ls", help="List all knowledge bases")
    list_parser.set_defaults(func=list_kbs)

    # Remove command
    remove_parser = kb_subparsers.add_parser("rm", help="Remove one or more knowledge bases")
    remove_parser.add_argument(
        "--kb-id",
        type=str,
        default=os.getenv("KBX_DEFAULT_KB_ID"),
        required='KBX_DEFAULT_KB_ID' not in os.environ,
        help="Knowledge base ID(s). Multiple IDs can be specified with comma separation (e.g., kb_id1,kb_id2,...). "
             "If not provided, KBX_DEFAULT_KB_ID environment variable will be used if set."
    )
    remove_parser.set_defaults(func=remove_kb)

    # Info command
    info_parser = kb_subparsers.add_parser("info", help="Show knowledge base information")
    info_parser.add_argument(
        "--kb-id",
        type=str,
        default=os.getenv("KBX_DEFAULT_KB_ID"),
        required='KBX_DEFAULT_KB_ID' not in os.environ,
        help="Knowledge base ID. If not provided, KBX_DEFAULT_KB_ID environment variable will be used if set."
    )
    info_parser.add_argument(
        "--format",
        choices=['json', 'yaml'],
        default='yaml',
        help="Output format for kb config (json or yaml)"
    )
    info_parser.add_argument(
        "--save",
        help="Save kb config to specified file (supports .yaml, .yml or .json)"
    )
    info_parser.set_defaults(func=show_kb_info)

    # Update command
    update_parser = kb_subparsers.add_parser("update", help="Update knowledge base configuration")
    update_parser.add_argument(
        "--kb-id",
        type=str,
        default=os.getenv("KBX_DEFAULT_KB_ID"),
        required='KBX_DEFAULT_KB_ID' not in os.environ,
        help="Knowledge base ID. If not provided, KBX_DEFAULT_KB_ID environment variable will be used if set."
    )
    update_parser.add_argument("--config", required=True, help="Path to YAML config file")
    update_parser.set_defaults(func=update_kb)
