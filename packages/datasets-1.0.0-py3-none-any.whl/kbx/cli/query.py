"""Query commands."""
import os
import requests
import json
from argparse import Namespace
from kbx.knowledge_base.types import QueryResults, RetrievalStepMessage, DeepThinkConfig
from termcolor import colored


def query_kb(args: Namespace):
    """Query knowledge base."""
    print(f"Querying knowledge base {colored(args.kb_id, 'green')} with query: {args.query}")
    try:
        if args.deep_think_llm:
            llm_model = args.deep_think_llm
        else:
            llm_model = None
        results = args.client.query_kb(
            kb_ids=args.kb_id.split(','),
            query=args.query,
            top_k=args.top_k,
            score_threshold=args.score_threshold,
            stream=args.stream,
            max_tokens=args.max_tokens,
            deep_think=DeepThinkConfig(llm_model=llm_model) if llm_model else None
        )

        if args.stream:
            for line in results.iter_lines():
                if line:
                    decode_line = line.decode('utf8')
                    if decode_line.startswith('data:'):
                        formatter_data = decode_line.split(":", 1)[1].strip()
                        res_data = json.loads(formatter_data)
                        if res_data.get("is_final", False):
                            results = QueryResults(**res_data)
                        else:
                            step_message = RetrievalStepMessage(**res_data["step_messages"][0])
                            print(f"step_name: {step_message.step_name}\n"
                                  f"content: {step_message.content}")
                            print('----------------------------------------------------------------------')
        else:
            results = QueryResults(**results)

        print("========================================================================")
        print(f'Get query results (id="{results.id}")')
        for k, qr in enumerate(results):
            print(f"------------------------------ result {k} ------------------------------")
            print(f'kb_id: "{colored(qr.kb_id, "green")}"')
            print(f'doc_id: "{colored(qr.doc_id, "blue")}"')
            print(f'doc_name: "{qr.meta_data["doc_name"]}"')
            print(f'score: {qr.score}\n')
            print(qr.try_get_content_as_str())
        print("------------------------------------------------------------------------")
    except requests.exceptions.RequestException as e:
        print(f"Failed to query knowledge base: {str(e)}")


def setup_query_parser(subparsers):
    """Setup query subcommands."""
    parser = subparsers.add_parser("query", help="Query knowledge base")
    parser.add_argument(
        "--kb-id",
        type=str,
        default=os.getenv("KBX_DEFAULT_KB_ID"),
        required='KBX_DEFAULT_KB_ID' not in os.environ,
        help="Knowledge base ID(s). Multiple IDs can be specified with comma separation (e.g., kb_id1,kb_id2,...). "
             "If not provided, KBX_DEFAULT_KB_ID environment variable will be used if set."
    )
    parser.add_argument("--query", required=True, help="Query string")
    parser.add_argument("--top-k", default=3, type=int, help="Number of results to return")
    parser.add_argument("--score-threshold", default=0.0, type=float, help="Score threshold for query results")
    parser.add_argument("--stream", default=False, action="store_true", help="Streaming mode for retieval")
    parser.add_argument("--max-tokens", default=32 * 1024, type=int, help="Result content limit")
    parser.add_argument(
        "--deep-think-llm",
        type=str,
        help="Deep think LLM model. If not provided, deep think will be disabled"
    )
    parser.set_defaults(func=query_kb)
