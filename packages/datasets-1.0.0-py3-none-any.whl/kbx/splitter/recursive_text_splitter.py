from typing import List

from kbx.splitter.naive_text_splitter import NaiveTextSplitter


class RecursiveTextSplitter(NaiveTextSplitter):
    """递归文本分块器，递归尝试不同的分隔符进行分割"""

    def split_text(self, text: str) -> List[str]:
        """递归分割文本

        Args:
            text: 需要分割的文本

        Returns:
            分割后的文本块列表
        """
        return self._recursive_split_text(text)

    def _recursive_split_text(self, text: str) -> List[str]:
        """递归分割文本

        Args:
            text: 需要分割的文本

        Returns:
            分割后的文本块列表
        """
        # 如果文本为空或长度小于chunk_size，直接返回
        if not self.is_valid_text(text):
            return []

        text_len = self._token_counter(text)
        if text_len <= self._chunk_size:
            return [text]

        # 获取适当的分隔符
        delimiter = self._get_delimiter(text)

        # 按照分隔符分割文本
        if delimiter:
            splits = text.split(delimiter)
        else:
            # 没有可用的分隔符，直接按照字符数量分割
            return [text[i:i + self._chunk_size] for i in range(0, len(text), self._chunk_size)]

        # 处理分割后的文本块
        final_chunks = []
        good_splits = []
        good_splits_lengths = []  # 缓存分割后的文本长度

        for split in splits:
            if not split:
                continue

            split_len = self._token_counter(split)

            # 如果分割后的文本长度小于chunk_size，添加到待合并列表
            if split_len < self._chunk_size:
                good_splits.append(split)
                good_splits_lengths.append(split_len)
            else:
                # 如果有待合并的内容，先处理它们
                if good_splits:
                    merged_text = self._merge_splits(good_splits, delimiter, good_splits_lengths)
                    final_chunks.extend(merged_text)
                    good_splits = []
                    good_splits_lengths = []

                # 对于大型文本块，递归处理
                sub_chunks = self._recursive_split_text(split)
                final_chunks.extend(sub_chunks)

        # 处理剩余的待合并内容
        if good_splits:
            merged_text = self._merge_splits(good_splits, delimiter, good_splits_lengths)
            final_chunks.extend(merged_text)

        return final_chunks

    def _get_delimiter(self, text: str) -> str:
        """获取适当的分隔符

        Args:
            text: 需要分割的文本

        Returns:
            选择的分隔符
        """
        # 尝试每个分隔符
        for delimiter in self._delimiters:
            if delimiter and delimiter in text:
                return delimiter

        return ""
