from typing import List, Tuple

from kbx.common.logging import logger
from kbx.common.types import DocData, Chunk, DocElementType, TOCNode
from kbx.common.utils import get_toc_node_content_str, doc_element_to_markdown
from kbx.common.token_counter.token_counter_factory import get_token_counter
from kbx.splitter.base_splitter import BaseSplitter
from kbx.splitter.types import SplitterConfig


class TOCAwareWrapper(BaseSplitter):
    """TOC感知分块包装器，可以包装任何分块器实现，使其具备TOC感知分块能力"""

    def __init__(self, base_splitter: BaseSplitter, config: SplitterConfig) -> None:
        """创建TOC感知分块包装器

        Args:
            base_splitter: 基础分块器，用于在无法使用TOC时的分块
            config: 分块配置
        """
        super().__init__(config)
        self._base_splitter = base_splitter
        self._token_counter = get_token_counter(config.token_counter)
        self._chunk_size = config.chunk_size
        self._content_mode = config.content_mode

    def split(self, doc_data: DocData) -> List[Chunk]:
        """使用TOC结构进行分块，如果TOC信息不可用则回退到基础分块器

        Args:
            doc_data: 包含文档内容和TOC信息的DocData对象

        Returns:
            List[Chunk]: 分割后的Chunk列表
        """
        # 保存doc_id供后续使用
        self._doc_data = doc_data

        # 检查是否应该使用TOC感知分块
        if self._is_empty_toc(doc_data.doc_toc):
            logger.debug("TOC不可用或未启用TOC感知分块，回退到基础分块方式")
            return self._base_splitter.split(doc_data)

        # 使用TOC结构进行分块
        logger.debug("使用TOC结构进行文档分块")
        return self._split_toc_node(doc_data.doc_toc, doc_data)

    def _is_empty_toc(self, toc_node: TOCNode) -> bool:
        """检查TOC是否为空或无效

        Args:
            toc_node: TOC节点

        Returns:
            bool: 如果TOC为空或无效返回True，否则返回False
        """
        # 没有子节点
        if not toc_node.children:
            return True

        # 检查根节点是否有doc_element_ids
        if not toc_node.doc_element_ids:
            logger.warning("根节点缺少doc_element_ids")
            return True

        # 检查子节点是否有关联的文档元素
        all_children_have_elements = True
        for child in toc_node.children:
            if not child.doc_element_ids:
                logger.warning(f"子节点'{child.title}'缺少doc_element_ids")
                all_children_have_elements = False
                break

        if not all_children_have_elements:
            return True

        return False

    def _split_toc_node(self, node: TOCNode, doc_data: DocData) -> List[Chunk]:
        """递归处理节点及其子节点，尝试智能合并

        Args:
            node: TOC节点
            doc_data: 文档数据

        Returns:
            List[Chunk]: 分块后的Chunk列表
        """
        # 1. 如果整个文档的token数量不超过限制，直接创建一个chunk
        if node.num_tokens > 0 and node.num_tokens <= self._chunk_size:
            content = get_toc_node_content_str(node, doc_data.doc_elements, mode=self._content_mode)
            if not self.is_valid_text(content):
                return []

            chunk = self._create_chunk(self._doc_data, content, node.doc_element_ids)
            return [chunk]

        # 2. 递归处理节点，自顶向下构建chunks
        chunks = []
        acc_content = ""
        merged_elem_ids = []

        # 2.1 处理直接元素
        for elem_id in node.self_doc_element_ids:
            elem = doc_data.doc_elements[elem_id]

            try:
                content = doc_element_to_markdown(elem, mode=self._content_mode)
                if not self.is_valid_text(content):
                    continue
            except (KeyError, IndexError) as e:
                logger.warning(f"访问元素{elem_id}失败: {e}")
                continue

            acc_content, merged_elem_ids, new_chunks = self._merge_with_previous_content(
                content, elem_id, elem.type, acc_content, merged_elem_ids, doc_data, is_child_node=False)
            chunks.extend(new_chunks)

        # 2.2 处理子节点
        if node.children:

            # 贪婪合并：尝试将直接元素与尽可能多的子节点合并
            for child in node.children:
                try:
                    content = get_toc_node_content_str(child, doc_data.doc_elements, mode=self._content_mode)
                except Exception as e:
                    logger.warning(f"获取子节点'{child.title}'内容失败: {e}")
                    continue

                # 子节点不需要elem_id和elem_type
                acc_content, merged_elem_ids, new_chunks = self._merge_with_previous_content(
                    content, None, None, acc_content, merged_elem_ids, doc_data, is_child_node=True, child=child)
                chunks.extend(new_chunks)

        if self.is_valid_text(acc_content):
            chunks.append(self._create_chunk(self._doc_data, acc_content, merged_elem_ids))

        return chunks

    def _merge_with_previous_content(self, content: str, elem_id: str, elem_type: DocElementType,
                                     acc_content: str, merged_elem_ids: List[str],
                                     doc_data: DocData, is_child_node: bool = False,
                                     child: TOCNode = None) -> Tuple[str, List[str], List[Chunk]]:
        """处理内容并返回chunks。

        将新内容与累积内容合并,如果超过chunk_size则进行分割。
        对于子节点和直接元素采用不同的处理策略。
        如果累积内容较小,会尝试与新内容合并。
        对于表格等特殊元素类型会进行特殊处理。

        Args:
            content: 要处理的内容
            elem_id: 元素ID（直接元素时使用）
            elem_type: 元素类型（直接元素时使用）
            acc_content: 累积的内容

            merged_elem_ids: 累积的元素ID列表
            doc_data: 文档数据
            is_child_node: 是否是子节点
            child: 子节点对象（子节点时使用）

        Returns:
            Tuple[str, List[str], List[Chunk]]: 处理后的acc_content、merged_elem_ids和chunks列表
        """
        chunks = []
        new_tokens = self._token_counter(content)
        acc_tokens = self._token_counter(acc_content) if acc_content else 0
        current_elem_ids = [elem_id] if elem_id else (child.doc_element_ids if child else [])

        # 如果累积内容与新内容超过限制，则进行处理
        if acc_tokens + new_tokens > self._chunk_size:
            # 如果累积内容本身太小，则与新内容合并
            if self.is_valid_text(acc_content) and acc_tokens < int(self._chunk_size * 0.1):
                # 如果累积内容与新内容只是略微超过chunk_size，直接合并
                if acc_tokens + new_tokens < int(self._chunk_size * 1.1):
                    chunks.append(self._create_chunk(self._doc_data,
                                                     f"{acc_content}\n{content}",
                                                     merged_elem_ids + current_elem_ids))
                    acc_content = ""
                    merged_elem_ids = []

                # 如果新内容比较长，则先分割再创建chunk
                else:
                    # 处理子节点
                    if is_child_node:
                        child_chunks = self._split_toc_node(child, doc_data)
                        child_chunks[0].doc_element_ids = merged_elem_ids + current_elem_ids
                        child_chunks[0].text = f"{acc_content}\n{child_chunks[0].text}"
                        chunks.extend(child_chunks[:-1])

                        # 将最后一个chunk的内容拿出来当做累积内容并尝试与后续内容合并
                        acc_content = child_chunks[-1].text
                        merged_elem_ids = child_chunks[-1].doc_element_ids

                    # 处理直接元素
                    else:
                        # 表格需要特殊处理
                        if elem_type == DocElementType.TABLE:
                            texts = self._base_splitter._split_table(doc_data.doc_elements[elem_id])
                            new_content = f"{acc_content}\n{texts[0]}"
                            chunks.append(self._create_chunk(self._doc_data,
                                                             new_content,
                                                             merged_elem_ids + [elem_id],
                                                             {'big_table': True}))
                        else:
                            texts = self.split_text(f"{acc_content}\n{content}")
                            chunks.append(self._create_chunk(self._doc_data, texts[0], merged_elem_ids + [elem_id]))

                        for text in texts[1:-1]:
                            meta_data = {'big_table': True} if elem_type == DocElementType.TABLE else {}
                            chunks.append(self._create_chunk(self._doc_data, text, [elem_id], meta_data))
                        acc_content = texts[-1]
                        merged_elem_ids = [elem_id]
            else:
                # 累积内容本身大小合适，则直接创建chunk
                if self.is_valid_text(acc_content):
                    chunks.append(self._create_chunk(self._doc_data, acc_content, merged_elem_ids))

                # 新内容本身超出限制，则分割后创建chunk
                if new_tokens > self._chunk_size:
                    if is_child_node:
                        child_chunks = self._split_toc_node(child, doc_data)
                        chunks.extend(child_chunks[:-1])

                        # 将最后一个chunk的内容拿出来当做累积内容并尝试与后续内容合并
                        acc_content = child_chunks[-1].text
                        merged_elem_ids = child_chunks[-1].doc_element_ids
                    else:
                        if elem_type == DocElementType.TABLE:
                            texts = self._base_splitter._split_table(doc_data.doc_elements[elem_id])
                        else:
                            texts = self.split_text(content)

                        for text in texts[:-1]:
                            meta_data = {'big_table': True} if elem_type == DocElementType.TABLE else {}
                            chunks.append(self._create_chunk(self._doc_data, text, [elem_id], meta_data))
                        acc_content = texts[-1]
                        merged_elem_ids = [elem_id]
                else:
                    acc_content = content
                    merged_elem_ids = current_elem_ids

        # 如果累积内容与新内容不超过限制，则将新内容累积到acc_content中
        else:
            if self.is_valid_text(acc_content) and not acc_content.endswith("\n"):
                acc_content += "\n"
            acc_content += content
            merged_elem_ids.extend(current_elem_ids)

        return acc_content, merged_elem_ids, chunks

    def split_text(self, text: str) -> List[str]:
        """将文本分割成块

        Args:
            text: 要分割的文本

        Returns:
            List[str]: 分割后的文本块列表
        """
        # 将调用转发到基础分块器
        return self._base_splitter.split_text(text)
