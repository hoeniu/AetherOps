import re
from typing import Iterable, List, Optional

from kbx.common.logging import logger
from kbx.common.types import DocData, DocElement, DocElementType, Chunk
from kbx.common.token_counter.token_counter_factory import get_token_counter
from kbx.parser.markdown.utils import table_2d_list_to_md
from kbx.splitter.base_splitter import BaseSplitter
from kbx.splitter.types import SplitterConfig


class NaiveTextSplitter(BaseSplitter):
    def __init__(self, config: SplitterConfig) -> None:
        """Create a new NaiveTextSplitter."""
        super().__init__(config)
        self._chunk_size = config.chunk_size
        self._delimiters = config.delimiters or ["\n\n", "\n", " ", ""]
        self._keep_delimiter = config.keep_delimiter
        self._token_counter = get_token_counter(config.token_counter)

    def split(self, doc_data: DocData) -> List[Chunk]:
        """Split doc_elements."""
        self._doc_data = doc_data
        chunks = []
        text = ""
        doc_elem_id = []

        for doc_elem in doc_data.doc_elements:
            content = None
            if doc_elem.type == DocElementType.TABLE:
                text, doc_elem_id, table_chunks = self._try_merge_table_with_context(doc_elem, text, doc_elem_id)
                chunks.extend(table_chunks)
                continue
            elif doc_elem.type == DocElementType.AUDIO and self.is_valid_text(doc_elem.text):
                chunks.append(self._create_chunk(
                    self._doc_data, doc_elem.text, [doc_elem.doc_element_id]))
                continue
            elif doc_elem.type in [DocElementType.FIGURE, DocElementType.VIDEO] \
                    and self.is_valid_text(doc_elem.content_description):
                chunks.append(self._create_chunk(
                    self._doc_data, doc_elem.content_description, [doc_elem.doc_element_id]))
                continue
            elif doc_elem.type == DocElementType.CODE_BLOCK:
                # 如果有代码内容描述，优先使用描述作为检索内容（适用于大多数embedding模型）
                # 否则使用原始代码片段（可能对embedding模型有特殊要求）
                content = (doc_elem.content_description
                           if self.is_valid_text(doc_elem.content_description)
                           else doc_elem.text) + '\n'
            elif doc_elem.type == DocElementType.TITLE:
                content = '#' * doc_elem.meta_data.get('title_level', 1) + ' ' + doc_elem.text + '\n\n'
            elif doc_elem.type == DocElementType.TEXT:
                content = doc_elem.text + '\n'

            if not self.is_valid_text(content):
                continue

            if self.is_valid_text(text) and \
                    self._token_counter(text) + self._token_counter(content) > self._chunk_size:
                chunks.extend(self._create_chunks(text.strip(), doc_elem_id, {}))
                # 重置text和doc_element_id
                text = content
                doc_elem_id = [doc_elem.doc_element_id]
            else:
                text += content
                doc_elem_id.append(doc_elem.doc_element_id)

        if self.is_valid_text(text):
            chunks.extend(self._create_chunks(text.strip(), doc_elem_id, {}))

        return chunks

    def _try_merge_table_with_context(self, table_elem: DocElement, context: str, doc_elem_id: list[str]) -> \
            tuple[str, List[str], List[Chunk]]:
        """尝试将表格与上下文合并

        将表格内容与前面累积的文本内容进行合并。如果合并后的内容超过chunk_size，则分别处理表格和文本内容。

        Args:
            table_elem: 表格类型的DocElement对象
            context: 前面累积的文本内容
            doc_elem_id: 前面累积内容对应的doc_element_id列表

        Returns:
            tuple[str, List[str], List[Chunk]]:
                - 剩余未处理的文本内容
                - 剩余未处理内容对应的doc_element_id列表
                - 已处理完成的chunks列表
        """

        if not table_elem.table:
            return context.strip(), doc_elem_id, []

        chunks = []
        context = context.strip()
        table_str = table_elem.table.as_md() if table_elem.table.is_standard else table_elem.table.as_html()
        if table_elem.table.caption:
            table_str = table_elem.table.caption + '\n\n' + table_str

        table_length = self._token_counter(table_str)
        context_length = self._token_counter(context)

        # 表格和上下文可以合并到一个chunk中
        if context_length + table_length <= self._chunk_size:
            combined_text = context + '\n\n' + table_str
            return combined_text, doc_elem_id, chunks

        # 表格和上下文不能合并到一个chunk中，分别处理上下文和表格
        # 如果累积内容本身太小，则将其与表格合并
        if self.is_valid_text(context) and context_length < int(self._chunk_size * 0.1):
            # 如果累积内容与表格只是略微超过chunk_size，直接合并
            if context_length + table_length < int(self._chunk_size * 1.1):
                combined_text = context + '\n\n' + table_str
                chunks.append(self._create_chunk(self._doc_data,
                                                 combined_text,
                                                 doc_elem_id + [table_elem.doc_element_id]))
                return '', [], chunks
            else:
                # 如果表格内容比较长，则先分割再创建chunk
                table_texts = self._split_table(table_elem)
                combined_text = context + '\n\n' + table_texts[0]
                chunks.append(self._create_chunk(self._doc_data,
                                                 combined_text,
                                                 doc_elem_id + [table_elem.doc_element_id]))
                for table_text in table_texts[1:-1]:
                    chunks.append(self._create_chunk(self._doc_data,
                                                     table_text,
                                                     [table_elem.doc_element_id],
                                                     {'big_table': True}))
                return table_texts[-1], [table_elem.doc_element_id], chunks
        else:
            # 累积内容本身大小合适，则创建chunk
            if self.is_valid_text(context):
                chunks.append(self._create_chunk(self._doc_data, context, doc_elem_id))
                context = ""
                doc_elem_id = []

            # 表格本身超出限制，则单独处理
            if table_length > self._chunk_size:
                table_texts = self._split_table(table_elem)
                for table_text in table_texts[:-1]:
                    chunks.append(self._create_chunk(self._doc_data,
                                                     table_text,
                                                     [table_elem.doc_element_id],
                                                     {'big_table': True}))
                context = table_texts[-1]
                doc_elem_id = [table_elem.doc_element_id]
            else:
                # 累积表格内容
                context = table_str
                doc_elem_id = [table_elem.doc_element_id]
            return context, doc_elem_id, chunks

    def _split_table(self, table_elem: DocElement) -> List[str]:
        # 检查是否有数据
        if not table_elem.table:
            return []

        # 如果不是标准表格，无法使用md格式
        if not table_elem.table.is_standard:
            return [table_elem.table.as_html()]
        else:
            # 如果表格内容小于chunk_size，直接返回
            if self._token_counter(table_elem.table.md) <= self._chunk_size:
                return [table_elem.table.md]

        chunks = []
        # NOTE: 这里先把表格转换成md格式
        full_md = table_2d_list_to_md(table_elem.table.data_2d, table_elem.table.has_header, caption=None)
        if not full_md:
            return []

        # 添加表格标题（如果有）
        caption = table_elem.table.caption + "\n\n" if self.is_valid_text(table_elem.table.caption) else ""

        lines = full_md.strip().split('\n')
        # 即使原始表格没有表头，table_2d_list_to_md函数也会生成col1,col2,...这样的表头，所以表头和分隔行是固定的
        header_lines = lines[:2]  # 表头和分隔行
        data_lines = lines[2:]  # 数据行

        # 初始化当前分块
        current_chunk = ""
        current_chunk += caption
        # 添加表头和分隔行
        current_chunk += "\n".join(header_lines) + "\n"
        current_chunk_length = self._token_counter(current_chunk)

        # 处理数据行
        for line in data_lines:
            if not line.strip():  # 跳过空行
                continue
            line_text = line + '\n'
            line_length = self._token_counter(line_text)

            # 检查添加后是否超出限制（需要包含表头长度）
            if current_chunk_length + line_length > self._chunk_size:
                if current_chunk:
                    chunks.append(current_chunk.strip())

                # 开始新的分块，重新添加表头和分隔行
                current_chunk = caption
                current_chunk += "\n".join(header_lines) + "\n"
                current_chunk += line_text
                current_chunk_length = self._token_counter(current_chunk)
            else:
                current_chunk += line_text
                current_chunk_length += line_length

        # 处理最后一个chunk
        if current_chunk:
            chunks.append(current_chunk.strip())

        return chunks

    def _create_kv_pair_table_chunks(self, table_elem: DocElement) -> List[Chunk]:
        """为表格每行创建独立文本块，格式为列名: 值对（分号分隔）

        Args:
            table_elem: 包含表格数据的文档元素，table属性应为二维列表，
                        首行为列名，后续行数据应与列数一致

        Returns:
            每个文本块对应一行数据，格式示例："姓名: 张三; 年龄: 30"
        """
        if not table_elem.table:
            return []

        chunks = []
        columns = table_elem.table[0]

        for row in table_elem.table[1:]:
            row_content = []
            for col_name, cell in zip(columns, row):
                # 处理空列名情况
                col = col_name.strip() if self.is_valid_text(col_name) else ""
                cell_value = cell.strip() if self.is_valid_text(cell) else ""

                # 生成有效内容
                if col and cell_value:
                    content = f"{col}: {cell_value}"
                elif cell_value:  # 只有值没有列名
                    content = cell_value
                else:  # 忽略空数据
                    continue

                row_content.append(content)

            if not row_content:
                continue

            chunks.append(self._create_chunk(
                "; ".join(row_content), [table_elem.doc_element_id], {"split_type": "kv_pair"}))

        return chunks

    def _create_chunks(self, text: str,
                       doc_element_ids: list[str],
                       meta_data: dict = None
                       ) -> List[Chunk]:
        """Create text chunks from a list of texts."""
        # 如果文本内容为空，直接返回空列表
        if not self.is_valid_text(text):
            return []

        # 如果文本内容本身小于chunk_size，直接创建chunk
        if self._token_counter(text) <= self._chunk_size:
            return [self._create_chunk(self._doc_data, text, doc_element_ids, meta_data)]

        # 如果文本内容是表格数据（说明是有单行数据特别长），不再进行分割
        if text.count("|") >= 2 and text.count("---") >= 1:
            meta_data["big_table"] = True
            return [self._create_chunk(self._doc_data, text, doc_element_ids, meta_data)]

        chunks = []

        for chunk in self.split_text(text):
            if not self.is_valid_text(chunk):
                continue
            chunks.append(self._create_chunk(self._doc_data, chunk, doc_element_ids, meta_data))
        return chunks

    def _join_texts(self, texts: list[str], delimiter: str) -> Optional[str]:
        text = delimiter.join(texts)
        text = text.strip()
        if text == "":
            return None
        else:
            return text

    def _merge_splits(self, splits: Iterable[str], delimiter: str, lengths: list[int]) -> list[str]:
        """将一些文本元素合并成更大的文本块

        Args:
            splits: 文本块列表
            delimiter: 用于合并的分隔符
        """
        # We now want to combine these smaller pieces into medium size
        # chunks to send to the LLM.
        delimiter_len = self._token_counter(delimiter)

        docs = []
        current_doc: list[str] = []
        total = 0
        index = 0
        for d in splits:
            _len = lengths[index]
            if total + _len + (delimiter_len if len(current_doc) > 0 else 0) > self._chunk_size:
                if total > self._chunk_size:
                    logger.warning(
                        f"Created a chunk of size {total}, which is longer than the specified {self._chunk_size}"
                    )
                if len(current_doc) > 0:
                    doc = self._join_texts(current_doc, delimiter)
                    if doc is not None:
                        docs.append(doc)
                    # Keep on popping if:
                    # - we have a larger chunk than in the chunk overlap
                    # - or if we still have any chunks and the length is long
                    while total > self._config.overlap_size or (
                        total + _len + (delimiter_len if len(current_doc) > 0 else 0) > self._chunk_size and total > 0
                    ):
                        total -= self._token_counter(current_doc[0]) + (delimiter_len if len(current_doc) > 1 else 0)
                        current_doc = current_doc[1:]
            current_doc.append(d)
            total += _len + (delimiter_len if len(current_doc) > 1 else 0)
            index += 1
        doc = self._join_texts(current_doc, delimiter)
        if self.is_valid_text(doc):
            docs.append(doc)
        return docs

    def split_text(self, text: str) -> list[str]:
        return self._split_text(text, self._delimiters)

    def _split_text(self, text: str, delimiters: list[str]) -> list[str]:
        """将文本分割成若干块

        Args:
            text: 需要分割的文本内容
        """
        """Split incoming text and return chunks."""

        final_chunks = []
        delimiter = delimiters[-1]
        new_delimiters = []

        for i, _s in enumerate(delimiters):
            if _s == "":
                delimiter = _s
                break
            if re.search(_s, text):
                delimiter = _s
                new_delimiters = delimiters[i + 1:]
                break

        splits = self._split_text_with_regex(text, delimiter, self._keep_delimiter)
        _good_splits = []
        _good_splits_lengths = []  # cache the lengths of the splits
        _delimiter = "" if self._keep_delimiter else " "

        for s in splits:
            s_len = self._token_counter(s)
            if s_len < self._chunk_size:
                _good_splits.append(s)
                _good_splits_lengths.append(s_len)
            else:
                if _good_splits:
                    merged_text = self._merge_splits(_good_splits, _delimiter, _good_splits_lengths)
                    final_chunks.extend(merged_text)
                    _good_splits = []
                    _good_splits_lengths = []
                if new_delimiters:
                    chunks = self._split_text(s, new_delimiters)
                    final_chunks.extend(chunks)
                else:
                    # 没有分隔符可以继续使用，但还是超过chunk size，直接根据chunk size切分
                    chunks = [s[i:i + self._chunk_size] for i in range(0, len(s), self._chunk_size)]
                    final_chunks.extend(chunks)

        if _good_splits:
            merged_text = self._merge_splits(_good_splits, _delimiter, _good_splits_lengths)
            final_chunks.extend(merged_text)

        return final_chunks

    def _split_text_with_regex(self, text: str, delimiter: str, keep_delimiter: bool) -> list[str]:
        # Now that we have the delimiter, split the text
        if delimiter:
            if keep_delimiter:
                # The parentheses in the pattern keep the delimiters in the result.
                # 使用re.escape转义（"."变为"\."）以避免特殊字符被误解为正则表达式的元字符，比如"*","."等
                _splits = re.split(f"({re.escape(delimiter)})", text)
                splits = [_splits[i - 1] + _splits[i] for i in range(1, len(_splits), 2)]
                if len(_splits) % 2 != 0:
                    splits += _splits[-1:]
            else:
                splits = re.split(f"({re.escape(delimiter)})", text)
                splits = [_splits[i] for i in range(0, len(_splits), 2)]
                if len(_splits) % 2 != 0:
                    splits += _splits[-1:]
        else:
            splits = list(text)
        return [s for s in splits if (s not in {"", "\n"})]
