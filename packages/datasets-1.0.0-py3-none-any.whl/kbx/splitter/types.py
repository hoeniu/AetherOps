from typing import List, Optional, Literal
from pydantic import Field
from kbx.common.types import TokenCounterConfig, KBXBaseModel


class SplitterConfig(KBXBaseModel):
    """分块配置"""
    name: str = Field(default='RecursiveTextSplitter', description="文本分块器的名称")
    chunk_size: int = Field(default=1024, description="文本分块时的最大token数量")
    delimiters: List[str] = Field(default=["\n\n", "\n", " "], description="文本分块时的分隔符")
    overlap_size: int = Field(default=0, description="文本分块时允许的最大重叠token数量")
    keep_delimiter: bool = Field(default=True, description="文本分块时分隔符是否保留")
    token_counter: Optional[TokenCounterConfig] = Field(
        default=None,
        description="文档解析过程中，用于统计token数量的配置，不设置则使用知识库统一配置"
    )
    content_mode: Literal['original', 'summary'] = Field(
        default='summary',
        description="分块时，用于获取内容的模式"
    )
