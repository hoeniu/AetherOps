from kbx.splitter.base_splitter import BaseSplitter
from kbx.splitter.types import SplitterConfig


def get_splitter(config: SplitterConfig) -> BaseSplitter:
    """获取splitter实例

    Args:
        config (SplitterConfig): 分块器配置

    Raises:
        RuntimeError: 不支持的分块器类型

    Returns:
        BaseSplitter: 分块器实例
    """
    splitter_name = config.name

    # 首先创建基础分块器
    base_splitter = None

    match splitter_name:
        case 'NaiveTextSplitter':
            from kbx.splitter.naive_text_splitter import NaiveTextSplitter
            base_splitter = NaiveTextSplitter(config)
        case 'RecursiveTextSplitter':
            from kbx.splitter.recursive_text_splitter import RecursiveTextSplitter
            base_splitter = RecursiveTextSplitter(config)
        case _:
            raise RuntimeError(f'Unknown splitter class: {splitter_name}')

    from kbx.splitter.toc_aware_wrapper import TOCAwareWrapper
    return TOCAwareWrapper(base_splitter, config)
