from abc import ABC, abstractmethod
from typing import List, Optional

from kbx.common.types import DocData, Chunk, DocElementType, DocElement
from kbx.common.utils import generate_new_id, get_node_by_level_str
from kbx.splitter.types import SplitterConfig


class BaseSplitter(ABC):
    """文本分割器基类"""
    def __init__(self, config: SplitterConfig):
        """创建一个新的文本分割器
        Args:
            config (SplitterConfig): 分割器的配置
        """
        self._config = config
        if self._config.overlap_size > self._config.chunk_size:
            raise ValueError(
                f"Got a larger chunk overlap ({self._config.overlap_size}) \
                 than chunk size ({self._config.chunk_size}), should be smaller."
            )

    @abstractmethod
    def split(self, doc_data: DocData) -> List[Chunk]:
        """对doc_elements进行分割

        Args:
            doc_data (DocData): 待分割的doc_data

        Returns:
            List[Chunk]: 分割后的Chunk列表
        """
        raise NotImplementedError

    def is_valid_text(self, text: Optional[str | None]) -> bool:
        """验证文本是否符合要求
        Args:
            text (str): 待验证的文本

        Returns:
            bool: 是否为有效文本
        """
        # strip会去除字符串两端的空格、换行符、回车符、tab键等特殊字符，但是不会去除字符串中间的特殊字符
        if text is None or not text.strip():
            return False

        return True

    def _create_chunk(self, doc_data: DocData, text: str, elem_ids: List[str], meta_data: dict = {}) -> Chunk:
        """创建Chunk对象

        Args:
            doc_data: 文档数据
            text: 文本内容
            elem_ids: 文档元素ID列表
            meta_data: 可选的元数据字典

        Returns:
            Chunk: 创建的Chunk对象
        """
        chunk = Chunk(
            text=text.strip(),
            chunk_id=generate_new_id(),
            doc_id=doc_data.doc_id,
            doc_element_ids=elem_ids,
            meta_data=meta_data
        )

        # NOTE：为避免重复存储大表格数据
        if meta_data.get("big_table"):
            return chunk

        doc_elements = [doc_data.doc_elements[doc_ele_id] for doc_ele_id in elem_ids]
        # 检查是否存在多模态数据（图片、视频、音频等）
        is_multimodal = any(
            doc_elem.type not in [DocElementType.TEXT, DocElementType.TITLE]
            for doc_elem in doc_elements
        )
        if is_multimodal:
            chunk.doc_elements = doc_elements

        # 补充chunk对应的行号和标题
        self._add_line_ranges_and_titles_to_chunk(doc_data, doc_elements, chunk)
        return chunk

    def _add_line_ranges_and_titles_to_chunk(self,
                                             doc_data: DocData,
                                             doc_elements: List[DocElement],
                                             chunk: Chunk) -> None:
        """
        补充chunk对应的:
        1. 行号, 从0开始 (目前仅适用于插入md文档时)
        2. 标题 (适用于文档包含目录树的场景)

        Args:
            doc_data (DocData): 文档数据
            doc_elements (List[DocElement]): 文档元素列表
            chunk (TextChunk): 文本块
        """
        # NOTE: 将chunk的line_ranges和titles设置为list类型
        # 因为这两个字段均从DocElement中获得，一个chunk可能对应多个DocElement。
        # 具体使用哪个line_range和title可以由用户在上层决定
        if 'line_ranges' not in chunk.meta_data:
            chunk.meta_data['line_ranges'] = []
        if 'titles' not in chunk.meta_data:
            chunk.meta_data['titles'] = []

        for doc_element in doc_elements:
            # 处理行号
            if doc_element.meta_data.get('line_range'):
                line_range = doc_element.meta_data['line_range']
                chunk.meta_data['line_ranges'].append(line_range)

            # 处理标题
            title = ''
            if doc_data.doc_toc and doc_element.toctree_node_path:
                node = get_node_by_level_str(doc_data.doc_toc, doc_element.toctree_node_path)
                if node:
                    title = node.title
                chunk.meta_data['titles'].append(title)
