import copy
from concurrent.futures import ThreadPoolExecutor
from typing import List, Dict, Tuple, Union, Optional, Any, Iterator

from kbx.common.logging import logger

from kbx.datastore.ds_factory import get_structured_datastore

from kbx.knowledge_base.base_index import BaseIndex
from kbx.common.types import DocData, IndexType, KBXError
from kbx.common.utils import get_pydantic_config_changes
from kbx.knowledge_base.structured.retrievers import NLSQLRetriever
from kbx.knowledge_base.types import StructuredIndexConfig, QueryConfig, QueryResults
from kbx.knowledge_base.structured.table_schema import TableSchemaGenerator, ImmutableTableConfig


class DefaultStructuredIndex(BaseIndex[StructuredIndexConfig]):
    """默认的结构化数据索引实现"""
    mutable_config = ["llm_model", "sql_gen_llm_model", "tables", "sql", "max_related_tables", "generate_iters"]

    def __init__(self, kb_id: str, index_config: StructuredIndexConfig) -> None:
        if not isinstance(index_config, StructuredIndexConfig):
            raise RuntimeError(f'Expect a index_config of StructuredIndexConfig, given {index_config}')
        super().__init__(kb_id=kb_id, index_config=index_config)

        # TODO: 初版仅支持结构化文档存储，v0.2需要增加除csv/xlsx等结构化数据的非结构化数据支持
        # TODO: 后续需要结合向量所用
        self._validate_index_config()
        self.retriver = NLSQLRetriever(kb_id=kb_id, index_config=index_config)
        self.table_schema_generator = TableSchemaGenerator(kb_id=kb_id, index_config=index_config)
        self.is_external_datastore = True if index_config.external_structured_ds else False
        self._create_info_table()

    @property
    def index_type(self) -> IndexType:
        return IndexType.STRUCTURED

    def _create_info_table(self) -> None:
        """在非外部知识库时创建信息记录表, 当前主要记录doc和table_name的映射"""
        # 如果不创建该表，每次delete数据，需要遍历整个数据库的所有表
        # 为了避免可能出现的数据长度超过限制，字段类型采用Text
        if self.is_external_datastore:
            return
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            existed_tables, kbx_error = structured_ds.show_tables()
            if kbx_error.code != KBXError.Code.SUCCESS:
                logger.error("Structured Index: Failed to obtain all tables in the current database. "
                             f"The error message is as follows: {kbx_error.msg}")
                existed_tables = []
            # TODO: 目前考虑使用Text类型，用以动态分配存储空间
            # text类型不支持UNIQUE，因此改为VARCHAR
            required_columns = {"doc_id": ["VARCHAR(64)", True, "", ""], "table_name": ["VARCHAR(32)", True, "", ""]}
            # id字段由datastore负责创建，此处校验该字段为可选
            allowed_columns = ["id", "doc_id", "table_name"]
            if ImmutableTableConfig.get_info_table() in existed_tables:
                (table_info, _), kbx_error = structured_ds.show_create_table(ImmutableTableConfig.get_info_table())
                if kbx_error.code != KBXError.Code.SUCCESS:
                    raise RuntimeError(
                        f"Failed to obtain the field content of {ImmutableTableConfig.get_info_table()}, "
                        f"the error message is as follows: {kbx_error.msg}")
                field_dict = {col[0]: col[1] for col in table_info}
                for field, (expected_type, _, _, _) in required_columns.items():
                    if field not in field_dict or not field_dict[field].lower().startswith(expected_type.lower()):
                        raise ValueError("Please reset the info_table parameter of StructuredIndexConfig. "
                                         "The table exists in the database and the columns are inconsistent "
                                         f"with the required columns. {field}, {field_dict}, {expected_type}")
                for field in field_dict.keys():
                    if field not in allowed_columns:
                        raise ValueError("Please reset the info_table parameter of StructuredIndexConfig. "
                                         "The table exists in the database and the columns are inconsistent "
                                         "with the required columns.")
            else:
                kbx_error = structured_ds.create_table(table_name=ImmutableTableConfig.get_info_table(),
                                                       attr=required_columns,
                                                       index={"index": ["doc_id", "table_name"]})
                if kbx_error.code != KBXError.Code.SUCCESS:
                    raise RuntimeError(
                        "Failed to create information record table %s, the error message is as follows: %s." %
                        (ImmutableTableConfig.get_info_table(), kbx_error.msg))

    def _validate_index_config(self) -> bool:
        """检查必要的索引配置"""
        if not self._index_config.llm_model:
            raise ValueError("The structured index module must be configured with the 'llm_model' parameter.")

        if not self._index_config.sql_gen_llm_model:
            self._index_config.sql_gen_llm_model = self._index_config.llm_model
            logger.warning("Structured Index: \'sql_gen_llm_model\' parameter is not configured,"
                           " \'llm_model\' will be used.")
        if self._index_config.max_related_tables <= 0:
            raise ValueError("Structured Index: Parameter \'max_related_tables\' must be greater than 0, "
                             f"but got {self._index_config.max_related_tables}.")
        if self._index_config.generate_iters <= 0:
            raise ValueError("Structured Index: Parameter \'generate_iters\' must be greater than 0, "
                             f"but got {self._index_config.generate_iters}.")

    def _validate_table_empty(self, table_name: str) -> bool:
        """判断数据库中表是否为空"""
        # id为必须创建的字段，由datastore负责创建
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            res, kbx_error = structured_ds.select(target_list=["id"], table_name=table_name, condition_list=[])
            if kbx_error.code != KBXError.Code.SUCCESS:
                logger.error("Structured Index: Failed to obtain data in the table, the error message is as "
                             f"follows: {kbx_error.msg}. The default table is not empty.")
                return False
        return len(res) == 0

    def vectorization(self, text: str) -> List[float]:
        """向量化文本输入"""
        # 暂时预留该接口
        '''
        from kbx.kbx import KBX
        embedding_config, embedding_client = KBX.get_ai_model_config_and_client(
            self._index_config.embedding_model,
            user_id=self._index_config.user_ctx.user_id
        )
        embedding = embedding_client.text_embedding(embedding_config, text=text)
        return embedding
        '''
        raise NotImplementedError

    def _doc_exists_in_kb(self, doc_id: str) -> bool:
        """用以判断文档是否在该知识库中"""
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            res, _ = structured_ds.select(target_list=["table_name"],
                                          table_name=ImmutableTableConfig.get_info_table(),
                                          condition_list=[f"doc_id='{doc_id}'"])
        return True if res else False

    def insert_single_doc(self, doc_data: DocData) -> KBXError:
        """插入一个文档数据

        Args:
            doc_data (DocData): 待插入文档的DocData数据

        Returns:
            KBXError: 文档插入的错误信息
        """
        if not isinstance(doc_data, DocData):
            raise RuntimeError(f'Expect a doc of DocData, given {doc_data}')

        # 一个文档的表可能存储在多个数据库表，一个数据库表也可能有多个文档
        # TODO: 此处是否要求用户的输入的结构化文件必须有表头，不然每次调用大模型，可能会很慢
        # TODO: 无法判断表的第一行是否为表头，因此均自动化的生成表头；插入时，只有在column和当前生成列名相同，插入同一个表
        if self.is_external_datastore:
            raise RuntimeError(
                "The structured index module does not allow external knowledge bases to perform insert operations.")

        # TODO: 此处是否要求用户的输入的结构化文件必须有表头，不然每次调用大模型，可能会很慢
        # NOTE: 当前只有在同一个文档的不同表才可能插入到同一个数据表中，不会出现跨文档插入同一个数据库表
        if self._doc_exists_in_kb(doc_data.doc_id):
            remove_res = self._remove_doc(doc_data.doc_id)
            if remove_res:
                logger.error("Structured Index: Failed to delete an existing document. "
                             f"The document data may be duplicated in the knowledge base {self._kb_id}.")

        doc_insert_err_msg: str = ''
        for doc_element in doc_data.doc_elements:
            if not doc_element.table or not doc_element.table.is_standard:
                continue

            # TODO: v0.2支持非结构化文档时，需要处理doc_element.table[:5]过长的问题
            # TODO: 如果doc_element.table.has_header为True，则可以省略下面的分析
            top_n_data = doc_element.table.data_2d[:5]
            is_header = False
            columns: List[str] = []
            if len(doc_element.table.data_2d) > 1:
                is_header = TableSchemaGenerator.is_header_row(
                    header=doc_element.table.data_2d[0],
                    data=doc_element.table.data_2d[1:5]
                )
                if is_header:
                    columns = [TableSchemaGenerator.convert_str(c) for c in doc_element.table.data_2d[0]]
                    if not all(TableSchemaGenerator.validate_str(c) for c in columns):
                        columns = []
            if not columns:
                columns: List[str] = self.table_schema_generator.generate_table_columns_name(
                    file_name=doc_data.file_name, table_caption=doc_element.table.caption, text=top_n_data)

            # TODO: 目前插入时，需要保证一个文档一个表，excel可以允许不同sheet如果数据一致，保存在同一个表？
            attrs = {
                pc: [ImmutableTableConfig.get_predefined_column_types()[pc], True, "", ""]
                for pc in ImmutableTableConfig.get_predefined_columns() if pc != "id"
            }
            for i, c in enumerate(columns):
                rows_data = doc_element.table.data_2d[1:5] if is_header else top_n_data
                data_type = TableSchemaGenerator.infer_column_type([d[i] for d in rows_data])
                attrs[c] = [data_type]

            existed_table_names = self.table_schema_generator.find_existed_table_name(
                existed_tables=self.table_schema_generator.get_table_columns(exclude_columns=["id"]),
                generated_table_columns=[f"{key} {values[0]}" for key, values in attrs.items() if key != "id"])

            table_name: str = self.table_schema_generator.generate_table_name(file_name=doc_data.file_name,
                                                                              table_caption=doc_element.table.caption,
                                                                              text=top_n_data,
                                                                              existed_table_names=existed_table_names,
                                                                              doc_id=doc_data.doc_id)
            # 目前一个table一个数据库表，只有在同文件下，两个表数据类型相同和生成的数据库表名相同才可合并为一个表
            if table_name not in existed_table_names:
                columns_comment = self.table_schema_generator.generate_table_columns_comment(
                    file_name=doc_data.file_name,
                    table_caption=doc_element.table.caption,
                    text=top_n_data,
                    columns_name=columns)
                for i, c in enumerate(columns):
                    attrs[c].extend([False, "", columns_comment[i]])
                # TODO: tabel_comment是否在生成列名和列的comment时给到llm
                table_comment = self.table_schema_generator.generate_table_comment(
                    file_name=doc_data.file_name,
                    table_caption=doc_element.table.caption,
                    text=top_n_data,
                    table_name=table_name)
                with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
                    kbx_error = structured_ds.create_table(table_name=table_name,
                                                           attr=attrs,
                                                           comment=table_comment,
                                                           index={"index": ["doc_id", "doc_element_id", "chunk_id"]})
                    structured_ds.flush()
                if kbx_error.code != KBXError.Code.SUCCESS:
                    doc_insert_err_msg += "\n" + kbx_error.msg
                    continue
            # TODO: 一个文档的多个table，有的成功有的失败，如何处理,把之前插入的都删除？要求用户在重新调用
            # insert 函数之前调用remove?
            with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
                kbx_error = structured_ds.insert(table_name=ImmutableTableConfig.get_info_table(),
                                                 item={"doc_id": doc_data.doc_id, "table_name": table_name}
                                                 )
                structured_ds.flush()
            if kbx_error.code != KBXError.Code.SUCCESS:
                # TODO: 同一个文档的多个table可能会插入同一个数据库表中，因此，此处暂时不记录错误信息
                pass

            total_data: List[Dict[str]] = []
            for i, row in enumerate(doc_element.table.data_2d):
                if is_header and i == 0:
                    continue
                row_data = {c: row[ci] for ci, c in enumerate(columns)}
                for col in ImmutableTableConfig.get_predefined_columns():
                    if col == "chunk_id":
                        row_data["chunk_id"] = str(i)
                    try:
                        row_data[col] = getattr(doc_data, col)
                    except Exception:
                        try:
                            row_data[col] = getattr(doc_element, col)
                        except Exception:
                            pass
                total_data.append(row_data)
            # TODO: 部分插入成功的问题需要抛出
            # 重复插入由datastore校验
            with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
                kbx_error = structured_ds.batch_insert(table_name=table_name, item_list=total_data)
                structured_ds.flush()
            if kbx_error.code != KBXError.Code.SUCCESS:
                # TODO: 此处可能会出现某个doc_element插入失败的情况，需要确认错误的返回结构
                doc_insert_err_msg += "\n" + kbx_error.msg
        if doc_insert_err_msg:
            return KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=doc_insert_err_msg)
        # logger.info(f"Structured Index: {doc_data.file_name} into the knowledge base {self._kb_id} successfully.")
        return KBXError()

    def get_legal_config_attr_changes(self) -> List[str]:
        """获取本Index允许修改的配置属性
        Returns:
            List[str]: 允许修改的配置属性Key列表
        """
        # TODO: @huaqiao，补充允许修改的合法配置属性
        return DefaultStructuredIndex.mutable_config

    def validate_index_config_changes(self, config_diff: Dict[str, Any]) -> KBXError:
        """检查Index配置修改是否合法，如果存在不允许的修改，返回（所有）对应的错误信息

        Args:
            config_diff (Dict[str, Any]): Index配置发生变动的部分

        Returns:
            KBXError: 错误信息
        """
        # TODO: @huaqiao，当前直接禁止修改配置，后续根据需要对此函数重新实现
        error_configs = []
        for k, v in config_diff.items():
            if k not in DefaultStructuredIndex.mutable_config:
                error_configs.append(k)
                continue
            if k in ["max_related_tables", "generate_iters"]:
                if v <= 0:
                    logger.error(f"Structured Index: Parameter \'{k}\' must be greater than 0, but got {v}.")
                    error_configs.append(k)

        if len(error_configs) > 0:
            return KBXError(code=KBXError.Code.INVALID_VALUE,
                            msg=f"Illegal structured index config changes: {error_configs}")

        return KBXError()

    def modify_index_config(self, new_index_config: StructuredIndexConfig) -> Tuple[KBXError, bool]:
        """修改本Index的配置

        Args:
            new_index_config (StructuredIndexConfig): 新的Index配置

        Returns:
            Tuple[KBXError, bool]: 第一项表示本次配置修改是否成功，第二项表示是否需要reindex，
                注意，只有在第一项为SUCCESS的情况下第二项才可能为True
        """
        # 比较新旧配置的差异
        config_diff = get_pydantic_config_changes(self._index_config, new_index_config, recursive=True)
        kbx_error = self.validate_index_config_changes(config_diff)
        if kbx_error.code != KBXError.Code.SUCCESS:
            return kbx_error, False
        self._index_config = new_index_config
        self._reinitialize_instances_from_config()
        return KBXError(), False

    def _reinitialize_instances_from_config(self):
        self.retriver = NLSQLRetriever(kb_id=self._kb_id, index_config=self._index_config)
        self.table_schema_generator = TableSchemaGenerator(kb_id=self._kb_id, index_config=self._index_config)

    def reindex(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        """对部分文档重新建立索引"""
        # 结构化数据库索引无该需求
        if self.is_external_datastore:
            raise RuntimeError(
                "The structured index module does not allow external knowledge bases to perform reindex operations")
        return

    def reindex_all(self) -> Optional[List[Tuple[str, str]]]:
        """对全部文档重新建立索引"""
        # 结构化数据库索引无函数功能需求
        if self.is_external_datastore:
            raise RuntimeError(
                "The structured index module does not allow external knowledge bases to perform reindex_all operations")
        return

    def _remove_doc(self, doc_id: str) -> Optional[Tuple[str, str]]:
        # 外部数据库由datastore层抛出错误
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            selected_info_table, kbx_error = structured_ds.select(target_list=["table_name", "id"],
                                                                  table_name=ImmutableTableConfig.get_info_table(),
                                                                  condition_list=[f"doc_id='{doc_id}'"])
            if kbx_error.code != KBXError.Code.SUCCESS:
                logger.error(
                    "Structured Index: Failed to find the data storage table from information record "
                    f"table {ImmutableTableConfig.get_info_table()}, the error message is as follows: {kbx_error.msg}")
                return (doc_id, kbx_error.msg)

            doc_delete_res: List[str, str] = []
            if selected_info_table:
                for it_res in selected_info_table:
                    selected_res, kbx_error_sec = structured_ds.select(target_list=["id"],
                                                                       table_name=it_res['table_name'],
                                                                       condition_list=[f"doc_id='{doc_id}'"])
                    if kbx_error_sec.code != KBXError.Code.SUCCESS:
                        # 此时说明该表不存在，只需要把信息记录表中数据删除即可
                        structured_ds.delete(item_id=str(it_res["id"]),
                                             table_name=ImmutableTableConfig.get_info_table())
                        structured_ds.flush()
                        continue
                    kbx_error = structured_ds.batch_delete(item_ids=[str(sr['id']) for sr in selected_res],
                                                           table_name=it_res['table_name'])
                    structured_ds.flush()

                    if self._validate_table_empty(table_name=it_res['table_name']):
                        drop_kbx_error = structured_ds.drop_table(table_name=it_res['table_name'])
                        structured_ds.flush()
                        if drop_kbx_error.code != KBXError.Code.SUCCESS:
                            logger.error(f"Structured Index: Failed to delete table {it_res['table_name']}, "
                                         f"the error message is as follows: {drop_kbx_error.msg}")
                    if kbx_error.code != KBXError.Code.SUCCESS:
                        doc_delete_res = [doc_id, kbx_error.msg]

                    if kbx_error.code == KBXError.Code.SUCCESS:
                        kbx_error = structured_ds.delete(item_id=str(it_res["id"]),
                                                         table_name=ImmutableTableConfig.get_info_table())
                        structured_ds.flush()
                        if kbx_error.code != KBXError.Code.SUCCESS:
                            if doc_delete_res:
                                doc_delete_res[1] += f"\n {kbx_error.msg}"
                            else:
                                doc_delete_res = [doc_id, kbx_error.msg]
        if doc_delete_res:
            return tuple(doc_delete_res)
        return

    def remove_docs(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        """删除一个或多个文档的索引数据"""
        if self.is_external_datastore:
            raise RuntimeError(
                "The structured index module does not allow external knowledge bases to perform deletion operations.")
        remove_res = []
        for doc_id in doc_ids:
            rem_es = self._remove_doc(doc_id)
            if rem_es:
                remove_res.append(rem_es)
        if remove_res:
            return remove_res
        logger.debug(f"Structured Index: delete docs from knowledge base {self._kb_id}: {doc_ids}")
        return

    def remove_index(self) -> None:
        """删除全部索引数据"""

        # 删除本index对应的所有持久化数据，例如调用xx_ds.delete_ds()
        # NOTE: 之后如果添加了其他datastore的使用，可能需要补充删除逻辑
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            structured_ds.delete_ds()

    def retrieve(self, query: QueryConfig, selected_doc_ids: Optional[List[str]] = None) -> Iterator[QueryResults]:
        """查询知识库"""
        if query.top_k <= 1:
            retrieval_res = self.retriver.retrieve(query=query)
            retrieval_res.is_final = True
            yield retrieval_res
            return
        # TODO: 目前考虑原始query作为k中的一个，生成k-1个query
        queries = [copy.deepcopy(query) for _ in range(query.top_k)]
        generated_queries = self.table_schema_generator.generate_content(prompt_key="multi_queries",
                                                                         separator="\n",
                                                                         **{
                                                                             "K": query.top_k - 1,
                                                                             "query": query.text,
                                                                         })
        logger.debug(f"Structured Index: The {query.top_k - 1} queries generated "
                     f"based on the original {query.text} are as follows: {generated_queries}")
        for i in range(0, min(query.top_k - 1, len(generated_queries))):
            if generated_queries[i]:
                queries[i + 1].text = generated_queries[i]

        results = QueryResults()
        from kbx.kbx import KBX
        with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as pool:
            future_results = [pool.submit(self.retriver.retrieve, query=query) for query in queries]
            for future in future_results:
                res = future.result()
                if res:
                    results.extend(res)
        results.is_final = True
        yield results
