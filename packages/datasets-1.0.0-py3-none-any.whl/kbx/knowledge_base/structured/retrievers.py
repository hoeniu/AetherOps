import re
import random
from concurrent.futures import ThreadPoolExecutor
from typing import List, Dict, Any, Tuple, Union, Optional
import json

from kbx.common.logging import logger

from kbx.common.prompt import get_category_prompts
from kbx.datastore.ds_factory import get_structured_datastore

from kbx.common.types import KBXError
from kbx.datastore.structured.sqlite_generator import SqliteGenerator
from kbx.knowledge_base.structured.table_schema import ImmutableTableConfig
from kbx.knowledge_base.types import StructuredIndexConfig, QueryConfig, QueryResult, \
    IndexType, StructuredQueryResult, QueryResults


class TableRetriever:
    """table和sql查询语句已知检索类"""
    def __init__(self, index_config: StructuredIndexConfig, kb_id: str) -> None:
        self._index_config = index_config
        self._kb_id = kb_id
        from kbx.kbx import KBX
        if index_config.external_structured_ds:
            self._structured_ds_type = index_config.external_structured_ds.type
        else:
            self._structured_ds_type = KBX.config.structured_ds.type
        if self._structured_ds_type.startswith("sqlalchemy_"):
            self._structured_ds_type = self._structured_ds_type.replace("sqlalchemy_", "")
        self._prompts = get_category_prompts(category='structured')
        self.chat_config, self.chat_client = KBX.get_ai_model_config_and_client(
            self._index_config.llm_model, user_id=index_config.user_ctx.user_id)
        sql_gen_llm_model = self._index_config.sql_gen_llm_model
        if not sql_gen_llm_model:
            sql_gen_llm_model = self._index_config.llm_model
        self.sql_gen_chat_config, self.sql_gen_chat_client = KBX.get_ai_model_config_and_client(
            sql_gen_llm_model, user_id=index_config.user_ctx.user_id)

    def retrieve(self, query: QueryConfig, sql: Union[Dict[str, str], str]) -> QueryResults:
        """允许一个数据库表可以有多条sql语句"""
        # TODO: v0.2需要支持表格的递归检索
        # TODO: 外部数据库下述代码做一下修改
        if not sql:
            raise ValueError("Please provide SQL statement.")
        if isinstance(sql, str):
            extracted_table, _ = SqliteGenerator.extract_table_names_v2(sql, dialect=self._structured_ds_type)
            sql = {",".join(extracted_table): sql}
        query_results = QueryResults()
        # TODO: v0.2后续可以增加多表联合查询和单表生成sql语句的结果
        # TODO: 增加sql语句的日志输出
        for table_name_str, select_sql in sql.items():
            execute_res, kbx_error = self._validate_and_run_select_sql(select_sql)
            select_sql = select_sql.replace("\n", " ")
            if kbx_error.code != KBXError.Code.SUCCESS:
                logger.error(
                    f"Structured Index: The {table_name_str} statement of {select_sql} is executed incorrectly. "
                    f"The error message is as follows: {kbx_error.msg}")
                continue
            # 插入时保证一个表只能来自同一个文档
            if execute_res["data"]:
                # 处理可能存在的[{'AVG(gdp)': None}]的情况
                execute_res_tmp = []
                for item in execute_res["data"]:
                    existed_item_data = {k: v for k, v in item.items() if not isinstance(v, type(None))}
                    if existed_item_data:
                        execute_res_tmp.append(existed_item_data)
                execute_res["data"] = execute_res_tmp

            if not execute_res["data"]:
                logger.debug("Structured Index: The execution result of the currently "
                             f"generated SQL statement {select_sql} is empty.")
                continue

            logger.info(f"Structured Index: The generated SQL query statement is as follows: {select_sql}")
            table_name_list = table_name_str.split(",")
            table_info_dict: Dict[str, Dict[str, Any]] = {}
            doc_ids: Dict[str, str] = {}
            with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
                for tn in table_name_list:
                    table_info_dict[tn] = {}
                    table_info_dict[tn]["columns"] = [
                        re.search(r"\((.*?)\)", k).group(1) if "(" in k and ")" in k else k
                        for k, _ in execute_res["data"][0].items()
                    ]

                    selected_res, select_kbx_error = structured_ds.select(
                        target_list=["doc_id", "doc_element_id", "chunk_id"], table_name=tn, condition_list=[])
                    (table_info, table_comment), show_kbx_error = structured_ds.show_create_table(table_name=tn)

                    if select_kbx_error.code != KBXError.Code.SUCCESS or not selected_res:
                        logger.error("Structured Index: Failed to get doc_id "
                                     f"from table {tn}, the error message is: {select_kbx_error.msg}.")
                    if selected_res:
                        doc_ids[tn] = selected_res[0]["doc_id"]

                    if show_kbx_error.code == KBXError.Code.SUCCESS:
                        if table_comment:
                            table_info_dict[tn]["comment"] = table_comment
                        if table_info:
                            column_comments = [
                                ti[-1] for column in table_info_dict[tn]["columns"] for ti in table_info
                                if ti[0] == column
                            ]
                            if column_comments:
                                table_info_dict[tn]["column_comments"] = column_comments

            text = "\n".join(["; ".join([f"{k}: {str(v)}" for k, v in res.items()]) for res in execute_res["data"]])
            text = self._prompts["query_result_cat"](template_type="text",
                                                     **{
                                                         "data": text,
                                                         "table_name": table_name_str,
                                                         "sql": select_sql
                                                     })
            score = self._generate_score(text=text, query=query.text)
            query_result = QueryResult(kb_id=self._kb_id, score=score, index_type=IndexType.STRUCTURED)
            meta_data: Dict[str, Any] = {}
            meta_data["doc_ids"] = doc_ids
            if len(table_name_list) > 1:
                meta_data["joint_query"] = True
            else:
                meta_data["joint_query"] = False
            query_result.structured_result = StructuredQueryResult(sql=select_sql,
                                                                   table_info_dict=table_info_dict,
                                                                   data=[[str(rv) for _, rv in res.items()]
                                                                         for res in execute_res["data"]],
                                                                   text=text,
                                                                   meta_data=meta_data)
            if doc_ids:
                query_result.doc_id = doc_ids[list(doc_ids.keys())[0]]
            query_results.append(query_result)

        return query_results

    def _validate_and_run_select_sql(self, sql: str) -> Tuple[Optional[Dict[str, Any]], KBXError]:
        """检查sql语句是否合法"""
        # TODO: sqlfluff/sqlite3/执行如果抛出错误即语句不合法，且需要考虑
        # TODO: 是否此处仅允许执行select语句, 为了方便把sql语句的执行的错误信息给到大模型，此函数实现校验和执行sql语句两种功能
        if not sql.lower().startswith('select'):
            # TODO: 明确结构化数据库的查询语句均为select吗
            msg = "The SQL statement obtained is not a select statement. " + \
                  "Currently only select statements are supported."
            return None, KBXError(code=KBXError.Code.INTERNAL_ERROR, msg=msg)
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            data, kbx_error = structured_ds.execute_sql(sql=sql)
        return data, kbx_error

    def _generate_score(self, text: str, query: str) -> float:
        # TODO: v0.2可以考虑增加embedding模型
        system_prompt = self._prompts['generate_score'].text
        user_input = (f"查询问题：{query}\n{text}")
        response = self.chat_client.chat(
            self.chat_config,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_input},
            ],
        ).choices[0].message.content
        response_json = json.loads(response.strip().lstrip('```json').strip('```'))
        try:
            score = float(response_json["overall_score"]["score"])
            if score < 0 or score > 1:
                score = 0.0
            return score
        except Exception:
            return 0.0


class SQLRetriever(TableRetriever):
    """table已知和sql查询需要生成的检索类"""
    def __init__(self, index_config: StructuredIndexConfig, kb_id: str) -> None:
        super().__init__(index_config=index_config, kb_id=kb_id)

    def retrieve(self, query: QueryConfig, tables: Union[List[str], str] = None) -> QueryResults:
        """llm生成sql语句"""
        if not tables:
            tables = self._index_config.tables

        if self._index_config.sql:
            return super().retrieve(query=query, sql=self._index_config.sql)

        if not tables:
            raise ValueError("Please provide Tables.")

        if ImmutableTableConfig.get_info_table() in tables:
            tables.remove(ImmutableTableConfig.get_info_table())
        # TODO: 可能涉及多个数据库的多个表
        if isinstance(tables, str):
            tables = [tables]

        tables_info: Dict[str, str] = {}
        for table in tables:
            table_info = self._get_single_table_info(table)
            if not table_info:
                logger.error(f"Structured Index: Failed to obtain information about table {table}.")
                continue
            tables_info[table] = table_info
        sql = self._generate_sql(query=query.text,
                                 info="\n\n".join(list(tables_info.values())),
                                 tables_name=list(tables_info.keys()))
        if not sql:
            return QueryResults(results=[])
        # 存在不会使用table_info中所有表的情况
        extracted_table, _ = SqliteGenerator.extract_table_names_v2(sql, dialect=self._structured_ds_type)
        sqls = {",".join(extracted_table): sql}

        return super().retrieve(query=query, sql=sqls)

    def _generate_sql(self, query: str, info: str, tables_name: List[str]) -> str:
        """生成sql语句"""
        text = self._prompts['text2sql'](template_type="text",
                                         **{
                                             "structured_base_type": self._structured_ds_type,
                                             "tables_name": ",".join(tables_name),
                                             "schema": info,
                                             "query": query,
                                         })

        sql = ""
        tmp_text = text
        for _ in range(self._index_config.generate_iters):  # 是否需要把错误信息给到大模型
            response = self.sql_gen_chat_client.chat(
                self.sql_gen_chat_config,
                messages=[
                    {"role": "user", "content": tmp_text},
                ],
                stream=False
            ).choices[0].message.content
            sql = self._parse_response_to_sql(response=response)
            _, kbx_error = self._validate_and_run_select_sql(sql=sql)
            if kbx_error.code == KBXError.Code.SUCCESS:
                break
            tmp_text = text + self._prompts['generate_sql_error'](template_type="text",
                                                                  **{
                                                                      "sql": sql,
                                                                      "error_msg": kbx_error.msg,
                                                                  })
        # TODO: 增加日志
        return sql

    def _parse_response_to_sql(self, response: str) -> str:
        """解析response to SQL."""
        if response.startswith("[SQL]"):
            response = response[len("[SQL]"):]
        raw_sql_str = response.strip().strip("```").strip("sql").strip()
        if "```" in raw_sql_str:
            raw_sql_str = raw_sql_str.split("```")[1]
            raw_sql_str = raw_sql_str.strip().strip("sql").strip()
        return raw_sql_str

    def _get_single_table_info(self, table_name: str) -> str:
        """获取表的信息."""
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            (table_info, table_comment), kbx_error = structured_ds.show_create_table(table_name=table_name)
        if kbx_error.code != KBXError.Code.SUCCESS:
            logger.error(f"Structured Index: Failed to obtain the field content of {table_name}, "
                         f"the error message is as follows: {kbx_error.msg}")
            return ""
        template = "Table '{table_name}' has columns: {columns}"
        if table_comment:
            template += f"\nTable '{table_name}' comment is: ({table_comment}) "

        columns_info_cat = []
        column_comments = {}
        for column in table_info:
            if column[0] in ImmutableTableConfig.get_predefined_columns():
                continue
            column_comments[column[0]] = column[-1]
            column_info = ""
            for i in range(len(column) - 1):
                column_info += " " + str(column[i])
            columns_info_cat.append(column_info)
        columns_info_str = ", ".join(columns_info_cat)
        # TODO: 增加关联的表，外键信息, template += "{foreign_keys}."
        targets = ",".join(list(column_comments.keys()))
        # NOTE: 实际测试下来在GDP查询场景下，增加每列的注释信息会导致查询结果不准确，暂时不增加每列注释信息
        # if column_comments:
        #     column_comments_str = "; ".join([f"The comment for column '{key}' is: ({value})"
        #                                      for key, value in column_comments.items()])
        #     template += f" \nThe comments for each column of table {table_name} are as " + \
        #     f"follows: {column_comments_str} .\n"
        # TODO: mysql/sqlite数据库支持LIMIT，如何后续其他数据库可能LIMIT可能需要修改
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            data, kbx_error = structured_ds.execute_sql(sql=f"SELECT {targets} FROM {table_name} LIMIT 1;")
        if kbx_error.code == KBXError.Code.SUCCESS and data["data"]:
            string_data = ", ".join(f"{key} : {value}" for key, value in data["data"][0].items())
            template += f" \nThe table '{table_name}' sample data for each column is as follows: ({string_data}) .\n"
        return template.format(table_name=table_name, columns=columns_info_str, )


class NLSQLRetriever(SQLRetriever):
    """table未知和sql查询需要生成的检索类"""
    def __init__(self, index_config: StructuredIndexConfig, kb_id: str) -> None:
        super().__init__(index_config=index_config, kb_id=kb_id)
        self._select_table_max_depth = 5
        self._select_table_batch = 50
        self._predefined_max_context_len = self.chat_config.max_context_len * 0.8

    def retrieve(self, query: QueryConfig) -> QueryResults:
        """llm生成sql语句和获取待查询的表"""
        if self._index_config.tables:
            return super().retrieve(query=query, tables=self._index_config.tables)

        selected_tables = self._select_relevant_tables(query=query)
        if selected_tables:
            return super().retrieve(query=query, tables=selected_tables)
        return QueryResults(results=[])

    def _select_relevant_tables(self, query: QueryConfig) -> List[str]:
        """通过llm大模型筛选出相关的表"""
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            existed_tables, _ = structured_ds.show_tables()
        if existed_tables and ImmutableTableConfig.get_info_table() in existed_tables:
            existed_tables.remove(ImmutableTableConfig.get_info_table())
        if not existed_tables:
            return []
        random.shuffle(existed_tables)
        group_selected_tables = self._group_and_select_relevant_tables(text=query.text, tables=existed_tables, depth=0)
        if group_selected_tables and len(group_selected_tables) <= self._index_config.max_related_tables:
            return group_selected_tables
        # NOTE: 如果采用table的comment提前进行筛选，需要保证必须存在表的注释。但是会有表不存在comment的情况，因此暂时不采用表的comment进行筛选
        selected_tables = self._select_relevant_table(text=query.text,
                                                      tables=group_selected_tables[:self._select_table_batch],
                                                      prompt_key="select_table",
                                                      **{"top_k": self._index_config.max_related_tables})

        if not selected_tables:
            selected_tables = existed_tables
        return selected_tables[:self._index_config.max_related_tables]

    def _group_and_select_relevant_tables(self, text: str, tables: List[str], depth=0) -> List[str]:
        """使用LLM分批次选择相关表"""

        if depth >= self._select_table_max_depth:
            return tables
        if not tables:
            return tables

        selected_tables: List[str] = []
        pre_lenght = len(self._prompts["select_table"].text) + len(text)
        group_tables = self._partition_tables_by_context_length(tables=tables, pre_lenght=pre_lenght)

        from kbx.kbx import KBX
        with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as pool:
            future_results = [
                pool.submit(self._select_relevant_table, text=text, tables=tables, prompt_key="select_table",
                            ) for tables in group_tables
            ]
            for future in future_results:
                res = future.result()
                if res:
                    selected_tables.extend(res)
        # NOTE: 当len(selected_tables) == self._index_config.max_related_tables + 1且selected_table == batch_size时，
        # 继续执行递归会导致选择出的表可能小于max_related_tables，可能最后选出的表会小于max_related_tables。但通常情况下，选择出的表数量也
        # 可能会小于max_related_tables，因此该情况应为正常情况
        if len(selected_tables) > self._select_table_batch and len(
                selected_tables) > self._index_config.max_related_tables:
            selected_tables = self._group_and_select_relevant_tables(text=text, tables=selected_tables, depth=depth + 1)

        return selected_tables

    def _partition_tables_by_context_length(self, tables: List[str], pre_lenght: int) -> List[List[str]]:
        """把所有的表数据按照不超过预定义的最大上下文长度进行拆分, 返回拆分后的tables"""

        tables_info = {table: self._get_single_table_info(table) for table in tables}
        if not tables_info:
            return []
        batch_tables: List[List[Dict[str, str]]] = []
        cur_length = pre_lenght
        current_batch: List[Dict[str, str]] = []
        batch_sizes: List[int] = []
        for table, table_info in tables_info.items():
            data_length = len(table) + len(table_info)
            if cur_length + data_length > self._predefined_max_context_len:
                batch_sizes.append(len(current_batch))
                batch_tables.append(current_batch)
                cur_length = pre_lenght + data_length
                current_batch = [table]
            else:
                cur_length += data_length
                current_batch.append(table)
        if current_batch:
            batch_tables.append(current_batch)
        # 更新batch_size
        if batch_sizes:
            self._select_table_batch = sum(batch_sizes) // len(batch_sizes)
        return batch_tables

    def _select_relevant_table(self, text: str, tables: List[str], prompt_key: str, **kwargs) -> List[str]:
        """使用LLM选择单batch内相关表"""
        if not tables:
            return []
        # TODO: 增加tokens估算（可以拍一个默认的最大token数据）
        # TODO: 让大模型从每个batch选择max_related_tables个表，超过max_related_tables个表时，做截断
        # 需要不需要在内部再保存max_depth参数，
        tables_info = {table: self._get_single_table_info(table) for table in tables}
        if not tables_info:
            return []
        kwargs["tables"] = ",".join(tables)
        kwargs["tables_info"] = ";".join(list(tables_info.values()))
        kwargs["query"] = text
        kwargs["top_k"] = self._index_config.max_related_tables
        prompt = self._prompts[prompt_key](template_type="text", **kwargs)
        response = self.chat_client.chat(
            self.chat_config,
            messages=[
                {"role": "user", "content": prompt},
            ],
            stream=False
        ).choices[0].message.content
        selected_tables = [table for table in response.split(",") if table in tables_info]
        return selected_tables[:self._index_config.max_related_tables]
