import re
from enum import Enum
from typing import List, Dict, Union, Optional

from kbx.common.logging import logger

from kbx.common.utils import generate_new_id
from kbx.common.prompt import get_category_prompts
from kbx.datastore.ds_factory import get_structured_datastore

from kbx.common.types import KBXError
from kbx.knowledge_base.types import StructuredIndexConfig


class ImmutableTableConfig(Enum):
    INFO_TABLE = "info_table"
    PREDEFINED_COLUMNS = {
        "id": "VARCHAR(64)",
        "doc_id": "VARCHAR(64)",
        "file_name": "VARCHAR(255)",
        "file_path": "TEXT",
        "doc_element_id": "VARCHAR(64)",
        "chunk_id": "VARCHAR(64)"
    }

    @classmethod
    def get_info_table(cls):
        """获取信息表名"""
        return cls.INFO_TABLE.value

    @classmethod
    def get_predefined_columns(cls):
        """获取默认数据字段"""
        return list(cls.PREDEFINED_COLUMNS.value.keys())

    @classmethod
    def get_predefined_column_types(cls):
        """获取默认数据字段的类型"""
        return cls.PREDEFINED_COLUMNS.value


class TableSchemaGenerator:
    def __init__(self, kb_id: str, index_config: StructuredIndexConfig) -> None:
        self._index_config = index_config
        self._kb_id = kb_id
        self._prompts = get_category_prompts(category="structured")

    @staticmethod
    def validate_str(text: str) -> bool:
        """验证生成的str是否合法"""
        pattern = re.compile(r'[，。！？；：“”‘’（）【】—《》〈〉、·!"#$%&\'()*+\-./:;<=>?@[\\\]^`{|}~]|\s')
        return not bool(pattern.search(text))

    @staticmethod
    def convert_str(text: str) -> str:
        """将不合法字符（包括中文标点符号、空格等）转换为英文下划线"""
        if text and text[0].isdigit():
            text = '_' + text
        # 通过正则替换掉任何不是字母、数字、下划线、或中文字符的符号
        text = re.sub(r'[，。！？；：“”‘’（）【】—《》〈〉、·!"#$%&\'()*+,\-./:;<=>?@[\\\]^_`{|}~]|\s', '_', text)
        return text.lower()

    def generate_content(self,
                         prompt_key: str,
                         error_msg: Optional[str] = None,
                         separator: Optional[str] = None,
                         **kwargs) -> Union[List[str], str]:
        """调用大模型生成内容"""
        from kbx.kbx import KBX
        chat_config, chat_client = KBX.get_ai_model_config_and_client(
            self._index_config.llm_model, user_id=self._index_config.user_ctx.user_id)
        query = self._prompts[prompt_key](template_type="text", **kwargs)
        if error_msg:
            query += self._prompts["generate_content_error"](template_type="text", **{"error_msg": error_msg})
        response = chat_client.chat(
            chat_config,
            messages=[
                {"role": "user", "content": query},
            ],
        ).choices[0].message.content

        if not separator:
            return response
        return [r.strip() for r in response.split(separator) if r.strip()]

    def find_existed_table_name(self, existed_tables: Dict[str, List[str]], generated_table_columns: List[str],
                                ) -> List[str]:
        target_columns = set([gtc.lower() for gtc in generated_table_columns])
        existed_table_names = []
        for table_name, columns in existed_tables.items():
            columns = [c.lower() for c in columns]
            if set(columns) == target_columns:
                existed_table_names.append(table_name)
        return existed_table_names

    def get_table_columns(self, exclude_columns: List[str] = []) -> Dict[str, List[str]]:
        """获取当前数据库内所有表的列和列的类型"""
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            existed_tables, kbx_error = structured_ds.show_tables()

            tables_columns: Dict[str, List[str]] = {}
            if kbx_error.code != KBXError.Code.SUCCESS:
                logger.error("Structured Index: Failed to obtain all tables in the current database. "
                             f"The error message is as follows: {kbx_error.msg}")
                return tables_columns

            for table_name in existed_tables:
                (table_info, _), kbx_error = structured_ds.show_create_table(table_name=table_name)
                if kbx_error.code != KBXError.Code.SUCCESS:
                    continue
                tables_columns[table_name] = [
                    f"{column_info[0]} {column_info[1]}" for column_info in table_info
                    if column_info[0] not in exclude_columns
                ]
        return tables_columns

    def generate_table_name(self, file_name: str, table_caption: str, text: List[List[str]],
                            existed_table_names: List[str], doc_id: str) -> str:
        """插入时自动生成表名"""
        data = "\n".join([", ".join(row) for row in text])
        params = {
            "file_name": file_name,
            "table_caption": table_caption,
            "data": data,
            "existed_table_names": ",".join(existed_table_names)
        }
        existed_doc2table: Dict[str, List[str]] = {}
        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            for etn in existed_table_names:
                selected_res, kbx_error = structured_ds.select(target_list=["doc_id"],
                                                               table_name=etn,
                                                               condition_list=[])
                if kbx_error.code == KBXError.Code.SUCCESS:
                    # 理论上数据表中，仅存在一个doc_id
                    for did in selected_res:
                        existed_doc2table[did["doc_id"]] = etn

        response = self.generate_content(prompt_key="generate_table_name", **params).lower()

        with get_structured_datastore(self._kb_id, self._index_config) as structured_ds:
            existed_tables, kbx_error = structured_ds.show_tables()

        for _ in range(self._index_config.generate_iters):
            if TableSchemaGenerator.validate_str(response[:32]):
                if kbx_error.code == KBXError.Code.SUCCESS:
                    # 需要在同一个doc_id才返回相同的数据库中已有表名，一般只有在excel文件才会出现该情况
                    if existed_doc2table.get(doc_id) == response[:32]:
                        return response[:32]
                    if response[:32] in existed_tables:
                        response += generate_new_id().replace("-", "")
                        response = response.lower()
                    break
            error_msg = self._prompts["generate_table_name_error"].text
            response = self.generate_content(prompt_key="generate_table_name", error_msg=error_msg, **params).lower()
        if response[:32] in existed_tables:
            response = ("_" + generate_new_id().replace("-", ""))[:32].lower()
        return response[:32]

    def generate_table_comment(self, file_name: str, table_caption: str, text: List[List[str]], table_name: str) -> str:
        """插入时自动生成表的注释"""
        data = "\n".join([", ".join(row) for row in text])
        response = self.generate_content(prompt_key="generate_table_comment",
                                         **{
                                             "file_name": file_name,
                                             "table_caption": table_caption,
                                             "data": data,
                                             "table_name": table_name
                                         })
        return response

    def generate_table_columns_name(self, file_name: str, table_caption: str, text: List[List[str]]) -> List[str]:
        """插入时自动生成表的列名"""
        data = "\n".join([", ".join(row) for row in text])
        params = {"file_name": file_name, "table_caption": table_caption, "data": data, "num_columns": len(text[0])}
        response = self.generate_content(prompt_key="generate_table_columns", separator=",", **params)
        for _ in range(self._index_config.generate_iters):  # 是否需要把错误信息给到大模型
            response = [re.lower() for re in response]
            if not TableSchemaGenerator.validate_str("_".join(response)):
                error_msg = self._prompts["generate_table_columns_invalid_error"].text
                response = self.generate_content(prompt_key="generate_table_columns",
                                                 error_msg=error_msg,
                                                 separator=",",
                                                 **params)
                continue
            if len(response) != len(text[0]):
                error_msg = self._prompts["generate_table_columns_invalid_error"](template_type="text",
                                                                                  **{
                                                                                      "num_gen_columns": len(response),
                                                                                      "num_columns": len(text[0])
                                                                                  })
                response = self.generate_content(prompt_key="generate_table_columns",
                                                 error_msg=error_msg,
                                                 separator=",",
                                                 **params)
                continue
            if set(ImmutableTableConfig.get_predefined_columns()).intersection(set(response)):
                error_msg = self._prompts["generate_table_columns_repeat_error"](
                    template_type="text", **{
                        "columns_name": ', '.join(ImmutableTableConfig.get_predefined_columns())
                    })

                response = self.generate_content(prompt_key="generate_table_columns",
                                                 error_msg=error_msg,
                                                 separator=",",
                                                 **params)
                continue
            break

        # TODO: 后续是否优化为通过列的数据通过翻译等其他方式转为列名
        if not TableSchemaGenerator.validate_str("_".join(response).lower()) or len(response) != len(text[0]):
            # 随机生成列名
            response = [("_" + generate_new_id().replace("-", ""))[:16] for _ in range(len(text[0]))]
        return [re.lower() for re in response]

    def generate_table_columns_comment(self, file_name: str, table_caption: str, text: List[List[str]],
                                       columns_name: List[str]) -> List[str]:
        """适用插入时自动生成表的注释"""
        data = "\n".join([", ".join(row) for row in text])
        params = {
            "file_name": file_name,
            "table_caption": table_caption,
            "data": data,
            "columns_name": ",".join(columns_name),
            "num_columns": len(text[0])
        }
        response = self.generate_content(prompt_key="generate_table_columns_comment", separator="\n", **params)
        for _ in range(self._index_config.generate_iters):  # 是否需要把错误信息给到大模型
            if len(response) != len(text[0]):
                error_msg = self._prompts["generate_table_columns_comment_error"](template_type="text",
                                                                                  **{
                                                                                      "num_gen_comments": len(response),
                                                                                      "num_columns": len(text[0])
                                                                                  })
                response = self.generate_content(prompt_key="generate_table_columns_comment",
                                                 error_msg=error_msg,
                                                 separator="\n",
                                                 **params)
        if len(response) != len(text[0]):
            return ["" for _ in range(len(text[0]))]
        return response

    @staticmethod
    def infer_column_type(data: List[str]) -> str:
        """推断列的数据类型，优先尝试 BIGINT -> FLOAT -> TEXT"""
        int_pattern = re.compile(r"^[+-]?\d+$")
        float_pattern = re.compile(r"^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$")
        is_integer = True
        is_float = True
        if not [d for d in data if d.strip()]:
            return "TEXT"

        for value in data:
            value = value.strip()
            if not value:
                continue
            if is_integer and not int_pattern.match(value):
                is_integer = False
            if not is_integer and is_float and not float_pattern.match(value):
                is_float = False
            if not is_integer and not is_float:
                break

        if is_integer:
            return "BIGINT"
        if is_float:
            return "FLOAT"
        return "TEXT"

    @staticmethod
    def is_header_row(header: List[str], data: List[List[str]]) -> bool:
        """判断第一行是否为表头，通过检查第一行与后续多行数据类型的一致性"""
        # TODO： 表头和数据均为string如何处理（重要）
        if not header or not data:
            return False
        for col_idx in range(len(header)):
            header_type = TableSchemaGenerator.infer_column_type([header[col_idx]])
            data_type = TableSchemaGenerator.infer_column_type([row[col_idx] for row in data])
            # 给定多行data理论上需要触发实际存入的数据列的类型本身不一致的情况
            if header_type != data_type:
                return True
        return False
