from typing import Union, Optional, Any, List, Dict, Tuple
from pydantic import BaseModel, Field, model_validator
import enum
from datetime import datetime
from kbx.common.types import IndexType, Chunk, GraphDSConfig, UserContext, FileInfo, KBXError
from kbx.common.types import StructuredDSConfig, TokenCounterConfig, KBXBaseModel
from kbx.common.otel import try_get_trace_id
from kbx.ai_model.types import ChatMessage, AIModelBundle
from kbx.parser.types import DocParseConfig
from kbx.rerank.types import RerankConfig
from kbx.splitter.types import SplitterConfig


class DocStatus(str, enum.Enum):
    """表示某个文档当前状态"""
    UPLOADING = 'UPLOADING'
    UPLOAD_FAILED = 'UPLOAD_FAILED'
    UPLOAD_SUCCESS = 'UPLOAD_SUCCESS'
    PARSING = 'PARSING'
    PARSE_FAILED = 'PARSE_FAILED'
    PARSE_SUCCESS = 'PARSE_SUCCESS'
    INDEXING = 'INDEXING'
    INDEX_FAILED = 'INDEX_FAILED'
    INDEX_SUCCESS = 'INDEX_SUCCESS'


class DocType(str, enum.Enum):
    """表示文档文件的具体类型，用于区分以下情况

    - 普通文档 (NORMAL)：需要直接进行解析和索引的文档，如docx/pdf/md/csv/pptx/excel等
    - 资源文件 (RESOURCE)：不需要直接进行解析+索引的文件，仅保存为文件，例如md/html使用相对路径引用的图片、音频、视频等
    """
    NORMAL = 'NORMAL'
    RESOURCE = 'RESOURCE'


class DocInfo(KBXBaseModel):
    """表示知识库中某文档除去内容数据（DocData）以外需要保存的相关属性、状态信息"""

    doc_id: Optional[str] = Field(default=None, description="文档唯一id")

    doc_type: DocType = Field(
        default=DocType.NORMAL,
        description="表示本文件是“普通文档”还是“资源文件”"
    )

    raw_file_info: Optional[FileInfo] = Field(default=None, description="该文档原始文件信息")
    extra_files_info: List[FileInfo] = Field(
        default_factory=list,
        description="从该文档中提取出其他保存为文件的列表，例如pptx文件中的内嵌音频、视频等"
    )

    doc_parse_config: Optional[DocParseConfig] = Field(
        default=None, description="该文档专属的解析配置，默认为None，表示使用知识库的通用解析配置")

    err_info: KBXError = Field(default=KBXError(code=KBXError.Code.SUCCESS), description="该文档加入知识库后可能在某个处理环节出现的错误信息")
    doc_status: DocStatus = Field(
        default=DocStatus.UPLOADING,
        description="该文档目前所处的状态，如果该文档的整个处理流程没有出错且已完成，则为INDEX_SUCCESS"
    )

    # TODO: 其他字段，如tokens数量、分块数量、当前状态等
    # status: str


class KBInfo(KBXBaseModel):
    """表示知识库的一些基本信息"""

    kb_id: str = Field(description="知识库id")
    name: str = Field(description="知识库名称")
    description: str = Field(description="知识库描述")
    creation_time: datetime = Field(default_factory=datetime.now, description="知识库创建时间")


class BaseIndexConfig(KBXBaseModel):
    user_ctx: Optional[UserContext] = Field(
        default=None, init=False, repr=False,
        exclude=True, description="🔒【内部使用】用户上下文"
    )


class VectorKeywordIndexConfig(BaseIndexConfig):
    """某个知识库创建时，Keyword关键字搜索及Embedding向量检索相关配置参数"""
    index_strategy: str = Field(default='DefaultVectorKeywordIndex', description="索引策略，如果不清楚保持默认即可")
    splitter_config: SplitterConfig = Field(
        default=SplitterConfig(name='RecursiveTextSplitter'),
        description="向量检索分块配置"
    )

    # vector index相关配置
    text_embedding_model: Optional[str] = Field(default=None, description="embedding 模型名")

    # keyword index相关配置
    keyword_extractor: Optional[str] = Field(default='jieba', description="关键字提取方法")
    max_keywords_per_chunk: Optional[int] = Field(default=100, description="每个chunk中最多包含多少个关键字")

    def update_with_model_bundle(self, model_bundle: AIModelBundle) -> 'VectorKeywordIndexConfig':
        """使用模型配置更新当前配置

        Args:
            model_bundle (AIModelBundle): 模型配置

        Returns:
            VectorKeywordIndexConfig: 更新后的配置
        """
        if not self.text_embedding_model:
            self.text_embedding_model = model_bundle.text_embedding

        return self


class KnowledgeGraphIndexConfig(BaseIndexConfig):
    """某个知识库创建时，知识图谱检索相关配置参数"""
    index_strategy: str = Field(default='DefaultGraphIndex', description="索引策略实现，如果不清楚保持默认即可")
    llm_model: str = Field(default='', description="大语言模型")
    embedding_model: str = Field(default='', description="嵌入模型")
    schema_dict: Dict[str, List[Dict[str, Any]]] = Field(default_factory=dict, description="schema字典，具体格式规范见说明文档。")
    max_retry: int = Field(default=3, description="出错重试次数")
    splitter_config: SplitterConfig = Field(default=SplitterConfig(name='RecursiveTextSplitter',
                                                                   chunk_size=4096),
                                            description="知识图谱检索分块配置")
    external_graph_ds: Optional[GraphDSConfig] = Field(
        default=None, description="区别于"
        "KBX.config.graph_ds(内部知识库), 本字段用于配置连接外部知识库图谱. 如果不接入外部知识库, 本字段设置为None.")

    def update_with_model_bundle(self, model_bundle: AIModelBundle) -> 'KnowledgeGraphIndexConfig':
        """使用模型配置更新当前配置

        Args:
            model_bundle (AIModelBundle): 模型配置

        Returns:
            KnowledgeGraphIndexConfig: 更新后的配置
        """
        if not self.llm_model:
            self.llm_model = model_bundle.llm
        if not self.embedding_model:
            self.embedding_model = model_bundle.text_embedding

        return self


class DynamicDocIndexConfig(BaseIndexConfig):
    """某个知识库创建时，动态文档检索相关配置参数

    注意：
    - 用户在创建知识库时，原则上只选择是否开启此索引，不需要配置任何其他参数
    - 除index_strategy外，不添加额外的配置参数，llm/max_iter等agent相关参数在test-time根据实际传入的deep_think进行设置
    - 此类型不能删除，而且需要提供user_ctx动态注入
    """
    index_strategy: str = Field(default='AgenticDynamicDocIndex', description="索引策略，如果不清楚保持默认即可")

    def update_with_model_bundle(self, model_bundle: AIModelBundle) -> 'DynamicDocIndexConfig':
        """使用模型配置更新当前配置

        Args:
            model_bundle (AIModelBundle): 模型配置

        Returns:
            DynamicDocIndexConfig: 更新后的配置
        """

        # NOTE: 保持兼容性，不更新任何模型配置

        return self


class StructuredIndexConfig(BaseIndexConfig):
    """某个知识库创建时，结构化数据检索相关配置参数"""
    index_strategy: str = Field(default='DefaultStructuredIndex', description="索引策略，如果不清楚保持默认即可")
    llm_model: str = Field(default="", description="llm 模型名")
    sql_gen_llm_model: str = Field(default="", description="用于生成sql的llm 模型名")
    # embedding_model: Optional[str] = Field(default=None, description="embedding 模型名")
    tables: Union[List[str], str] = Field(default="", description="执行检索的表格")
    sql: Union[Dict[str, str], str] = Field(default="", description="执行检索的sql语句")
    max_related_tables: int = Field(default=5, description="大模型需要选取的与query相关的感兴趣表的最大数量")
    generate_iters: int = Field(default=5, description="大模型生成时的最大迭代生成次数, 适用于生成出错时")
    # 其他可能的meta信息
    meta_data: Dict[str, Any] = Field(default_factory=dict, description="用于记录, 在创建知识库时额外的一些记录信息")
    external_structured_ds: Optional[StructuredDSConfig] = Field(
        default=None, description="区别于"
        "KBX.config.structured_ds(内部知识库), 本字段用于配置连接外部知识库. 如果不接如外部知识库, 本字段设置为None.")

    def update_with_model_bundle(self, model_bundle: AIModelBundle) -> 'StructuredIndexConfig':
        """使用模型配置更新当前配置

        Args:
            model_bundle (AIModelBundle): 模型配置

        Returns:
            StructuredIndexConfig: 更新后的配置
        """
        if not self.llm_model:
            self.llm_model = model_bundle.llm
        if not self.sql_gen_llm_model:
            self.sql_gen_llm_model = model_bundle.llm

        return self


class KBCreationConfig(KBXBaseModel):
    """用于创建一个新知识库的配置参数，创建成功后自动生成一个唯一的kb_id，用于后续管理"""
    name: str = Field(default='', description="知识库名称")
    description: str = Field(default='', description="知识库描述")

    ai_model_bundle: AIModelBundle = Field(default=AIModelBundle(), description="知识库默认可以使用的模型选择，类似于Dify的系统模型选择")
    is_external_datastore: bool = Field(default=False, description="本知识库是否是从外部导入")

    # 文档解析相关
    doc_parse_config: DocParseConfig = Field(default=DocParseConfig(), description="文档解析相关参数")

    # 知识查询相关
    vector_keyword_config: Optional[VectorKeywordIndexConfig] = None
    kg_config: Optional[KnowledgeGraphIndexConfig] = None
    structured_config: Optional[StructuredIndexConfig] = None
    dynamic_doc_config: Optional[DynamicDocIndexConfig] = None

    # 重排相关
    rerank_config: Optional[RerankConfig] = Field(default=None, description="重排相关参数")

    token_counter: TokenCounterConfig = Field(
        default=TokenCounterConfig(),
        description="本知识库在文档解析、分块过程中用于统计token数量的参数，不设置则使用默认配置"
    )

    # TODO: 其他字段

    @model_validator(mode='after')
    def fill_token_counter(self) -> 'KBCreationConfig':
        # 检查一些内部属性是否有使用None的默认token_counter，替换为顶层的token_counter
        if self.doc_parse_config and self.doc_parse_config.token_counter is None:
            self.doc_parse_config.token_counter = self.token_counter
        if self.vector_keyword_config and self.vector_keyword_config.splitter_config.token_counter is None:
            self.vector_keyword_config.splitter_config.token_counter = self.token_counter
        if self.kg_config and self.kg_config.splitter_config.token_counter is None:
            self.kg_config.splitter_config.token_counter = self.token_counter
        return self

    @model_validator(mode='after')
    def fill_model_bundle(self) -> 'KBCreationConfig':
        """检查一些内部属性是否有未配置的模型，根据顶层model_bundle进行填充"""
        if self.doc_parse_config:
            self.doc_parse_config.update_with_model_bundle(self.ai_model_bundle)
        if self.vector_keyword_config:
            self.vector_keyword_config.update_with_model_bundle(self.ai_model_bundle)
        if self.kg_config:
            self.kg_config.update_with_model_bundle(self.ai_model_bundle)
        if self.structured_config:
            self.structured_config.update_with_model_bundle(self.ai_model_bundle)
        if self.dynamic_doc_config:
            self.dynamic_doc_config.update_with_model_bundle(self.ai_model_bundle)
        if self.rerank_config:
            self.rerank_config.update_with_model_bundle(self.ai_model_bundle)

        return self


class DeepThinkConfig(BaseModel):
    # 对外重点暴露的控制参数
    llm_model: str = Field(default='', description="大语言模型")
    max_iter: int = Field(default=5, description="深度思考过程的最大迭代次数")

    # 其他内部细节控制参数（外部用户一般可以忽略）
    kb_selector: bool = Field(
        default=True,
        description="本次查询使用是否允许Agent自动进行知识库选择"
    )
    doc_selector: bool = Field(
        default=True,
        description="本次查询使用是否允许Agent自动进行文档列表筛选"
    )
    dynamic_doc_index: bool = Field(
        default=True,
        description="本次查询使用是否允许Agent动态驱动文档内容检索"
    )
    deep_searcher: str = Field(
        default='DeepSearcher',
        description="本次查询使用DeepSearcher智能体的配置，为空时则不使用DeepSearcher智能体"
    )
    graph_navigator: str = Field(
        default='DefaultGraphNavigator',
        description="本次查询使用GraphNavigator智能体的配置，为空时则不使用GraphNavigator智能体"
    )
    # 内部参数，外部用户忽略
    hierarchy: str = Field(default="KB", init=False, repr=False,
                           exclude=True, description="使用DeepSearcher智能体的层级，choises=[KBX, KB]")

    def update_with_model_bundle(self, model_bundle: AIModelBundle) -> 'DeepThinkConfig':
        """使用AIModelBundle模型配置更新当前配置

        Args:
            model_bundle (AIModelBundle): 模型配置

        Returns:
            DeepThinkConfig: 更新后的配置
        """
        if not self.llm_model:
            self.llm_model = model_bundle.llm

        return self


class QueryConfig(KBXBaseModel):
    """查询参数"""
    text: str = Field(default="", description="需要查询的问题或关键词（文本），与messages二选一")
    messages: List[ChatMessage] = Field(
        default_factory=list,
        description="消息历史，与text二选一，包括用户最近的聊天历史，"
        "包含消息所属角色(system, user, assistant)，以及内容，格式与openai chat接口的messages一致"
    )
    max_tokens: int = Field(
        default=32 * 1024,
        description="检索结果的内容上限，最终输出token数不超过max_tokens"
    )
    stream: bool = Field(
        default=False,
        description="是否采用流式输出"
    )
    deep_think: Optional[DeepThinkConfig] = Field(
        default=None,
        description="本次查询使用深度思考的配置，为None时则不使用深度思考，不为None时，则在查询中会尽量使用深度思考智能体保障查询的质量"
                    "包括知识库选择，文档选择，动态文档索引深，度检索智能体，知识图谱子图检索智能体等。"
    )
    top_k: int = 5
    score_threshold: float = 0.0
    vector_dynamic_kwargs: Dict[str, Any] = Field(
        default={"keyword_similarity_weight": 0.0},
        description="向量索引动态参数，可配置参数：向量和关键词的权重"
    )
    enable_index_types: Optional[List[IndexType]] = Field(
        default=None,
        description="本次查询开启哪些索引类型，默认为None，表示全部启用"
    )
    ai_model_bundle: AIModelBundle = Field(default=AIModelBundle(), description="知识库默认可以使用的模型选择，类似于Dify的系统模型选择")

    @model_validator(mode='after')
    def fill_model_bundle(self) -> 'QueryConfig':
        """检查一些内部属性是否有未配置的模型，根据顶层model_bundle进行填充"""
        if self.deep_think:
            self.deep_think.update_with_model_bundle(self.ai_model_bundle)
        return self


class StructuredQueryResult(KBXBaseModel):
    """结构化数据库查询的返回结构"""
    sql: str = Field(default="", description="大模型生成的sql语句")
    table_info_dict: Dict[str, Dict[str, Any]] = Field(default_factory=dict, description="查询出的表的信息")
    data: List[List[str]] = Field(default_factory=list, description="查询出的数据")
    text: str = Field(default="", description="查询出的转换为文本后的数据")
    meta_data: Dict[str, Any] = Field(default_factory=dict, description="用于记录查询后的其他信息")


class QueryResult(KBXBaseModel):
    chunk: Optional[Chunk] = Field(default=None, description="查询出来的Chunk数据")
    graph_triplets: Optional[List[Tuple[str, str, str]]] = Field(default=None, description="查询出来的三元组")
    subgraph_options: Optional[Dict[str, Any]] = Field(default=None, description="查询出来的知识子图的echarts option封装")
    structured_result: Optional[StructuredQueryResult] = Field(default=None, description="结构化数据库查询的返回结果")
    index_type: IndexType = Field(default=IndexType.VECTOR_KEYWORD, description="使用哪一种查询方法得到的该结果")
    score: float = Field(default=0.0, description="评分")
    # 用于溯源
    kb_id: str = Field(default='', description="此检索结果来源于哪个知识库")
    doc_id: str = Field(default='', description="此检索结果来源于哪个文档")
    meta_data: Optional[Dict[str, str]] = Field(default=None, description="包含文档名称、知识库名称及其他可能需要的meta信息")

    def try_get_content_as_str(self) -> str:
        """强制以字符串形式返回内容

        Returns:
            str: 字符串格式的内容
        """
        # TODO: 一个临时实现
        if self.graph_triplets:
            return '\n'.join([', '.join(t) for t in self.graph_triplets])
        if self.chunk:
            return self.chunk.text
        elif self.structured_result:
            return self.structured_result.text
        else:
            return ""


class RetrievalStepMessage(KBXBaseModel):
    step_name: str = Field(description="检索阶段的事件名称，目前以三大检索阶段为主，主要为'选择知识库'、'选择文档'、'DeepSearcher深度检索/文档检索'")
    content: str = Field(default="", description="中间步骤产生的数据，适合直接在前端以markdown格式展示")  # 不同index内部数据前面统一加**{index_type}**


class QueryResults(KBXBaseModel):
    """QueryResult的集合类，支持流式返回"""
    results: List[QueryResult] = Field(default_factory=list, description="查询结果列表")
    step_messages: List[RetrievalStepMessage] = Field(default_factory=list, description="检索过程中的中间数据")
    is_final: bool = Field(default=False, description="表示是否为某阶段retrieve的最终结果")
    id: str = Field(default_factory=try_get_trace_id, description="本次查询请求用于跟踪的唯一id")

    @model_validator(mode='before')
    @classmethod
    def validate_step_messages(cls, values):
        if 'step_messages' in values and isinstance(values['step_messages'], RetrievalStepMessage):
            values['step_messages'] = [values['step_messages']]
        return values

    def __iter__(self):
        return iter(self.results)

    def __getitem__(self, index: int) -> QueryResult:
        return self.results[index]

    def __setitem__(self, index: int, result: QueryResult):
        self.results[index] = result

    def __len__(self) -> int:
        return len(self.results)

    def __repr__(self):
        return f"QueryResults(results={self.results})"

    def __eq__(self, other):
        if not isinstance(other, QueryResults):
            return False
        return self.results == other.results and self.step_messages == other.step_messages

    def append(self, res_data: Union[QueryResult, RetrievalStepMessage]):
        if isinstance(res_data, QueryResult):
            self.results.append(res_data)
        elif isinstance(res_data, RetrievalStepMessage):
            self.step_messages.append(res_data)

    def extend(self, results: Union[List[QueryResult], 'QueryResults']):
        if isinstance(results, list):
            self.results.extend(results)
        elif isinstance(results, QueryResults):
            self.results.extend(results.results)
            self.step_messages.extend(results.step_messages)

    def clear(self):
        self.results.clear()
        self.step_messages.clear()
