from kbx.knowledge_base.base_index import BaseIndex
from kbx.knowledge_base.types import VectorKeywordIndexConfig, \
    KnowledgeGraphIndexConfig, StructuredIndexConfig, DynamicDocIndexConfig


def get_vector_keyword_index(index_class_name: str, kb_id: str, index_config: VectorKeywordIndexConfig) -> BaseIndex:
    """获取一个向量关键字索引实例

    Args:
        index_class_name (str): 索引策略类名
        kb_id (str): 知识库id
        index_config (KeywordIndexConfig): 索引配置

    Returns:
        BaseIndex: 新创建的索引实例
    """
    match index_class_name:
        case 'DefaultVectorKeywordIndex':
            from kbx.knowledge_base.vector_keyword.default_vector_keyword_index import DefaultVectorKeywordIndex
            return DefaultVectorKeywordIndex(kb_id=kb_id, index_config=index_config)
        case _:
            raise RuntimeError(f'Unknown index class: {index_class_name}')


def get_knowledge_graph_index(index_class_name: str, kb_id: str, index_config: KnowledgeGraphIndexConfig) -> BaseIndex:
    """获取一个知识图谱索引实例

    Args:
        index_class_name (str): 索引策略类名
        kb_id (str): 知识库id
        index_config (KeywordIndexConfig): 索引配置

    Returns:
        BaseIndex: 新创建的索引实例
    """
    match index_class_name:
        case 'DefaultGraphIndex':
            from kbx.knowledge_base.graph.default_graph_index import DefaultGraphIndex
            return DefaultGraphIndex(kb_id=kb_id, index_config=index_config)
        case _:
            raise RuntimeError(f'Unknown index class: {index_class_name}')


def get_structured_index(index_class_name: str, kb_id: str, index_config: StructuredIndexConfig) -> BaseIndex:
    """获取一个结构化数据库索引实例

    Args:
        index_class_name (str): 索引策略类名
        kb_id (str): 知识库id
        index_config (KeywordIndexConfig): 索引配置

    Returns:
        BaseIndex: 新创建的索引实例
    """
    match index_class_name:
        case 'DefaultStructuredIndex':
            from kbx.knowledge_base.structured.default_structured_index import DefaultStructuredIndex
            return DefaultStructuredIndex(kb_id=kb_id, index_config=index_config)
        case _:
            raise RuntimeError(f'Unknown index class: {index_class_name}')


def get_dynamic_doc_index(index_class_name: str, kb_id: str, index_config: DynamicDocIndexConfig) -> BaseIndex:
    """获取一个动态文档文件索引实例

    Args:
        index_class_name (str): 索引策略类名
        kb_id (str): 知识库id
        index_config (DynamicDocIndexConfig): 索引配置

    Returns:
        BaseIndex: 新创建的索引实例
    """
    match index_class_name:
        case 'DefaultDynamicDocIndex':
            from kbx.knowledge_base.dynamic_doc.default_dynamic_doc_index import DefaultDynamicDocIndex
            return DefaultDynamicDocIndex(kb_id=kb_id, index_config=index_config)
        case 'AgenticDynamicDocIndex':
            from kbx.knowledge_base.dynamic_doc.agentic_dynamic_doc_index import AgenticDynamicDocIndex
            return AgenticDynamicDocIndex(kb_id=kb_id, index_config=index_config)
        case _:
            raise RuntimeError(f'Unknown index class: {index_class_name}')
