from typing import Union, List, Tuple, Optional, Any, Dict, Iterator
import json
from textwrap import dedent
from kbx.common.logging import logger
from kbx.common.types import IndexType, DocData, KBXError, Chunk
from kbx.common.utils import get_pydantic_config_changes, generate_new_id, \
    doc_element_to_markdown, doc_elements_to_markdown, get_category_prompts, toc_tree_to_string, get_node_by_level_str
from kbx.datastore.ds_factory import get_doc_datastore
from kbx.knowledge_base.base_index import BaseIndex
from kbx.knowledge_base.types import DynamicDocIndexConfig, QueryConfig, QueryResult, QueryResults
from agno.agent import Agent


class AgenticDynamicDocIndex(BaseIndex[DynamicDocIndexConfig]):
    """由Agent驱动的动态文档索引实现，通过Agent自主地在知识库中搜索与用户问题相关的资料。

    主要特点：
    1. 使用Agent来驱动整个搜索过程，而不是固定的workflow
    2. Agent可以自主决定如何获取和筛选文档内容
    3. 支持更灵活的文档内容筛选策略
    """

    def __init__(self, kb_id: str, index_config: DynamicDocIndexConfig) -> None:
        """
        初始化
        Args:
            kb_id (str): 知识库ID
            index_config (DynamicDocIndexConfig): 知识库配置
        """
        if not isinstance(index_config, DynamicDocIndexConfig):
            raise RuntimeError(f'Expect a index_config of DynamicDocIndexConfig, given {index_config}')
        super().__init__(kb_id=kb_id, index_config=index_config)

        self.prompt_templates = get_category_prompts('agentic_dynamic_doc')

    def list_docs(self) -> str:
        """获取知识库中的所有文档列表

        每次调用都会实时从知识库获取最新的文档列表，确保返回的数据是最新的。
        返回的每个文档信息包含：
        - id: 文档ID
        - file_path: 文档文件路径
        - summary: （可选）文档内容摘要

        Returns:
            str: 文档列表的JSON字符串表示，如果获取失败则返回包含错误信息的JSON字符串
        """
        doc_info_list = []
        with get_doc_datastore(self.kb_id) as doc_store:
            doc_ids, err = doc_store.list_doc_ids()
            if err.code != KBXError.Code.SUCCESS:
                logger.error(f"Failed to list doc ids: {err}")
                return json.dumps({"err_msg": f"获取文档列表失败: {err.msg}"}, ensure_ascii=False)

            for doc_id in doc_ids:
                doc_data, err = doc_store.load_doc_data(doc_id=doc_id)
                if err.code != KBXError.Code.SUCCESS:
                    continue
                doc_info = {
                    'id': doc_data.doc_id,
                    'file_path': doc_data.file_path,
                }
                if doc_data.doc_toc.summary:
                    # 如果文档有摘要，则添加到doc_info中
                    # TODO: summary最大长度限制
                    MAX_SUMMARY_LENGTH = 100
                    summary = doc_data.doc_toc.summary
                    if len(summary) > MAX_SUMMARY_LENGTH:
                        summary = summary[:MAX_SUMMARY_LENGTH] + '...'
                    doc_info['summary'] = summary
                doc_info_list.append(doc_info)
        return json.dumps(doc_info_list, ensure_ascii=False)

    def get_doc_toc(self, doc_id: str) -> str:
        """获取指定文档的目录结构

        每次调用都会实时从知识库获取最新的目录结构，确保返回的数据是最新的。
        如果文档不存在或获取失败，返回包含错误信息的JSON字符串。

        Args:
            doc_id (str): 文档ID

        Returns:
            str: 目录结构的字符串表示，如果文档不存在或获取失败则返回包含错误信息的JSON字符串
        """
        with get_doc_datastore(self.kb_id) as doc_store:
            doc_data, err = doc_store.load_doc_data(doc_id=doc_id)
            if err.code != KBXError.Code.SUCCESS:
                logger.error(f"Failed to get doc data (doc_id={doc_id}): {err}")
                return json.dumps({"err_msg": f"获取文档目录失败: {err.msg}"}, ensure_ascii=False)
            if not doc_data.doc_toc.children:
                # 如果文档没有目录结构，则返回空字符串
                return ""
            return toc_tree_to_string(doc_data.doc_toc)

    def get_doc_content(self, doc_id: str, toc_level: str) -> str:
        """获取指定文档的内容，形成一个包含doc_element_id和对应内容单元的列表，输出样例格式如下：
        [
            {
                "doc_element_id": "doc_element_id",
                "content": "一段md格式的正文段落"
            },
            {
                "doc_element_id": "doc_element_id",
                "content": "图片3-4 xxxx图：图片内容描述"
            },
            {
                "doc_element_id": "doc_element_id",
                "content": "表格3-4 xxxx表：表格内容描述"
            },
            {
                "doc_element_id": "doc_element_id",
                "content": "一段python代码xxxxx"
            },
            ...
        ]

        每次调用都会实时从知识库获取最新的文档内容，确保返回的数据是最新的。
        如果文档不存在或获取失败，返回包含错误信息的JSON字符串。

        Args:
            doc_id (str): 文档ID
            toc_level (Optional[str]): 目录层级，如'0.0.1'，如果设置为None或空字符串则返回整个文档内容

        Returns:
            str: 文档内容列表的JSON字符串表示，如果文档不存在或获取失败则返回包含错误信息的JSON字符串
        """
        with get_doc_datastore(self.kb_id) as doc_store:
            doc_data, err = doc_store.load_doc_data(doc_id=doc_id)
            if err.code != KBXError.Code.SUCCESS:
                logger.error(f"Failed to get doc data (doc_id={doc_id}): {err}")
                return json.dumps({"err_msg": f"获取文档内容失败: {err.msg}"}, ensure_ascii=False)

        if toc_level:
            # 如果指定了目录层级，则只返回该层级的内容
            node = get_node_by_level_str(doc_data.doc_toc, toc_level)
            if not node:
                return json.dumps({"err_msg": f"未找到指定的目录层级: {toc_level}"}, ensure_ascii=False)
            # 获取该章节下的所有元素
            elements = []
            for element_id in node.doc_element_ids:
                element = doc_data.doc_elements[element_id]
                elements.append({
                    "doc_element_id": element_id,
                    "content": doc_element_to_markdown(element, mode='summary')
                })
            return json.dumps(elements, ensure_ascii=False)
        else:
            # 否则返回整个文档内容
            elements = [
                {
                    "doc_element_id": element.doc_element_id,
                    "content": doc_element_to_markdown(element, mode='summary')
                }
                for element in doc_data.doc_elements
            ]
            return json.dumps(elements, ensure_ascii=False)

    @property
    def index_type(self) -> IndexType:
        """
        索引类型
        Returns:
            IndexType: 索引类型
        """
        return IndexType.DYNAMIC_DOC

    def insert_single_doc(self, doc_data: DocData) -> KBXError:
        """插入一个文档数据

        Args:
            doc_data (DocData): 待插入文档的DocData数据

        Returns:
            KBXError: 文档插入的错误信息
        """
        # 本索引不需要建立任何索引数据
        return KBXError()

    def reindex(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        return None

    def reindex_all(self) -> Optional[List[Tuple[str, str]]]:
        return None

    def remove_docs(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        return None

    def get_legal_config_attr_changes(self) -> List[str]:
        """获取本Index允许修改的配置属性
        Returns:
            List[str]: 允许修改的配置属性Key列表
        """
        legal_changes = []
        return legal_changes

    def validate_index_config_changes(self, config_diff: Dict[str, Any]) -> KBXError:
        """检查Index配置修改是否合法，如果存在不允许的修改，返回（所有）对应的错误信息

        Args:
            config_diff (Dict[str, Any]): Index配置发生变动的部分

        Returns:
            KBXError: 错误信息
        """
        illegal_changes: List[str] = []
        for key in config_diff.keys():
            if key not in self.get_legal_config_attr_changes():
                illegal_changes.append(f'Can not modify {key} field')

        if len(illegal_changes) > 0:
            return KBXError(
                code=KBXError.Code.INVALID_VALUE,
                msg=f"Illegal DynamicDocIndexConfig changes: {config_diff}"
            )
        return KBXError()

    def modify_index_config(self, new_index_config: DynamicDocIndexConfig) -> Tuple[KBXError, bool]:
        """修改本Index的配置

        Args:
            new_index_config (DynamicDocIndexConfig): 新的Index配置

        Returns:
            Tuple[KBXError, bool]: 第一项表示本次配置修改是否成功，第二项表示是否需要reindex，
                注意，只有在第一项为SUCCESS的情况下第二项才可能为True
        """
        err = KBXError()
        config_diff = get_pydantic_config_changes(self._index_config, new_index_config, recursive=True)
        if not config_diff:
            return err, False

        # 检查修改是否合法
        err = self.validate_index_config_changes(config_diff)
        if err.code != KBXError.Code.SUCCESS:
            return err, False

        self._index_config = new_index_config

        return KBXError(), False

    def remove_index(self) -> None:
        """删除全部索引数据"""
        return None

    def retrieve(self, query: QueryConfig, selected_doc_ids: Optional[List[str]] = None) -> Iterator[QueryResults]:
        """使用Agent进行文档检索，步骤如下

        1. 让Agent挑选出可能与之相关的文档列表
        2. 让Agent对每个文档进行详细内容分析和相关性评分
        3. 对每个结果进行打分过滤，并生成返回结果

        Args:
            query (QueryConfig): 查询配置
            selected_doc_ids (Optional[List[str]], optional): 预选的文档ID列表. Defaults to None.

        Returns:
            Iterator[QueryResults]: 可能包含中间步骤结果以及最终查询结果的迭代器
        """
        if not query.deep_think or not query.deep_think.dynamic_doc_index or not query.deep_think.llm_model:
            # 仅在开启deep think增强时才执行
            logger.info(f"Deep think is disabled or invalid, skip dynamic doc index: deep_think={query.deep_think}")
            yield QueryResults(results=[], is_final=True)
            return

        from kbx.kbx import KBX
        # 从deep_think中动态获取llm_config和llm_client，也就是允许进行test-time调整
        llm_config, _ = KBX.get_ai_model_config_and_client(
            name=query.deep_think.llm_model,
            user_id=self._index_config.user_ctx.user_id
        )

        import time
        t0 = time.time()
        if not selected_doc_ids:
            logger.info("No pre-selected docs from outside, use agent to select docs")
            # Step 1: 让Agent挑选出可能与之相关的文档列表
            doc_selector = Agent(
                model=llm_config.agno_model(),
                description=self.prompt_templates['DOC_SELECTOR_DESCRIPTION'].text,
                instructions=self.prompt_templates['DOC_SELECTOR_INSTRUCTIONS'].text,
                debug_mode=True,
                retries=query.deep_think.max_iter
            )
            # TODO: 如果知识库文档数量太多，可能需要考虑分批处理
            user_prompt = dedent(f"""
                ## 用户的问题

                {query.text}

                ## 文档列表
                {self.list_docs()}
            """)
            response = doc_selector.run(
                messages=[
                    {
                        "role": "user",
                        "content": user_prompt
                    }
                ]
            )
            try:
                results = json.loads(response.content.strip().lstrip("```json").strip("```"))
                logger.info(f"Selected docs: {results}")
                selected_doc_ids = [result["doc_id"] for result in results]
            except Exception as e:
                logger.error(f"Failed to parse agent response: {e}\n\n{response.content}")
                yield QueryResults(results=[], is_final=True)
                return
            if len(selected_doc_ids) == 0:
                yield QueryResults(results=[], is_final=True)
                return
        else:
            logger.info(f"Use pre-selected docs from outside: {selected_doc_ids}")

        if query.top_k > 0:
            # 强制进行数量过滤
            selected_doc_ids = selected_doc_ids[:query.top_k * 2]
        t1 = time.time()
        logger.debug(f"Step 1: Selected {len(selected_doc_ids)} docs, time cost {t1 - t0:.2f}s")

        # Step 2: 根据上一步初步筛选的文档列表，每个文档都创建一个agent让其进行详细内容分析和相关性评分
        doc_content_list = []
        doc_data_cache: Dict[str, DocData] = {}
        for doc_id in selected_doc_ids:
            with get_doc_datastore(self.kb_id) as doc_store:
                doc_data, err = doc_store.load_doc_data(doc_id=doc_id)
                if err.code != KBXError.Code.SUCCESS:
                    continue
                doc_data_cache[doc_id] = doc_data

            toc_str = self.get_doc_toc(doc_id)
            if not toc_str:
                toc_str = "无"
            prompt = dedent(
                f"""
                ## 用户问题
                {query.text}

                ## 文档信息
                `doc_id`: {doc_id}
                `file_name`: {doc_data_cache[doc_id].file_name}

                ## 文档目录树TOC
                {toc_str}
                """
            )
            doc_analyzer = Agent(
                model=llm_config.agno_model(),
                description=self.prompt_templates['DOC_ANALYZER_DESCRIPTION'].text,
                instructions=self.prompt_templates['DOC_ANALYZER_INSTRUCTIONS'].text,
                tools=[self.get_doc_content],
                debug_mode=True,
                retries=max(query.deep_think.max_iter, 3)
            )

            response = doc_analyzer.run(
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )
            try:
                results = json.loads(response.content.strip().lstrip("```json").strip("```"))
                if not isinstance(results, list):
                    raise ValueError(f"Invalid doc_analyzer agent response:\n{results}")
                for result in results:
                    doc_element_ids = []
                    if 'toc_levels' in result:
                        for toc_level in result["toc_levels"]:
                            node = get_node_by_level_str(doc_data.doc_toc, toc_level)
                            if node:
                                doc_element_ids.extend(node.doc_element_ids)
                    else:
                        start_doc_element_id = result["start_doc_element_id"]
                        end_doc_element_id = result["end_doc_element_id"]
                        start_index = doc_data.doc_elements.id_map[start_doc_element_id]
                        end_index = doc_data.doc_elements.id_map[end_doc_element_id]
                        if start_index > end_index:
                            start_index, end_index = end_index, start_index
                        doc_element_ids = [
                            doc_data.doc_elements[index].doc_element_id for index in range(start_index, end_index + 1)
                        ]

                    # 过滤非法的doc_element_ids
                    legal_doc_element_ids = set(doc_data.doc_elements.id_map.keys())
                    doc_element_ids = [
                        doc_element_id for doc_element_id in doc_element_ids
                        if doc_element_id in legal_doc_element_ids
                    ]

                    doc_content_list.append(
                        {
                            'doc_id': doc_id,
                            'doc_element_ids': doc_element_ids,
                            'score': result['score'],
                        }
                    )
            except Exception as e:
                logger.error(f"Failed to parse doc_analyzer agent response: {e}\n{response.content}")
                continue
        t2 = time.time()
        logger.debug(
            f"Step 2: Analyzed and filtered {len(doc_content_list)} docs, time cost {t2 - t1:.2f}s"
        )

        if len(doc_content_list) == 0:
            yield QueryResults(results=[], is_final=True)
            return

        # Step 3: 对每个结果进行打分过滤，并生成返回结果
        results = []
        for doc_content in doc_content_list:
            doc_id = doc_content['doc_id']
            doc_element_ids = doc_content['doc_element_ids']
            score = doc_content['score']

            if query.score_threshold and score < query.score_threshold:
                continue

            # 获取文档内容
            content = doc_elements_to_markdown(
                [doc_data_cache[doc_id].doc_elements[doc_element_id] for doc_element_id in doc_element_ids],
                mode='original'
            )
            results.append(
                QueryResult(
                    chunk=Chunk(
                        text=content,
                        chunk_id=generate_new_id(),
                        doc_id=doc_id,
                        doc_element_ids=doc_element_ids
                    ),
                    score=score,
                    kb_id=self.kb_id,
                    index_type=self.index_type,
                    doc_id=doc_id
                )
            )

        yield QueryResults(results=results, is_final=True)
