from typing import Union, List, Tuple, Optional, Any, Dict, Set, Iterator

import json
from concurrent.futures import ThreadPoolExecutor
from kbx.common.logging import logger
from kbx.common.prompt import get_category_prompts
from kbx.common.types import IndexType, DocData, KBXError, Chunk
from kbx.ai_model.types import AIModelType
from kbx.common.utils import get_pydantic_config_changes, doc_data_to_markdown, generate_new_id, toc_tree_to_string, \
    get_toc_node_content_str, get_node_by_level_str
from kbx.datastore.ds_factory import get_doc_datastore
from kbx.knowledge_base.base_index import BaseIndex
from kbx.knowledge_base.types import DynamicDocIndexConfig, \
    QueryConfig, QueryResults, QueryResult


def filter_nested_toc_levels(toc_levels: List[str]) -> List[str]:
    """过滤掉互相包含的章节编号，只保留最具体的章节编号

    Args:
        toc_levels (List[str]): 章节编号列表，例如 ['0.0', '0.0.6', '0.0.6.40']

    Returns:
        List[str]: 过滤后的章节编号列表，例如 ['0.0.6.40']
    """
    # 按章节编号长度从长到短排序
    sorted_levels = sorted(toc_levels, key=len, reverse=True)

    filtered_levels: Set[str] = set()
    for level in sorted_levels:
        # 检查当前level是否已经被更具体的level包含
        if not any(other.startswith(level) for other in filtered_levels):
            filtered_levels.add(level)

    # 按原始顺序返回
    return [level for level in toc_levels if level in filtered_levels]


class DefaultDynamicDocIndex(BaseIndex[DynamicDocIndexConfig]):
    """默认的粗粒度动态文档文件索引实现，不建立任何索引数据，只在查询时根据文档内容生成索引数据，具体步骤如下：

    1. 给定用户query和知识库的文档列表，使用LLM进行文档筛选，生成感兴趣的文档列表
    2. 对感兴趣的文档列表，挨个进行文档内的检索，具体如下
        2.1 如果文档有章节目录，先使用LLM挑选与问题有关的章节列表作为此步骤输出
        2.2 如果文档没有章节目录，直接全文当成此步骤的输出
    3. 对步骤2的输出，如果内容过长，使用LLM进行进一步的筛选
    4. 对步骤3的输出，使用LLM进行重排，生成最终带有分数的检索结果
    """

    def __init__(self, kb_id: str, index_config: DynamicDocIndexConfig) -> None:
        """
        初始化
        Args:
            kb_id (str): 知识库ID
            index_config (DynamicDocIndexConfig): 知识库配置
        """
        if not isinstance(index_config, DynamicDocIndexConfig):
            raise RuntimeError(f'Expect a index_config of DynamicDocIndexConfig, given {index_config}')
        super().__init__(kb_id=kb_id, index_config=index_config)

    @property
    def index_type(self) -> IndexType:
        """
        索引类型
        Returns:
            IndexType: 索引类型
        """
        return IndexType.DYNAMIC_DOC

    def insert_single_doc(self, doc_data: DocData) -> KBXError:
        """插入一个文档数据

        Args:
            doc_data (DocData): 待插入文档的DocData数据

        Returns:
            KBXError: 文档插入的错误信息
        """
        # 本索引不需要建立任何索引数据
        return KBXError()

    def reindex(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        return None

    def reindex_all(self) -> Optional[List[Tuple[str, str]]]:
        return None

    def remove_docs(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        return None

    def get_legal_config_attr_changes(self) -> List[str]:
        """获取本Index允许修改的配置属性
        Returns:
            List[str]: 允许修改的配置属性Key列表
        """
        # TODO: 其他参数修改待实现
        legal_changes = []
        return legal_changes

    def validate_index_config_changes(self, config_diff: Dict[str, Any]) -> KBXError:
        """检查Index配置修改是否合法，如果存在不允许的修改，返回（所有）对应的错误信息

        Args:
            config_diff (Dict[str, Any]): Index配置发生变动的部分

        Returns:
            KBXError: 错误信息
        """
        illegal_changes: List[str] = []
        for key in config_diff.keys():
            if key not in self.get_legal_config_attr_changes():
                illegal_changes.append(f'Can not modify {key} field')

        if len(illegal_changes) > 0:
            return KBXError(
                code=KBXError.Code.INVALID_VALUE,
                msg=f"Illegal DynamicDocIndexConfig changes: {config_diff}"
            )
        return KBXError()

    def modify_index_config(self, new_index_config: DynamicDocIndexConfig) -> Tuple[KBXError, bool]:
        """修改本Index的配置

        Args:
            new_index_config (DynamicDocIndexConfig): 新的Index配置

        Returns:
            Tuple[KBXError, bool]: 第一项表示本次配置修改是否成功，第二项表示是否需要reindex，
                注意，只有在第一项为SUCCESS的情况下第二项才可能为True
        """
        err = KBXError()
        config_diff = get_pydantic_config_changes(self._index_config, new_index_config, recursive=True)
        if not config_diff:
            return err, False

        # 检查修改是否合法
        err = self.validate_index_config_changes(config_diff)
        if err.code != KBXError.Code.SUCCESS:
            return err, False

        self._index_config = new_index_config

        return KBXError(), False

    def remove_index(self) -> None:
        """删除全部索引数据"""

        '''
        # TODO: 只能挨个遍历删除吗？
        with get_doc_datastore(self.kb_id) as ds:
            doc_ids, err = ds.list_doc_ids()
            if err.code != KBXError.Code.SUCCESS:
                logger.error(f"Failed to list doc ids: {err}")
                return
            for doc_id in doc_ids:
                chunk_ids, err, _ = ds.list_chunk_ids_by_doc_id(doc_id, self.index_type)
                if err.code != KBXError.Code.SUCCESS:
                    continue
                for chunk_id in chunk_ids:
                    ds.delete_chunk(chunk_id=chunk_id, index_type=self.index_type)
        '''

        return None

    def retrieve(self, query: QueryConfig, selected_doc_ids: Optional[List[str]] = None) -> Iterator[QueryResults]:
        if not query.deep_think or not query.deep_think.llm_model:
            # 仅在开启deep think增强时才执行
            yield QueryResults(results=[], is_final=True)
            return

        from kbx.kbx import KBX
        # 从deep_think中动态获取llm_config和llm_client，也就是允许进行test-time调整
        llm_config, llm_client = KBX.get_ai_model_config_and_client(
            name=query.deep_think.llm_model,
            user_id=self._index_config.user_ctx.user_id
        )

        # 获取当前的文档列表
        # TODO: 目前doc_ds没有直接获取所有文档元信息的接口，因此只能把所有文档的doc_data一次性获取出来，待优化
        doc_data_dict: Dict[str, DocData] = {}
        doc_info_list = []
        k = 0
        with get_doc_datastore(self.kb_id) as doc_store:
            doc_ids, err = doc_store.list_doc_ids()
            if err.code != KBXError.Code.SUCCESS:
                logger.error(f"Failed to list doc ids: {err}")
                yield QueryResults(results=[], is_final=True)
                return
            for doc_id in doc_ids:
                doc_data, err = doc_store.load_doc_data(doc_id=doc_id)
                doc_data_dict[doc_data.doc_id] = doc_data
                # TODO: 获取文档摘要
                doc_info_list.append({
                    'id': doc_data.doc_id,
                    'file_name': doc_data.file_name,
                    'summary': doc_data.doc_toc.summary,
                })
                k += 1

        # Step 1: 在知识库所有文档列表中进行感兴趣文档的选择
        if not selected_doc_ids:
            # 如果外部没有提前筛选文档列表，则使用LLM进行文档筛选
            prompt_templates = get_category_prompts('default_dynamic_doc')
            prompt_select_doc = prompt_templates['SELECT_DOC'].text
            # prompt = f'用户问题：{query.text}\n\n文档列表：\n{str(doc_info_list)}\n'
            prompt = json.dumps({
                'query': query.text,
                'top_k': query.top_k,
                'doc_list': doc_info_list,
            }, ensure_ascii=False)
            messages = [
                {'role': 'system', 'content': prompt_select_doc},
                {'role': 'user', 'content': prompt}
            ]
            resp = llm_client.chat(
                llm_config,
                messages=messages,
                stream=False
            ).choices[0].message.content
            logger.debug(f'DynamicDocIndex step 1\n\n## messages\n\n{messages}\n\n## resp\n\n{resp}')
            # NOTE: 有些大模型输出会有类似```json\n{...}\n```的格式，需要去掉
            selected_doc_ids = resp.lstrip('```json').strip('```')
            try:
                selected_doc_ids = json.loads(selected_doc_ids)
                # 只取top k
                if query.top_k > 0:
                    selected_doc_ids = selected_doc_ids[:query.top_k]
                if len(selected_doc_ids) == 0:
                    logger.debug(
                        f'DynamicDocIndex step 1, query="{query.text}", '
                        f'select_doc_ids=[] in kb_id={self.kb_id}'
                    )
                    yield QueryResults(results=[], is_final=True)
                    return
                selected_doc_ids = [selection['doc_id'] for selection in selected_doc_ids]
            except Exception:
                logger.error(f"Failed to parse selected doc ids: \"{selected_doc_ids}\"")
                yield QueryResults(results=[], is_final=True)
                return
            logger.debug(
                f'DynamicDocIndex step 1, query="{query.text}", '
                f'select doc_ids={selected_doc_ids} in kb_id={self.kb_id}'
            )

        chunks: List[Chunk] = []

        def _filter_context_from_doc(doc_data: DocData) -> Optional[Chunk]:
            # Step2：对选择的top_k文档进一步筛选其章节内容
            context: str = ''
            doc_element_ids: List[str] = []
            # 先检查该文档的目录树结构
            if doc_data.doc_toc.children:
                # 如果有目录树，可以让LLM先根据目录树筛选与query相关的章节列表
                toc_str = toc_tree_to_string(doc_data.doc_toc)
                prompt_templates = get_category_prompts('default_dynamic_doc')
                prompt_filter_toc_chapters = prompt_templates['FILTER_TOC_CHAPTERS'].text
                prompt = json.dumps({
                    'query': query.text,
                    'toc_tree': toc_str,
                }, ensure_ascii=False)
                filtered_toc_levels = llm_client.chat(
                    llm_config,
                    messages=[
                        {'role': 'system', 'content': prompt_filter_toc_chapters},
                        {'role': 'user', 'content': prompt}
                    ],
                    temperature=0.7
                ).choices[0].message.content
                filtered_toc_levels = filtered_toc_levels.strip('\n').lstrip('```json').strip('```').strip('\n')
                try:
                    filtered_toc_levels = json.loads(filtered_toc_levels)
                    if len(filtered_toc_levels) == 0:
                        return None
                except Exception:
                    logger.error(f"Failed to parse filtered toc ranges: \"{filtered_toc_levels}\"")
                    return None
                # 防止LLM输出的章节编号存在互相包含的情况，例如['0.0', '0.0.6', '0.0.6.40']需要处理成['0.0.6.40']
                filtered_toc_levels = filter_nested_toc_levels(filtered_toc_levels)
                logger.debug(
                    f'DynamicDocIndex step 2, query="{query.text}", filter toc chapters={filtered_toc_levels}'
                    f' for doc {doc_data.doc_id} in kb_id={self.kb_id}'
                )

                context = '\n\n'.join(
                    [
                        get_toc_node_content_str(
                            get_node_by_level_str(doc_data.doc_toc, level_str),
                            doc_data.doc_elements)
                        for level_str in filtered_toc_levels
                    ]
                )
                for level_str in filtered_toc_levels:
                    node = get_node_by_level_str(doc_data.doc_toc, level_str)
                    doc_element_ids.extend(node.doc_element_ids)
            else:
                # 如果没有目录树，直接尝试把全文当做上下文
                context = doc_data_to_markdown(doc_data, mode='original')
                doc_element_ids = [doc_element.doc_element_id for doc_element in doc_data.doc_elements]

            if context == '':
                return None

            # Step3：如果内容过长，使用LLM进行进一步的筛选
            # TODO: 如何判断内容过长？

            return Chunk(
                text=context,
                chunk_id=generate_new_id(),
                doc_id=doc_data.doc_id,
                doc_element_ids=doc_element_ids,
            )
        from kbx.kbx import KBX
        with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as executor:
            chunks = list(executor.map(
                _filter_context_from_doc, [
                    doc_data_dict[doc_id] for doc_id in selected_doc_ids
                ]
            ))

        # Step 4: 使用Rerank模型对这些chunks打分
        scores = [0.5 for _ in range(len(chunks))]
        if query.ai_model_bundle.bundles.get(AIModelType.RERANK, None):
            rerank_config, rerank_client = KBX.get_ai_model_config_and_client(
                name=query.ai_model_bundle.bundles[AIModelType.RERANK],
                user_id=self._index_config.user_ctx.user_id
            )
            rets = rerank_client.rerank(
                rerank_config,
                query=query.text,
                texts=[chunk.text for chunk in chunks],
                top_n=query.top_k
            )
            scores = [ret[2] for ret in rets]
            chunks = [chunks[ret[0]] for ret in rets]

        results = QueryResults(results=[
            QueryResult(
                chunk=chunk,
                score=scores[k],
                kb_id=self.kb_id,
                index_type=self.index_type,
                doc_id=chunk.doc_id
            ) for k, chunk in enumerate(chunks) if chunk is not None
        ], is_final=True)

        yield results
