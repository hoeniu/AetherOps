from typing import List, Optional, Union, Tuple, Dict, Any, Iterator
import numpy as np
from collections import defaultdict
import concurrent.futures
from kbx.kbx import KBX
from kbx.knowledge_base.types import VectorKeywordIndexConfig, QueryConfig, QueryResult, QueryResults
from kbx.knowledge_base.base_index import BaseIndex
from kbx.common.types import IndexType, IndexType, Chunk, DocData
from kbx.common.utils import get_pydantic_config_changes
from kbx.splitter.splitter_factory import get_splitter
from kbx.common.logging import logger
from kbx.common.types import KBXError
from kbx.datastore.ds_factory import get_doc_datastore, get_vector_datastore, get_keyword_datastore
from kbx.knowledge_base.vector_keyword.jieba_extractor import JiebaKeywordExtractor


class DefaultVectorKeywordIndex(BaseIndex[VectorKeywordIndexConfig]):
    """默认的关键字、向量索引实现，可以两者同时打开，或者二选一"""
    def __init__(
        self, kb_id: str,
        index_config: VectorKeywordIndexConfig,
    ) -> None:
        if not isinstance(index_config, VectorKeywordIndexConfig):
            raise RuntimeError(f'Expect a index_config of VectorKeywordIndexConfig, given {index_config}')
        super().__init__(kb_id=kb_id, index_config=index_config)
        self._enable_keyword_index = False
        self._enable_vector_index = False
        self._validate_index_params(index_config)

    def _validate_index_params(self, index_config: VectorKeywordIndexConfig):
        if index_config.keyword_extractor:
            if not index_config.keyword_extractor.strip():
                raise ValueError("keyword_extractor cannot be an empty string.")
            if index_config.max_keywords_per_chunk <= 0:
                raise ValueError("max_keywords_per_chunk must be greater than 0 when keyword_extractor is set.")
            if index_config.keyword_extractor == 'jieba':
                self._keyword_extractor = JiebaKeywordExtractor()
            else:
                raise RuntimeError(f'Expect a keyword_extractor of jieba, given \
                    {index_config.keyword_extractor} is not implemented!')
        else:
            if index_config.max_keywords_per_chunk != 0:
                raise ValueError("max_keywords_per_chunk must be 0 when keyword_extractor is None.")

        self._index_source_of_docstore = IndexType.VECTOR_KEYWORD
        if index_config.text_embedding_model and index_config.text_embedding_model.strip():
            self._enable_vector_index = True
        if index_config.keyword_extractor and index_config.keyword_extractor.strip():
            self._enable_keyword_index = True

    @property
    def index_type(self) -> IndexType:
        return IndexType.VECTOR_KEYWORD

    def _split_doc(self, doc: DocData) -> List[Chunk]:
        splitter = get_splitter(self._index_config.splitter_config)
        # splitter._config.chunk_size = 20
        chunks = splitter.split(doc)
        # doc_store = NanoDocDS(config=self._doc_config, kb_id=kb_id)
        # TODO 保存DocData应该是上层的工作？这里为了测试用
        """ ↓ 测试用"""
        # self._doc_store.save_doc_data(doc)
        """ ↑ 测试用"""
        result_chunks = []
        with get_doc_datastore(self._kb_id) as doc_store:
            for chunk in chunks:
                if chunk.text:
                    res = doc_store.save_chunk(chunk, self._index_source_of_docstore)
                    if res.code != KBXError.Code.SUCCESS:
                        logger.error(f'Failed to save text chunk: {res.msg}')
                        continue
                    result_chunks.append(chunk)
        return result_chunks

    def insert_single_doc(self, doc_data: DocData) -> KBXError:
        """插入一个文档数据

        Args:
            doc_data (DocData): 待插入文档的DocData数据

        Returns:
            KBXError: 文档插入的错误信息
        """
        if not isinstance(doc_data, DocData):
            raise RuntimeError(f'Expect a doc of DocData, given {doc_data}')

        doc_id = doc_data.doc_id
        # kb中存在该文档，则更新
        with get_doc_datastore(self._kb_id) as doc_store:
            chunks_ids, chunk_err, _ = doc_store.list_chunk_ids_by_doc_id(doc_id, self._index_source_of_docstore)
        if chunk_err.code == KBXError.Code.SUCCESS:
            if chunks_ids:  # 非空列表
                reindex_error = self.reindex(doc_id)
                if reindex_error is not None and len(reindex_error) > 0:
                    return KBXError(
                        code=KBXError.Code.RUNTIME_ERROR,
                        msg=reindex_error[0][1]
                    )
                return KBXError()
        else:
            raise RuntimeError(f'Failed to list chunk ids by doc_id: {chunk_err.msg}')

        chunks = self._split_doc(doc_data)

        err = KBXError()
        if self._enable_vector_index:
            err = self._create_vector_index(doc_id, chunks)
            if err.code != KBXError.Code.SUCCESS:
                return err
        if self._enable_keyword_index:
            err = self._create_keyword_index(doc_id, chunks)
        return err

    def _process_batch_embedding(self, chunk_batch, doc_id, embedding_client, embedding_config):
        chunk_text = [chunk.text for chunk in chunk_batch if chunk.text]
        try:
            return embedding_client.text_embedding_batch(embedding_config, texts=chunk_text)
        except Exception as e:
            # 出错场景1：len(chunk) > model 的上下文
            # TODO：这样会导致doc ds和vector ds的chunk_id不一致，删除时提示 “Delete of nonexisting embedding ID”
            warning_message = f"Failed to transform chunks to embeddings for doc_id {doc_id}: {e}"
            logger.warning(warning_message)
            return None

    def _create_vector_index(self, doc_id: str, texts: list[Chunk], **kwargs) -> KBXError:
        """为每个doc创建向量，存入向量库，返回错误信息 (doc_id, err_msg)"""
        self.embedding_config, self.embedding_client = \
            KBX.get_ai_model_config_and_client(
                self._index_config.text_embedding_model,
                user_id=self._index_config.user_ctx.user_id
            )
        chunk_batch_size = kwargs.get('chunk_batch_size', 4)
        chunk_embedding_list = []
        future_results = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=KBX.config.num_threads) as executor:
            for i in range(0, len(texts), chunk_batch_size):
                chunk_batch = texts[i:i + chunk_batch_size]
                # TODO: 图片chunk，获得chunk.base64
                future_result = executor.submit(
                    self._process_batch_embedding, chunk_batch,
                    doc_id, self.embedding_client, self.embedding_config)
                future_results.append(future_result)

        for future_result in future_results:
            embedding_result = future_result.result()
            start_idx = future_results.index(future_result) * chunk_batch_size
            if embedding_result is None:
                continue
            for j, vector in enumerate(embedding_result):
                try:
                    chunk_number = start_idx + j
                    chunk = texts[chunk_number]
                    chunk_id = chunk.chunk_id
                    normalized_embedding = (vector / np.linalg.norm(vector)).tolist()
                    chunk_embedding_list.append((chunk_id, normalized_embedding))
                except Exception as e:
                    warning_message = f"Failed to normalize text chunk {chunk_id} for doc_id {doc_id}: {e}"
                    logger.warning(warning_message)
                    continue

        with get_vector_datastore(self._kb_id) as vector_store:
            kbx_error = vector_store.add(chunk_embedding_list)
        if kbx_error.code != KBXError.Code.SUCCESS:
            err_msg = f"Failed to save doc {doc_id} to the vector database. Error message: {kbx_error.msg}"
            logger.error(err_msg)
            return KBXError(
                code=KBXError.Code.SUCCESS,
                msg=err_msg
            )
        return KBXError()

    def _create_keyword_index(self, doc_id: str, texts: list[Chunk]) -> KBXError:
        """创建关键字索引"""
        text_keyword_list = []
        for text in texts:
            chunk_id = text.chunk_id
            keywords = self._keyword_extractor.extract_keywords(
                text.text,
                self._index_config.max_keywords_per_chunk
            )
            text_keyword_list.append([keywords, chunk_id])

        with get_keyword_datastore(self._kb_id) as keyword_store:
            kbx_error = keyword_store.add(text_keyword_list)
        if kbx_error.code != KBXError.Code.SUCCESS:
            err_msg = f"Failed to save doc {doc_id} to the keyword database. Error message: {kbx_error.msg}"
            logger.error(err_msg)
            return KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=err_msg
            )
        return KBXError()

    def reindex(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        if isinstance(doc_ids, str):
            doc_ids = [doc_ids]

        doc_err_msg = self.remove_docs(doc_ids)
        if doc_err_msg:
            raise RuntimeError(
                f'[Internal Error] Failed to remove docs for {doc_ids}:\n'
                f'{doc_err_msg}'
            )

        doc_err_msg: List[Tuple[str, str]] = []
        insert_err_msg = self._get_doc_data_and_insert(doc_ids)
        if insert_err_msg:
            doc_err_msg.extend(insert_err_msg)
            return doc_err_msg
        return

    def _get_doc_data_and_insert(self, doc_ids) -> List[Tuple[str, str]]:
        doc_err_msg: List[Tuple[str, str]] = []
        for doc_id in doc_ids:
            with get_doc_datastore(self._kb_id) as doc_store:
                doc_data, kbx_error = doc_store.load_doc_data(doc_id)
                if kbx_error.code != KBXError.Code.SUCCESS:
                    err_msg = f"Failed to load doc {doc_id}. Error message: {kbx_error.msg}"
                    logger.error(err_msg)
                    doc_err_msg.append((doc_id, err_msg))
                    continue
            err = self.insert_single_doc(doc_data)
            if err.code != KBXError.Code.SUCCESS:
                doc_err_msg.append((doc_id, err.msg))
        return doc_err_msg

    def reindex_all(self) -> Optional[List[Tuple[str, str]]]:
        with get_doc_datastore(self._kb_id) as doc_store:
            doc_ids, kbx_error = doc_store.list_doc_ids()
        if kbx_error.code != KBXError.Code.SUCCESS:
            err_msg = f"Failed to list all doc_ids. Error message: {kbx_error.msg}"
            logger.error(err_msg)
            raise RuntimeError(err_msg)

        doc_err_msg: List[Tuple[str, str]] = []
        error_message = self._delete_chunks_in_doc_store(doc_ids)
        if error_message:
            doc_err_msg.extend(error_message)

        # 更换embedding model时，向量维度改变，需要删除之前的vector store再重建
        self.remove_index()

        insert_error = self._get_doc_data_and_insert(doc_ids)
        if insert_error:
            doc_err_msg.extend(insert_error)
        if doc_err_msg:
            return doc_err_msg
        return

    def _delete_chunks_in_doc_store(self, doc_ids: List[str]):
        doc_err_msg: List[Tuple[str, str]] = []
        for doc_id in doc_ids:
            # 获得doc对应的所有chunk_ids
            with get_doc_datastore(self._kb_id) as doc_store:
                chunk_ids, kbx_error, _ = doc_store.list_chunk_ids_by_doc_id(
                    doc_id, self._index_source_of_docstore)
                if kbx_error.code != KBXError.Code.SUCCESS:
                    logger.error(f"Failed to list chunk ids for doc {doc_id}. Error message: {kbx_error.msg}")
                    doc_err_msg.append((doc_id, kbx_error.msg))
                    continue
            # ckids = copy.deepcopy(chunk_ids)

            # 删除chunk、chunk_id与doc_id的映射关系
            with get_doc_datastore(self._kb_id) as doc_store:
                for chunk_id in chunk_ids:
                    doc_store_error = doc_store.delete_chunk(chunk_id, self._index_source_of_docstore)
                    if doc_store_error.code != KBXError.Code.SUCCESS:
                        logger.error(f"Failed to delete chunk {chunk_id} from doc db. \
                                    Error message: {doc_store_error.msg}")
                        doc_err_msg.append((doc_id, doc_store_error.msg))
        if doc_err_msg:
            return doc_err_msg

    def remove_docs(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        """根据doc_ids，去向量库删除DocData对应的textchunk和embedding"""
        doc_err_msg: List[Tuple[str, str]] = []
        if isinstance(doc_ids, str):
            doc_ids = [doc_ids]
        # NOTE: 此函数如果在以下步骤获得错误返回值，均为不符合预期的未定义行为，因此这里统一按异常抛出，
        #       后续可以进行重点关注，是否存在“预期内”的错误场景，需要区分文档id以返回值的方式体现
        for doc_id in doc_ids:
            # 获得doc对应的所有chunk_ids
            with get_doc_datastore(self._kb_id) as doc_store:
                chunk_ids, kbx_error, _ = doc_store.list_chunk_ids_by_doc_id(
                    doc_id, self._index_source_of_docstore)
                if kbx_error.code != KBXError.Code.SUCCESS:
                    logger.error(
                        f"[Internal Error] Failed to list chunk ids for doc {doc_id}. Error message: {kbx_error.msg}"
                    )
                    continue
            # ckids = copy.deepcopy(chunk_ids)

            # 删除embedding
            if self._enable_vector_index:
                with get_vector_datastore(self._kb_id) as vector_store:
                    kbx_error = vector_store.delete_by_chunk_ids(chunk_ids)
                if kbx_error.code != KBXError.Code.SUCCESS:
                    raise RuntimeError(
                        f"[Internal Error] Failed to delete chunks index from vector db. Error message: {kbx_error.msg}"
                    )

            # 删除keyword
            if self._enable_keyword_index:
                with get_keyword_datastore(self._kb_id) as keyword_store:
                    del_error = keyword_store.delete_by_chunk_ids(chunk_ids)
                if del_error.code != KBXError.Code.SUCCESS:
                    raise RuntimeError(
                        f"Failed to delete chunks index from keyword db. Error message: {del_error.msg}"
                    )

            # 删除chunk、chunk_id与doc_id的映射关系
            with get_doc_datastore(self._kb_id) as doc_store:
                for chunk_id in chunk_ids:
                    doc_store_error = doc_store.delete_chunk(chunk_id, self._index_source_of_docstore)
                    if doc_store_error.code != KBXError.Code.SUCCESS:
                        raise RuntimeError(
                            f"Failed to delete chunk {chunk_id} from doc db. "
                            f"Error message: {doc_store_error.msg}"
                        )

            # TODO: doc_store中的doc_data应该是上层删除，这里只为了测试用
            # TODO: 但是delete_doc_data包括了delete_chunk操作，所以上层需要先调用index.remove，再调用doc_store.delete_doc_data
            """ ↓ 测试用"""
            # self._doc_store.delete_doc_data(doc_id)
            """ ↑ 测试用"""

        if doc_err_msg:
            return doc_err_msg
        return

    # TODO: 考虑add_chunks的场景，append到chunks的末尾（dify）or 倒数第二个（ragflow）
    # 同时考虑 add_chunks的时候，是否增加关键词
    # def add_chunks()

    def _weighted_scores(self, keyword_list, vector_list, keyword_weight=0.5, vector_weight=0.5):
        result = defaultdict(float)
        keyword_dict = {item[0]: item[1] for item in keyword_list}
        for id_, score in vector_list:
            if id_ in keyword_dict:
                result[id_] = keyword_weight * keyword_dict[id_] + vector_weight * score
            else:
                result[id_] = vector_weight * score

        # 处理仅出现在keyword列表中的项
        for id_, score in keyword_list:
            if id_ not in result:
                result[id_] = keyword_weight * score

        return sorted(result.items(), key=lambda item: item[1], reverse=True)

    def get_legal_config_attr_changes(self) -> List[str]:
        """获取本Index允许修改的配置属性
        Returns:
            List[str]: 允许修改的配置属性Key列表
        """
        legal_changes = [
            'text_embedding_model',
            'splitter_config',
            'max_keywords_per_chunk'
        ]
        return legal_changes

    def validate_index_config_changes(self, config_diff: Dict[str, Any]) -> KBXError:
        """检查Index配置修改是否合法，如果存在不允许的修改，返回（所有）对应的错误信息

        Args:
            config_diff (Dict[str, Any]): Index配置发生变动的部分

        Returns:
            KBXError: 错误信息
        """
        illegal_changes: List[str] = []
        for key in config_diff.keys():
            if key not in self.get_legal_config_attr_changes():
                illegal_changes.append(f'Can not modify {key} field')

        if len(illegal_changes) > 0:
            return KBXError(
                KBXError.Code.INVALID_VALUE,
                f"Illegal vector index config changes: {config_diff}"
            )
        return KBXError()

    def modify_index_config(self, new_index_config: VectorKeywordIndexConfig) -> Tuple[KBXError, bool]:
        """修改本Index的配置

        Args:
            new_index_config (VectorKeywordIndexConfig): 新的Index配置

        Returns:
            Tuple[KBXError, bool]: 第一项表示本次配置修改是否成功，第二项表示是否需要reindex，
                注意，只有在第一项为SUCCESS的情况下第二项才可能为True
        """
        err = KBXError()
        config_diff = get_pydantic_config_changes(self._index_config, new_index_config, recursive=True)
        if not config_diff:
            return err, False

        # 检查修改是否合法
        err = self.validate_index_config_changes(config_diff)
        if err.code != KBXError.Code.SUCCESS:
            return err, False

        # 参数修改分为三种类型
        vector_diff = 'text_embedding_model' in config_diff
        keyword_diff = 'max_keywords_per_chunk' in config_diff
        splitter_diff = 'splitter_config' in config_diff

        self._index_config = new_index_config

        # TODO
        # 1. 修改了splitter相关参数，不再对已插入的文档reindex，只对新增文档生效
        # 2. 如果只修改keyword相关参数，则只reindex keyword
        # 3. 修改了text_embedding_model， 只reindex vector
        if splitter_diff:
            # 默认只有"chunk_size, delimiters, overlap_size"可以修改。 # noqa
            # TODO: 目前修改splitter_config不做任何操作
            # TODO：后续考虑是否修改keyword_index相应的splitter_config
            pass

        if vector_diff:
            assert self._enable_vector_index is not None
        if keyword_diff:
            # 需要额外修改keyword index的max_keywords_per_chunk参数
            assert self._enable_keyword_index is not None
            # self._enable_keyword_index._index_config.max_keywords_per_chunk = \
            #     self._index_config.max_keywords_per_chunk
            # NOTE 目前不支持修改max_keywords_per_chunk参数<=0
            assert self._index_config.max_keywords_per_chunk > 0

        # NOTE: 目前vector或者keyword参数修改，则整个知识库重建
        return KBXError(), vector_diff or keyword_diff

    def remove_index(self) -> None:
        """删除全部索引数据"""
        # 删除本index对应的所有持久化数据，例如调用xx_ds.delete_ds()
        # NOTE: 之后如果添加了其他datastore的使用，可能需要补充删除逻辑
        if self._enable_vector_index:
            self._remove_vector_index()
        if self._enable_keyword_index:
            self._remove_keyword_index()

    def _remove_vector_index(self) -> None:
        with get_vector_datastore(self._kb_id) as vector_store:
            del_vec_ds_error = vector_store.delete_ds()
            assert del_vec_ds_error.code == KBXError.Code.SUCCESS, \
                f"delete vector store failed: {del_vec_ds_error.msg}"

    def _remove_keyword_index(self) -> None:
        with get_keyword_datastore(self._kb_id) as keyword_store:
            del_kwd_ds_error = keyword_store.delete_ds()
            assert del_kwd_ds_error.code == KBXError.Code.SUCCESS, \
                f"delete keyword store failed: {del_kwd_ds_error.msg}"

    def retrieve(self, query: QueryConfig, selected_doc_ids: Optional[List[str]] = None) -> Iterator[QueryResults]:
        """向量化query,去向量库里查询，返回id和相似度"""
        if selected_doc_ids is None:
            selected_doc_ids = []

        query_text = query.text
        top_k = query.top_k
        score_threshold = query.score_threshold

        retrived_vector_scores = None
        retrived_keyword_scores = None

        # vector检索
        if self._enable_vector_index:
            self.embedding_config, self.embedding_client = \
                KBX.get_ai_model_config_and_client(
                    self._index_config.text_embedding_model,
                    user_id=self._index_config.user_ctx.user_id
                )
            query_embedding_result = self.embedding_client.text_embedding(self.embedding_config, text=query_text)
            query_embedding_result = (
                query_embedding_result / np.linalg.norm(query_embedding_result)).tolist()

            # 如果selected_doc_ids不为空，则只在指定doc的chunk进行查询，不进行全量查询
            selected_chunk_ids = None
            if selected_doc_ids:
                logger.info(f"The following docs are selected: {selected_doc_ids}")
                selected_chunk_ids = []
                with get_doc_datastore(self._kb_id) as doc_store:
                    for doc_id in selected_doc_ids:
                        chunk_ids, chunk_err, _ = doc_store.list_chunk_ids_by_doc_id(
                            doc_id, self._index_source_of_docstore)
                        if chunk_err.code != KBXError.Code.SUCCESS:
                            logger.error(f"Failed to list chunk ids for doc {doc_id}: {chunk_err.msg}")
                            continue
                        selected_chunk_ids.extend(chunk_ids)
                if not selected_chunk_ids:
                    selected_chunk_ids = None

            with get_vector_datastore(self._kb_id) as vector_store:
                retrived_vector_scores, vec_error = vector_store.search_by_vector(
                    query_embedding_result,
                    topk=top_k * 2,
                    selected_chunk_ids=selected_chunk_ids
                )
                # print("all vector ids: ", vector_store._collection.get(include=["embeddings"])["ids"])
                # print("len of vector: ", len(vector_store._collection.get(include=["embeddings"])["ids"]))
            if vec_error.code != KBXError.Code.SUCCESS:
                logger.error(f"Failed to retrieve by vector. Error message: {vec_error.msg}")

        # keyword检索
        if self._enable_keyword_index:
            query_keywords_result = self._keyword_extractor.extract_keywords(query_text)
            with get_keyword_datastore(self._kb_id) as keyword_store:
                retrived_keyword_scores, kwd_error = \
                    keyword_store.search(query_keywords_result, topk=top_k * 2)
            if kwd_error.code != KBXError.Code.SUCCESS:
                logger.error(f"Failed to retrieve by keyword. Error message: {kwd_error.msg}")

        # 同时开启两种索引
        if retrived_vector_scores and retrived_keyword_scores:
            retrived_results = self._weighted_scores(
                retrived_keyword_scores,
                retrived_vector_scores,
                # TODO：若只开启vector或keyword中的一种，则keyword_similarity_weight只能为0或1
                keyword_weight=query.vector_dynamic_kwargs["keyword_similarity_weight"],
                vector_weight=1 - query.vector_dynamic_kwargs["keyword_similarity_weight"]
            )
            top_k_results = retrived_results[:top_k]
        else:
            if retrived_vector_scores:
                top_k_results = retrived_vector_scores[:top_k]
            elif retrived_keyword_scores:
                top_k_results = retrived_keyword_scores[:top_k]
            else:
                top_k_results = []

        results = QueryResults()
        with get_doc_datastore(self._kb_id) as doc_store:
            for ret_res in top_k_results:
                chunk_id = ret_res[0]
                chunk, kbx_error = doc_store.load_chunk(chunk_id, self._index_source_of_docstore)
                if kbx_error.code != KBXError.Code.SUCCESS:
                    logger.error(f"Failed to load text chunk {chunk_id}. Error message: {kbx_error.msg}")
                else:
                    if ret_res[1] > score_threshold:
                        query_result = QueryResult(
                            kb_id=self._kb_id,
                            chunk=chunk,
                            index_type=self.index_type,
                            doc_id=chunk.doc_id,
                            score=ret_res[1]
                        )
                        results.append(query_result)
        results.is_final = True
        yield results
