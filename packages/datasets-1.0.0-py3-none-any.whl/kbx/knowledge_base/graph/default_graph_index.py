import json
import random
from typing import Union, List, Tuple, Optional, Any, Dict, Iterator
import networkx as nx
from kbx.common.logging import logger
from kbx.common.prompt import get_category_prompts
from kbx.common.types import IndexType, DocData, KBXError
from kbx.common.utils import get_pydantic_config_changes
from kbx.datastore.ds_factory import get_graph_datastore, \
    get_doc_datastore, get_keyword_datastore, get_vector_datastore
from kbx.kbx import KBX
from kbx.knowledge_base.base_index import BaseIndex
from kbx.knowledge_base.types import KnowledgeGraphIndexConfig, \
    QueryConfig, QueryResult, QueryResults
from streamlit_echarts import JsCode

from kbx.agent.agent_factory import get_agent
from kbx.agent.types import KnowledgeExtractAgentConfig


class DefaultGraphIndex(BaseIndex[KnowledgeGraphIndexConfig]):
    """默认的知识图谱索引实现"""

    def __init__(self, kb_id: str, index_config: KnowledgeGraphIndexConfig) -> None:
        """
        初始化
        Args:
            kb_id (str): 知识库ID
            index_config (KnowledgeGraphIndexConfig): 知识库配置
        """
        if not isinstance(index_config, KnowledgeGraphIndexConfig):
            raise RuntimeError(f'Expect a index_config of KnowledgeGraphIndexConfig, given {index_config}')
        super().__init__(kb_id=kb_id, index_config=index_config)
        self.chat_config, self.llm = KBX.get_ai_model_config_and_client(
            index_config.llm_model,
            user_id=self._index_config.user_ctx.user_id
        )
        self.embedding_config, self.embedding_client = KBX.get_ai_model_config_and_client(
            self._index_config.embedding_model,
            user_id=self._index_config.user_ctx.user_id
        )
        self.schema = index_config.schema_dict  # self._load_schema(kb_id, index_config)

        agent_config = KnowledgeExtractAgentConfig(
            agent_name="DefaultKnowledgeExtractor",
            user_ctx=self._index_config.user_ctx,
            max_iter=3,
            llm_model=self._index_config.llm_model,
            schema_dict=self.schema
        )
        self.knowledge_extractor = get_agent(agent_config)
        self.data_store = get_graph_datastore(kb_id, index_config)
        # self.entity_doc_datastore = get_keyword_datastore(kb_id)
        # self.doc_store = get_doc_datastore(kb_id)
        self.data_store.connect()
        self.keyword_datastore_namespaces = {
            "ENTITY_CHUNK": "entity_chunk",
            "CHUNK_ENTITY": "chunk_entity",
        }
        self.mutable_configs = ['llm_model', 'max_retry', 'splitter_config', 'embedding_model']
        if index_config.external_graph_ds:  # is external graph datastore
            self._build_vector_data_store()
            # pass

    def _format_entity_to_text(self, entity):
        property_values = []
        for k, v in entity.items():
            property_values.append('{}\t{}'.format(k, v))
        return '\n'.join(property_values)

    def _should_ignore_embedding(self, entity):
        embedding_properties = [p['类型'] for p in self.schema['属性'] if '嵌入' in p and p['嵌入'] == '是']
        for p in embedding_properties:
            if p in entity and entity[p]:
                return True
        return False

    def _build_vector_data_store(self):
        logger.info("Build entity vector datastore from external")
        with get_vector_datastore(self._kb_id, index_type=self.index_type) as vector_store:
            for node_id in self.data_store.node_ids:
                if vector_store.if_chunk_id_exists(str(node_id)):
                    continue
                entity = self.data_store.search_node_by_id(node_id)
                if not self._should_ignore_embedding(entity):
                    entity_embedding = self.embedding_client.text_embedding(self.embedding_config,
                                                                            self._format_entity_to_text(entity))
                    vector_store.add([(str(node_id), entity_embedding)])
                    logger.info(f"Insert {entity} to vector index.")

    @property
    def index_type(self) -> IndexType:
        """
        索引类型
        Returns:
            IndexType: 索引类型
        """
        return IndexType.KNOWLEDGE_GRAPH

    def _simplify_entity(self, entity: dict) -> dict:
        """
        简化实体,只保留名称和类型
        Args:
            entity (dict): 实体字典

        Returns:
            dict: 只包含名称和类型的实体dict
        """
        simple_properties = [
            '类型',
            '名称',
        ]
        return dict(filter(lambda kv: kv[0] in simple_properties, entity.items()))

    def _is_legal_entity(self, entity: dict) -> bool:
        """
        简化实体,只保留名称和类型
        Args:
            entity (dict): 实体字典

        Returns:
            bool: 是合法实体返回True, 否则返回False
        """
        necessary_properties = [
            '类型',
            '名称',
        ]
        for p in necessary_properties:
            if p not in entity or not entity[p]:
                return False
        property_types = set(prop['类型'] for prop in self.schema['属性'])
        entity_types = set(ent['类型'] for ent in self.schema['实体'])
        for k, v in entity.items():
            if not isinstance(k, str) or not isinstance(v, str) or k not in property_types:
                return False
        if '类型' in entity and entity['类型'] not in entity_types:
            return False
        return True

    def _could_align_to_entity(self, entity: Dict[str, Any],
                               same_name_entities: List[int],
                               linked_edges: Tuple[Dict, Dict, Dict]) -> \
            Optional[int]:
        """
        判断实体是否可以与同名实体对齐
        Args:
            entity (dict): 实体字典
            same_name_entities (list[dict]): 同名实体列表
            linked_edges (list[dict]): 实体的邻接边

        Returns:
            int: 存在对齐实体, 则返回对齐实体ID, 否则返回None
        """
        if not same_name_entities:
            return None
        if entity['类型'] != '人':  # TODO: 临时方案, 非人类型实体, 名称相同, 则暂时认为相同
            return same_name_entities[0]
        for linked_edge in linked_edges:  # 检查是否有相同的邻接边
            potential_ids = self.data_store.search_node_complex(self._simplify_entity(entity),
                                                                [(self._simplify_entity(linked_edge[0]),
                                                                  linked_edge[1],
                                                                  self._simplify_entity(linked_edge[2]))])
            if potential_ids:  # 找到匹配时，返回第一个ID（假设只有一个匹配）
                return potential_ids[0]
        return None

    def _search_entity_by_name(self, entity: dict, name_properties: List[str]) -> List[int]:
        entity = self._simplify_entity(entity)
        entities = []
        for name in name_properties:
            extended_entity = {}
            for k, v in entity.items():
                if k != "名称":
                    extended_entity[k] = v
                else:
                    extended_entity[name] = v
            entities += self.data_store.search_node_by_property(extended_entity)
        return list(set(entities))

    def insert_single_doc(self, doc_data: DocData) -> KBXError:
        """插入一个文档数据

        Args:
            doc_data (DocData): 待插入文档的DocData数据

        Returns:
            KBXError: 文档插入的错误信息
        """
        if not isinstance(doc_data, DocData):
            raise RuntimeError(f'Expect a doc of DocData, given {doc_data}',
                               f"Actual type: {type(doc_data)}")

        # name_properties = ["名称", "简称", "英文名称", "英文简称"]
        name_properties = list([e['类型'] for e in self.schema['属性'] if e['是否标识'] == '是'])
        # property_types = set(prop['类型'] for prop in self.schema['属性'])
        from kbx.splitter.splitter_factory import get_splitter
        # 检查文档是否已经存在, 如果存在, 重新索引
        with get_doc_datastore(self._kb_id) as doc_store:
            chunks_ids, chunk_err, _ = doc_store.list_chunk_ids_by_doc_id(doc_data.doc_id, self.index_type)
        if chunk_err.code == KBXError.Code.SUCCESS:
            if chunks_ids:
                reindex_error = self.reindex(doc_data.doc_id)
                if reindex_error is not None and len(reindex_error) > 0:
                    return KBXError(
                        code=KBXError.Code.RUNTIME_ERROR,
                        msg=reindex_error[0][1]
                    )
        else:
            raise RuntimeError(f'Failed to list chunk ids by doc_id: {chunk_err.msg}')
        splitter = get_splitter(self._index_config.splitter_config)
        chunks = splitter.split(doc_data)
        # logger.info(chunks)
        with get_doc_datastore(self._kb_id) as doc_store:
            for chunk in chunks:
                error = doc_store.save_chunk(chunk, self.index_type)
                if error.code != KBXError.Code.SUCCESS:
                    logger.error(error)
                    return error
        for chunk in chunks:
            if not chunk.text.strip():
                logger.warning(f"Got empty chunk text: {chunk}")
                continue
            entities, edges = self.knowledge_extractor.extract(text=chunk.text)
            entity_id_map = {}
            for entity in entities:
                same_name_entities = self._search_entity_by_name(entity, name_properties)
                if len(same_name_entities) > 1:
                    logger.warning(
                        f"More than one entities found for same-name-entity-search: {same_name_entities}")
                linked_edges = list(filter(lambda ent: ent[0]['名称'] == entity['名称'] or \
                                           ent[2]['名称'] == entity['名称'],
                                           edges))
                node_id = self._could_align_to_entity(entity, same_name_entities, linked_edges)
                if node_id is not None:
                    self.data_store.update_node(node_id, entity, override=False)
                    # logger.info("Update node: {}-{}".format(node_id, str(entity)))
                else:
                    node_id = self.data_store.insert_node(entity)
                    # logger.info("Insert node: {}-{}".format(node_id, str(entity)))
                entity_id_map[entity['名称']] = node_id
                with get_vector_datastore(self._kb_id, index_type=self.index_type) as vector_store:
                    entity = self.data_store.search_node_by_id(node_id)
                    if not self._should_ignore_embedding(entity):
                        entity_embedding = self.embedding_client.text_embedding(
                            self.embedding_config,
                            self._format_entity_to_text(entity))
                        vector_store.add([(str(node_id), entity_embedding)])
                with get_keyword_datastore(self.kb_id, index_type=self.index_type) as entity_doc_datastore:
                    error = entity_doc_datastore.add([([str(node_id)], chunk.chunk_id)])
                    if error.code != KBXError.Code.SUCCESS:
                        return error
                with get_keyword_datastore(self.kb_id, index_type=self.index_type,
                                           namespace=self.keyword_datastore_namespaces[
                                               'CHUNK_ENTITY']) as chunk_entity_store:
                    error = chunk_entity_store.add([([chunk.chunk_id], str(node_id))])
                    if error.code != KBXError.Code.SUCCESS:
                        return error

            # logger.info(entities)
            for edge in edges:
                if edge[0]['名称'] in entity_id_map and edge[2]['名称'] in entity_id_map:
                    self.data_store.upsert_edge(entity_id_map[edge[0]['名称']],
                                                entity_id_map[edge[2]['名称']], edge[1], edge[1])
                    # logger.info("Edge upsert: {}->{} {}".format(entity_id_map[edge[0]['名称']],
                    #                                             entity_id_map[edge[2]['名称']], str(edge[1])))
        self.data_store.flush()
        return KBXError()

    def get_legal_config_attr_changes(self) -> List[str]:
        """获取本Index允许修改的配置属性
        Returns:
            List[str]: 允许修改的配置属性Key列表
        """
        return self.mutable_configs

    def validate_index_config_changes(self, config_diff: Dict[str, Any]) -> KBXError:
        """检查Index配置修改是否合法，如果存在不允许的修改，返回（所有）对应的错误信息

        Args:
            config_diff (Dict[str, Any]): Index配置发生变动的部分

        Returns:
            KBXError: 错误信息
        """
        error_configs = []
        for k, _ in config_diff.items():
            if k not in self.mutable_configs:
                error_configs.append(k)
        if error_configs:
            return KBXError(
                code=KBXError.Code.INVALID_VALUE,
                msg=f"Illegal graph index config changes, immutable configs: {error_configs}"
            )
        return KBXError()

    def modify_index_config(self, new_index_config: KnowledgeGraphIndexConfig) -> Tuple[KBXError, bool]:
        """修改本Index的配置

        Args:
            new_index_config (KnowledgeGraphIndexConfig): 新的Index配置

        Returns:
            Tuple[KBXError, bool]: 第一项表示本次配置修改是否成功，第二项表示是否需要reindex，
                注意，只有在第一项为SUCCESS的情况下第二项才可能为True
        """
        # 比较新旧配置的差异
        config_diff = get_pydantic_config_changes(self._index_config, new_index_config, recursive=True)
        error = self.validate_index_config_changes(config_diff)
        if error.code != KBXError.Code.SUCCESS:
            return error, False

        self._index_config = new_index_config
        self._refresh_member_from_config(config_diff)
        # NOTE: 当前知识图谱索引不支持修改embedding模型等配置，因此不需要reindex
        return KBXError(), False

    def _refresh_member_from_config(self, config_diff: Dict[str, Any]):
        if 'llm_model' in config_diff:
            self.chat_config, self.llm = KBX.get_ai_model_config_and_client(
                self._index_config.llm_model,
                user_id=self._index_config.user_ctx.user_id
            )

    def reindex(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        """对部分文档重新建立索引

        Args:
            doc_ids (Union[str, List[str]]): 需要重新建立索引的文档id

        Returns:
            Optional[List[Tuple[str, str]]]: 如果执行成功直接返回None，否则会把错误信息进行返回，
                格式为[(doc_id, err_msg), (doc_id, err_msg), ...]
        """
        if isinstance(doc_ids, str):
            doc_ids = [doc_ids]
        if not doc_ids:
            return None
        remove_results = self.remove_docs(doc_ids)
        error_dict = {}
        doc_err_msg = []
        if remove_results:
            error_dict = dict(remove_results)
        doc_data_list: List[DocData] = []
        with get_doc_datastore(self._kb_id) as doc_store:
            for doc_id in doc_ids:
                if doc_id in error_dict:
                    doc_err_msg.append((doc_id, error_dict[doc_id]))
                    continue
                doc_data, kbx_error = doc_store.load_doc_data(doc_id)
                if kbx_error.code != KBXError.Code.SUCCESS:
                    doc_err_msg.append((doc_id, kbx_error.msg))
                    continue
                doc_data_list.append(doc_data)
        if doc_data_list:
            for doc_data in doc_data_list:
                err = self.insert_single_doc(doc_data)
                if err.code != KBXError.Code.SUCCESS:
                    doc_err_msg.append((doc_data.doc_id, err.msg))
        if doc_err_msg:
            return doc_err_msg
        return None

    def reindex_all(self) -> Optional[List[Tuple[str, str]]]:
        """对全部文档重新建立索引

        Returns:
            Optional[List[Tuple[str, str]]]: 如果执行成功直接返回None，否则会把错误信息进行返回，
                格式为[(doc_id, err_msg), (doc_id, err_msg), ...]
        """
        with get_doc_datastore(self._kb_id) as doc_store:
            doc_ids, kbx_error = doc_store.list_doc_ids()
        return self.reindex(doc_ids)

    def remove_docs(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        """删除一个或多个文档的索引数据

        Args:
            doc_ids (Union[str, List[str]]): _description_

        Returns:
            Optional[List[Tuple[str, str]]]: 如果执行成功直接返回None，否则会把错误信息进行返回，
                格式为[(doc_id, err_msg), (doc_id, err_msg), ...]
        """
        if isinstance(doc_ids, str):
            doc_ids = [doc_ids]
        if not doc_ids:
            return None
        doc_err_msg = []
        with get_vector_datastore(self.kb_id, index_type=self.index_type) as vector_store:
            with get_keyword_datastore(self.kb_id, index_type=self.index_type) as entity_chunk_datastore:
                with get_keyword_datastore(self.kb_id, index_type=self.index_type,
                                           namespace=self.keyword_datastore_namespaces[
                                               'CHUNK_ENTITY']) as chunk_entity_store:
                    with get_doc_datastore(self._kb_id) as doc_store:
                        for doc_id in doc_ids:
                            # 获得所有chunk id
                            chunk_ids, kbx_error, _ = doc_store.list_chunk_ids_by_doc_id(doc_id, self.index_type)
                            if kbx_error.code != KBXError.Code.SUCCESS:
                                doc_err_msg.append((doc_id, kbx_error.msg))
                                continue
                            # 删除chunk、chunk_id与doc_id的映射关系
                            for chunk_id in chunk_ids:
                                # logger.info(f"Delete chunk {chunk_id} from doc store. ")
                                doc_store.delete_chunk(chunk_id, self.index_type)
                            # 从实体-chunk索引中删除
                            # logger.info(f"Delete chunks {chunk_ids} from entity chunk store. ")
                            kbx_error = entity_chunk_datastore.delete_by_chunk_ids(chunk_ids)
                            if kbx_error.code != KBXError.Code.SUCCESS:
                                doc_err_msg.append((doc_id, kbx_error.msg))
                                continue
                            # 从图谱中删除实体
                            for chunk_id in chunk_ids:
                                # 查询chunk 中的所有实体
                                entity_scores, kbx_error = chunk_entity_store.search([chunk_id])
                                if kbx_error.code != KBXError.Code.SUCCESS:
                                    doc_err_msg.append((doc_id, kbx_error.msg))
                                    continue
                                entity_scores = list(filter(lambda ent: ent[1] > 0.0, entity_scores))
                                # logger.info(f"Find chunk entities: {entity_scores}")
                                for ent, _ in entity_scores:
                                    # 该实体是否还有其他chunk包含
                                    chunk_scores, kbx_error = entity_chunk_datastore.search([ent])
                                    if kbx_error.code != KBXError.Code.SUCCESS:
                                        doc_err_msg.append((doc_id, kbx_error.msg))
                                        continue
                                    chunk_scores = list(filter(lambda chk: chk[1] > 0.0, chunk_scores))
                                    if not chunk_scores:
                                        # 实体不再存在于其他文档的chunk中, 则从图谱中删除
                                        # logger.info(f"Delete entity {ent}")
                                        self.data_store.delete_node(int(ent))
                                        if vector_store.if_chunk_id_exists(ent):
                                            vector_store.delete_by_chunk_ids([ent])
                                        # TODO: 此处应该删除chunk的索引, 暂无该接口, delete by ent
                                        kbx_error = chunk_entity_store.delete_by_chunk_ids([ent])
                                        if kbx_error.code != KBXError.Code.SUCCESS:
                                            doc_err_msg.append((doc_id, kbx_error.msg))
                                            continue
        if doc_err_msg:
            return doc_err_msg
        return None

    def remove_index(self) -> None:
        """删除全部索引数据"""

        # 删除本index对应的所有持久化数据，例如调用xx_ds.delete_ds()
        # NOTE: 之后如果添加了其他datastore的使用，可能需要补充删除逻辑
        with self.data_store:
            self.data_store.delete_ds()

        with get_keyword_datastore(self.kb_id, index_type=self.index_type) as keyword_ds:
            keyword_ds.delete_ds()

    def gen_instructions_from_template(self, task: str, text: str, entities: list[dict] = None) -> str:
        """
        获得大模型的instructions
        Args:
            task (str): 任务: NER, NER_PROPERTY, RE
            text (str): 输入text
            entities (list[dict]): 输入text中的实体, 在NER_PROPERTY, RE任务中使用

        Returns:
            str: instruction
        """
        templates = get_category_prompts('graph')
        if task == "NER":
            entity_types = list(map(lambda e: e['类型'], self.schema['实体']))
            return templates['NER'].text % (json.dumps(entity_types, ensure_ascii=False), text)
        if task == "ENTITY_ALIGNMENT":
            return templates['ENTITY_ALIGNMENT'].text % (text, json.dumps(list(map(lambda ent: ent['名称'], entities)),
                                                         ensure_ascii=False))
        if task == "NER_PROPERTY":
            property_types = list(map(lambda e: e['类型'], self.schema['属性']))
            return templates['NER_PROPERTY'].text % (
                json.dumps(property_types, ensure_ascii=False),
                json.dumps(list(map(lambda ent: ent['名称'], entities)), ensure_ascii=False),
                json.dumps(property_types, ensure_ascii=False),
                text)
        if task == "RE":
            relation_types = list(map(lambda e: e['类型'], self.schema['关系']))
            relation_explain = list(map(lambda e: "- {0}: {1}".format(e['类型'], e['说明']), self.schema['关系']))
            return templates['RE'].text % (json.dumps(relation_types, ensure_ascii=False),
                                           "\n".join(relation_explain),
                                           json.dumps(list(map(lambda ent: ent['名称'], entities)), ensure_ascii=False),
                                           json.dumps(relation_types, ensure_ascii=False),
                                           text)
        if task == "RELATED_NER_FILTER":
            return templates['RELATED_NER_FILTER'].text % (text,
                                                           json.dumps(list(map(lambda ent: ent['名称'], entities)),
                                                                      ensure_ascii=False))
        raise ValueError("Task {} not supported.".format(task))

    def _format_triples(self, triples: list[list], separator: str = ",") -> str:
        """
        格式化三元组
        Args:
            triples (list[list[str]]): 三元组列表

        Returns:
            str: 三元组str
        """
        return "\n".join(list(set([separator.join(triple) for triple in triples])))

    def _remove_duplicate(self, triplet_results: list[list[str]]) -> list[list[str]]:
        """
        刪除重复的三元组
        Args:
            triplet_results: 输入三元组

        Returns:
            list[list[str]]: 去重后的三元组
        """
        joined_set = set()
        results = []
        for triplet in triplet_results:
            tpl = ",".join(triplet)
            if tpl not in joined_set:
                results.append(triplet)
                joined_set.add(tpl)
        return results

    def _extend_entities(self, entities: list[dict], name_properties):
        extended_entities = []
        for name in name_properties:
            for entity in entities:
                extended_entity = {}
                for k, v in entity.items():
                    if k != "名称":
                        extended_entity[k] = v
                    else:
                        extended_entity[name] = v
                extended_entities.append(extended_entity)
        return extended_entities

    def _search_entities_by_vectors(self, query_embedding_results: List[List[float]],
                                    top_k: int = 1):
        with get_vector_datastore(self._kb_id, index_type=self.index_type) as vector_store:
            results = []
            for query_embedding_result in query_embedding_results:
                retrieved_results, kbx_error = vector_store.search_by_vector(
                    query_embedding_result,
                    topk=top_k
                )
                if retrieved_results and kbx_error.code == KBXError.Code.SUCCESS:
                    results += retrieved_results
            logger.info(f"Vector search results: {results}")
            entity_ids = list(map(lambda x: int(x[0]), results))
            return entity_ids

    def _default_subgraph_options(self):
        return {
            "backgroundColor": "#2c343c",
            "title": {
                "text": "知识子图",
                "subtext": "",
                "top": "bottom",
                "left": "right",
            },
            "tooltip": {},
            "series": [
                {
                    "type": "graph",
                    "layout": "force",
                    "animation": False,
                    "symbol": "circle",
                    "data": [],
                    "links": [],
                    "roam": True,
                    "label": {
                        "position": "right",
                        "show": True,
                        "formatter": JsCode(
                            "function(params) {  "
                            "return params.name.length > 30 ? params.name.substring(0, 30) : params.name;}"
                        ).js_code
                    },
                    # "labelLayout": {"hideOverlap": True},
                    "edgeSymbol": ['none', 'arrow'],
                    "edgeSymbolSize": [4, 8],
                    "edgeLabel": {"show": True, "fontSize": 12,
                                  "formatter": JsCode("function(param) {  return param.data.value;}").js_code},
                    "draggable": True,
                    "scaleLimit": {"min": 0.4, "max": 12},
                    "lineStyle": {"color": "source", "width": 2, "opacity": 0.7, "curveness": 0},
                    "emphasis": {"focus": "adjacency", "lineStyle": {"width": 3, "curveness": 0}},
                    "force": {"repulsion": 60, "edgeLength": 50, "gravity": 0.2},
                    "zoom": 2,
                }
            ],
        }

    def _is_json(self, result):
        try:
            json.loads(result)
        except ValueError as e:
            logger.warn(e)
            return False
        return True

    def retrieve(self, query: QueryConfig, selected_doc_ids: Optional[List[str]] = None) -> Iterator[QueryResults]:
        """查询

        Args:
            query (QueryConfig): 查询参数
            selected_doc_ids (Optional[List[str]]): 需要检索的文档id列表
        Returns:
            Iterator[QueryResults]: 可能包含中间步骤结果以及最终查询结果的迭代器
        """
        if not query.deep_think or not query.deep_think.graph_navigator or not query.deep_think.llm_model:
            retrieval_res = self._retrieve(query)
            retrieval_res.is_final = True
            yield retrieval_res
            return
        else:
            from ...agent.types import KnowledgeGraphNavigateAgentConfig
            from ...agent.graph.default_knowledge_graph_navigator import DefaultKnowledgeGraphNavigator

            agent_config = KnowledgeGraphNavigateAgentConfig(
                agent_name="DefaultKnowledgeGraphNavigator",
                user_ctx=self._index_config.user_ctx,
                max_iter=3,
                llm_model=self._index_config.llm_model,
                schema_dict=self.schema
            )
            navigator = get_agent(agent_config)
            assert isinstance(navigator, DefaultKnowledgeGraphNavigator)
            start_nodes = self._retrieve_entity(query)
            graph = navigator.navigate(self.data_store, query, start_nodes)
            if graph is None:
                retrieval_res = self._retrieve(query)
                retrieval_res.is_final = True
                yield retrieval_res
            else:
                subgraph_options = self._default_subgraph_options()
                triplets = self._format_triplets(graph)
                node_links = self._node_link_for_option(graph)
                subgraph_options['series'][0]['data'] = node_links['data']
                subgraph_options['series'][0]['links'] = node_links['links']
                ids = graph.nodes()
                chunks_results = None
                with get_keyword_datastore(self.kb_id, index_type=self.index_type) as entity_doc_datastore:
                    chunks_results, error = entity_doc_datastore.search(list(map(lambda ent: str(ent), ids)))

                retrieval_res = self._wrap_query_results(triplets, subgraph_options, chunks_results, query.text)
                retrieval_res.is_final = True
                yield retrieval_res

    def _get_node_name(self, node: Dict, name_properties: Union[str, List] = None) -> str:
        """
        根据指定的属性名称从节点字典中获取节点名称。

        Args:
            node (Dict): 节点的属性字典，包含各种属性键值对。
            name_properties (Union[str, List], optional): 用于获取节点名称的属性名或属性名列表。
                如果为 None，则默认使用 ['名称']。默认为 None。

        Returns:
            str: 节点的名称。如果指定的属性都不存在于节点字典中，则返回 '未知'。
        """
        # 如果未指定属性名称，使用默认的属性名称列表
        if name_properties is None:
            name_properties = ['名称']
        # 如果 name_properties 是一个字符串，直接从节点字典中获取该属性的值
        if isinstance(name_properties, str):
            return node[name_properties]
        # 如果 name_properties 是一个列表，遍历列表中的属性名称
        elif isinstance(name_properties, List):
            for property in name_properties:
                # 如果属性名称存在于节点字典中，返回该属性的值
                if property in node:
                    return node[property]
        # 如果所有指定的属性名称都不存在于节点字典中，返回 '未知'
        return '未知'

    def _format_triplets(self, graph: nx.Graph) -> List[Tuple[str, str, str]]:
        """
        将图对象转换为三元组列表。
        Args:
            graph (nx.Graph): 图对象。
        Returns:
            List[Tuple[str, str, str]]: 三元组列表。
        """
        # 创建一个空列表，用于存储三元组
        triplets = []
        # 遍历图的所有边
        for u, v, data in graph.edges(data=True):
            # 从边的属性中获取关系类型
            relation_type = data.get('类型', '')
            # 将三元组添加到列表中
            triplets.append((graph.nodes[u]['名称'], relation_type, graph.nodes[v]['名称']))
        for node, data in graph.nodes(data=True):
            for p, v in data.items():
                if p != '名称':
                    triplets.append((data['名称'], p, v))
        # 返回三元组列表
        return triplets

    def _node_link_for_option(self, graph: nx.Graph,
                              name_properties: list = ["名称", "简称", "英文名称", "英文简称"],
                              with_property=True,
                              node_filter=None,
                              edge_filter=None) -> dict:
        """
        生成echarts图的节点和边
        Args:
            graph (nx.Graph): 图
        Returns:
            dict: 节点和边
        """
        node_links = {"data": [], "links": []}
        if not graph.nodes():
            return node_links
        nodes = []
        links = []
        link_count = {}
        subgraph_auto_increment_id = 0
        subgraph_id_map = {}
        colors = ['#FFFFFF', '#000000', '#87CEEB', '#FFFF00', '#FF0000',
                  '#9932CC', '#FFB6C1', '#00FF00', '#C0C0C0', '#00008B',
                  '#FF4500', '#98FB98', '#D8BFD8', '#DAA520', '#FFA500',
                  '#6495ED', '#006400', '#00BFFF', '#FF1493', '#8B4513', ]

        def get_subgraph_node_id(key):
            """
            获取子图节点的唯一ID

            参数:
                key: 节点的键

            返回:
                int: 子图节点的唯一ID
            """
            if key not in subgraph_id_map:
                nonlocal subgraph_auto_increment_id
                subgraph_id_map[key] = subgraph_auto_increment_id
                subgraph_auto_increment_id = subgraph_auto_increment_id + 1
            return subgraph_id_map[key]

        def get_default(d, default, *keys):
            """
            获取字典中的默认值

            参数:
                d: 字典
                default: 默认值
                *keys: 键列表

            返回:
                字典中的值或默认值
            """
            dd = d
            for k in keys:
                if (not isinstance(dd, dict)) or (k not in dd):
                    return default
                dd = dd[k]
            return dd

        def set_value(d, v, *keys):
            """
            设置字典中的值

            参数:
                d: 字典
                v: 值
                *keys: 键列表
            """
            dd = d
            for i in range(len(keys) - 1):
                if keys[i] not in dd:
                    dd[keys[i]] = {}
                dd = dd[keys[i]]
            dd[keys[-1]] = v
        property_index = max(graph.nodes) + 1
        for e in graph.nodes():
            nodes.append({
                "id": get_subgraph_node_id(e),
                "name": self._get_node_name(graph.nodes[e], name_properties),
                "symbolSize": 20,
                "x": (random.random() - 0.5) * 500,
                "y": (random.random() - 0.5) * 500,
                "value": graph.nodes[e]['类型'],
                "itemStyle": {
                    "color": colors[hash(self._get_node_name(graph.nodes[e], name_properties))
                                    % len(colors)],
                }
            })
            for k, v in graph.nodes[e].items():
                nodes.append({
                    "id": get_subgraph_node_id(property_index),
                    "name": v,
                    "symbolSize": 20,
                    "x": (random.random() - 0.5) * 500,
                    "y": (random.random() - 0.5) * 500,
                    "value": k,
                    "itemStyle": {
                        "color": colors[hash(v) % len(colors)],
                    }
                })
                c = get_default(link_count, 0, int(e), property_index)
                links.append({
                    "value": k,
                    "source": get_subgraph_node_id(e),
                    "target": get_subgraph_node_id(property_index),
                    "label": {
                        "show": True
                    },
                    "lineStyle": {
                        "curveness": 0 + 0.2 * c
                    }
                })
                set_value(link_count, c + 1, int(e), property_index)
                property_index += 1
        for u, v, d in graph.edges(data=True):
            c = get_default(link_count, 0, int(u), int(v))
            links.append({
                "value": d['类型'],
                "source": get_subgraph_node_id(u),
                "target": get_subgraph_node_id(v),
                "label": {
                    "show": True
                },
                "lineStyle": {
                    "curveness": 0 + 0.2 * c
                }
            })
            set_value(link_count, c + 1, int(u), int(v))

        nodes.sort(key=lambda nd: nd['id'])
        node_links = {"data": nodes, "links": links}
        return node_links

    def _retrieve_entity(self, query: QueryConfig) -> List[int]:
        """
        实体检索核心方法，通过多策略组合获取相关实体

        Args:
            query (QueryConfig): 包含查询文本、top_k等参数的查询配置对象
        Returns:
            List[int]: 相关实体的ID列表
        """
        # 定义用于识别实体名称的属性字段（名称/简称等）
        # name_properties = ["名称", "简称", "英文名称", "英文简称", "别名"]
        name_properties = list([e['类型'] for e in self.schema['属性'] if e['是否标识'] == '是'])

        # 生成NER指令模板获取大模型初始响应
        prompt = self.gen_instructions_from_template("NER", query.text)
        ids = []
        response = self.llm.chat(
            self.chat_config,
            messages=[
                {"role": "user", "content": prompt},
            ],
            max_tokens=self.chat_config.max_tokens
        ).choices[0].message.content
        # logger.info(f'query={query}\nresponse={response}')
        entities = None
        if self._is_json(response):
            entities = json.loads(response)
        if entities:  # has entities
            # logger.info(f"Extracted entities: {entities}")
            entities = self._extend_entities(entities, name_properties)
            for entity in entities:
                ids += self.data_store.search_node_by_property(entity)
            if len(ids) < query.top_k:  # entities not enough in data store
                logger.info("Entities not enough in data store, use vector search to fill results.")
                query_embedding = self.embedding_client.text_embedding(self.embedding_config, text=query.text)
                ids += self._search_entities_by_vectors([query_embedding], query.top_k)
            # logger.info(f"Retrieved entities by entity vectors: {ids}")
        else:  # no entities
            # logger.info("No entities extracted from question")
            query_embedding = self.embedding_client.text_embedding(self.embedding_config, text=query.text)
            ids = self._search_entities_by_vectors([query_embedding], query.top_k)
        ids = list(set(ids))
        # do entity filter by llm
        candidates = [self.data_store.search_node_by_id(node_id) for node_id in ids]
        prompt = self.gen_instructions_from_template("RELATED_NER_FILTER", query.text, candidates)
        # logger.info(prompt)
        response = self.llm.chat(
            self.chat_config,
            messages=[
                {"role": "user", "content": prompt},
            ],
            max_tokens=self.chat_config.max_tokens
        ).choices[0].message.content
        selected_entities = []
        if self._is_json(response):
            selected_entities = json.loads(response)
        if isinstance(selected_entities, list) and len(selected_entities) > 0:
            logger.info(f"Filtered entities: {selected_entities}")
            selected_entities = set(selected_entities)
            select_ids = []
            for node_id in ids:
                if self.data_store.search_node_by_id(node_id)["名称"] in selected_entities:
                    select_ids.append(node_id)
            if select_ids:
                ids = select_ids
        else:
            logger.info("No entity left, use unfiltered entities.")
        return ids

    def _calculate_score(self, graph_triplets: List[List[str]], query_text: str) -> float:
        """
        计算查询结果的得分

        Args:
            graph_triplets (List[List[str]]): 三元组结果
            query_text (str): 查询文本

        Returns:
            float: 余弦相似度
        """
        graph_triplets_string = self._format_triples(graph_triplets, separator=" ")
        query_embedding, triplets_embedding = self.embedding_client.text_embedding_batch(
            self.embedding_config,
            texts=[query_text, graph_triplets_string]
        )

        # 沿用chromadb的余弦距离计算
        from chromadb.utils import distance_functions
        import numpy as np

        query_embedding_np = np.array(query_embedding)
        triplets_embedding_np = np.array(triplets_embedding)

        cosine_score = 1 - distance_functions.cosine(query_embedding_np, triplets_embedding_np)
        return float(cosine_score)

    def _wrap_query_results(self, triple_results: List[List[str]],
                            subgraph_options: Dict,
                            chunks_results: List[Tuple[str, float]],
                            query_text: str) -> QueryResults:
        """
        包装查询结果
        Args:
            triple_results (List[List[str]]): 三元组结果
            subgraph_options (dict): 子图选项
            chunks_results (List[Tuple[str, float]]): 文档块结果
        Returns:
            QueryResults: 查询结果列表
        """
        graph_triplets = self._remove_duplicate(triple_results)
        cosine_score = self._calculate_score(graph_triplets, query_text)

        if chunks_results:
            max_score_chunk_id = None
            max_score = 0

            from collections import Counter
            chunk_counts = Counter()

            for chunk_id, score in chunks_results:
                if score > 0:
                    chunk_counts[chunk_id] += 1
                    if chunk_counts[chunk_id] > max_score:
                        max_score = chunk_counts[chunk_id]
                        max_score_chunk_id = chunk_id

            # 如果没有有效结果，设置默认值
            if max_score_chunk_id is None and chunks_results:
                max_score_chunk_id = chunks_results[0][0]
            with get_doc_datastore(self._kb_id) as doc_store:
                chunk, error = doc_store.load_chunk(max_score_chunk_id, self.index_type)
                if error.code != KBXError.Code.SUCCESS:
                    err_msg = f"Failed to load text chunk {max_score_chunk_id} from doc ds."
                    err_msg += f" Error message: {error.msg}"
                    logger.error(err_msg)
                    query_result = QueryResult(graph_triplets=graph_triplets,
                                               subgraph_options=subgraph_options,
                                               index_type=self.index_type,
                                               score=cosine_score,
                                               kb_id=self._kb_id)
                    return QueryResults(results=[query_result])
                else:
                    doc_id = chunk.doc_id
            query_result = QueryResult(chunk=chunk,
                                       graph_triplets=graph_triplets,
                                       subgraph_options=subgraph_options,
                                       index_type=self.index_type,
                                       score=cosine_score,
                                       kb_id=self._kb_id,
                                       doc_id=doc_id)
        else:
            query_result = QueryResult(graph_triplets=graph_triplets,
                                       subgraph_options=subgraph_options,
                                       index_type=self.index_type,
                                       score=cosine_score,
                                       kb_id=self._kb_id)
        return QueryResults(results=[query_result])

    def _retrieve(self, query: QueryConfig) -> QueryResults:
        """查询

        Args:
            query (QueryConfig): 查询参数

        Returns:
            QueryResults: 查询结果
        """
        retry_count = 0
        # name_properties = ["名称", "简称", "英文名称", "英文简称"]
        name_properties = list([e['类型'] for e in self.schema['属性'] if e['是否标识'] == '是'])
        while retry_count < self._index_config.max_retry:
            try:
                triple_results = []
                subgraph_options = self._default_subgraph_options()
                chunks_results = []
                ids = self._retrieve_entity(query)
                # logger.info(f"Retrieved entities by question vector: {ids}")
                if ids:
                    triples = self.data_store.collect_triples(ids, name_properties)
                    subgraph = self.data_store.subgraph(ids, name_properties)
                    subgraph_options['series'][0]['data'] = subgraph['nodes']
                    subgraph_options['series'][0]['links'] = subgraph['links']
                    # logger.info(triples)
                    triple_results += triples
                    with get_keyword_datastore(self.kb_id, index_type=self.index_type) as entity_doc_datastore:
                        chunk_id_scores, error = entity_doc_datastore.search(list(map(lambda ent: str(ent), ids)))
                        chunks_results += chunk_id_scores
                        # logger.info(f"chunks={chunk_id_scores}")
                else:
                    # logger.info("No entities retrieved")
                    return QueryResults(results=[])
                return self._wrap_query_results(triple_results, subgraph_options, chunks_results, query.text)
            except Exception as e:
                retry_count = retry_count + 1
                logger.error(e)
