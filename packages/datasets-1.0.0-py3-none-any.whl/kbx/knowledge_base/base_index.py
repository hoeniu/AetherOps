from abc import ABC, abstractmethod
from typing import Union, List, Tuple, Optional, Dict, Any, Generic, TypeVar
from kbx.knowledge_base.types import VectorKeywordIndexConfig, KnowledgeGraphIndexConfig, \
    StructuredIndexConfig, DynamicDocIndexConfig, QueryConfig, QueryResult
from kbx.common.types import IndexType, DocData, KBXError


ALL_INDEX_CONFIG_TYPES = Union[
    VectorKeywordIndexConfig,
    KnowledgeGraphIndexConfig,
    StructuredIndexConfig,
    DynamicDocIndexConfig,
]
TC = TypeVar('TC', bound=ALL_INDEX_CONFIG_TYPES)


class BaseIndex(ABC, Generic[TC]):
    def __init__(
        self,
        kb_id: str,
        index_config: TC,
    ) -> None:
        """所有索引类型的基类

        Args:
            kb_id (str): 知识库唯一id
            index_config (ALL_INDEX_CONFIG_TYPES): 所需创建的索引配置参数
        """
        self._kb_id = kb_id
        self._index_config: TC = index_config

    @property
    def kb_id(self) -> str:
        """获取本索引对应的知识库id

        Returns:
            str: 知识库唯一id
        """
        return self._kb_id

    @property
    def index_type(self) -> IndexType:
        """获取本索引的类型

        Returns:
            IndexType: 索引类型
        """
        if isinstance(self._index_config, KnowledgeGraphIndexConfig):
            return IndexType.KNOWLEDGE_GRAPH
        elif isinstance(self._index_config, VectorKeywordIndexConfig):
            return IndexType.VECTOR_KEYWORD
        elif isinstance(self._index_config, StructuredIndexConfig):
            return IndexType.STRUCTURED
        else:
            raise RuntimeError(f'Unknown index config type: {self._index_config}')

    @abstractmethod
    def insert_single_doc(self, doc_data: DocData) -> KBXError:
        """插入一个文档数据

        Args:
            doc_data (DocData): 待插入文档的DocData数据

        Returns:
            KBXError: 文档插入的错误信息
        """
        raise NotImplementedError

    def get_legal_config_attr_changes(self) -> List[str]:
        """获取本Index允许修改的配置属性
        Returns:
            List[str]: 允许修改的配置属性Key列表，注意，只提供一级属性中允许修改的名称列表，不做递归分析
        """
        return []

    def validate_index_config_changes(self, config_diff: Dict[str, Any]) -> KBXError:
        """检查Index配置修改是否合法，如果存在不允许的修改，返回（所有）对应的错误信息

        Args:
            config_diff (Dict[str, Any]): Index配置发生变动的部分

        Returns:
            KBXError: 错误信息
        """
        raise NotImplementedError

    def modify_index_config(self, new_index_config: TC) -> Tuple[KBXError, bool]:
        """修改本Index的配置，注意，对于修改embedding模型等特殊配置后，可能需要上层额外进行reindex调用

        Args:
            new_index_config (ALL_INDEX_CONFIG_TYPES): 新的Index配置

        Returns:
            Tuple[KBXError, bool]: 第一项表示本次配置修改是否成功，第二项表示是否需要reindex，
                注意，只有在第一项为SUCCESS的情况下第二项才可能为True
        """
        raise NotImplementedError

    @abstractmethod
    def reindex(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        """对部分文档重新建立索引

        Args:
            doc_ids (Union[str, List[str]]): 需要重新建立索引的文档id

        Returns:
            Optional[List[Tuple[str, str]]]: 如果执行成功直接返回None，否则会把错误信息进行返回，
                格式为[(doc_id, err_msg), (doc_id, err_msg), ...]
        """
        raise NotImplementedError

    @abstractmethod
    def reindex_all(self) -> Optional[List[Tuple[str, str]]]:
        """对全部文档重新建立索引

        Returns:
            Optional[List[Tuple[str, str]]]: 如果执行成功直接返回None，否则会把错误信息进行返回，
                格式为[(doc_id, err_msg), (doc_id, err_msg), ...]
        """
        raise NotImplementedError

    @abstractmethod
    def remove_docs(self, doc_ids: Union[str, List[str]]) -> Optional[List[Tuple[str, str]]]:
        """删除一个或多个文档的索引数据

        Args:
            doc_ids (Union[str, List[str]]): _description_

        Returns:
            Optional[List[Tuple[str, str]]]: 如果执行成功直接返回None，否则会把错误信息进行返回，
                格式为[(doc_id, err_msg), (doc_id, err_msg), ...]
        """
        raise NotImplementedError

    @abstractmethod
    def remove_index(self) -> None:
        """删除全部索引数据"""
        raise NotImplementedError

    @abstractmethod
    def retrieve(self, query: QueryConfig, selected_doc_ids: Optional[List[str]] = None) -> List[QueryResult]:
        """查询

        Args:
            query (QueryConfig): 查询参数
            selected_doc_ids (Optional[List[str]]): 需要检索的文档id列表，如果为None/空列表，则检索全部文档
        Returns:
            List[QueryResult]: 查询结果
        """
        raise NotImplementedError

    # TODO: 其他标准接口？待补充
