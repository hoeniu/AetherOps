from __future__ import annotations

import functools
from typing import List, Union, Tuple, Dict, Optional, Any, Iterable, Iterator, Callable
from abc import ABC
import os
import json
import threading, queue
from datetime import datetime
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor
from sqlalchemy.orm import Session
from kbx.common.constants import DEFAULT_USER_ID
from kbx.common.utils import generate_new_id, get_pydantic_config_changes, inject_user_ctx, doc_elements_to_markdown
from kbx.common.types import DocData, IndexType, DocFileType, \
    KBXError, UserContext
from kbx.common.logging import logger
from kbx.parser.types import DocParseConfig
from kbx.parser.constants import DEFAULT_NORMAL_DOC_FILE_PATTERNS
from kbx.knowledge_base.types import KBCreationConfig, QueryConfig, QueryResult, QueryResults, \
    Chunk, DocInfo, DocType, DocStatus, RetrievalStepMessage
from kbx.knowledge_base.base_index import BaseIndex
from kbx.knowledge_base.index_factory import get_knowledge_graph_index, \
    get_structured_index, get_vector_keyword_index, get_dynamic_doc_index
from kbx.parser.parser_factory import SmartParser
from kbx.db.types import UserORM, KBInfoORM, DocInfoORM, FileInfoORM
from kbx.db.session import DBSession
from kbx.datastore.ds_factory import get_file_datastore, get_doc_datastore
from kbx.datastore.types import FileType
from kbx.rerank.rerank_factory import get_rerank
from kbx.agent.types import SearchAgentConfig, TOCAgentConfig
from kbx.common.toc_builder import TOCBuilder
from kbx.common.otel import get_tracer, context_wrapper, get_context


tracer = get_tracer(__name__)


INDEX_CONFIG_ATTR_TYPE_PAIRS = [
    ('vector_keyword_config', IndexType.VECTOR_KEYWORD),
    ('structured_config', IndexType.STRUCTURED),
    ('kg_config', IndexType.KNOWLEDGE_GRAPH),
    ('dynamic_doc_config', IndexType.DYNAMIC_DOC),
]


class KnowledgeBase(ABC):
    def __init__(self, *args, **kwargs) -> None:
        """知识库类型，禁止直接通过__init__进行实例构造，必须使用以下方法获得实例
        - create_new_kb: 用于创建一个新知识库实例
        - get_existed_kb: 用于获取一个已存在的知识库实例
        """
        raise RuntimeError(
            f'Please do not call {self.__class__.__name__}.__init__() directly.'
            'Use create_new_kb or get_existed_kb instead.'
        )

    @property
    def index_map(self) -> Dict[IndexType, BaseIndex]:
        return self._index_map

    @staticmethod
    @tracer.start_as_current_span("knowledge_base.create_new_kb")
    def create_new_kb(
        kb_config: KBCreationConfig,
        user_id: str,
        desired_kb_id: Optional[str] = None,
    ) -> KnowledgeBase:
        """创建一个新的空知识库
        如果因为配置不合法或其他原因导致知识库创建失败，会抛出异常

        Args:
            kb_config (Optional[KBCreationConfig]): 知识库的配置参数
            user_id (str): 该知识库所属用户的user_id
            desired_kb_id (Optional[str]): 期望新创建知识库使用的唯一id，默认为空，此时会自动生成一个新的kb_id

        Returns:
            KnowledgeBase: 知识库实例
        """
        if not kb_config.name or not isinstance(kb_config.name, str):
            raise ValueError(f'Please provide a valid name for the knowledge base, given "{kb_config.name}"')

        kb = KnowledgeBase.__new__(KnowledgeBase)

        with DBSession() as db:
            # 查询租户id
            user = db.query(UserORM).filter(UserORM.id == user_id).first()
            if user is None:
                raise ValueError(f'User id {user_id} does not exists.')
            kb._tenant_id = user.tenant_id

        kb._user_id = user_id
        kb._kb_config = inject_user_ctx(
            config=kb_config,
            user_ctx=UserContext(user_id=kb._user_id, tenant_id=kb._tenant_id),
            recursive=True,
        )
        kb._kb_id = None

        with DBSession() as db:
            if desired_kb_id:
                previous_kb_info = db.query(KBInfoORM).filter_by(
                    user_id=user_id,
                    tenant_id=kb._tenant_id,
                    id=desired_kb_id
                ).first()
                if previous_kb_info:
                    raise RuntimeError(
                        f'Knowledge base {desired_kb_id} already exists, '
                        'can not create a new one with the same id.'
                    )
                kb._kb_id = desired_kb_id
            else:
                # 如果没有指定有效的desired_kb_id，统一为None，后续由数据库自动生成
                desired_kb_id = None

            previous_kb_info = db.query(KBInfoORM).filter_by(
                user_id=user_id, tenant_id=kb._tenant_id, name=kb_config.name).first()
            if previous_kb_info:
                raise RuntimeError(
                    f'Knowledge base {kb_config.name} already exists, '
                    'can not create a new one with the same name.'
                )

            kb_info = KBInfoORM(
                id=desired_kb_id,
                name=kb_config.name,
                creation_time=datetime.now(),
                description=kb_config.description,
                creation_config_json=kb_config.model_dump_json(),
                tenant_id=kb._tenant_id,
                user_id=user_id,
            )
            db.add(kb_info)
            db.commit()

            kb._kb_id = str(kb_info.id)
            kb._tenant_id = kb_info.tenant_id

        try:
            # 提前准备好index
            kb._index_map = {}
            for config_attr, index_type in INDEX_CONFIG_ATTR_TYPE_PAIRS:
                index = getattr(kb, f'_try_get_{index_type.value.lower()}_index')()
                kb._index_map[index_type] = index
        except Exception as e:
            # 如果index初始化失败，则删除知识库
            kb.remove_kb()
            raise RuntimeError(f'Failed to initialize index for knowledge base: {e}')
        # 过滤未开启的index索引
        kb._index_map = dict(filter(lambda kv: kv[1] is not None, kb._index_map.items()))

        return kb

    @staticmethod
    @tracer.start_as_current_span("knowledge_base.get_existed_kb")
    def get_existed_kb(
        kb_id: Optional[str] = None,
        kb_name: Optional[str] = None,
        user_id: str = DEFAULT_USER_ID,
    ) -> KnowledgeBase:
        """给定一个已经存在的知识库唯一id或名称，从数据库中读取相关信息，然后初始化对应的实例
        如果kb_id不存在，会直接抛出异常

        Args:
            kb_id (Optional[str]): 知识库唯一id，与kb_name至少提供一个
            kb_name (Optional[str]): 知识库名称，与kb_id至少提供一个
            user_id (str): 该知识库所属用户的user_id

        Returns:
            KnowledgeBase: 知识库实例
        """
        if not kb_id and not kb_name:
            raise ValueError('Please provide valid kb_id or kb_name.')

        tenant_id = None
        # 查询db，尝试恢复kb_id对应的知识库相关信息
        with DBSession() as db:
            filter_kwargs = {'user_id': user_id}
            if kb_id:
                filter_kwargs['id'] = kb_id
            if kb_name:
                filter_kwargs['name'] = kb_name
            kb_info_orm = db.query(KBInfoORM).filter_by(**filter_kwargs).first()
            if kb_info_orm is None:
                raise RuntimeError(f"Knowledge base {kb_id} does not exists for user {user_id}")
            else:
                kb_id = kb_info_orm.id
                kb_name = kb_info_orm.name
                tenant_id = kb_info_orm.tenant_id

        kb = KnowledgeBase.__new__(KnowledgeBase)
        kb._kb_id = kb_id
        kb._kb_config = inject_user_ctx(
            config=KBCreationConfig(**json.loads(kb_info_orm.creation_config_json)),
            user_ctx=UserContext(user_id=user_id, tenant_id=tenant_id),
            recursive=True,
        )
        kb._user_id = user_id
        kb._tenant_id = tenant_id

        # 提前准备好index
        kb._index_map = {
            IndexType.VECTOR_KEYWORD: kb._try_get_vector_keyword_index(),
            IndexType.STRUCTURED: kb._try_get_structured_index(),
            IndexType.KNOWLEDGE_GRAPH: kb._try_get_knowledge_graph_index(),
            IndexType.DYNAMIC_DOC: kb._try_get_dynamic_doc_index(),
        }
        # 过滤未开启的index索引
        kb._index_map = dict(filter(lambda kv: kv[1] is not None, kb._index_map.items()))

        return kb

    @tracer.start_as_current_span("knowledge_base.remove_kb")
    def remove_kb(self) -> None:
        """删除此知识库"""

        # TODO: 需要加锁？

        # 注意这里的删除逻辑是：
        # - 删除所有文档
        # - 删除各个（空）索引
        # - 删除相关Datastore
        # - 删除知识库记录

        err_msg_list = []

        # 删除文档
        while doc_ids := self.list_doc_ids()[0]:
            self.remove_docs(doc_ids=doc_ids)

        # 删除索引
        for index_type in self.index_map.keys():
            try:
                self.index_map[index_type].remove_index()
            except Exception as e:
                err_msg_list.append(f'Failed to remove {index_type} index for knowledge base {self.kb_id}:\n{e}')

        # 删除File/Doc Datastore
        try:
            with get_file_datastore(self.kb_id) as file_ds:
                file_ds.delete_ds()
        except Exception as e:
            err_msg_list.append(f'Remove file datastore for knowledge base {self.kb_id} failed: {e}')

        try:
            with get_doc_datastore(self.kb_id) as doc_ds:
                doc_ds.delete_ds()
        except Exception as e:
            err_msg_list.append(f'Remove doc datastore for knowledge base {self.kb_id} failed: {e}')

        # 删除知识库相关记录
        with DBSession() as db:
            db.query(KBInfoORM).filter_by(id=self.kb_id, user_id=self.user_id, tenant_id=self.tenant_id).delete()
            db.commit()

        if err_msg_list:
            logger.error(
                'Something went wrong when removing knowledge base'
                f' {self.kb_id}:\n' + "\n".join(err_msg_list)
            )

        # 把相关信息设为无效值
        self._kb_id: Optional[str] = None
        self._kb_config: Optional[KBCreationConfig] = None
        self._user_id: Optional[str] = None
        self._tenant_id: Optional[str] = None

    @staticmethod
    def if_kb_exists(
        kb_id: Optional[str] = None,
        kb_name: Optional[str] = None,
        user_id: str = DEFAULT_USER_ID,
    ) -> bool:
        """判断指定kb_id/kb_name的知识库是否存在

        Args:
            kb_id (Optional[str]): 知识库唯一id，与kb_name至少提供一个
            kb_name (Optional[str]): 知识库名称，与kb_id至少提供一个
            user_id (str): 该知识库所属用户的user_id

        Returns:
            bool: 指定知识库是否存在
        """
        if not kb_id and not kb_name:
            raise ValueError('Please provide valid kb_id or kb_name.')

        # 查询db，尝试恢复kb_id对应的知识库相关信息
        with DBSession() as db:
            filter_kwargs = {'user_id': user_id}
            if kb_id:
                filter_kwargs['id'] = kb_id
            if kb_name:
                filter_kwargs['name'] = kb_name
            kb_info_orm = db.query(KBInfoORM).filter_by(**filter_kwargs).first()
            return kb_info_orm is not None

    @property
    def kb_config(self) -> KBCreationConfig:
        """获取本知识库的参数配置

        Returns:
            KBCreationConfig: 本知识库的参数配置
        """
        if self._kb_config:
            # 返回一个深拷贝，防止外部直接对其进行修改
            return self._kb_config.model_copy(deep=True)
        else:
            return None

    @property
    def kb_name(self) -> str:
        """获取本知识库的名称

        Returns:
            str: 知识库名称
        """
        return str(self.kb_config.name)

    @property
    def kb_id(self) -> str:
        """获取本知识库的唯一id

        Returns:
            str: 知识库唯一id
        """
        return str(self._kb_id)

    @property
    def user_id(self) -> str:
        """获取本知识库的用户id

        Returns:
            str: 用户id
        """

        return self._user_id

    @property
    def tenant_id(self) -> str:
        """获取本知识库的租户id

        Returns:
            str: 租户id
        """

        return self._tenant_id

    def get_legal_config_attr_changes(self) -> List[Union[str, Tuple[str, List]]]:
        """获取本知识库允许修改的配置属性
        Returns:
            List[Union[str, Tuple[str, List]]]: 允许修改的配置属性Key列表，
                如果是一级属性，则对应元素为str类型，如果是二级属性（例如某个IndexConfig的配置），则为元组，
                元组第一个元素为一级属性名称，第二个元素为二级属性中允许修改的部分，例如
                [
                    'name',
                    'description',
                    ('vector_config': ['embedding_model']),
                    ('kg_config': ['embedding_model', 'llm_model']),
                ]
        """
        legal_changes = [
            'name',
            'description',
            'rerank_config',
        ]

        for key, index_type in INDEX_CONFIG_ATTR_TYPE_PAIRS:
            if index_type in self.index_map:
                legal_changes.append((key, self.index_map[index_type].get_legal_config_attr_changes()))

        return legal_changes

    def validate_kb_config_changes(self, config_diff: Dict[str, Any]) -> KBXError:
        """检查知识库配置修改是否合法，如果存在不允许的修改，返回（所有）对应的错误信息

        Args:
            config_diff (Dict[str, Any]): 知识库配置发生变动的部分

        Returns:
            KBXError: 错误信息
        """
        illegal_changes: List[str] = []

        # NOTE: 检查是否有非法修改
        # 先处理顶层属性中禁止修改的部分
        illegal_attrs = [
            'is_external_datastore',
            'doc_parse_config',  # TODO: 待实现
        ]
        for key in illegal_attrs:
            if key in config_diff:
                illegal_changes.append(f'Can not modify {key} field')
        # 再处理各类索引相关的修改
        for key, index_type in INDEX_CONFIG_ATTR_TYPE_PAIRS:
            if key in config_diff:
                if index_type not in self.index_map:
                    # NOTE: 目前不支持对创建知识库时禁用的索引进行改配置
                    # TODO: 待实现创建知识库后开启新index或禁用旧index
                    illegal_changes.append(f'Can not modify {key} field because {index_type} index is not enabled')
                else:
                    # 如果索引存在，检查是否有非法修改
                    err = self.index_map[index_type].validate_index_config_changes(config_diff[key])
                    if err.code != KBXError.Code.SUCCESS:
                        illegal_changes.append(f'Illegal {key}: {err.msg}')

        if len(illegal_changes) == 0:
            return KBXError()
        else:
            illegal_changes_str = "\n\t".join(illegal_changes)
            return KBXError(
                code=KBXError.Code.INVALID_VALUE,
                msg=(f"Invalid KB config changes for kb {self.kb_config.name} "
                     f'(id={self.kb_id}):\n{illegal_changes_str}')
            )

    @tracer.start_as_current_span("knowledge_base.modify_kb_config")
    def modify_kb_config(self, new_kb_config: KBCreationConfig) -> KBXError:
        """修改知识库配置

        Args:
            new_kb_config (KBCreationConfig): 新的知识库配置

        Returns:
            KBXError: 错误信息
        """
        # 先复制一份，避免外部修改
        new_kb_config = inject_user_ctx(
            config=new_kb_config.model_copy(deep=True),
            user_ctx=UserContext(user_id=self.user_id, tenant_id=self.tenant_id),
            recursive=True
        )

        err = KBXError()
        config_diff = get_pydantic_config_changes(self.kb_config, new_kb_config, recursive=True)
        if not config_diff:
            # 如果没有任何修改，直接返回
            return err

        # 实现逻辑：
        #   1. 先检查是否有不允许的非法参数修改，如果有的话直接返回对应错误消息，不对现有知识库做任何修改
        #   2. 检查KBCreationConfig顶层属性是否有发生合法修改，并进行对应处理
        #   3. 如果发生了某特定索引相关的修改，调用对应Index的modify_index_config接口

        # step 1
        err = self.validate_kb_config_changes(config_diff)
        if err.code != KBXError.Code.SUCCESS:
            # 如果存在非法修改，直接返回对应错误
            return err

        # step 2
        for key in ['name', 'description']:
            if key in config_diff:
                # 如果修改了此类参数，只需要更新kb_info表中的记录即可，不涉及额外变动
                with DBSession() as db:
                    db.query(KBInfoORM).filter_by(id=self.kb_id, user_id=self.user_id, tenant_id=self.tenant_id).update(
                        {key: getattr(new_kb_config, key)}
                    )
                    db.commit()
                    setattr(self._kb_config, key, getattr(new_kb_config, key))
        if 'rerank_config' in config_diff:
            # 如果修改了rerank_config，需要更新所有索引的rerank_config
            setattr(self._kb_config, 'rerank_config', new_kb_config.rerank_config)
            new_config_json = self._kb_config.model_dump_json()
            with DBSession() as db:
                db.query(KBInfoORM).filter_by(id=self.kb_id, user_id=self.user_id, tenant_id=self.tenant_id).update(
                    {'creation_config_json': new_config_json}
                )
                db.commit()

        index_errors = {}
        for key, index_type in INDEX_CONFIG_ATTR_TYPE_PAIRS:
            if key in config_diff:
                # 如果修改了某特定索引相关的配置，调用对应Index的modify_index_config接口
                tmp_err, need_reindex = self.index_map[index_type].modify_index_config(getattr(new_kb_config, key))
                if tmp_err.code != KBXError.Code.SUCCESS:
                    # 如果修改失败，记录对应错误
                    index_errors[index_type] = tmp_err
                else:
                    # 改配成功
                    setattr(self._kb_config, key, getattr(new_kb_config, key))
                    # 检查是否需要额外调用reindex_all，各个文档状态由reindex_all负责更新
                    if need_reindex:
                        self.reindex_all(reparse=False)
        if len(index_errors) > 0:
            err = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f'Failed to modify KB config for kb {self.kb_config.name} (id={self.kb_id}):\n' + str(index_errors)
            )

        # 更新kb_info表中的记录
        # NOTE: 这里不判断err是否出错，原因是考虑万一出现部分修改成功、部分失败的情况
        with DBSession() as db:
            kb_info_orm = db.query(KBInfoORM).filter_by(
                id=self.kb_id, user_id=self.user_id, tenant_id=self.tenant_id).first()
            kb_info_orm.creation_config_json = self.kb_config.model_dump_json()
            db.commit()

        return err

    def _update_doc_info(self, doc_info: DocInfo, db: Optional[Session] = None):
        """更新文档信息"""
        doc_info_orm = DocInfoORM.from_pydantic(
            doc_info=doc_info,
            kb_id=self.kb_id,
            user_id=self.user_id,
            tenant_id=self.tenant_id
        )
        if db:
            db.merge(doc_info_orm)
            db.commit()
        else:
            with DBSession() as db:
                db.merge(doc_info_orm)
                db.commit()

    @tracer.start_as_current_span("knowledge_base.upload_file")
    def _upload_file(self, file_path: str, save_dir: str = "") -> DocInfo:
        doc_info = DocInfo()
        doc_info.doc_status = DocStatus.PARSING

        if not isinstance(file_path, str) or file_path == '':
            doc_info.err_info = KBXError(
                code=KBXError.Code.INVALID_VALUE,
                msg=f'Please provide a valid file path, given "{file_path}"'
            )
            doc_info.doc_status = DocStatus.UPLOAD_FAILED
            return doc_info

        if not os.path.isfile(file_path):
            doc_info.err_info = KBXError(
                code=KBXError.Code.INVALID_VALUE,
                msg=f'File {file_path} does not exist or it is not a file.'
            )
            doc_info.doc_status = DocStatus.UPLOAD_FAILED
            return doc_info

        # 检查文件大小
        file_size = os.path.getsize(file_path)
        from kbx.kbx import KBX
        if file_size > KBX.config.upload_file_size_limit:
            doc_info.err_info = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f'File "{file_path}" is too large, max size is '
                f'{KBX.config.upload_file_size_limit} bytes, given {file_size}.'
            )
            doc_info.doc_status = DocStatus.UPLOAD_FAILED
            return doc_info

        doc_id = generate_new_id()
        # 检查之前是否有同名文件
        has_previous_doc = False

        # 处理save_dir，确保无论是否以"/"开头，都视为相同的路径
        normalized_save_dir = save_dir.lstrip('/') if save_dir else ""
        full_save_dir_path = os.path.join(
            FileType.RAW_DOC_FILES,
            normalized_save_dir
        ) if normalized_save_dir else FileType.RAW_DOC_FILES

        with DBSession() as db:
            fname = os.path.basename(file_path)
            # 构建完整的文件路径，包括save_dir
            file_path_in_db = os.path.join(full_save_dir_path, fname)

            previous_doc = db.query(DocInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id,
                file_path=file_path_in_db
            ).first()
            if previous_doc:
                # NOTE: 如果有同名文件，直接使用之前的doc_id
                doc_id = previous_doc.id
                has_previous_doc = True
        if has_previous_doc:
            # 如果有重名文件，先删除之前的文件及相关索引数据，防止数据重复累积
            self.remove_docs(doc_ids=[doc_id])

        # 文档上传
        with get_file_datastore(self.kb_id) as file_ds:
            # 构建完整的保存路径
            rets = file_ds.upload_files(file_list=[file_path], save_dir=full_save_dir_path)
        err, file_info = rets[0]
        doc_info.raw_file_info = file_info
        if err.code != KBXError.Code.SUCCESS:
            doc_info.err_info = err
            doc_info.doc_status = DocStatus.UPLOAD_FAILED
            return doc_info
        assert file_info is not None

        # 只要上传成功，就需要更新业务数据库中的DocInfo/FileInfo记录
        doc_info.doc_id = doc_id
        doc_info.raw_file_info = file_info
        with DBSession() as db:
            # 创建一条文件信息记录
            new_file_info_orm = FileInfoORM.from_pydantic(
                file_info=doc_info.raw_file_info,
                kb_id=self.kb_id,
                user_id=self.user_id,
                tenant_id=self.tenant_id,
                doc_id_if_raw_doc_file=doc_id,
                doc_id_if_extra_file=None,
            )
            existing_file_info_orm = db.query(FileInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id,
                file_path=file_info.file_path
            ).first()
            if existing_file_info_orm:
                # 如果之前有相同文件记录，则需要更新id
                new_file_info_orm.id = existing_file_info_orm.id
            db.merge(new_file_info_orm)
            db.commit()

            # 覆盖写入新的doc_info记录
            # 即将进入文档解析阶段
            doc_info.doc_status = DocStatus.UPLOAD_SUCCESS
            self._update_doc_info(doc_info, db=db)
        return doc_info

    @tracer.start_as_current_span("knowledge_base.parse_doc")
    def _parse_doc(self, doc_info: DocInfo) -> Tuple[DocInfo, Optional[DocData]]:
        if doc_info.doc_status == DocStatus.UPLOAD_FAILED:
            # 如果上传失败，直接返回，除此之外其他状态均可正常进行文档解析
            return doc_info, None

        # 先更新为PARSING状态
        doc_info.doc_status = DocStatus.PARSING
        self._update_doc_info(doc_info, db=None)

        # NOTE: 不管之后文档解析成功或失败，先插入一个empty doc data占位，
        #       保证系统中每一个记录的doc_id均可以查询到对应的doc_data
        doc_data = DocData(
            doc_id=doc_info.doc_id,
            file_name=os.path.split(doc_info.raw_file_info.file_path)[-1],
            file_path=doc_info.raw_file_info.file_path,
            file_raw_path=doc_info.raw_file_info.file_raw_path,
            file_url=doc_info.raw_file_info.file_url,
            doc_elements=[]
        )
        with get_doc_datastore(self.kb_id) as doc_store:
            doc_store.save_doc_data(doc_data=doc_data)
            doc_store.flush()

        file_type = DocFileType.get_file_type_by_file_name(doc_info.raw_file_info.file_path)
        if file_type == DocFileType.UNKNOWN:
            doc_info.doc_status = DocStatus.PARSE_FAILED
            doc_info.err_info = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f"Unsupported doc file type: {doc_info.raw_file_info.file_path}"
            )
            self._update_doc_info(doc_info, db=None)
            return doc_info, None

        # 文档解析
        from kbx.kbx import KBX
        try:
            # 优先使用doc_info中的doc_parse_config，如果没有则使用kb_config中的doc_parse_config
            doc_parse_config = doc_info.doc_parse_config
            if doc_parse_config is None:
                doc_parse_config = self.kb_config.doc_parse_config
            if KBX.celery_app is None:
                # 如果没有配置celery，直接在当前进程中解析
                file_ds = get_file_datastore(self.kb_id)
                parser = SmartParser(doc_parse_config, file_ds)
                doc_data = parser.parse(file_path=doc_info.raw_file_info.file_path, doc_id=doc_info.doc_id)
            else:
                # 如果配置了celery，使用celery异步解析
                result = KBX.celery_app.send_task(
                    'kbx.tasks.document_parse_task.parse_document_file',
                    kwargs={
                        'file_path': doc_info.raw_file_info.file_path,
                        'doc_id': doc_info.doc_id,
                        'doc_parse_config_json_str': doc_parse_config.model_dump_json(),
                        'kb_id': self.kb_id,
                    }
                )
                # https://docs.celeryq.dev/en/latest/userguide/tasks.html#avoid-launching-synchronous-subtasks
                doc_data = result.get(disable_sync_subtasks=False)
                assert doc_data is not None
                assert isinstance(doc_data, DocData)
        except Exception as e:
            doc_info.doc_status = DocStatus.PARSE_FAILED
            doc_info.err_info = KBXError(
                code=KBXError.Code.RUNTIME_ERROR,
                msg=f'Failed to parse {doc_info.raw_file_info.file_path}: {e}'
            )
            self._update_doc_info(doc_info, db=None)
            return doc_info, None

        # doc_data立即写入doc_store
        with get_doc_datastore(self.kb_id) as doc_store:
            doc_store.save_doc_data(doc_data=doc_data)
            doc_store.flush()
        with DBSession() as db:
            # 确认解析出doc_data后，更新doc_info记录
            db.merge(
                DocInfoORM.from_pydantic(
                    doc_info=doc_info,
                    kb_id=self.kb_id,
                    user_id=self.user_id,
                    tenant_id=self.tenant_id
                )
            )

            # 查找并插入额外的文件
            for element in doc_data.doc_elements:
                if element.data_file_path:
                    if FileType.RAW_DOC_FILES in element.data_file_path:
                        # 如果文件在RAW_DOC_FILES目录下（也就是资源文件），则不作为extra_file文件插入
                        continue
                    # 访问file_ds获取相关文件信息
                    with file_ds:
                        rets = file_ds.list_files(element.data_file_path, limit=1)
                        if len(rets) == 0 or rets[0].file_path != element.data_file_path:
                            # 如果文件不存在，报错
                            err_msg = f"Can not find extra data file {element.data_file_path} " \
                                f"for {doc_info.raw_file_info.file_path}"
                            logger.error(err_msg)
                            continue
                        extra_file_info = rets[0]
                    doc_info.extra_files_info.append(extra_file_info)
                    new_file_info_orm = FileInfoORM.from_pydantic(
                        file_info=extra_file_info,
                        kb_id=self.kb_id,
                        user_id=self.user_id,
                        tenant_id=self.tenant_id,
                        doc_id_if_extra_file=doc_info.doc_id,
                    )
                    existing_file_info_orm = db.query(FileInfoORM).filter_by(
                        tenant_id=self.tenant_id,
                        user_id=self.user_id,
                        kb_id=self.kb_id,
                        file_path=element.data_file_path
                    ).first()
                    if existing_file_info_orm:
                        # 如果之前有相同文件记录，则需要复用旧id
                        new_file_info_orm.id = existing_file_info_orm.id
                    db.merge(new_file_info_orm)

            db.commit()

        doc_info.doc_status = DocStatus.PARSE_SUCCESS
        self._update_doc_info(doc_info, db=None)

        return doc_info, doc_data

    def _parse_doc_by_id(self, doc_id: str) -> DocInfo:
        with DBSession() as db:
            doc_info_orm = db.query(DocInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id,
                id=doc_id,
            ).first()
            if doc_info_orm is None:
                return DocInfo(
                    doc_id=doc_id,
                    err_info=KBXError(
                        code=KBXError.Code.RUNTIME_ERROR,
                        msg=f'Failed to parse doc: doc_id {doc_id} not found'
                    )
                )
            doc_info = doc_info_orm.to_pydantic()
        if doc_info.doc_type != DocType.NORMAL:
            # 如果文档类型不是标准文档，则直接返回
            return doc_info
        doc_info, _ = self._parse_doc(doc_info=doc_info)
        return doc_info

    @tracer.start_as_current_span("knowledge_base.index_doc")
    def _index_doc(self, doc_info: DocInfo, doc_data: DocData) -> DocInfo:
        if doc_info.doc_status == DocStatus.UPLOAD_FAILED or doc_info.doc_status == DocStatus.PARSE_FAILED:
            return doc_info

        # 先更新为PARSING状态
        doc_info.doc_status = DocStatus.INDEXING
        self._update_doc_info(doc_info, db=None)

        for index_type, index in self.index_map.items():
            # 在对应的index里插入文档
            # TODO: 后续统一改为单个文档的插入接口
            err = index.insert_single_doc(doc_data)
            if err.code != KBXError.Code.SUCCESS:
                # 记录错误信息
                doc_info.doc_status = DocStatus.INDEX_FAILED
                doc_info.err_info = KBXError(
                    code=KBXError.Code.RUNTIME_ERROR,
                    msg=f'Failed to build {index_type} index for {doc_info.raw_file_info.file_path}: {err.msg}'
                )
                self._update_doc_info(doc_info, db=None)
                return doc_info

        # 插入文档一切正常
        doc_info.doc_status = DocStatus.INDEX_SUCCESS
        doc_info.err_info = KBXError(code=KBXError.Code.SUCCESS)
        self._update_doc_info(doc_info, db=None)
        return doc_info

    @tracer.start_as_current_span("knowledge_base.insert_single_doc")
    def insert_single_doc(
        self,
        file_path: str,
        doc_parse_config: Optional[DocParseConfig] = None,
        save_dir: str = "",
        doc_type: Optional[DocType] = DocType.NORMAL,
        doc_patterns: Optional[List[str]] = None,
        only_upload: bool = False,
    ) -> DocInfo:
        """对单个本地文档文件进行入库，包括如下步骤

        - 检查输入文件路径是否合法
        - 上传至KBX文件存储
        - 调用parser解析成DocData
        - 使用解析出的DocData建立索引

        任意一个环节出错，会直接返回，错误信息通过DocInfo的err_info和doc_status体现

        Args:
            file_path (str): 文档（本地）路径
            doc_parse_config (Optional[DocParseConfig]): 本次插入文档的专用解析配置参数，默认为None，表示使用知识库中的同样解析器配置
            save_dir (str): 文档保存的相对路径文件夹，默认为空字符串，表示保存在RAW_DOC_FILES根目录下。
                支持以"/"开头和不以"/"开头的两种形式，如"/project/docs"和"project/docs"是等价的。
            doc_type (Optional[DocType]): 文档类型参数，可以配置为以下值：
                - DocType.NORMAL，表示作为“普通文档”上传
                - DocType.RESOURCE，表示作为“资源文件”上传，例如md文档通过相对路径引用的图片等资源文件，之后不会进行解析、索引，
                - None，表示需要通过doc_patterns确定是否属于普通文档文件
            doc_patterns (Optional[List[str]]): 指定“普通文档”文件名规则列表，当doc_type=None时将根据doc_patterns确定文档类型，例如
                - 指定一种或多种文件名后缀，例如["*.md", "*.docx", "*.csv"]
                - 指定一个或多个文件命名规则，例如["index.html", "index.md"]
                如果设置为None，则使用本项目默认的DEFAULT_NORMAL_DOC_FILE_PATTERNS
            only_upload (bool): 是否只进行上传，稍后再进行解析和索引，默认为False，表示上传后直接进行解析和索引

        Returns:
            DocInfo: 文档状态信息，注意，如果返回的DocInfo.doc_status为UPLOAD_FAILED，则文档信息并不会入库。
        """
        # 0. 确定文档类型
        if doc_type is None:
            # 如果doc_type为None，则需要通过doc_patterns确定是否属于资源文件
            if not doc_patterns:
                doc_patterns = DEFAULT_NORMAL_DOC_FILE_PATTERNS
            import fnmatch
            if any(fnmatch.fnmatch(file_path, pattern) for pattern in doc_patterns):
                # 如果匹配到任意一种doc_patterns，则认为是普通文档
                doc_type = DocType.NORMAL
            else:
                # 如果没有匹配到doc_patterns，则认为是资源文件
                doc_type = DocType.RESOURCE

        logger.info(f'Inserting file: {file_path} (doc_type: {doc_type})')

        # 1. 上传文档
        doc_info = self._upload_file(file_path=file_path, save_dir=save_dir)
        if doc_info.err_info.code != KBXError.Code.SUCCESS:
            # 如果上传失败，直接返回
            doc_info.err_info.msg = f"\"{file_path}\" 上传失败：{doc_info.err_info.msg}"
            return doc_info

        # 1.5 如果doc_type为RESOURCE或only_upload为True，则直接返回
        doc_info.doc_type = doc_type
        self._update_doc_info(doc_info, db=None)
        if doc_type == DocType.RESOURCE or only_upload:
            # NOTE: 跳过后续的解析和索引步骤
            return doc_info

        # 2. 解析文档
        if doc_parse_config:
            # 如果设置了专属解析器，进行更新
            doc_info.doc_parse_config = doc_parse_config
        doc_info, doc_data = self._parse_doc(doc_info=doc_info)
        if doc_info.err_info.code != KBXError.Code.SUCCESS:
            # 如果解析失败，直接返回
            doc_info.err_info.msg = f"\"{file_path}\" 解析失败：{doc_info.err_info.msg}"
            return doc_info

        # 3. 为此文档建立索引
        doc_info = self._index_doc(doc_info=doc_info, doc_data=doc_data)

        return doc_info

    @tracer.start_as_current_span("knowledge_base.insert_docs")
    def insert_docs(
        self,
        file_list: Union[str, List[str]],
        doc_parse_config: Optional[DocParseConfig] = None,
        save_dir: str = "",
        doc_patterns: Optional[List[str]] = None,
        only_upload: bool = False,
    ) -> List[DocInfo]:
        """对一系列本地文档文件进行入库，包括如下步骤

        - 存入文件存储
        - 调用parser解析成DocData
        - 建立索引

        注意，
        - 如果输入文件列表存在重名的文件会直接报错
        - 对于输入的file_list，不管每个文件的原始路径如何，最终全部只保留文件名放到save_dir文件夹里，例如
            输入：file_list=['a.txt', 'b/c.txt', 'd/e/f.txt']，save_dir='x'，则实际存入知识库后的路径为['x/a.txt', 'x/c.txt', 'x/f.txt']
            这里不考虑输入文件之间相对路径的原因是无法确认相对路径的基准base_dir（除非专门添加一个参数）

        Args:
            file_list (Union[str, List[str]]): 文档（本地）路径列表
            doc_parse_config (Optional[DocParseConfig]): 本次插入文档的专用解析配置参数，默认为None，表示使用知识库中的同样解析器配置
            save_dir (str): 文档保存的相对路径文件夹，默认为空字符串，表示保存在RAW_DOC_FILES根目录下。
                           支持以"/"开头和不以"/"开头的两种形式，如"/project/docs"和"project/docs"是等价的。
            doc_patterns (Optional[List[str]]): 指定“普通文档”文件名规则列表，当doc_type=None时将根据doc_patterns确定文档类型，例如
                - 指定一种或多种文件名后缀，例如["*.md", "*.docx", "*.csv"]
                - 指定一个或多个文件命名规则，例如["index.html", "index.md"]
                如果设置为None，则使用本项目默认的DEFAULT_NORMAL_DOC_FILE_PATTERNS
            only_upload (bool): 是否只进行上传，稍后再进行解析和索引，默认为False，表示上传后直接进行解析和索引

        Returns:
            List[DocInfo]: 各文档的入库结果，长度与输入的file_list相同，对应每个文件在插入后的相关状态信息
        """
        if isinstance(file_list, str):
            file_list = [file_list]

        from kbx.kbx import KBX

        if len(file_list) > KBX.config.upload_file_batch_limit:
            # 如果本次上传的文件数量超过限制，直接报错
            raise ValueError(
                'Failed to insert docs because total file num exceeds limit: '
                f'{len(file_list)} vs {KBX.config.upload_file_batch_limit}'
            )

        if any([not isinstance(file_path, str) or file_path == '' for file_path in file_list]):
            raise ValueError(
                f'Please provide valid file paths, given {file_list}'
            )

        file_names = [os.path.basename(file_path) for file_path in file_list]
        if len(set(file_names)) != len(file_names):
            raise ValueError(
                f'Can not insert duplicate files:\n{file_names}'
            )

        # NOTE: 把file_list中的文件拆分成普通文档和资源文件列表，之后插入时需要确保先插入资源文件再插入普通文档
        # 防止普通文档解析时，相关资源文件还未插入
        normal_docs = []
        resource_docs = []
        import fnmatch
        if not doc_patterns:
            doc_patterns = DEFAULT_NORMAL_DOC_FILE_PATTERNS
        for file_path in file_list:
            if any(fnmatch.fnmatch(file_path, pattern) for pattern in doc_patterns):
                normal_docs.append(file_path)
            else:
                resource_docs.append(file_path)

        # from kbx.kbx import KBX
        # 串行调用, 后面根据KBX的config来判断进行串行或并行调用
        rets_resource = [
            self.insert_single_doc(
                file_path,
                doc_parse_config=doc_parse_config,
                save_dir=save_dir,
                doc_type=DocType.RESOURCE,
                doc_patterns=None,
                only_upload=only_upload
            ) for file_path in resource_docs
        ]
        rets_normal = [
            self.insert_single_doc(
                file_path,
                doc_parse_config=doc_parse_config,
                save_dir=save_dir,
                doc_type=DocType.NORMAL,
                doc_patterns=None,
                only_upload=only_upload
            ) for file_path in normal_docs
        ]

        # 并行调用
        # TODO: 目前parser模块无法保证线程安全，暂时关闭并行调用
        #  with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as pool:
        #      rets_resource = list((pool.map(self.insert_single_doc, resource_docs)))
        #      rets_normal = list((pool.map(self.insert_single_doc, normal_docs)))

        # 需要恢复输入文档列表顺序，因为预期size不会太大，这里直接用list的index来恢复
        rets = [None] * len(file_list)
        for i, file_path in enumerate(file_list):
            if file_path in resource_docs:
                rets[i] = rets_resource[resource_docs.index(file_path)]
            else:
                rets[i] = rets_normal[normal_docs.index(file_path)]
        return rets

    @tracer.start_as_current_span("knowledge_base.insert_docs_folder")
    def insert_docs_folder(
        self,
        folder_path: str,
        doc_parse_config: Optional[DocParseConfig] = None,
        recursive: bool = True,
        include_patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        max_files_per_batch: int = 20,
        save_dir: str = "",
        doc_patterns: Optional[List[str]] = None,
        only_upload: bool = False,
    ) -> Dict[str, List[DocInfo]]:
        """递归遍历本地文件夹，并按文件夹结构将文件分批插入到知识库中

        该函数会根据recursive参数决定是否遍历指定文件夹的子文件夹，将找到的文件按照其相对路径结构插入到知识库中。
        例如，如果本地有文件"/path/to/project/docs/api.md"，且folder_path为"/path/to/project"，
        则该文件会被插入到知识库的"docs"目录下，保持原有的目录结构，例如"docs/api.md"。

        如果指定了save_dir参数，则所有文件会被插入到save_dir指定的目录下，保持原有的相对路径结构。
        例如，如果save_dir为"project"，则"/path/to/project/docs/api.md"会被插入到"project/docs/api.md"。

        Args:
            folder_path (str): 要遍历的本地文件夹路径
            doc_parse_config (Optional[DocParseConfig]): 本次插入文档的专用解析配置参数，默认为None，表示使用知识库中的同样解析器配置
            recursive (bool): 是否递归处理子文件夹，默认为True
            include_patterns (Optional[List[str]]): 本次上传要包含的文件匹配模式列表，支持通配符，如["*.md", "docs/*.pdf", "api/**/*.txt"]
                默认为None表示包含所有文件
            exclude_patterns (Optional[List[str]]): 本次上传要排除的文件匹配模式列表，支持通配符，如["*.tmp", "temp/*", "**/draft_*"]
                默认为None表示不排除任何文件
            max_files_per_batch (int): 每批处理的最大文件数，默认为20
            save_dir (str): 文档存储的相对路径文件夹，默认为空字符串，表示存储在RAW_DOC_FILES目录下
                支持两种格式，如"/project"和"project"，两者等价
            doc_patterns (Optional[List[str]]): 指定“普通文档”文件名规则列表，当doc_type=None时将根据doc_patterns确定文档类型，例如
                - 指定一种或多种文件名后缀，例如["*.md", "*.docx", "*.csv"]
                - 指定一个或多个文件命名规则，例如["index.html", "index.md"]
                如果设置为None，则使用本项目默认的DEFAULT_NORMAL_DOC_FILE_PATTERNS
            only_upload (bool): 是否只进行上传，稍后再进行解析和索引，默认为False，表示上传后直接进行解析和索引

        Returns:
            Dict[str, List[DocInfo]]: 各文件夹的文档入库结果，键为相对路径，值为该路径下的文档入库结果列表
                                    根目录（当前目录）的结果使用'.'作为键
        """
        if not os.path.exists(folder_path):
            raise ValueError(f"Folder path {folder_path} does not exist.")
        if not os.path.isdir(folder_path):
            raise ValueError(f"Path {folder_path} is not a directory.")

        import fnmatch

        # 收集所有文件及其相对路径
        all_files = []
        for root, _, files in os.walk(folder_path, topdown=True):
            # 如果不是递归模式且不是顶层目录，跳过处理
            if not recursive and root != folder_path:
                continue

            for file in files:
                # 忽略隐藏文件
                if file.startswith('.'):
                    continue

                # 获取文件的完整路径
                full_path = os.path.join(root, file)
                # 计算相对于folder_path的路径
                rel_path = os.path.relpath(root, folder_path)
                # 如果rel_path是当前目录，则设为空字符串
                if rel_path == '.':
                    rel_path = ""

                # 构建相对于folder_path的文件路径，用于模式匹配
                rel_file_path = os.path.join(rel_path, file) if rel_path else file

                # 检查是否应该包含此文件
                should_include = True

                # 检查include_patterns
                if include_patterns:
                    should_include = any(fnmatch.fnmatch(rel_file_path, pattern) for pattern in include_patterns)

                # 检查exclude_patterns
                if should_include and exclude_patterns:
                    should_include = not any(fnmatch.fnmatch(rel_file_path, pattern) for pattern in exclude_patterns)

                if should_include:
                    all_files.append((full_path, rel_path))

        if not doc_patterns:
            doc_patterns = DEFAULT_NORMAL_DOC_FILE_PATTERNS
        # 按相对路径和文档类型分组
        normal_docs_by_dir: Dict[str, List[str]] = {}
        resource_docs_by_dir: Dict[str, List[str]] = {}
        for full_path, rel_path in all_files:
            if any(fnmatch.fnmatch(full_path, pattern) for pattern in doc_patterns):
                if rel_path not in normal_docs_by_dir:
                    normal_docs_by_dir[rel_path] = []
                normal_docs_by_dir[rel_path].append(full_path)
            else:
                if rel_path not in resource_docs_by_dir:
                    resource_docs_by_dir[rel_path] = []
                resource_docs_by_dir[rel_path].append(full_path)

        results: Dict[str, List[DocInfo]] = {}

        # 定义一个用于处理每个目录下文件的工具函数
        def fn_handle_docs(docs_by_dir: Dict[str, List[str]]):
            for rel_path, files in docs_by_dir.items():
                # 构建目标保存路径
                target_save_dir = os.path.join(save_dir, rel_path) if save_dir else rel_path

                # 分批处理文件
                for i in range(0, len(files), max_files_per_batch):
                    batch = files[i:i + max_files_per_batch]
                    batch_results = self.insert_docs(
                        file_list=batch,
                        doc_parse_config=doc_parse_config,
                        save_dir=target_save_dir,
                        doc_patterns=doc_patterns,
                        only_upload=only_upload
                    )
                    if rel_path not in results:
                        results[rel_path] = []
                    results[rel_path].extend(batch_results)

        # 先处理每个目录下的资源文件
        fn_handle_docs(resource_docs_by_dir)
        # 再处理每个目录下的普通文档文件
        fn_handle_docs(normal_docs_by_dir)

        # 将空字符串键替换为'.'，使结果更加直观
        if "" in results:
            results["."] = results.pop("")

        return results

    def _try_get_vector_keyword_index(self) -> Optional[BaseIndex]:
        if self._kb_config.vector_keyword_config is None:
            return None

        return get_vector_keyword_index(
            self._kb_config.vector_keyword_config.index_strategy,
            self.kb_id,
            self._kb_config.vector_keyword_config
        )

    def _try_get_structured_index(self) -> Optional[BaseIndex]:
        if self._kb_config.structured_config is None:
            return None

        return get_structured_index(
            self._kb_config.structured_config.index_strategy,
            self.kb_id,
            self._kb_config.structured_config
        )

    def _try_get_knowledge_graph_index(self) -> Optional[BaseIndex]:
        if self._kb_config.kg_config is None:
            return None

        return get_knowledge_graph_index(
            self._kb_config.kg_config.index_strategy,
            self.kb_id,
            self._kb_config.kg_config
        )

    def _try_get_dynamic_doc_index(self) -> Optional[BaseIndex]:
        if self._kb_config.dynamic_doc_config is None:
            return None

        return get_dynamic_doc_index(
            self._kb_config.dynamic_doc_config.index_strategy,
            self.kb_id,
            self._kb_config.dynamic_doc_config
        )

    def list_doc_ids(
        self,
        offset: int = 0,
        limit: int = 20,
        doc_type_filter: Optional[List[DocType]] = None
    ) -> Tuple[List[str], int]:
        """列举本知识库所包含的文档id列表

        Args:
            offset (int): 分页偏移量，也就是从第几个item开始查询，默认从0开始
            limit (int): 分页大小限制，也就是本次查询最多返回多少个item
            doc_type_filter (Optional[List[DocType]]): 文档类型过滤列表，默认为None，表示不进行过滤，返回所有类型的文档id

        Returns:
            Tuple[List[str], int]: 指定分页范围内的文档id列表和总数量
        """
        # 从DB中查询符合条件的文档id列表
        with DBSession() as db:
            query = db.query(DocInfoORM.id).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id
            )
            if doc_type_filter:
                query = query.filter(DocInfoORM.doc_type.in_(doc_type_filter))
            total_count = query.count()
            doc_ids = query.offset(offset=offset).limit(limit=limit).all()
        return [doc_id for (doc_id,) in doc_ids], total_count

    def list_docs_info(
        self,
        offset: int = 0,
        limit: int = 20,
        doc_type_filter: Optional[List[DocType]] = None
    ) -> Tuple[List[DocInfo], int]:
        """列举本知识库所包含的文档列表

        Args:
            offset (int): 分页偏移量，也就是从第几个item开始查询，默认从0开始
            limit (int): 分页大小限制，也就是本次查询最多返回多少个item
            doc_type_filter (Optional[List[DocType]]): 文档类型过滤列表，默认为None，表示不进行过滤，返回所有类型的文档

        Returns:
            Tuple[List[DocInfo], int]: 指定分页范围内的文档列表和总数量
        """
        with DBSession() as db:
            query = db.query(DocInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id
            )
            if doc_type_filter:
                query = query.filter(DocInfoORM.doc_type.in_(doc_type_filter))
            total_count = query.count()
            doc_info_orms = query.offset(offset).limit(limit).all()
            doc_infos = [doc_info_orm.to_pydantic() for doc_info_orm in doc_info_orms]
        return doc_infos, total_count

    def get_doc_info(self, doc_id: str) -> DocInfo:
        """获取某个文档的相关信息

        Args:
            doc_id (str): 文档id

        Raises:
            NotImplementedError: _description_

        Returns:
            DocInfo: 文档相关信息
        """
        with DBSession() as db:
            doc_info_orm = db.query(DocInfoORM).filter_by(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                kb_id=self.kb_id,
                id=doc_id
            ).first()
            if doc_info_orm is None:
                raise RuntimeError(f'Failed to find doc_id={doc_id} in knowledge base (id={self.kb_id})')
            return doc_info_orm.to_pydantic()

    def get_doc_data(self, doc_id: str) -> DocData:
        """获取某个文档的DocData内容数据

        Args:
            doc_id (str): 文档id

        Returns:
            DocData: 文档数据
        """
        with get_doc_datastore(self.kb_id) as doc_ds:
            doc_data, err = doc_ds.load_doc_data(doc_id)
        if err.code != KBXError.Code.SUCCESS:
            raise RuntimeError(err.msg)
        return doc_data

    @tracer.start_as_current_span("knowledge_base.rebuild_doc_toc_by_ai")
    def rebuild_doc_toc_by_ai(
        self,
        doc_id: str,
        agent_config: Optional[TOCAgentConfig] = None,
        save: bool = False
    ) -> DocData:
        """【临时API】对指定文档使用AI Agent重新构建TOC，并保存到

        TODO:
        - agent_config的agent_name必须保证对应一个TOCAgent
        - 此接口设计离最终产品化可能还有距离，建议先内部试用，后续根据实际情况进行调整优化

        Args:
            doc_id (str): 文档id
            agent_config (Optional[TOCAgentConfig]): AI Agent配置
            save (bool, optional): 是否保存修改后的文档. Defaults to False.

        Returns:
            DocData: 修改后的文档数据
        """
        with get_doc_datastore(self.kb_id) as doc_ds:
            doc_data, err = doc_ds.load_doc_data(doc_id)
        if err.code != KBXError.Code.SUCCESS:
            raise RuntimeError(err.msg)

        if agent_config is None:
            if self._kb_config.ai_model_bundle.llm is not None:
                agent_config = TOCAgentConfig(
                    agent_name='IterativeTOCAgent',
                    llm_model=self._kb_config.ai_model_bundle.llm
                )
        if not agent_config or not isinstance(agent_config, TOCAgentConfig) or \
                not agent_config.llm_model:
            raise ValueError(
                'Expect valid agent_config for ai-based toc rebuild, but got '
                f'{agent_config.model_dump(mode="json")}'
            )

        toc_builder = TOCBuilder(config=self._kb_config.doc_parse_config)
        doc_data = toc_builder.build_toc_by_ai(doc_data, agent_config, deepcopy=False)

        if save:
            with get_doc_datastore(self.kb_id) as doc_ds:
                err = doc_ds.save_doc_data(doc_id, doc_data)
            if err.code != KBXError.Code.SUCCESS:
                raise RuntimeError(err.msg)

        return doc_data

    def _update_docs_status(self, doc_ids: Iterable[str], doc_status: DocStatus):
        with DBSession() as db:
            db.query(DocInfoORM).filter(
                DocInfoORM.tenant_id == self.tenant_id,
            ).filter(
                DocInfoORM.user_id == self.user_id
            ).filter(
                DocInfoORM.kb_id == self.kb_id
            ).filter(
                DocInfoORM.id.in_(doc_ids)
            ).update(
                {
                    'doc_status': doc_status
                }
            )
            db.commit()

    @tracer.start_as_current_span("knowledge_base.reindex")
    def reindex(self, doc_ids: Union[str, List[str]], reparse: bool = False) -> Dict[str, KBXError]:
        """对部分文档重新建立索引

        Args:
            doc_ids (Union[str, List[str]]): 需要重新建立索引的文档id
            reparse (bool): 是否需要重新解析文档

        Returns:
            Dict[str, KBXError]: 执行reindex后的错误信息， 格式为{doc_id1: err1, doc_id2: err2, ...}
        """
        if isinstance(doc_ids, str):
            doc_ids = [doc_ids]

        # 只处理标准文档
        doc_ids = [doc_id for doc_id in doc_ids if self.get_doc_info(doc_id).doc_type == DocType.NORMAL]

        # 记录reindex过程中哪些文档出错了，格式为{doc_id: err_msg}
        doc_id_errors: Dict[str, KBXError] = {}

        if reparse:
            # 需要重新解析文档
            # from kbx.kbx import KBX
            # 串行调用, 后面根据KBX的config来判断进行串行或并行调用
            doc_info_list = [self._parse_doc_by_id(doc_id) for doc_id in doc_ids]
            # TODO: 并行调用
            # with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as pool:
            #      doc_info_list = list(pool.map(self._parse_doc_by_id, doc_ids))
            doc_id_errors = {
                doc_info.doc_id: KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=doc_info.err_info.msg)
                for doc_info in doc_info_list
                if doc_info.err_info.code != KBXError.Code.SUCCESS
            }

        # 检查doc_ids中是否存在不存在的doc_id，提前标记出错
        with get_doc_datastore(self.kb_id) as doc_store:
            all_available_doc_ids, err = doc_store.list_doc_ids()
            if err.code != KBXError.Code.SUCCESS:
                raise RuntimeError(f'[Internal Error] Failed to list_doc_ids: {err.msg}')
            illegal_doc_ids = set(doc_ids) - set(all_available_doc_ids)
            doc_id_errors.update({
                doc_id: KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=f'doc_id {doc_id} not found')
                for doc_id in illegal_doc_ids
            })

        # 调用index.reindex前，剔除掉解析失败或不存在的非法文档id
        success_doc_ids = set(doc_ids) - set(doc_id_errors.keys())

        # TODO: 异步并发优化
        for k, index in self.index_map.items():
            tmp_errs = index.reindex(success_doc_ids)
            if tmp_errs:
                for tmp_err in tmp_errs:
                    doc_id, err_msg = tmp_err
                    doc_index_err_msg = str(k) + ': ' + err_msg
                    if doc_id not in doc_id_errors:
                        doc_id_errors[doc_id] = KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=doc_index_err_msg)
                    else:
                        doc_id_errors[doc_id].msg += f'\n{doc_index_err_msg}'

        # reindex后批量把成功的文档状态设置为INDEX_SUCCESS，失败的文档错误信息进行更新
        success_doc_ids = set(doc_ids) - set(doc_id_errors.keys())
        self._update_docs_status(doc_ids=success_doc_ids, doc_status=DocStatus.INDEX_SUCCESS)
        if len(doc_id_errors) > 0:
            with DBSession() as db:
                for doc_id, err in doc_id_errors.items():
                    logger.error(f'Failed to reindex doc_id {doc_id}: {err.msg}')
                    doc_info_orm = db.query(DocInfoORM).filter(
                        DocInfoORM.tenant_id == self.tenant_id,
                    ).filter(
                        DocInfoORM.user_id == self.user_id
                    ).filter(
                        DocInfoORM.kb_id == self.kb_id
                    ).filter(
                        DocInfoORM.id == doc_id
                    ).first()
                    if doc_info_orm:
                        doc_info_orm.err_code = err.code
                        doc_info_orm.err_msg = err.msg
                        doc_info_orm.doc_status = DocStatus.INDEX_FAILED
                db.commit()

        return doc_id_errors

    @tracer.start_as_current_span("knowledge_base.reindex_all")
    def reindex_all(self, reparse: bool = False) -> Dict[str, KBXError]:
        """对全部文档重新建立索引

        Args:
            reparse (bool): 是否需要重新解析文档

        Returns:
            Dict[str, KBXError]: 执行reindex后的错误信息， 格式为{doc_id1: err1, doc_id2: err2, ...}
        """
        doc_id_errors: Dict[str, KBXError] = {}

        # 先获取所有标准文档的doc_id列表（limit设置为-1）
        doc_ids, _ = self.list_doc_ids(offset=0, limit=-1, doc_type_filter=[DocType.NORMAL])

        if reparse:
            # from kbx.kbx import KBX
            # 串行调用, 后面根据KBX的config来判断进行串行或并行调用
            doc_info_list = [self._parse_doc_by_id(doc_id) for doc_id in doc_ids]
            # 并行调用
            # with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as pool:
            #     doc_info_list = list(pool.map(self._parse_doc_by_id, doc_ids))
            doc_id_errors.update({
                doc_info.doc_id: KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=doc_info.err_info.msg)
                for doc_info in doc_info_list
                if doc_info.err_info.code != KBXError.Code.SUCCESS
            })
        else:
            # 如果不做重新的解析，先检查是否存在之前就解析失败的文档，提前标记出错
            with DBSession() as db:
                parse_failed_doc_info_orms = db.query(DocInfoORM).filter(
                    DocInfoORM.tenant_id == self.tenant_id,
                ).filter(
                    DocInfoORM.user_id == self.user_id
                ).filter(
                    DocInfoORM.kb_id == self.kb_id
                ).filter(
                    DocInfoORM.doc_status == DocStatus.PARSE_FAILED
                ).all()
                doc_id_errors.update({
                    doc_info_orm.id: KBXError(
                        code=KBXError.Code.RUNTIME_ERROR,
                        msg=f"Failed to parse doc_id={doc_info_orm.id} before reindex"
                    )
                    for doc_info_orm in parse_failed_doc_info_orms
                })

        success_doc_ids = set(doc_ids) - set(doc_id_errors.keys())
        # reindex前先把所有解析成功的文档状态置为INDEXING状态
        self._update_docs_status(doc_ids=success_doc_ids, doc_status=DocStatus.INDEXING)

        # TODO: 异步并发优化
        for k, index in self.index_map.items():
            tmp_errs = index.reindex_all()
            if tmp_errs:
                for tmp_err in tmp_errs:
                    doc_id, err_msg = tmp_err
                    doc_index_err_msg = str(k) + ': ' + err_msg
                    if doc_id not in doc_id_errors:
                        doc_id_errors[doc_id] = KBXError(code=KBXError.Code.RUNTIME_ERROR, msg=doc_index_err_msg)
                    else:
                        doc_id_errors[doc_id].msg += f'\n{doc_index_err_msg}'

        # reindex后批量把成功的文档状态设置为INDEX_SUCCESS，失败的文档错误信息进行更新
        success_doc_ids = set(success_doc_ids) - set(doc_id_errors.keys())
        self._update_docs_status(doc_ids=success_doc_ids, doc_status=DocStatus.INDEX_SUCCESS)
        if len(doc_id_errors) > 0:
            with DBSession() as db:
                for doc_id, err in doc_id_errors.items():
                    logger.error(f'Failed to reindex doc_id {doc_id}: {err.msg}')
                    doc_info_orm = db.query(DocInfoORM).filter(
                        DocInfoORM.tenant_id == self.tenant_id,
                    ).filter(
                        DocInfoORM.user_id == self.user_id
                    ).filter(
                        DocInfoORM.kb_id == self.kb_id
                    ).filter(
                        DocInfoORM.id == doc_id
                    ).first()
                    if doc_info_orm:
                        doc_info_orm.err_code = err.code
                        doc_info_orm.err_msg = err.msg
                        doc_info_orm.doc_status = DocStatus.INDEX_FAILED
                db.commit()

        return doc_id_errors

    @tracer.start_as_current_span("knowledge_base.remove_docs")
    def remove_docs(self, doc_ids: Union[str, List[str]]) -> List[Tuple[str, KBXError]]:
        """删除一个或多个文档的索引数据

        Args:
            doc_ids (Union[str, List[str]]): _description_

        Returns:
            Dict[IndexType, List[Tuple[str, str]]]: 如果执行成功直接返回None，否则会把错误信息进行返回，
                格式为[(doc_id, err), (doc_id, err), ...]
        """
        if isinstance(doc_ids, str):
            doc_ids = [doc_ids]

        doc_id2err: Dict[str, KBXError] = {}

        # 删除文件、DocInfo记录
        file_ds = get_file_datastore(self.kb_id)
        doc_ds = get_doc_datastore(self.kb_id)
        with DBSession() as db:
            for doc_id in doc_ids:
                doc_info_orm = db.query(DocInfoORM).filter_by(
                    tenant_id=self.tenant_id,
                    user_id=self.user_id,
                    kb_id=self.kb_id,
                    id=doc_id
                ).first()
                if doc_info_orm is None:
                    if doc_id in doc_id2err:
                        continue
                    doc_id2err[doc_id] = KBXError(
                        code=KBXError.Code.RUNTIME_ERROR,
                        msg=f"Failed to find DocInfo record for doc_id={doc_id}"
                    )
                    continue

                # 注意，只要上面成功获取到了doc_info_orm，接下来任意中间环节即使失败也要尝试继续执行剩余步骤的删除，
                # 并且保证最终删除doc_info_orm，实现此文档的软删除
                if doc_info_orm.doc_type == DocType.NORMAL:
                    # 只有标准文档才需要删除索引
                    for index in self.index_map.values():
                        tmp_errs = index.remove_docs(doc_ids=[doc_id])
                        if tmp_errs:
                            if tmp_errs[0][0] != doc_id:
                                raise RuntimeError(f'Unexpected doc_id, expected {doc_id}, given {tmp_errs[0][0]}')
                            doc_id2err[doc_id] = KBXError(code=KBXError.Code.RUNTIME_ERROR,
                                                          msg=tmp_errs[0][1])

                # First delete physical files
                with ExitStack() as stack:
                    stack.enter_context(file_ds)
                    stack.enter_context(doc_ds)

                    # Delete raw doc file
                    err = file_ds.delete_file(doc_info_orm.file_path)
                    if err.code != KBXError.Code.SUCCESS:
                        doc_id2err[doc_id] = err

                    # Delete doc data
                    err = doc_ds.delete_doc_data(doc_id=doc_id)
                    if err.code != KBXError.Code.SUCCESS:
                        doc_id2err[doc_id] = err

                    # Delete any extra files
                    for extra_file_info_orm in doc_info_orm.extra_files_info:
                        file_ds.delete_file(extra_file_info_orm.file_path)

                # 不管上面是否出错，这里都要删除DocInfoORM，实现此文档的软删除
                # NOTE: 不需要额外进行file_info_orm的删除，因为会进行关联删除
                db.delete(doc_info_orm)
                db.commit()

        return list(doc_id2err.items())

    def _select_docs_by_name(self, query: QueryConfig) -> List[str]:
        """根据用户输入的查询问题，选择出相关的文档

        Args:
            query (QueryConfig): 查询参数

        Returns:
            List[str]: 文档id列表，若没有搜索到相关文档，则返回空列表，即进行全量搜索
        """
        doc_info_list = []
        system_prompt = ''
        import copy
        messages = copy.deepcopy(query.messages)

        # 处理历史消息
        for message in messages:
            if message['role'] == 'system':
                # 系统prompt用于指导文档选择
                system_prompt += message['content']
                messages.remove(message)

        # TODO 只保留最后6条消息
        messages = messages[-6:]
        if query.text:
            messages.append({"role": "user", "content": query.text})

        with get_doc_datastore(self.kb_id) as doc_store:
            doc_ids, err = doc_store.list_doc_ids()
            if err.code != KBXError.Code.SUCCESS:
                return []
            for doc_id in doc_ids:
                doc_data, err = doc_store.load_doc_data(doc_id=doc_id)
                # TODO: summary提取
                doc_info_list.append({
                    'file_name': doc_data.file_name,
                    # 'summary': doc_data.summary,
                    'doc_id': doc_id
                })
        document_info = json.dumps(doc_info_list, ensure_ascii=False)

        from kbx.kbx import KBX
        from kbx.common.prompt import get_category_prompts
        doc_selector_prompt = get_category_prompts(category='select_docs')['doc_selector'].text
        config, client = KBX.get_ai_model_config_and_client(
            query.deep_think.llm_model, self.user_id)
        prompt = doc_selector_prompt.format(
            additional_system_prompt=system_prompt,
            document_info=document_info
        )

        all_messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": json.dumps(messages, ensure_ascii=False)}
            # TODO 超过context_length时，需要进行截断
        ]
        response = client.chat(
            config,
            messages=all_messages,
            temperature=0.7,
            stream=False
        ).choices[0].message.content.strip("'\"")
        if not response or response.isspace():
            return []
        all_doc_ids = self.list_doc_ids(offset=0, limit=-1)[0]
        doc_ids = response.replace("\n", "").split("</think>")[-1].split('\n')
        doc_ids = [doc_id for doc_id in doc_ids if doc_id in all_doc_ids]
        return doc_ids

    def _wrap_retrieve_func(self, retrieve_function: Callable, query: QueryConfig):
        """
        包装检索函数。

        Args:
            retrieve_function: 原始检索函数
            query: 查询配置

        Returns:
            包装后的检索函数。如果开启了深度搜索,则返回深度搜索agent的检索函数;
            否则返回原始检索函数。
        """
        if query.deep_think and query.deep_think.deep_searcher and query.deep_think.hierarchy == "KB":
            search_agent_config = inject_user_ctx(
                config=SearchAgentConfig(
                    agent_name=query.deep_think.deep_searcher,
                    max_iter=query.deep_think.max_iter,
                    llm_model=query.deep_think.llm_model
                ),
                user_ctx=UserContext(user_id=self.user_id, tenant_id=self.tenant_id),
                recursive=True,
            )
            from ..agent.agent_factory import get_agent
            search_agent = get_agent(search_agent_config)
            from ..agent.search.base_searcher import BaseSearcher
            assert isinstance(search_agent, BaseSearcher)
            return functools.partial(search_agent.retrieve, retrieve_function=retrieve_function)
        return retrieve_function

    def _auto_fill_query_deep_think(self, query: QueryConfig) -> QueryConfig:
        """
        根据query config中的deep_think配置，进行自动填充。

        Args:
            query: 查询配置

        Returns:
            填充后的查询配置
        """
        if query.deep_think:
            # 如果本次查询开启了agent增强，需要确保对模型参数进行自动填充
            if not query.ai_model_bundle or len(query.ai_model_bundle.bundles) == 0:
                # 如果query config没有传递ai_model_bundle，则尝试使用知识库的默认模型配置方案
                if self.kb_config.ai_model_bundle and len(self.kb_config.ai_model_bundle.bundles) > 0:
                    query.ai_model_bundle = self.kb_config.ai_model_bundle.model_copy(deep=True)

            if query.ai_model_bundle.bundles:
                # 如果有非空的ai model bundle，则进行自动填充更新
                query.deep_think.update_with_model_bundle(query.ai_model_bundle)
        if query.deep_think and not query.deep_think.llm_model:
            logger.error(f'Invalid deep think config: {query.deep_think}')
            # NOTE: 如果没有合法的deep think配置，可能需要进行清空？
            query.deep_think = None
        return query

    @tracer.start_as_current_span("knowledge_base._unique_top_k_results")
    def _unique_top_k_results(self, query: QueryConfig, results: List[QueryResult]) -> List[QueryResult]:
        """
        对检索结果进行去重和重排。

        Args:
            query: 查询配置
            results: 检索结果
        """
        from ..agent.search.deepsearcher import DeepSearcher
        results = DeepSearcher.deduplicate_results(results)
        # TODO: 结果相关性过滤
        # 调用rerank模型进行结果重排
        if self.kb_config.rerank_config:
            rerank_model = get_rerank(self.kb_config.rerank_config)
            results = rerank_model.rerank(query, results)

        if query.top_k > 0:
            results = results[:query.top_k]
        return results

    @tracer.start_as_current_span("knowledge_base._pre_select_docs")
    def _pre_select_docs(self, query: QueryConfig) -> Tuple[Optional[List[str]], Optional[RetrievalStepMessage]]:
        """
        文档列表筛选，可以先进行判断
        如果doc_selector为True，则先进行文档过滤
        Args:
            query: 查询配置

        Returns:
            文档列表和检索步骤消息。如果开启了文档选择，则返回文档列表和检索步骤消息;
            否则返回None。
        """
        if query.deep_think and query.deep_think.doc_selector:
            doc_ids = self._select_docs_by_name(query)
            doc_names = [os.path.basename(self.get_doc_info(doc_id).raw_file_info.file_path) for doc_id in doc_ids]
            markdown_str = f"查询文本：{query.text}\n\n"
            if doc_names:
                markdown_str += f"待检索文档列表为：{'、'.join(doc_names)}\n\n"
            else:
                markdown_str += "默认使用全部文档进行检索\n\n"
            msg = RetrievalStepMessage(
                step_name="检索文档选择",
                content=markdown_str
            )
            return doc_ids, msg
        return None, None

    def _post_fill_doc_info(self, results_flat: List[QueryResult]) -> List[QueryResult]:
        """
        处理所有检索结果中doc elements的url信息，防止因为nginx文件服务地址变动导致url失效

        Args:
            results_flat: 检索结果

        Returns:
            处理后的检索结果
        """
        # NOTE: 处理所有检索结果中doc elements的url信息，防止因为nginx文件服务地址变动导致url失效
        from kbx.kbx import KBX
        for res in results_flat:
            if res.chunk and res.chunk.doc_elements:
                for elem in res.chunk.doc_elements:
                    if elem.data_file_url:
                        expected_url = KBX.config.file_service_prefix + '/' + elem.data_file_raw_path
                        if elem.data_file_url != expected_url:
                            # 因为Python遍历List时是引用，所以可以inplace修改
                            logger.warning(
                                'File service address changed, update file url from'
                                f' {elem.data_file_url} to {expected_url}'
                            )
                            elem.data_file_url = expected_url

        for res in results_flat:
            res.meta_data = {'kb_name': self.kb_name}
            if res.doc_id:
                doc_name = os.path.basename(self.get_doc_info(res.doc_id).raw_file_info.file_path)
                res.meta_data.update({'doc_name': doc_name})

            if res.chunk and res.chunk.doc_elements:
                res.chunk.text = doc_elements_to_markdown(res.chunk.doc_elements, mode='original')
        return results_flat

    def _select_index_for_retrieve(self, query: QueryConfig) -> Dict[IndexType, BaseIndex]:
        """
        根据query config中的enable_index_types配置，选择要使用的索引

        Args:
            query: 查询配置

        Returns:
            选择的索引字典，key为索引类型，value为索引对象
        """
        if not query.enable_index_types:
            selected_index = self.index_map
        else:
            selected_index = {
                key: self.index_map[key] for key in query.enable_index_types if key in self.index_map
            }

        if len(selected_index) > 1 and IndexType.DYNAMIC_DOC in selected_index and query.deep_think and \
                not query.deep_think.dynamic_doc_index:
            # 如果开启了动态文档检索且还有其他索引，但是用户关闭了动态文档检索，则需要移除动态文档检索
            selected_index.pop(IndexType.DYNAMIC_DOC)
            logger.debug(
                'Dynamic doc index is disabled, remove it from selected_index: '
                f'{selected_index}, query_config={query}'
            )
        return selected_index

    def _retrieve(self, query: QueryConfig) -> Iterator[QueryResults]:
        """在本知识库中进行查询

        Args:
            query (QueryConfig): 查询参数
        Returns:
            Iterator[QueryResults]: 查询结果生成器
        """
        query = self._auto_fill_query_deep_think(query)

        def retrieve_function(query: QueryConfig) -> Iterator[QueryResults]:
            """
            检索函数，用于在知识库中进行查询

            Args:
                query: 查询配置
            """
            results = QueryResults()
            # 文档列表筛选，可以先进行判断
            # 如果doc_selector为True，则先进行文档过滤
            # NOTE: 目前仅vector index支持在过滤后的文档进行检索，其他index进行全量检索
            selected_doc_ids = None
            selected_doc_ids, step_msg = self._pre_select_docs(query)
            if step_msg:
                results.append(step_msg)
                if query.stream:
                    yield QueryResults(step_messages=step_msg)

            # 索引选择
            selected_index = self._select_index_for_retrieve(query)

            if len(selected_index) == 0:
                raise ValueError(
                    'You must enable at least one index type, given '
                    f'{query.enable_index_types}, available {self.index_map}'
                )
            elif len(selected_index) == 1:
                # 如果只涉及一个index，直接调用
                k, index = list(selected_index.items())[0]
                # 此处根据配置选择是否使用DeepSearcher
                retrieve_func = index.retrieve
                for intermediate_res in retrieve_func(query=query, selected_doc_ids=selected_doc_ids):
                    if not intermediate_res.is_final:
                        if query.stream:
                            yield intermediate_res
                    else:
                        results.extend(intermediate_res)
            else:
                # 多种索引并发调用
                futures = {}

                # 流式处理需要的队列和控制标志
                stream_queue = queue.Queue()
                stream_lock = threading.Lock()
                active_indexes = len(selected_index)

                def excute_stream_retrieval(key, retrieve_func, query, selected_doc_ids):
                    nonlocal active_indexes
                    retrieval_res = None
                    for intermediate_res in retrieve_func(query=query, selected_doc_ids=selected_doc_ids):
                        if not intermediate_res.is_final:
                            if query.stream:
                                with stream_lock:
                                    stream_queue.put(intermediate_res)
                        else:
                            retrieval_res = intermediate_res

                    # 标记此索引的流式检索已完成
                    with stream_lock:
                        active_indexes -= 1
                    return retrieval_res

                with ThreadPoolExecutor(max_workers=len(selected_index)) as pool:
                    # 这里不做span和context存在性检测，上游请确保context的存在
                    current_context = get_context()
                    for k, index in selected_index.items():
                        # 此处根据配置选择是否使用DeepSearcher
                        retrieve_func = index.retrieve
                        futures[k] = pool.submit(context_wrapper, current_context,
                                                 excute_stream_retrieval, k, retrieve_func, query, selected_doc_ids)

                    while active_indexes > 0 or not stream_queue.empty():
                        with stream_lock:
                            try:
                                intermediate_res = stream_queue.get_nowait()
                                yield intermediate_res
                            except queue.Empty:
                                pass

                    # 收集最终结果
                    for k, future in futures.items():
                        last_res = future.result()
                        results.extend(last_res)
            results.is_final = True
            yield results

        results = QueryResults()
        retrieve_func = self._wrap_retrieve_func(retrieve_function=retrieve_function, query=query)
        for res in retrieve_func(query=query):
            if not res.is_final:  # 避免results重复返回
                if query.stream:
                    yield res
            else:
                results.extend(res)
        results_list = self._unique_top_k_results(query, results.results)
        results_list = self._post_fill_doc_info(results_list)
        results.results = results_list
        results.is_final = True
        yield results

    @tracer.start_as_current_span("knowledge_base.retrieve")
    def retrieve(self, query: QueryConfig) -> Union[QueryResults, Iterator[QueryResults]]:
        if query.stream:
            return self._retrieve(query=query)
        else:
            return next(self._retrieve(query=query))

    def list_chunks(self, doc_id: str, offset: int = 0, limit: int = 20
                    ) -> Tuple[List[Tuple[Optional[Chunk], KBXError]], int]:
        """列出指定文档的offset - offset+limit范围的文本块，注意，

        - 此知识库必须开启了向量索引，否则直接抛出异常
        - 如果offset+limit已经超出了实际的文本块数量，返回值数量可能小于limit

        Args:
            doc_id (str): 文档ID
            offset (int): 偏移量. 默认为0.
            limit (int): 限制数量. 默认为20.

        Returns:
            Tuple[List[Tuple[Optional[Chunk], KBXError]], int]: 文本块列表和总数量
        """

        if self.kb_config.vector_keyword_config is None:
            raise ValueError(
                'You can not get text chunks for knowledge base '
                f'"{self.kb_id}" because vector index is disabled.'
            )

        with get_doc_datastore(self.kb_id) as doc_ds:
            chunk_ids, err, total_count = doc_ds.list_chunk_ids_by_doc_id(doc_id, index_type=IndexType.VECTOR_KEYWORD,
                                                                          offset=offset, limit=limit)
            if err.code != KBXError.Code.SUCCESS:
                raise RuntimeError(f'Failed to list chunk ids for doc_id {doc_id}: {err.msg}')

            chunks = []
            for chunk_id in chunk_ids:
                chunk, err = doc_ds.load_chunk(chunk_id, index_type=IndexType.VECTOR_KEYWORD)
                chunks.append((chunk, err))

            return chunks, total_count
