# 默认的文档文件名规则列表
DEFAULT_NORMAL_DOC_FILE_PATTERNS = [
    "*.docx",
    "*.pdf",
    "*.pptx",
    "*.md",
    "*.txt",

    # 表格
    "*.csv",
    "*.xls",
    "*.xlsx",
    "*.xlsm",

    # 网页
    "*.html",

    # 视频
    "*.mp4",
    "*.mov",

    # 音频
    "*.mp3",
    "*.wav",
]
