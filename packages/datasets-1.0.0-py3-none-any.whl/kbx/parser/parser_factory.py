from typing import Optional

from kbx.common.logging import logger
from kbx.common.types import DocData, DocFileType
from kbx.datastore.file.file_base import BaseFileDS
from kbx.parser.base_parser import BaseParser
from kbx.parser.types import DocParseConfig


_parser_cache = {}


class SmartParser(BaseParser):
    """智能解析器，根据文件类型自动选择最合适的解析器"""

    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None):
        super().__init__(config, file_ds)
        self._fallback_parsers = {
            DocFileType.DOCX: 'DefaultDocxParser',
            DocFileType.PDF: 'DefaultPdfParser',
            DocFileType.PPTX: 'DefaultPptxParser',
            DocFileType.MARKDOWN: 'MarkdownItPyParser',
            DocFileType.CSV: 'DefaultCsvParser',
            DocFileType.EXCEL: 'DefaultExcelParser',
            DocFileType.TXT: 'DefaultTxtParser',
            DocFileType.AUDIO: 'DefaultAudioParser',
            DocFileType.IMAGE: 'DefaultImageParser',
            DocFileType.VIDEO: 'DefaultVideoParser',
            DocFileType.HTML: 'DefaultHTMLParser',
        }
        self._parser_blacklist = {'SmartParser'}

    def _is_landscape_pdf(self, file_path: str) -> bool:
        """判断PDF文件是否为横向（宽度大于长度）"""
        try:
            import pypdfium2 as pdfium
            # 只加载文档元数据和第一页，不加载页面内容
            pdf = pdfium.PdfDocument(file_path, autoclose=True)
            # 只获取第一页的尺寸信息
            if len(pdf) > 0:
                page = pdf[0]
                width, height = page.get_size()
                return width > height
            return False
        except Exception:
            return False

    def _auto_select_parser(self, file_path: str, doc_id: str) -> str:
        file_type = DocFileType.get_file_type_by_file_name(file_path)
        if file_type == DocFileType.UNKNOWN:
            raise RuntimeError(f'Unsupported file type: {file_path}')

        parser_name = None
        # 如果用户配置了该文件类型的解析器，优先使用
        if self._config and self._config.file_parsers.get(file_type):
            parser_name = self._config.file_parsers[file_type]
        elif file_type == DocFileType.PPTX:
            # 默认使用DefaultPptxParser
            parser_name = 'DefaultPptxParser'
            # 如果配置了VLM文本嵌入策略，使用VlmSlidesParser
            if self._config.image_strategy:
                from kbx.common.types import ImageEmbeddingStrategy
                if self._config.image_strategy.type == ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING:
                    parser_name = 'VlmSlidesParser'
        elif file_type == DocFileType.PDF:
            if self._is_landscape_pdf(file_path):
                # 如果是横向PDF，使用VLMPdfParser
                parser_name = 'VLMPdfParser'
            else:
                # 默认使用DefaultPdfParser
                parser_name = 'DefaultPdfParser'
                # 如果配置了MinerU且配置文件存在,则使用MinerU
                if self._config.pdf_ocr_strategy and self._config.pdf_ocr_strategy.parser_type == 'MinerU':
                    try:
                        import os
                        from kbx.common.utils import get_default_base_dir
                        base_dir = get_default_base_dir()
                        config_path = os.path.join(base_dir, 'ckpts/MinerU/magic-pdf.json')
                        if os.path.exists(config_path):
                            from kbx.parser.pdf.minerU_pdf_parser import MinerUPdfParser    # noqa
                            parser_name = 'MinerUPdfParser'
                        else:
                            logger.warning("MinerU模型配置文件不存在，使用默认PDF解析器")
                    except Exception as e:
                        logger.error(f"无法加载MinerU解析器: {e}，使用默认PDF解析器")
        else:
            # 否则使用默认的解析器
            parser_name = self._fallback_parsers.get(file_type)
            if not parser_name:
                raise RuntimeError(f'No parser available for file type: {file_type}')

        if parser_name in self._parser_blacklist:
            raise RuntimeError(f'Circular parser selection detected: {parser_name}')
        return parser_name

    def parse(self, file_path: str, doc_id: str) -> DocData:
        parser_name = self._auto_select_parser(file_path, doc_id)
        logger.debug(f"{file_path} -> selected parser: {parser_name}")

        self._concrete_parser = get_parser(parser_name, self._config, self._file_ds)
        return self._parse(file_path, doc_id)

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        return self._concrete_parser.parse(file_path, doc_id)


def generate_parser_cache_key(parser_name: str, config: Optional[DocParseConfig] = None) -> str:
    """生成parser缓存的key

    Args:
        parser_name: 解析器名称
        config: 解析器配置参数

    Returns:
        str: 缓存key
    """
    # 创建包含 parser_name 和关键配置参数的缓存键
    config_parts = []
    if config:
        # 只选择影响解析器行为的关键配置项
        config_parts = [
            f"save_external_data={config.save_external_data}",
            f"enable_layout_recognition={config.enable_layout_recognition}"
        ]

        # 添加策略配置的类型信息
        if config.image_strategy:
            config_parts.append(f"image_strategy={config.image_strategy.type}")
        if config.video_strategy:
            config_parts.append(f"video_strategy={config.video_strategy.type}")
        if config.audio_strategy:
            config_parts.append(f"audio_strategy={config.audio_strategy.type}")
        if config.pdf_ocr_strategy:
            config_parts.append(f"pdf_ocr_strategy={config.pdf_ocr_strategy.parser_type}")

        # 添加用户ID（如果存在）
        if config.user_ctx and hasattr(config.user_ctx, 'user_id'):
            config_parts.append(f"user_id={config.user_ctx.user_id}")

    # 生成配置哈希
    config_str = "_".join(config_parts)
    config_hash = hash(config_str) if config_str else 0

    # 最终缓存键
    return f"{parser_name}_{config_hash}"


def get_parser(parser_name: str = 'SmartParser',
               config: DocParseConfig = DocParseConfig(),
               file_ds: BaseFileDS = None) -> BaseParser:
    """parser的工厂函数，根据用户给定的参数选择并创建对应的parser实例

    Args:
        parser_name (str): 文档解析器名称
        config (DocParseConfig): 文档解析器配置
        file_ds (BaseFileDS, optional): 文件datastore实例，用于访问远程文件；默认为None，仅用于本地调试

    Returns:
        BaseParser: 解析器实例
    """

    global _parser_cache

    # 生成缓存key
    cache_key = generate_parser_cache_key(parser_name, config)

    if cache_key in _parser_cache:
        return _parser_cache[cache_key]

    if parser_name == 'SmartParser':
        return SmartParser(config, file_ds)
    match parser_name:
        case 'DefaultDocxParser':
            from kbx.parser.docx.default_docx_parser import DefaultDocxParser
            return DefaultDocxParser(config, file_ds)
        case 'DefaultMarkdownParser':
            from kbx.parser.markdown.default_markdown_parser import DefaultMarkdownParser
            return DefaultMarkdownParser(config, file_ds)
        case 'MarkdownItPyParser':
            from kbx.parser.markdown.markdown_it_parser import MarkdownItPyParser
            return MarkdownItPyParser(config, file_ds)
        case 'DefaultPdfParser':
            from kbx.parser.pdf.default_pdf_parser import DefaultPdfParser
            return DefaultPdfParser(config, file_ds)
        case 'DeepdocPdfParser':
            from kbx.parser.pdf.deepdoc_pdf_parser import DeepdocPdfParser
            return DeepdocPdfParser(config, file_ds)
        case 'MinerUPdfParser':
            # import os
            # from kbx.common.utils import get_default_base_dir
            # base_dir = get_default_base_dir()
            # os.environ['MINERU_TOOLS_CONFIG_JSON'] = os.path.join(base_dir, 'ckpts/MinerU/magic-pdf.json')
            from kbx.parser.pdf.minerU_pdf_parser import MinerUPdfParser
            return MinerUPdfParser(config, file_ds)
        case 'DefaultPptxParser':
            from kbx.parser.pptx.default_pptx_parser import DefaultPptxParser
            return DefaultPptxParser(config, file_ds)
        case 'DefaultCsvParser':
            from kbx.parser.structured.default_csv_parser import DefaultCsvParser
            return DefaultCsvParser(config, file_ds)
        case 'DefaultExcelParser':
            from kbx.parser.structured.default_excel_parser import DefaultExcelParser
            return DefaultExcelParser(config, file_ds)
        case 'DefaultTxtParser':
            from kbx.parser.txt.default_txt_parser import DefaultTxtParser
            return DefaultTxtParser(config, file_ds)
        case 'DefaultAudioParser':
            from kbx.parser.audio.default_audio_parser import DefaultAudioParser
            return DefaultAudioParser(config, file_ds)
        case 'DefaultImageParser':
            from kbx.parser.image.default_image_parser import DefaultImageParser
            return DefaultImageParser(config, file_ds)
        case 'DefaultVideoParser':
            from kbx.parser.video.default_video_parser import DefaultVideoParser
            return DefaultVideoParser(config, file_ds)
        case 'VlmSlidesParser':
            from kbx.parser.pptx.vlm_slides_parser import VlmSlidesParser
            return VlmSlidesParser(config, file_ds)
        case 'DefaultHTMLParser':
            from kbx.parser.html.default_html_parser import DefaultHTMLParser
            return DefaultHTMLParser(config, file_ds)
        case 'VLMPdfParser':
            from kbx.parser.pdf.vlm_pdf_parser import VLMPdfParser
            return VLMPdfParser(config, file_ds)
        case _:
            raise RuntimeError(f'Unknown parser class: {parser_name}')
