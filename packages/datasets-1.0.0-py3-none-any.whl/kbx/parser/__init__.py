from kbx.common.registry import Registry


PARSER_REGISTRY = Registry()
