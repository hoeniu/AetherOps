import os
import io
import numpy as np
from typing import List
from pydub import AudioSegment
from pydub.silence import detect_silence
from pathlib import Path
from kbx.datastore.file.file_base import BaseFileDS
from kbx.parser.base_parser import BaseParser
from kbx.parser.types import DocParseConfig
from kbx.common.types import DocData, DocElement, DocElementType
from kbx.common.types import AudioEmbeddingStrategy
from kbx.common.utils import generate_new_id
from kbx.common.logging import logger


class DefaultAudioParser(BaseParser):
    """
    默认音频解析器，继承自BaseParser，用于解析音频文件并提取音频特征。

    该解析器是音频文件解析的默认实现，支持mp3/wav等格式，基于pydub进行音频处理和智能分割。

    支持解析音频文件中的以下内容：

    - 音频智能分割（基于静音检测）
    - 音频转文本（语音识别）
    - 音频元数据提取

    不支持的功能：

    - 复杂音频处理（如音色分析、音效处理）
    - 环境音、配乐等声音的处理分析
    - 音频水印处理
    """
    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None):
        super().__init__(config, file_ds)
        splitter_map = {
            'size': self._size_based_splitter,
            'time': self._time_based_splitter,
            'intelligent': self._intelligent_splitter
        }
        self._splitter = splitter_map.get(self._config.audio_strategy.split_mode)
        from kbx.kbx import KBX
        self._cache_dir = KBX.config.cache_dir

    @staticmethod
    def file_extensions() -> List[str]:
        return ['.mp3', '.wav']

    @staticmethod
    def postprocess_steps() -> List[str]:
        return ['audio']

    def _time_based_splitter(self, file_path, doc_id) -> List[DocElement]:
        """按固定时间维度切分音频策略

        Args:
            file_path (str): 原始视频文件路径
        Returns:
            List[DocElement]: 已分割音频构建的DocElement列表
        """
        with self.open(file_path, mode='rb', encoding=None) as file_obj:
            audio = AudioSegment.from_file(file_obj)
        chunk_duration = 20  # 固定时间间隔（min）
        chunk_duration_ms = chunk_duration * 60 * 1000

        if len(audio) < chunk_duration_ms:
            return [DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.AUDIO,
                data_file_path=file_path,
                meta_data={'time_stamp': (0, len(audio))}
            )]

        doc_eles = []
        for split_number, i in enumerate(range(0, len(audio), chunk_duration_ms)):
            chunk = audio[i: i + chunk_duration_ms]
            io_buffer = io.BytesIO()
            ori_format = Path(file_path).suffix.lstrip('.')
            chunk.export(io_buffer, format=ori_format)
            data_file_path = self._save_extra_file(io_buffer.getvalue(), doc_id, f"part{split_number}")
            doc_eles.append(DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.AUDIO,
                data_file_path=data_file_path,
                meta_data={'time_stamp': (i, i + chunk_duration_ms)}
            ))

        return doc_eles

    def _size_based_splitter(self, file_path, doc_id) -> List[DocElement]:
        """按固定尺寸切分音频策略

        Args:
            file_path (str): 原始视频文件路径
        Returns:
            List[DocElement]: 已分割音频构建的DocElement列表
        """
        with self.open(file_path, mode='rb', encoding=None) as file_obj:
            audio = AudioSegment.from_file(file_obj)
            file_obj.seek(0)
            total_size = len(file_obj.read())
        max_size_bytes = 20 * 1024 * 1024  # 20 MB to bytes，略小于最大请求限制
        max_duration_ms = int(max_size_bytes * len(audio) / total_size)

        if len(audio) < max_duration_ms:
            return [DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.AUDIO,
                data_file_path=file_path,
                meta_data={'time_stamp': (0, len(audio))}
            )]

        doc_eles = []
        for split_number, i in enumerate(range(0, len(audio), max_duration_ms)):
            chunk = audio[i: i + max_duration_ms]
            io_buffer = io.BytesIO()
            ori_format = Path(file_path).suffix.lstrip('.')
            chunk.export(io_buffer, format=ori_format)
            data_file_path = self._save_extra_file(io_buffer.getvalue(), doc_id, f"part{split_number}")
            doc_eles.append(DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.AUDIO,
                data_file_path=data_file_path,
                meta_data={'time_stamp': (i, i + max_duration_ms)}
            ))

        return doc_eles

    def _intelligent_splitter(self, file_path, doc_id) -> List[DocElement]:
        """结合音频silence检测以及固定尺寸分割的智能分割策略

        Args:
            file_path (str): 原始视频文件路径
        Returns:
            List[DocElement]: 已分割音频构建的DocElement列表
        """
        with self.open(file_path, mode='rb', encoding=None) as file_obj:
            audio = AudioSegment.from_file(file_obj)
            file_obj.seek(0)
            total_size = len(file_obj.read())

        # 根据尺寸获得最大时间间隔
        max_size_bytes = 20 * 1024 * 1024  # 20 MB to bytes，略小于最大请求限制
        if total_size < max_size_bytes:
            return [DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.AUDIO,
                data_file_path=file_path,
                meta_data={'time_stamp': (0, len(audio))}
            )]
        max_duration_ms = int(max_size_bytes * len(audio) / total_size)
        logger.debug(f'根据尺寸限制，计算可得最大间隔为{max_duration_ms}')

        # 获取音频可能的静音段
        max_db = audio.dBFS
        chunk_size = 1000
        chunk_dbs = []
        for i in range(0, len(audio), chunk_size):
            chunk = audio[i:i + chunk_size]
            chunk_dbs.append(chunk.dBFS)
        min_db = np.min([db for db in chunk_dbs if db > float('-inf')])
        logger.debug(f"音频总长度: {len(audio) / 1000:.2f} 秒")
        logger.debug(f"最大分贝: {max_db:.2f} dB")
        logger.debug(f"平均分贝: {np.mean(chunk_dbs):.2f} dB")
        logger.debug(f"最小分贝: {min_db:.2f} dB")

        min_silence_len = 1000
        silence_thresh = min_db + 15  # dBFS表示，值越小声音分贝越低
        silence_ranges = detect_silence(
            audio,
            min_silence_len=min_silence_len,
            silence_thresh=silence_thresh
        )

        optimal_points = []
        current_position = 0
        while current_position < len(audio):
            target_position = current_position + max_duration_ms
            best_split_point = None
            min_distance = float('inf')

            for start, end in silence_ranges:
                if start < current_position:
                    continue
                mid_point = (start + end) / 2
                distance = abs(mid_point - target_position)

                if distance < min_distance:
                    min_distance = distance
                    best_split_point = mid_point

                if start > target_position + 5000:
                    break

            if best_split_point:
                optimal_points.append(int(best_split_point))
                current_position = best_split_point
            else:
                optimal_points.append(int(target_position))
                current_position = target_position

        start_time = 0
        doc_eles = []
        for i, best_point in enumerate(optimal_points):
            chunk = audio[start_time:best_point]
            io_buffer = io.BytesIO()
            ori_format = Path(file_path).suffix.lstrip('.')
            chunk.export(io_buffer, format=ori_format)
            data_file_path = self._save_extra_file(io_buffer.getvalue(), doc_id, f"part{i}")
            doc_eles.append(DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.AUDIO,
                data_file_path=data_file_path,
                meta_data={'time_stamp': (start_time, best_point)}
            ))
            start_time = best_point

        return doc_eles

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        """默认音频解析实现函数

        Args:
            file_path (str): 原始音频文件远程路径
            doc_id (str): 原始音频文件id

        Returns:
            DocData: 解析后的DocData数据
        """
        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)

        if self._config.audio_strategy.type == AudioEmbeddingStrategy.SPEECH2TEXT_TEXT_EMBEDDING:
            doc.doc_elements = self._splitter(file_path, doc_id)
        else:
            doc.doc_elements = [DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.AUDIO)]

        return doc
