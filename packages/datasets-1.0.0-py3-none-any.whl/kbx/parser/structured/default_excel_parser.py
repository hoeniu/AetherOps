from datetime import datetime
from io import BytesIO
import os
from typing import List, Union

from openpyxl import load_workbook
from openpyxl.utils import range_boundaries
import xlrd

from kbx.common.types import Table
from kbx.common.utils import generate_new_id
from kbx.common.logging import logger
from kbx.parser.base_parser import BaseParser
from kbx.common.types import DocData, DocElement, DocElementType
from kbx.parser.utils import postprocess_table_data


class DefaultExcelParser(BaseParser):
    """
    Excel文档默认解析器，继承自BaseParser，用于解析Excel文件。

    该解析器是Excel文档解析的默认实现，支持xls、xlsx和xlsm格式，基于openpyxl和xlrd库进行解析。

    支持解析Excel文档中的以下内容：

    - 多工作表数据提取
    - 合并单元格处理
    - 多种数据类型转换（文本、数字、日期、布尔值）
    - 自动处理不同Excel版本格式
    - 表格数据后处理

    不支持的功能：

    - 复杂公式计算
    - 图表和图形信息提取
    - 宏代码解析
    - 样式信息提取
    - 大文件分块处理
    """
    @staticmethod
    def file_extensions() -> List[str]:
        return ['.xlsx', '.xlsm', '.xls']

    @staticmethod
    def postprocess_steps() -> List[str]:
        return ['table']

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        """Load from Excel file in xls or xlsx format using Pandas and openpyxl."""
        self.doc = DocData(doc_id=doc_id,
                           file_name=os.path.basename(file_path),
                           file_path=file_path)

        doc_elements = []
        file_extension = os.path.splitext(file_path)[-1].lower()
        if file_extension in [".xlsx", ".xlsm"]:
            doc_elements = self._parse_xlsx(file_path)
        elif file_extension == ".xls":
            doc_elements = self._parse_xls(file_path)
        else:
            raise ValueError(f"Unsupported file extension: {file_extension}")

        self.doc.doc_elements = doc_elements
        return self.doc

    def _parse_xlsx(self, file_path: str) -> List[DocElement]:
        """Parse .xlsx files into list of DocElement using openpyxl."""
        parsed_elems = []
        with self.open(file_path, 'rb') as f:
            workbook = load_workbook(f, data_only=True)

            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]
                table_data = []

                # Handle merged cells
                merged_cells_map = self._process_xlsx_merged_cells(sheet)

                # Extract table data
                for row_idx, row in enumerate(sheet.iter_rows(values_only=True), start=1):
                    row_data = []
                    for col_idx, cell_value in enumerate(row, start=1):
                        cell_value = self._get_cell_value_xlsx(sheet.cell(row_idx, col_idx))
                        if cell_value is None:      # 如果单元格为空，检查是否是合并单元格
                            cell_value = merged_cells_map.get((row_idx, col_idx), None)
                        row_data.append(cell_value)
                    table_data.append(row_data)

                table_data = postprocess_table_data(table_data)
                elem = self._create_table_element(table_data, sheet_name)
                if elem:
                    parsed_elems.append(elem)

        return parsed_elems

    def _parse_xls(self, file_path: str) -> dict:
        """Parse .xls files using xlrd and olefile for image extraction."""
        parsed_elems = []
        with self.open(file_path, 'rb') as f:
            # 将文件对象包装为 BytesIO
            file_stream = BytesIO(f.read())
            workbook = xlrd.open_workbook(file_contents=file_stream.getvalue(), formatting_info=True)

            for sheet_name in workbook.sheet_names():
                sheet = workbook.sheet_by_name(sheet_name)
                table_data = []

                # Handle merged cells
                merged_cells_map = self._process_xls_merged_cells(sheet)

                # Extract table data
                for row_idx in range(sheet.nrows):
                    row_data = []
                    for col_idx in range(sheet.ncols):
                        cell = sheet.cell(row_idx, col_idx)
                        cell_value = self._get_cell_value_xls(cell)
                        if cell_value == "":
                            cell_value = merged_cells_map.get((row_idx, col_idx), None)
                        row_data.append(cell_value)
                    table_data.append(row_data)

                table_data = postprocess_table_data(table_data)
                elem = self._create_table_element(table_data, sheet_name)
                if elem:
                    parsed_elems.append(elem)

        return parsed_elems

    def _process_xlsx_merged_cells(self, sheet):
        # Handle merged cells
        merged_cells_map = {}
        for merged_range in sheet.merged_cells.ranges:
            # 获取合并单元格的边界
            min_col, min_row, max_col, max_row = range_boundaries(str(merged_range))
            # 获取合并单元格的左上角单元格的值
            value = sheet.cell(row=min_row, column=min_col).value
            # 填充合并单元格内其他单元格的值
            for row in range(min_row, max_row + 1):
                for col in range(min_col, max_col + 1):
                    merged_cells_map[(row, col)] = value

        return merged_cells_map

    def _process_xls_merged_cells(self, sheet):
        """Process merged cells in an .xls sheet."""
        merged_cells_map = {}
        for (min_row, max_row, min_col, max_col) in sheet.merged_cells:
            value = sheet.cell_value(min_row, min_col)
            for row in range(min_row, max_row):
                for col in range(min_col, max_col):
                    merged_cells_map[(row, col)] = value

        return merged_cells_map

    def _create_table_element(self, table_data: List[List[str]], sheet_name: str) -> Union[DocElement | None]:
        """Create a DocElement from table data."""
        if table_data:
            # TODO(@dengwenda): 是否可以区分表头和数据？
            try:
                table = Table.from_2d_list(
                    table_data,
                    has_header=None,
                    caption=self.doc.file_name + ' - ' + sheet_name
                )
            except ValueError as e:
                import traceback
                logger.error(f"Error parsing table:\n {traceback.format_exc()}\n {e}")
                return None
            elem = DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.TABLE,
                table=table,
                meta_data={"sheet_name": sheet_name}
            )
            return elem

        return None

    def _get_cell_value_xlsx(self, cell) -> str:
        """Get the appropriate value of a cell in .xlsx files, handling its type."""
        if cell.value is None:
            return None
        elif isinstance(cell.value, str):
            return cell.value.strip()
        elif isinstance(cell.value, (int, float)):
            return str(cell.value)
        elif isinstance(cell.value, bool):
            return "TRUE" if cell.value else "FALSE"
        elif isinstance(cell.value, datetime):
            # If the value is already a datetime object, format it as 'YYYY-MM-DD'
            return cell.value.strftime('%Y-%m-%d %H:%M:%S')
        else:
            # For other types (e.g., formula, error, or unsupported types), convert to string
            return str(cell.value)

    def _get_cell_value_xls(self, cell) -> str:
        """Get the appropriate value of a cell, handling its type."""
        if cell.ctype == xlrd.XL_CELL_EMPTY:
            return ""
        elif cell.ctype == xlrd.XL_CELL_TEXT:
            return cell.value.strip()
        elif cell.ctype == xlrd.XL_CELL_NUMBER:
            return str(cell.value)
        elif cell.ctype == xlrd.XL_CELL_DATE:
            date = xlrd.xldate_as_tuple(cell.value, datemode=0)
            return f"{date[0]}-{date[1]:02d}-{date[2]:02d} {date[3]}:{date[4]}:{date[5]}"
        elif cell.ctype == xlrd.XL_CELL_BOOLEAN:
            return "TRUE" if cell.value else "FALSE"
        elif cell.ctype == xlrd.XL_CELL_ERROR:
            return f"ERROR({cell.value})"
        else:
            return str(cell.value)
