import csv
import os
from typing import List

from kbx.common.logging import logger
from kbx.datastore.file.file_base import BaseFileDS
from kbx.parser.base_parser import BaseParser
from kbx.common.types import DocData, DocElement, DocElementType, Table
from kbx.parser.types import DocParseConfig
from kbx.common.utils import generate_new_id


class DefaultCsvParser(BaseParser):
    """
    CSV文档默认解析器，继承自BaseParser，用于解析CSV文件。

    该解析器是CSV文档解析的默认实现，基于Python标准库csv模块进行解析。

    支持解析CSV文档中的以下内容：

    - 表格数据完整提取
    - 支持多种编码格式
    - 自动处理不同操作系统的换行符
    - 支持自定义编码检测

    不支持的功能：

    - 复杂表格结构解析（如合并单元格）
    - 表格样式信息提取
    - 大文件分块处理
    - 数据格式转换
    """
    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None) -> None:
        super().__init__(config, file_ds)

    @staticmethod
    def file_extensions() -> List[str]:
        return ['.csv']

    @staticmethod
    def postprocess_steps() -> List[str]:
        return ['table']

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        """Load data into document objects."""
        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)

        doc.doc_elements = self._read_csv_elements(file_path, 'utf-8')

        return doc

    def _read_csv_elements(self, file_path: str, encoding: str) -> List[DocElement]:
        """
        读取CSV文件并将其内容转换为文档元素列表。

        参数:
        - file_path (str): CSV文件的路径。
        - encoding (str): 文件的编码方式。

        返回:
        - List[DocElement]: 包含CSV文件内容的文档元素列表。
        """
        table_2d: List[List[str]] = []

        # newline参数可以确保在不同操作系统上正确处理换行符，避免出现不必要的空行或换行问题
        with self.open(file_path, 'r', encoding=encoding, newline="") as csvfile:
            reader = csv.reader(csvfile)

            # store row data
            for row in reader:
                content = [str(col).strip() for col in row]
                table_2d.append(content)

        # 对于CSV文件，我们默认不知道是否有表头，所以has_header设为None
        try:
            table = Table.from_2d_list(
                data=table_2d,
                has_header=None,  # 表示未知是否有表头
                caption=os.path.basename(file_path)
            )
        except ValueError as e:
            import traceback
            logger.error(f"Error parsing table:\n {traceback.format_exc()}\n {e}")
            return []

        metadata = {'file_type': 'csv'}
        doc_elem = DocElement(
            doc_element_id=generate_new_id(),
            type=DocElementType.TABLE,
            table=table,
            meta_data=metadata
        )

        return [doc_elem]
