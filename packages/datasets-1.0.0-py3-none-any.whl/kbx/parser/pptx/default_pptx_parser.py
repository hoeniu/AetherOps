import os
from typing import List, Any

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

from kbx.common.logging import logger
from kbx.common.utils import generate_new_id
from kbx.parser.base_parser import BaseParser
from kbx.common.types import DocData, DocElement, DocElementType, Table


def safe_get_attr(obj: Any, attr_path: str, default: Any = None) -> Any:
    """
    安全地获取嵌套属性值，避免AttributeError异常

    Args:
        obj: 要获取属性的对象
        attr_path: 属性路径，使用点号分隔，如 'graphic.graphicData'
        default: 如果属性不存在时返回的默认值

    Returns:
        属性值或默认值
    """
    attrs = attr_path.split('.')
    current = obj

    for attr in attrs:
        if not hasattr(current, attr):
            return default
        current = getattr(current, attr)
        if current is None:
            return default

    return current


class DefaultPptxParser(BaseParser):
    """
    PPTX文档默认解析器，继承自BaseParser，用于解析PPTX文件。

    该解析器是PPTX文档解析的默认实现，基于python-pptx库进行本地解析。

    支持解析PPTX文档中的以下内容：

    - 幻灯片文本内容提取
    - 图片内容提取（保存本地文件）
    - 表格内容提取
    - 幻灯片笔记提取
    - 幻灯片结构提取（标题层级）
    - 图表数据提取
    - 分页信息保留

    不支持的功能：

    - 动画效果解析
    - 音频/视频内容提取
    - 复杂形状内容的完全提取
    """
    @staticmethod
    def file_extensions() -> List[str]:
        return ['.pptx']

    @staticmethod
    def postprocess_steps() -> List[str]:
        # TODO: audio and video postprocess
        return ['table', 'image']

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        """
        Parse the PowerPoint file and extract content from slides with error handling.
        Args:
            file_path (str): The path to the PowerPoint file.
            doc_id (str): The document ID.

        Returns:
            A DocData object containing the parsed content: text, images, tables, etc.
        """
        doc = DocData(doc_id=doc_id, file_name=os.path.basename(file_path), file_path=file_path)

        try:
            with self.open(file_path, 'rb') as f:
                presentation = Presentation(f)
        except Exception as e:
            logger.error(f"Failed to parse PPTX file {file_path}: {str(e)}")

        # enumerate从1开始不会漏掉第一张PPT,因为它只是改变了计数的起始值
        # 从1开始是因为幻灯片编号通常从1开始计数,而不是从0开始,这样更符合用户习惯,在显示和引用幻灯片时更直观
        for slide_number, slide in enumerate(presentation.slides, start=1):
            # 创建临时列表，收集该幻灯片的所有元素
            slide_elements = []
            has_title = False

            try:
                # 提取文本，检查是否包含标题
                text_elements = self._extract_text_from_slide(slide, slide_number)
                for elem in text_elements:
                    if elem.type == DocElementType.TITLE:
                        has_title = True
                        break
                slide_elements.extend(text_elements)
            except Exception as e:
                logger.warning(f"Failed to extract text from slide {slide_number}: {str(e)}")

            # 提取其他元素
            try:
                slide_elements.extend(self._extract_images_from_slide(slide, slide_number, doc_id))
            except Exception as e:
                logger.warning(f"Failed to extract images from slide {slide_number}: {str(e)}")

            try:
                slide_elements.extend(self._extract_tables_from_slide(slide, slide_number))
            except Exception as e:
                logger.warning(f"Failed to extract tables from slide {slide_number}: {str(e)}")

            try:
                slide_elements.extend(self._extract_charts_from_slide(slide, slide_number))
            except Exception as e:
                logger.warning(f"Failed to extract charts from slide {slide_number}: {str(e)}")

            try:
                slide_elements.extend(self._extract_shapes_from_slide(slide, slide_number))
            except Exception as e:
                logger.warning(f"Failed to extract shapes from slide {slide_number}: {str(e)}")

            try:
                slide_elements.extend(self._extract_notes_from_slide(slide, slide_number))
            except Exception as e:
                logger.warning(f"Failed to extract notes from slide {slide_number}: {str(e)}")

            # 如果没有标题，添加一个默认标题
            if not has_title:
                default_title = DocElement(
                    doc_element_id=generate_new_id(),
                    text=f"幻灯片 {slide_number}",
                    type=DocElementType.TITLE,
                    meta_data={
                        "slide_number": slide_number,
                        "file_type": "pptx",
                        "title_level": 1,
                        "is_auto_generated": True  # 标记为自动生成的标题
                    }
                )
                # 将默认标题添加到元素列表的最前面
                slide_elements.insert(0, default_title)
                logger.debug(f"为幻灯片 {slide_number} 添加了自动生成的标题")

            # 将处理好的所有幻灯片元素添加到doc_elements
            doc.doc_elements.extend(slide_elements)

        return doc

    def _extract_text_from_slide(self, slide, slide_number: int) -> List[DocElement]:
        """Extract all text from the slide."""
        texts = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                # 检查是否为标题占位符
                is_title = False
                title_level = 0

                # 检查占位符类型 - 需要添加对python-pptx库中相关常量的引用
                is_placeholder = safe_get_attr(shape, 'is_placeholder')
                if is_placeholder:
                    # 通常PH_TYPE_TITLE = 1, PH_TYPE_SUBTITLE = 2
                    ph_type = shape.placeholder_format.type
                    if ph_type == 1:  # 主标题
                        is_title = True
                        title_level = 1
                    elif ph_type == 2:  # 副标题
                        is_title = True
                        title_level = 2

                for paragraph in shape.text_frame.paragraphs:
                    element_type = DocElementType.TITLE if is_title else DocElementType.TEXT
                    meta_data = {
                        "slide_number": slide_number,
                        "file_type": "pptx"
                    }

                    if is_title:
                        meta_data["title_level"] = title_level

                    text_elem = DocElement(
                        doc_element_id=generate_new_id(),
                        text=paragraph.text.strip(),
                        type=element_type,
                        meta_data=meta_data
                    )
                    texts.append(text_elem)
        return texts

    def _extract_images_from_slide(self, slide, slide_number: int, doc_id: str) -> List[DocElement]:
        """
        Extract all images from the slide.

        Returns:
            A list of DocElement where each contains a data file path for local storage.
        """
        images = []
        for shape in slide.shapes:
            if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                image_bytes = shape.image.blob
                data_file_path = self._save_extra_file(image_bytes, doc_id)
                image_elem = DocElement(
                    doc_element_id=generate_new_id(),
                    type=DocElementType.FIGURE,
                    data_file_path=data_file_path,
                    meta_data={
                        "slide_number": slide_number,
                        "file_type": "pptx"
                    }
                )
                images.append(image_elem)
        return images

    def _extract_tables_from_slide(self, slide, slide_number: int) -> List[DocElement]:
        """
        Extract all tables from the slide.

        Returns:
            A list of DocElement, each contains a table represented as a 2D list of strings.
        """
        tables = []
        for shape in slide.shapes:
            if shape.shape_type == MSO_SHAPE_TYPE.TABLE:
                table = shape.table
                table_data = self._process_table(table)
                try:
                    table = Table.from_2d_list(table_data, has_header=None, caption='')
                except ValueError as e:
                    import traceback
                    logger.error(f"Error parsing table:\n {traceback.format_exc()}\n {e}")
                    continue
                table_elem = DocElement(
                    doc_element_id=generate_new_id(),
                    type=DocElementType.TABLE,
                    table=table,
                    meta_data={
                        "slide_number": slide_number,
                        "content_type": "table",
                        "file_type": "pptx"
                    }
                )
                tables.append(table_elem)

        return tables

    def _process_table(self, table) -> List[List[str]]:
        """
        Process a table, accounting for merged cells.

        Returns:
            A 2D list representing the table, where merged cells are filled with their content.
        """
        num_rows = len(table.rows)
        num_cols = len(table.columns)
        result = [["" for _ in range(num_cols)] for _ in range(num_rows)]

        # Track merged cells and their content
        merged_cells = {}

        for row_idx, row in enumerate(table.rows):
            for col_idx, cell in enumerate(row.cells):
                cell_text = cell.text.strip()
                # Identify the cell's location
                cell_address = (row_idx, col_idx)

                if cell_address not in merged_cells:
                    # Determine the span of the merged cell
                    row_span, col_span = self._get_cell_span(cell, table, row_idx, col_idx)

                    # Fill in the merged cells with the content of the master cell
                    for r in range(row_idx, row_idx + row_span):
                        for c in range(col_idx, col_idx + col_span):
                            merged_cells[(r, c)] = cell_text
                            result[r][c] = cell_text

        return result

    def _get_cell_span(self, cell, table, row_idx, col_idx):
        """
        Determine the row and column span for a merged cell.

        Returns:
            A tuple (row_span, col_span) representing the span of the merged cell.
        """
        row_span = 1
        col_span = 1

        # Check vertically for merging
        for r in range(row_idx + 1, len(table.rows)):
            if table.cell(r, col_idx) is cell:
                row_span += 1
            else:
                break

        # Check horizontally for merging
        for c in range(col_idx + 1, len(table.columns)):
            if table.cell(row_idx, c) is cell:
                col_span += 1
            else:
                break

        return row_span, col_span

    def _extract_notes_from_slide(self, slide, slide_number: int) -> List[DocElement]:
        """Extract notes from the slide."""
        notes = []
        notes_text_frame = safe_get_attr(slide, 'notes_slide.notes_text_frame')
        if notes_text_frame:
            notes_text = notes_text_frame.text.strip()
            if notes_text:
                notes_elem = DocElement(
                    doc_element_id=generate_new_id(),
                    text=notes_text,
                    meta_data={
                        "slide_number": slide_number,
                        "content_type": "note",
                        "file_type": "pptx"
                    }
                )
                notes.append(notes_elem)
        return notes

    def _extract_charts_from_slide(self, slide, slide_number: int) -> List[DocElement]:
        """Extract chart data from the slide."""
        charts = []
        for shape in slide.shapes:
            if safe_get_attr(shape, 'has_chart'):
                chart = shape.chart
                try:
                    chart_data = self._process_chart(chart)
                    chart_title = safe_get_attr(chart, 'chart_title.text_frame.text', "")

                    try:
                        table = Table.from_2d_list(chart_data, has_header=None, caption=chart_title)
                    except ValueError as e:
                        import traceback
                        logger.error(f"Error parsing table:\n {traceback.format_exc()}\n {e}")
                        continue

                    chart_elem = DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.TABLE,
                        table=table,
                        meta_data={
                            "slide_number": slide_number,
                            "content_type": "chart",
                            "file_type": "pptx"
                        }
                    )
                    charts.append(chart_elem)
                except Exception as e:
                    logger.warning(f"Failed to process chart data: {str(e)}")
                    # 至少保留图表标题信息
                    chart_title = safe_get_attr(chart, 'chart_title.text_frame.text')
                    if chart_title:
                        chart_elem = DocElement(
                            doc_element_id=generate_new_id(),
                            text=f"Chart: {chart_title}",
                            meta_data={
                                "slide_number": slide_number,
                                "content_type": "chart_title",
                                "file_type": "pptx"
                            }
                        )
                        charts.append(chart_elem)
        return charts

    def _process_chart(self, chart) -> List[List[str]]:
        """Extract data from a chart object."""
        chart_data = []

        # 尝试提取类别标签作为表头
        headers = ["Category"]
        series = safe_get_attr(chart, 'series', [])
        if series:
            for s in series:
                name = safe_get_attr(s, 'name')
                if name:
                    headers.append(str(name))
            chart_data.append(headers)

            # 尝试提取数据行
            categories = safe_get_attr(chart, 'plots.0.categories')
            if categories:
                categories = [str(c) for c in categories]
                for i, category in enumerate(categories):
                    row = [category]
                    for s in series:
                        try:
                            values = safe_get_attr(s, 'values')
                            if values and i < len(values):
                                value = values[i]
                                row.append(str(value))
                            else:
                                row.append("")
                        except (IndexError, AttributeError):
                            row.append("")
                    chart_data.append(row)

        # 如果上面的尝试失败，使用简化处理
        if not chart_data:
            chart_data = [["Chart data could not be fully extracted"]]

        return chart_data

    def _extract_shapes_from_slide(self, slide, slide_number: int) -> List[DocElement]:
        """Extract text from shapes and SmartArt in the slide."""
        shape_elements = []

        for shape in slide.shapes:
            # 处理SmartArt
            graphic = safe_get_attr(shape, 'graphic')
            if graphic:
                try:
                    smart_art_text = self._extract_smart_art_text(shape)
                    if smart_art_text:
                        shape_elem = DocElement(
                            doc_element_id=generate_new_id(),
                            text=smart_art_text,
                            meta_data={
                                "slide_number": slide_number,
                                "content_type": "smartart",
                                "file_type": "pptx"
                            }
                        )
                        shape_elements.append(shape_elem)
                except Exception as e:
                    logger.warning(f"Failed to extract SmartArt text: {str(e)}")

            # 处理其他普通形状（排除已处理的表格、图片和文本框）
            elif (safe_get_attr(shape, 'shape_type') and \
                  shape.shape_type != MSO_SHAPE_TYPE.TABLE and \
                  shape.shape_type != MSO_SHAPE_TYPE.PICTURE and \
                  not safe_get_attr(shape, 'has_text_frame') and \
                  not safe_get_attr(shape, 'has_chart')):
                try:
                    shape_type = safe_get_attr(shape, 'shape_type', "unknown")
                    shape_type = str(shape_type)
                    shape_elem = DocElement(
                        doc_element_id=generate_new_id(),
                        text=f"Shape: {shape_type}",
                        meta_data={
                            "slide_number": slide_number,
                            "content_type": "shape",
                            "shape_type": shape_type,
                            "file_type": "pptx"
                        }
                    )
                    shape_elements.append(shape_elem)
                except Exception as e:
                    logger.warning(f"Failed to process shape: {str(e)}")

        return shape_elements

    def _extract_smart_art_text(self, shape) -> str:
        """Extract text from SmartArt objects."""
        texts = []
        try:
            graphic_data = safe_get_attr(shape, 'graphic.graphicData')
            if graphic_data:
                for elem in graphic_data.iter():
                    text = safe_get_attr(elem, 'text')
                    if text and text.strip():
                        texts.append(text)
        except (AttributeError, TypeError) as e:
            logger.warning(f"Error extracting SmartArt text: {str(e)}")

        return "\n".join(filter(None, texts))
