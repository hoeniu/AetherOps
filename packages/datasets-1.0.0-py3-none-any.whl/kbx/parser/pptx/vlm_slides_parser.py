import os
from typing import List
from pdf2image import convert_from_path
from kbx.kbx import KBX
from kbx.datastore.file.file_base import BaseFileDS
from kbx.parser.base_parser import BaseParser
from kbx.parser.types import DocParseConfig
from kbx.common.types import DocData, DocElement, DocElementType
from kbx.parser.multimodal.multimodal_processor import ImageProcessor
from kbx.common.utils import generate_new_id


class VlmSlidesParser(BaseParser):
    """
    Slides风格的PPTX/PDF解析器，继承自BaseParser，会把输入的PDF/PPTX文件按页渲染成图片然后使用VLM进行内容分析生成对应的Summary。

    该解析器基于libreoffice和pdf2image进行转换和解析。

    支持解析Slides文档中的以下内容：

    - PPTX转PDF格式转换
    - 幻灯片页面提取为图像
    - 图像质量优化和压缩
    - 视觉语言模型(VLM)特征提取
    - 自动生成图像描述

    不支持的功能：

    - 原始PPTX文件结构解析
    - 动画和过渡效果提取
    - 幻灯片备注信息提取
    - 复杂图表和图形解析
    - 大文件分块处理
    - 内嵌音频、视频提取
    """
    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None):
        super().__init__(config, file_ds)
        if config.image_strategy is None:
            raise RuntimeError('Image strategy is not specified in DocParseConfig, must provide for VlmSlidesParser')
        self.image_processor = ImageProcessor(config)

    @staticmethod
    def file_extensions() -> List[str]:
        return ['.pptx', '.pdf']

    @staticmethod
    def postprocess_steps() -> List[str]:
        return ['image']

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path,
                      doc_elements=[])
        if self._file_ds is None:
            raise RuntimeError('File datastore is not specified in VlmSlidesParser')
        self._file_ds.connect()
        self._file_ds.download_files([file_path], save_dir=KBX.config.cache_dir)
        file_name = os.path.basename(file_path)
        if not file_name.endswith('.pdf'):
            os.system(
                f'libreoffice --headless --convert-to pdf:writer_pdf_Export '
                f'--outdir {KBX.config.cache_dir} {os.path.join(KBX.config.cache_dir, file_name)}')
            file_name = os.path.splitext(file_name)[0] + '.pdf'

        pdf_path = os.path.join(KBX.config.cache_dir, file_name)
        images = convert_from_path(pdf_path)

        for index, image in enumerate(images):
            data_file_path = self._save_extra_file(image, doc_id, save_name=f'page_{index}')

            doc_ele = DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.FIGURE,
                data_file_path=data_file_path,
                meta_data={'file_type': 'slides'})
            doc.doc_elements.append(doc_ele)

        self._file_ds.close()
        return doc
