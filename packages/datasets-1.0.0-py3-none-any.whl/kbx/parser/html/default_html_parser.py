import os
import requests
from PIL import Image
from io import BytesIO
from typing import List, Optional, cast, Final
from bs4 import BeautifulSoup, NavigableString, PageElement, Tag
from bs4.element import PreformattedString

from kbx.datastore.file.file_base import BaseFileDS
from kbx.parser.types import DocParseConfig
from kbx.common.types import DocData, DocElement, DocElementType
from kbx.common.utils import generate_new_id
from kbx.parser.base_parser import BaseParser
from kbx.common.types import DocData, DocElement, DocElementType, Table
from kbx.parser.html.utils import is_online_path


TAGS_FOR_NODE_ITEMS: Final = [
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "p",
    "pre",
    "code",
    "ul",
    "ol",
    "li",
    "table",
    "figure",
    "img",
]


class DefaultHTMLParser(BaseParser):
    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None):
        super().__init__(config, file_ds)

        self._config = config
        self._file_ds = file_ds
        self._call_by_VLM_parser = False

    @staticmethod
    def file_extensions() -> List[str]:
        return ['.html']

    def _parse(self, file_path: str, doc_id: str = None):
        self.validate_file(file_path)
        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)

        with self.open(file_path, 'r') as f:
            content = f.read()
        doc = self._parse_html(content, doc)
        return doc

    def _parse_from_str(self, content: str, doc):
        doc = self._parse_html(content, doc)
        return doc

    def _parse_html(self, text_stream: str, doc: DocData) -> list[tuple[Optional[str], str]]:
        """Parse html file into tuples."""

        soup = BeautifulSoup(text_stream, 'html.parser')
        content = soup.body
        if content is None:
            return doc

        for br in content("br"):
            br.replace_with(NavigableString("\n"))

        self.walk(content, doc)
        return doc

    def walk(self, tag: Tag, doc: DocData) -> None:
        text: str = ""
        for element in tag.children:
            if isinstance(element, Tag):
                self.analyze_tag(cast(Tag, element), doc)

            elif isinstance(element, NavigableString) and not isinstance(element, PreformattedString):
                # Floating text outside paragraphs or analyzed tags
                text += element
                siblings: list[Tag] = [item for item in element.next_siblings if isinstance(item, Tag)]
                if element.next_sibling is None or any(item.name in TAGS_FOR_NODE_ITEMS for item in siblings):
                    text = text.strip()

                    if text and tag.name in ["div"]:
                        doc_elem = DocElement(
                            doc_element_id=generate_new_id(),
                            type=DocElementType.TEXT,
                            text=text)
                        doc.doc_elements.append(doc_elem)
        return

    def analyze_tag(self, tag: Tag, doc: DocData) -> None:
        if tag.name in ["h1", "h2", "h3", "h4", "h5", "h6"]:
            self.handle_header(tag, doc)
        elif tag.name in ["p"]:
            self.handle_paragraph(tag, doc)
        elif tag.name in ["pre", "code"]:
            self.handle_code(tag, doc)
        elif tag.name in ["ul", "ol"]:
            self.handle_list(tag, doc)
        elif tag.name in ["li"]:
            self.handle_list_item(tag, doc)
        elif tag.name == "table":
            self.handle_table(tag, doc)
        elif tag.name == "figure":
            self.handle_figure(tag, doc)
        elif tag.name == "img":
            self.handle_image(tag, doc)
        else:
            self.walk(tag, doc)

    def get_text(self, item: PageElement) -> str:
        """Get the text content of a tag."""
        parts: list[str] = self.extract_text_recursively(item)

        return "".join(parts) + " "

    # Function to recursively extract text from all child nodes
    def extract_text_recursively(self, item: PageElement) -> list[str]:
        result: list[str] = []

        if isinstance(item, NavigableString):
            return [item]

        tag = cast(Tag, item)
        if tag.name not in ["ul", "ol"]:
            for child in tag:
                # Recursively get the child's text content
                result.extend(self.extract_text_recursively(child))

        return ["".join(result) + " "]

    def handle_header(self, element: Tag, doc: DocData) -> None:
        """Handles header tags (h1, h2, etc.)."""
        hlevel = int(element.name.replace("h", ""))
        text = element.text.strip()

        meta_data = {'title_level': hlevel}
        doc_elem = DocElement(
            doc_element_id=generate_new_id(),
            type=DocElementType.TITLE,
            text=text,
            meta_data=meta_data)
        doc.doc_elements.append(doc_elem)
        return doc_elem

    def handle_paragraph(self, element: Tag, doc: DocData) -> None:
        """Handles paragraph tags (p)."""
        if element.text is None:
            return
        text = element.text.strip()
        doc_elem = DocElement(
            doc_element_id=generate_new_id(),
            type=DocElementType.TEXT,
            text=text)
        doc.doc_elements.append(doc_elem)
        return doc_elem

    def handle_list(self, element: Tag, doc: DocData) -> None:
        """Handles list tags (ul, ol) and their list items."""
        self.walk(element, doc)

    def handle_list_item(self, element: Tag, doc: DocData) -> None:
        """Handles list item tags (li)."""
        nested_list = element.find(["ul", "ol"])

        if nested_list:
            # Text in list item can be hidden within hierarchy, hence
            # we need to extract it recursively
            text: str = self.get_text(element)
            # Flatten text, remove break lines:
            text = text.replace("\n", "").replace("\r", "")
            text = " ".join(text.split()).strip()

            if len(text) > 0:
                # create a list-item
                doc_elem = DocElement(
                    doc_element_id=generate_new_id(),
                    type=DocElementType.TEXT,
                    text=text)
                doc.doc_elements.append(doc_elem)
            else:
                self.walk(element, doc)

        elif element.text.strip():
            text = element.text.strip()
            doc_elem = DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.TEXT,
                text=text)
            doc.doc_elements.append(doc_elem)

    def handle_table(self, element: Tag, doc: DocData) -> None:
        """Handles table tags."""
        # nested_tables = element.find("table")
        # if nested_tables is not None:
        #     logger.warning("Skipping nested table.")
        #     return None
        meta_data = {}
        if 'data-bbox' in element.attrs:
            bbox = element.attrs['data-bbox']
            bbox = bbox.split(' ')
            bbox = [int(b) for b in bbox]
            meta_data = {'bbox': bbox}

        caption = element.find('caption')
        if caption is not None:
            caption = caption.get_text(strip=True)
        else:
            caption = ''

        doc_elem = DocElement(
            doc_element_id=generate_new_id(),
            type=DocElementType.TABLE,
            table=Table.from_html(element.decode(), caption=caption),
            meta_data=meta_data)
        doc.doc_elements.append(doc_elem)

    def handle_code(self, element: Tag, doc: DocData) -> None:
        """Handles monospace code snippets (pre)."""
        if element.text is None:
            return

        text = element.text.strip()
        if text:
            doc_elem = DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.CODE_BLOCK,
                text=text)
            doc.doc_elements.append(doc_elem)

    def handle_image(self, element: Tag, doc: DocData) -> None:
        """Handles image tags (img)."""

        if isinstance(element, Tag) and 'src' in element.attrs:
            src = element.attrs['src']
            image = self.read_img(src)

            if image is None:
                return

            data_file_path = self._save_extra_file(image, doc.doc_id)
            doc_elem = DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.FIGURE,
                image_caption='',
                data_file_path=data_file_path)
            doc.doc_elements.append(doc_elem)

        elif isinstance(element, Tag) and 'data-bbox' in element.attrs and self._call_by_VLM_parser:
            bbox = element.attrs['data-bbox']
            bbox = bbox.split(' ')
            bbox = [int(b) for b in bbox]
            meta_data = {'bbox': bbox}

            doc_elem = DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.FIGURE,
                image_caption='',
                meta_data=meta_data)
            doc.doc_elements.append(doc_elem)

        else:
            return

    def handle_figure(self, element: Tag, doc: DocData) -> None:
        """Handles image tags (img)."""

        contains_captions = element.find(["figcaption"])
        if isinstance(contains_captions, Tag):
            texts = []
            for item in contains_captions:
                texts.append(item.text)
            texts = ("".join(texts)).strip()
        else:
            texts = ''

        img = element.find(["img"])
        if isinstance(img, Tag) and 'src' in img.attrs:
            src = img.attrs['src']
            image = self.read_img(src)

            if image is None:
                return

            data_file_path = self._save_extra_file(image, doc.doc_id)
            doc_elem = DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.FIGURE,
                image_caption=texts,
                data_file_path=data_file_path)
            doc.doc_elements.append(doc_elem)
        return

    def read_img(self, src):
        if is_online_path(src):
            if not self._config.save_external_data:
                return None
            try:
                response = requests.get(src)
                response.raise_for_status()  # 如果请求失败，将抛出异常
                image = Image.open(BytesIO(response.content))
            except IOError:
                image = None
        else:
            if os.path.exists(src):
                image = Image.open(src)
            else:
                image = None
        return image
