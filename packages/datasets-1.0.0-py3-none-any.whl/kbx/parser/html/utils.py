from typing import List, Tuple, Optional
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import html


def is_online_path(path_str):
    parsed = urlparse(path_str)
    if parsed.scheme in ('http', 'https') and parsed.netloc:
        return True
    else:
        return False


def table_2d_list_to_html(
    data: List[List[str]],
    has_header: Optional[bool] = None,
    caption: Optional[str] = None
) -> str:
    """将标准二维List格式表格转换为html格式

    Args:
        data (List[List[str]]): 二维List格式数据
        has_header (Optional[bool], optional): 是否有表头. None表示未知. Defaults to None.
        caption (Optional[str], optional): 表注. Defaults to None.

    Returns:
        str: html格式表格数据
    """
    html_str = "<table>"

    # 添加表注
    if caption:
        html_str += f"<caption>{html.escape(caption)}</caption>"

    # 根据has_header参数决定是否将第一行作为表头
    if data and len(data) > 0:
        if has_header:  # 明确指定有表头
            # 如果有表头，第一行作为表头
            html_str += "<thead><tr>"
            for cell in data[0]:
                cell = cell.replace('\n', '<br>')
                html_str += f"<th>{html.escape(cell)}</th>"
            html_str += "</tr></thead>"
            data = data[1:]

        # 处理数据行
        html_str += "<tbody>"
        for row in data:
            html_str += "<tr>"
            for cell in row:
                cell = cell.replace('\n', '<br>')
                html_str += f"<td>{html.escape(cell)}</td>"
            html_str += "</tr>"
        html_str += "</tbody>"

    html_str += "</table>"
    return html_str


def parse_html_table(html: str) -> Tuple[str, bool, List[List[str]]]:
    """解析一个html表格，返回表格的表注、是否有表头和表数据

    注意，如果输入的html存在语法错误或是非法表格，会抛出ValueError异常

    Args:
        html (str): html格式数据

    Returns:
        Tuple[str, bool, List[List[str]]]: 表注、是否有表头、表数据
    """
    soup = BeautifulSoup(html, 'html.parser')
    table = soup.find('table')
    if not table:
        raise ValueError(f"No table found in html data:\n{html}")

    # 提取表注
    caption = ""
    caption_tag = table.find('caption')
    if caption_tag:
        caption = caption_tag.get_text(strip=True)

    # 提取表头和数据
    data_2d = []
    has_header = False

    # 检查是否有thead标签
    thead = table.find('thead')
    if thead:
        has_header = True
        header_row = thead.find('tr')
        if header_row:
            header_cells = header_row.find_all(['th', 'td'])
            header = [cell.get_text(strip=True) for cell in header_cells]
            data_2d.append(header)

    # 提取数据行
    tbody = table.find('tbody')
    if tbody:
        rows = tbody.find_all('tr')
    else:
        # 如果没有tbody，则直接从table中获取所有tr
        rows = table.find_all('tr')
        # 如果第一行是表头且没有thead标签，则跳过第一行
        if has_header and len(rows) > 0:
            rows = rows[1:]

    for row in rows:
        cells = row.find_all(['td', 'th'])
        row_data = [cell.get_text(strip=True) for cell in cells]
        data_2d.append(row_data)

    # 如果没有明确的表头标记，但第一行是th元素，则认为有表头
    if not has_header and len(data_2d) > 0:
        first_row = data_2d[0]
        if all(cell.startswith('<th') for cell in first_row):
            has_header = True

    return caption, has_header, data_2d
