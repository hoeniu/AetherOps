from functools import lru_cache
import os
import re
from typing import List
from xml.etree import ElementTree
from lxml import etree

from docx import Document

from kbx.common.logging import logger
from kbx.common.types import DocData, DocElement, DocElementType, Table
from kbx.common.utils import generate_new_id
from kbx.datastore.file.file_base import BaseFileDS
from kbx.parser.base_parser import BaseParser
from kbx.parser.types import DocParseConfig
from kbx.parser.utils import download_image_as_bytes, postprocess_table_data


class DefaultDocxParser(BaseParser):
    """
    DOCX文档默认解析器，继承自BaseParser，用于解析Microsoft Word (.docx)文件。

    该解析器是DOCX文档解析的默认实现，不依赖OCR/Layout模型或其他外部大模型，完全基于本地解析。

    支持解析docx文档中的以下内容：

    - 文本内容（包括标题、正文等）
    - 表格内容（自动处理合并单元格）
    - 嵌入图片（保存为本地文件）
    - 外部图片（可选下载并保存为本地文件）
    - 超链接（转换为Markdown格式）

    标题识别方式：
    - 基于样式识别：使用"Heading X"样式的段落
    - 基于大纲级别识别：检测paragraphs的outline_level属性，支持将有大纲级别但不是标题样式的段落识别为标题

    不支持的功能：

    - 文档中的复杂样式（如文本框、艺术字等）
    - 文档中的批注和修订内容
    - 文档中的公式和图表
    """
    NSMAP = {
        'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
        'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
        'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
        'w14': 'http://schemas.microsoft.com/office/word/2010/wordml'
    }

    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None) -> None:
        super().__init__(config, file_ds)
        self._pattern_dict = {
            'table': re.compile(r'^([表表Chart]|表格|Table|tbl|Tab|表)\s*[\d\u2160-\u2188]*\s*[\.:，。]?(.*)$',
                                re.UNICODE),
            'image': re.compile(r'^(图|Figure|Fig|Fig\.|图片|Image|Img|Figura)\s*[\d\u2160-\u2188]*\s*[\.:，。]?(.*)$',
                                re.UNICODE)
        }
        # 缓存常用正则表达式
        self._regex_cache = {
            # 处理数字之间的空格
            'number_space': re.compile(r'(\d)\s+(\d)'),

            # 处理字母和中文之间的空格
            'alnum_chinese': re.compile(r'([a-zA-Z0-9]+)\s+([\u4e00-\u9fff])'),
            'chinese_alnum': re.compile(r'([\u4e00-\u9fff])\s+([a-zA-Z0-9]+)'),

            # 处理中文之间的空格
            'chinese_space': re.compile(r'([\u4e00-\u9fff])\s+([\u4e00-\u9fff])'),

            # 处理数字与单位符号之间的空格
            'number_unit': re.compile(r'(\d)\s+([°%‰′″℃℉])'),

            # 处理小数点数字中的空格
            'decimal_number': re.compile(r'(\d)\s*\.\s*(\d)'),

            # 处理千分位数字中的空格
            'thousand_separator': re.compile(r'(\d)\s+(\d{3}\b)'),

            # 处理英文缩写中的空格
            'abbreviation': re.compile(r'([A-Z])\s*\.\s*([A-Z])\s*\.'),

            # 处理特殊符号周围空格
            'special_symbol': re.compile(r'([\u4e00-\u9fff])\s*([+×÷=≠≈<>])\s*([\u4e00-\u9fff0-9])'),

            # 处理连续多个空格
            'multi_space': re.compile(r'\s{2,}'),

            # 处理开头结尾空格
            'trim_space': re.compile(r'^\s+|\s+$'),

            # 处理特定场景的连续字母数字
            'special_alnum': re.compile(r'([a-zA-Z0-9]+)\s+([a-zA-Z0-9]+)(?=[\u4e00-\u9fff])')
        }

    @staticmethod
    def file_extensions() -> List[str]:
        return ['.docx']

    @staticmethod
    def postprocess_steps() -> List[str]:
        return ['image']

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)

        self._parse_docx(file_path, doc)

        return doc

    def _parse_docx(self, file_path: str, doc_data: DocData) -> None:
        """
            解析docx文件并将其内容转换为DocElement列表。
        """
        # TODO: 如果遇到超大的docx文件，考虑使用docx.parts.story.StoryPart的流式处理处理
        with self.open(file_path, 'rb', encoding=None) as f:
            doc = Document(f)

        image_elems = self._extract_images_from_docx(doc, doc_data.doc_id)
        self._extract_hyperlinks(doc)

        self._paragraphs = doc.paragraphs
        self._tables = doc.tables
        self._para_index, self._table_index = 0, 0

        self._caption = None
        self._caption_dict = {'table': set(), 'image': set()}

        # 创建一个集合来跟踪已处理的图片ID
        processed_image_ids = set()

        for element in doc.element.body:
            if hasattr(element, "tag"):
                tag = etree.QName(element.tag).localname
                if tag == "p":
                    para = self._paragraphs[self._para_index]
                    self._para_index += 1

                    # 处理图片(图片在element中的tag跟普通段落一样)
                    if "w:drawing" in element.xml:
                        elem, image_id = self._process_image_element(element, image_elems)
                        if elem:
                            doc_data.doc_elements.append(elem)
                            if image_id:
                                processed_image_ids.add(image_id)
                    # 处理段落
                    else:
                        elem = self._process_paragraph_element(para, doc)
                        if elem:
                            doc_data.doc_elements.append(elem)
                # 处理表格
                elif tag == "tbl":
                    table = self._tables[self._table_index]
                    self._table_index += 1
                    try:
                        elem = self._process_table_element(table)
                        if elem:
                            doc_data.doc_elements.append(elem)
                    except ValueError as e:
                        import traceback
                        logger.error(f"Error parsing table in {file_path}:\n {traceback.format_exc()}\n {e}")
                        continue

        # 处理剩余的图片
        for image_id, elem in image_elems.items():
            if image_id not in processed_image_ids:
                doc_data.doc_elements.append(elem)

    def _process_image_element(self, element, image_elems):
        blip = element.xpath(".//a:blip")
        if not blip:
            return None, None
        image_id = blip[0].get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed")

        if image_id not in image_elems:
            return None, None

        # 获取图片元素
        image_elem = image_elems[image_id]

        # 创建图片元素的深拷贝
        from copy import deepcopy
        image_elem_copy = deepcopy(image_elem)

        # 为复制的元素分配新的唯一ID
        image_elem_copy.doc_element_id = generate_new_id()

        # 处理图注
        next_para = self._paragraphs[self._para_index] if self._para_index < len(self._paragraphs) else None
        self._caption, image_caption = self._handle_caption(self._caption, next_para, 'image')
        image_elem_copy.image_caption = image_caption

        return image_elem_copy, image_id

    def _get_paragraph_outline_level(self, para):
        """获取段落的大纲级别(outline level)

        Word文档中的段落可以有大纲级别(outline level)属性，但不一定是使用Heading样式。
        本方法通过多种策略尝试获取段落的大纲级别：
        1. 从段落样式(para.style)中获取outline_level属性
        2. 从段落元素(para._element.pPr)中直接获取
        3. 使用lxml解析XML获取

        各种方法按顺序尝试，一旦成功获取就返回结果。所有方法都失败则返回None。

        Args:
            para: 段落对象

        Returns:
            int: 大纲级别(整数，从0开始)，如果没有大纲级别则返回None
        """
        # 方法0: 尝试通过段落样式获取outline level
        try:
            if hasattr(para, 'style') and hasattr(para.style, 'element') and para.style.element is not None:
                style_element = para.style.element
                if hasattr(style_element, 'pPr') and style_element.pPr is not None:
                    for child in style_element.pPr.getchildren():
                        if child.tag.endswith('outlineLvl'):
                            val = child.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                            if val is not None:
                                try:
                                    return int(val)
                                except ValueError:
                                    pass
        except Exception as e:
            logger.debug(f"通过para.style获取outline_level时出错: {str(e)}")

        if not hasattr(para, '_element') or not hasattr(para._element, 'pPr') or para._element.pPr is None:
            return None

        # 方法1: 直接通过python-docx API查找outline_level属性
        try:
            pPr = para._element.pPr

            # 查找方式1: 使用getchildren()
            if hasattr(pPr, 'getchildren'):
                for child in pPr.getchildren():
                    if child.tag.endswith('outlineLvl'):
                        val = child.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                        if val is not None:
                            try:
                                return int(val)
                            except ValueError:
                                pass

            # 查找方式2: 直接通过tag名查找（部分版本的API可能支持）
            if hasattr(pPr, 'outlineLvl') and pPr.outlineLvl is not None:
                val = pPr.outlineLvl.val
                if val is not None:
                    try:
                        return int(val)
                    except ValueError:
                        pass
        except Exception as e:
            logger.debug(f"通过python-docx API获取outline_level时出错: {str(e)}")

        # 方法2: 尝试使用lxml转换后获取
        try:
            if hasattr(para._element, 'xml'):
                xml_str = para._element.xml
                root = etree.fromstring(xml_str)
                outline_elements = root.xpath(".//w:outlineLvl", namespaces=self.NSMAP)
                if outline_elements and len(outline_elements) > 0:
                    val = outline_elements[0].get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val")
                    if val is not None:
                        try:
                            return int(val)
                        except ValueError:
                            pass
        except Exception as e:
            logger.debug(f"通过lxml获取outline_level时出错: {str(e)}")

        return None

    def _process_paragraph_element(self, para, doc):
        parsed_paragraph = self._parse_paragraph(doc, para)
        if parsed_paragraph:
            style = para.style.name if hasattr(para.style, 'name') else ""
            if style == "Caption":
                self._caption = para.text
                return None

            doc_element_type = DocElementType.TEXT
            meta_data = {}

            # 通过样式识别标题
            if style.startswith("Heading"):
                doc_element_type = DocElementType.TITLE
                meta_data = {"title_level": int(style.split(" ")[-1])}
            # 通过outline_level识别标题
            else:
                outline_level = self._get_paragraph_outline_level(para)
                if outline_level is not None:
                    doc_element_type = DocElementType.TITLE
                    meta_data = {"title_level": outline_level + 1}  # 为保持与Heading样式一致，level+1
                    logger.debug(f"检测到outline_level={outline_level}的标题: {parsed_paragraph}")

            doc_elem = DocElement(doc_element_id=generate_new_id(),
                                  type=doc_element_type,
                                  text=parsed_paragraph,
                                  meta_data=meta_data)
            return doc_elem

        return None

    def _process_table_element(self, table):
        parsed_table = self._parse_table(table)
        table_caption = None
        next_para = self._paragraphs[self._para_index] if self._para_index < len(self._paragraphs) else None
        self._caption, table_caption = self._handle_caption(self._caption, next_para, 'table')

        table_data = postprocess_table_data(parsed_table)
        if table_data is None or len(table_data) == 0:
            return None
        table_elem = DocElement(
            doc_element_id=generate_new_id(),
            type=DocElementType.TABLE,
            table=Table.from_2d_list(table_data, has_header=None, caption=table_caption),
            meta_data={'file_type': 'docx'}
        )

        return table_elem

    def _handle_caption(self, caption, next_para, caption_type):
        pattern = self._pattern_dict[caption_type]
        new_caption = None

        # caption在前面的情况
        if caption and caption not in self._caption_dict["image"] and caption not in self._caption_dict["table"]:
            match = pattern.match(caption)
            if match:
                self._caption_dict[caption_type].add(caption)
                new_caption = caption
                caption = None
        # caption在后面的情况
        else:
            if next_para is not None and next_para.style.name == "Caption":
                match = pattern.match(next_para.text)
                if match:
                    self._caption_dict[caption_type].add(next_para.text)
                    new_caption = next_para.text
        return caption, new_caption

    def _extract_hyperlinks(self, doc: Document) -> None:
        """提取文档中的超链接"""
        hyperlinks_url = None
        url_pattern = re.compile(r"https?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+")
        for para in doc.paragraphs:
            for run in para.runs:
                if run.text and hyperlinks_url:
                    result = f"  [{run.text}]({hyperlinks_url})  "
                    run.text = result
                    hyperlinks_url = None
                if "HYPERLINK" in run.element.xml:
                    try:
                        xml = ElementTree.XML(run.element.xml)
                        x_child = [c for c in xml.iter() if c is not None]
                        for x in x_child:
                            if x.tag.endswith("instrText"):
                                for i in url_pattern.findall(x.text):
                                    hyperlinks_url = str(i)
                    except Exception as e:
                        raise RuntimeError("Failed to parse HYPERLINK xml") from e

    def _extract_images_from_docx(self, doc, doc_id):
        """
        Extract images from a docx file, supporting both embedded and external images.
        """
        self._image_map = {}
        image_elems = {}

        for key, rel in doc.part.rels.items():
            # Check if the relationship contains an image
            if "image" in rel.target_ref:
                try:
                    if rel.is_external:     # Case 1: External images
                        if self._config.save_external_data:
                            bytes_data = download_image_as_bytes(rel._target)
                            if bytes_data:
                                file_path = self._save_extra_file(bytes_data, doc_id)
                                if file_path:
                                    doc_elem = DocElement(doc_element_id=generate_new_id(),
                                                          type=DocElementType.FIGURE,
                                                          data_file_path=file_path)
                            image_elems[key] = doc_elem
                        else:
                            logger.debug("Skipping external image because save_external_data is disabled.")
                            continue
                    else:   # Case 2: Embedded images
                        bytes_data = rel.target_part.blob
                        if bytes_data:
                            file_path = self._save_extra_file(bytes_data, doc_id)
                            if file_path:
                                doc_elem = DocElement(doc_element_id=generate_new_id(),
                                                      type=DocElementType.FIGURE,
                                                      data_file_path=file_path)
                        image_elems[key] = doc_elem

                    # Update the image map with Markdown-style placeholders
                    self._image_map[rel.target_part] = f"![image]({doc_id}/{doc_elem.doc_element_id})"
                except Exception as e:
                    logger.error(f"Error processing image {rel.target_ref}: {e}")
                    continue  # Skip problematic images
        return image_elems

    def _parse_paragraph(self, doc, paragraph) -> str:
        """解析段落中的文字内容"""
        paragraph_content = []
        for run in paragraph.runs:
            # 处理勾选框
            checkbox_state = self._detect_checkbox_state(run)
            if checkbox_state is not None:
                paragraph_content.append("[✓]" if checkbox_state else "[□]")
                continue
            # 处理图片
            if hasattr(run.element, "tag") and isinstance(run.element.tag, str) and run.element.tag.endswith("r"):
                drawing_elements = run.element.findall(
                    ".//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}drawing"
                )
                for drawing in drawing_elements:
                    blip_elements = drawing.findall(
                        ".//{http://schemas.openxmlformats.org/drawingml/2006/main}blip"
                    )
                    for blip in blip_elements:
                        embed_id = blip.get(
                            "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed"
                        )
                        if embed_id:
                            image_part = doc.part.related_parts.get(embed_id)
                            if image_part in self._image_map:
                                paragraph_content.append(self._image_map[image_part])

            # 处理文本
            if run.text.strip():
                paragraph_content.append(run.text.strip())

        text = " ".join(paragraph_content) if paragraph_content else ""
        return self._process_spacing(text.strip())

    def _parse_table(self, table) -> List[List[str]]:
        # 逐一处理表格中的单元格
        return [self._parse_row(row) for row in table.rows]

    def _parse_row(self, row) -> List[str]:
        # python-docx在处理表格时，能够自动处理合并单元格，包括合并行和合并列
        return [self._parse_cell(cell) for cell in row.cells]

    def _parse_cell(self, cell) -> str:
        return self._parse_cell_element(cell._element)

    def _parse_cell_element(self, tc_element) -> str:
        """直接通过XML解析单元格"""
        cell_content = []
        for child in tc_element.iterchildren():
            if child.tag.endswith('p'):
                para = self._parse_cell_paragraph_by_xml(child)
                if para:
                    cell_content.append(para)
            elif child.tag.endswith('tbl'):
                nested_table = self._parse_table_by_xml(child)
                cell_content.append(f"\n[嵌套表格开始]\n{self._format_table(nested_table)}\n[嵌套表格结束]\n")
        return '\n'.join(cell_content)

    def _parse_cell_paragraph_by_xml(self, p_element) -> str:
        """直接通过XML解析段落"""
        para_content = []
        xml_element = self._convert_to_lxml(p_element)

        for run in xml_element.xpath(".//w:r", namespaces=self.NSMAP):
            # 处理勾选框
            checkbox_state = self._detect_checkbox_state(run)
            if checkbox_state is not None:
                para_content.append("[✓]" if checkbox_state else "[□]")
                continue

            # 处理普通文本
            text_elem = run.find(".//w:t", namespaces=self.NSMAP)
            if text_elem is not None and text_elem.text:
                text = text_elem.text.strip()
                if text:
                    para_content.append(text)

        # 处理图片
        for drawing in xml_element.xpath(".//w:drawing", namespaces=self.NSMAP):
            blip = drawing.find(".//a:blip", namespaces=self.NSMAP)
            if blip is not None:
                embed_id = blip.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed")
                if embed_id:
                    para_content.append(self._image_map.get(embed_id, ""))

        return self._process_spacing(' '.join(para_content))

    def _parse_table_by_xml(self, tbl_element) -> List[List[str]]:
        """直接通过XML解析表格"""
        xml_element = self._convert_to_lxml(tbl_element)
        return [
            [self._parse_cell_element(cell) for cell in row.xpath(".//w:tc", namespaces=self.NSMAP)]
            for row in xml_element.xpath(".//w:tr", namespaces=self.NSMAP)
        ]

    @lru_cache(maxsize=128)
    def _process_spacing(self, text) -> str:
        """统一空格处理方法：处理各种场景下的多余空格"""
        # 去除开头结尾空格
        text = self._regex_cache['trim_space'].sub('', text)

        # 处理连续多个空格
        text = self._regex_cache['multi_space'].sub(' ', text)

        # 处理数字之间的空格（优先处理）
        text = self._regex_cache['number_space'].sub(r'\1\2', text)

        # 处理特定场景的连续字母数字（如LrM o融合）
        text = self._regex_cache['special_alnum'].sub(r'\1\2', text)

        # 处理字母/数字和中文之间的空格
        text = self._regex_cache['alnum_chinese'].sub(r'\1\2', text)
        text = self._regex_cache['chinese_alnum'].sub(r'\1\2', text)

        # 处理中文之间的空格
        text = self._regex_cache['chinese_space'].sub(r'\1\2', text)

        # 处理数字与单位符号之间的空格
        text = self._regex_cache['number_unit'].sub(r'\1\2', text)

        # 处理小数点数字中的空格
        text = self._regex_cache['decimal_number'].sub(r'\1.\2', text)

        # 处理千分位数字中的空格
        text = self._regex_cache['thousand_separator'].sub(r'\1\2', text)

        # 处理英文缩写中的空格
        text = self._regex_cache['abbreviation'].sub(r'\1.\2.', text)

        # 处理特殊符号周围空格
        text = self._regex_cache['special_symbol'].sub(r'\1\2\3', text)

        return text

    def _format_table(self, table_data) -> str:
        """ 辅助格式化表格结构 """
        return '\n'.join(["|" + "|".join(row) + "|" for row in table_data])

    def _parse_cell_paragraph(self, paragraph) -> str:
        paragraph_content = []
        for run in paragraph.runs:
            if run.element.xpath(".//a:blip"):
                for blip in run.element.xpath(".//a:blip"):
                    image_id = blip.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed")
                    if not image_id:
                        continue
                    image_part = paragraph.part.rels[image_id].target_part

                    if image_part in self._image_map:
                        image_link = self._image_map[image_part]
                        paragraph_content.append(image_link)
            else:
                text = run.text.strip()
                if text:
                    paragraph_content.append(text)

        text = " ".join(paragraph_content).strip()
        return self._process_spacing(text.strip())

    def _detect_checkbox_state(self, run):
        """检测勾选框并返回状态"""
        try:
            # 统一处理不同节点类型
            xml = self._convert_to_lxml(run.element) if hasattr(run, 'element') else run

            for sdt in xml.xpath(".//self::w:sdt | ancestor::w:sdt", namespaces=self.NSMAP):
                checkbox = sdt.find(".//w14:checkbox", namespaces=self.NSMAP)
                if checkbox is not None:
                    checked = checkbox.find(".//w14:checked", namespaces=self.NSMAP)
                    if checked is not None:
                        val = checked.get("{http://schemas.microsoft.com/office/word/2010/wordml}val", "0")
                        return val.lower() in ["1", "on", "true"]  # 支持多种真值表示

            # 检测旧式勾选框（Word 2007）
            for check in xml.xpath(".//w:checkBox", namespaces=self.NSMAP):
                checked = check.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}checked")
                if checked is not None:
                    return checked.lower() in ["1", "true", "yes"]

            return None
        except Exception as e:
            logger.debug(f"Checkbox detection error: {str(e)}", exc_info=True)
            return None

    def _convert_to_lxml(self, element):
        """将ElementTree元素转换为lxml元素"""
        return etree.fromstring(etree.tostring(element))
