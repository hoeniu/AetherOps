import json
import os
import re
from typing import List

if 'MINERU_TOOLS_CONFIG_JSON' not in os.environ:
    os.environ['MINERU_TOOLS_CONFIG_JSON'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'magic-pdf.json')
import fitz
from magic_pdf.model.doc_analyze_by_custom_model import doc_analyze
from magic_pdf.data.dataset import PymuDocDataset
from magic_pdf.dict2md.ocr_mkcontent import get_title_level, merge_para_with_text
from magic_pdf.config.enums import SupportedPdfParseMethod
from PIL import Image

from kbx.datastore.file.file_base import BaseFileDS
from kbx.parser.types import DocParseConfig
from kbx.parser.base_parser import BaseParser
from kbx.common.types import DocData, DocElement, DocElementType, Table
from kbx.common.utils import generate_new_id


class MinerUPdfParser(BaseParser):
    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None):
        super().__init__(config, file_ds)

        if config is None or config.pdf_ocr_strategy is None:
            raise RuntimeError(f'Must provide "pdf_ocr_strategy" in DocParseConfig to use MinerUPdfParser. '
                               f'Given DocParseConfig: {config}')
        parser_type = config.pdf_ocr_strategy.parser_type
        assert parser_type == 'MinerU', f'"parser_type" must be [MinerU] for MinerUPdfParser. ' \
                                        f'Given DocParseConfig: {config}'

        with open(os.getenv('MINERU_TOOLS_CONFIG_JSON'), 'r', encoding='utf-8') as f:
            config = json.load(f)

        # 检查并转换models-dir和layoutreader-model-dir为绝对路径
        need_update = False
        if 'models-dir' in config and not os.path.isabs(config['models-dir']):
            config['models-dir'] = os.path.abspath(os.path.expanduser(config['models-dir']))
            need_update = True

        if 'layoutreader-model-dir' in config and not os.path.isabs(config['layoutreader-model-dir']):
            config['layoutreader-model-dir'] = os.path.abspath(os.path.expanduser(config['layoutreader-model-dir']))
            need_update = True

        # 检测CUDA是否可用，可用时使用CUDA，默认使用CPU
        import torch
        device = "cuda" if torch.cuda.is_available() else "cpu"
        # 如果使用GPU，则更新配置文件，因为magic-pdf内部是通过配置文件中的device-mode来选择使用的device
        if device == "cuda":
            config['device-mode'] = 'cuda'
            need_update = True

        if need_update:
            with open(os.getenv('MINERU_TOOLS_CONFIG_JSON'), 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=4)

    @staticmethod
    def file_extensions() -> List[str]:
        return ['.pdf']

    def _parse(self, file_path: str, doc_id: str = None) -> DocData:
        self.validate_file(file_path)

        with self.open(file_path, 'rb') as f:
            pdf_bytes = f.read()

        # 创建dataset，存储pdf的元数据
        dataset = PymuDocDataset(pdf_bytes)

        # imageWriter=None 表示不将检测出来的图、表保存成单独的图片
        # 如果需要保存，可以传入imageWriter=FileBasedDataWriter('./')
        # 例如：
        # from magic_pdf.data.data_reader_writer import FileBasedDataWriter
        # imageWriter = FileBasedDataWriter('./')
        imageWriter = None

        # 根据pdf的元数据，判断是文本pdf，还是ocr pdf，然后选择相应的处理方式
        if dataset.classify() == SupportedPdfParseMethod.OCR:
            # 解析pdf数据（可能进行版面识别、公式检测和识别、OCR、表格识别等流程，具体看magic-pdf.json文件的配置）
            infer_result = dataset.apply(doc_analyze, ocr=True)

            # 对解析结果进行后处理
            pipe_result = infer_result.pipe_ocr_mode(imageWriter)
        else:
            infer_result = dataset.apply(doc_analyze, ocr=False)
            pipe_result = infer_result.pipe_txt_mode(imageWriter)

        # pipe_result提供了可以直接获取md、json、普通文本的接口，但并不符合我们最终的输出格式，所以需要进行转换
        parser_results = pipe_result._pipe_res['pdf_info']

        res = self.format_result(parser_results, dataset, file_path, doc_id)

        # 借助pdf内置目录为标题分配层级信息
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        toc = doc.get_toc()

        if toc:
            current_toc = toc
            for doc_ele in res.doc_elements:
                if doc_ele.type == DocElementType.TITLE:
                    formatter_title = re.sub(r'[^\w\s]', '', doc_ele.text.strip())
                    for index, title_info in enumerate(current_toc):
                        formatter_toc_title = re.sub(r'[^\w\s]', '', title_info[1])
                        if formatter_toc_title.replace(" ", "").lower() in formatter_title.replace(" ", "").lower() \
                                and title_info[2] == doc_ele.meta_data['page'] + 1:
                            doc_ele.meta_data['title_level'] = title_info[0]
                            doc_ele.text = title_info[1]
                            current_toc = current_toc[index + 1:]
                            break
                    if doc_ele.meta_data.get('title_level', '') == '':
                        doc_ele.type = DocElementType.TEXT
        return res

    def format_result(self, parser_results, dataset, file_path: str, doc_id: str):
        doc = DocData()
        doc.doc_id = doc_id
        doc.file_name = os.path.basename(file_path)
        doc.file_path = file_path

        for page_id, parser_result in enumerate(parser_results):

            img_dict = dataset.get_page(page_id).get_image()
            pdf_page = img_dict['img']
            pdf_page = Image.fromarray(pdf_page)
            page_width = img_dict['width']
            page_height = img_dict['height']

            for block_id, para_block in enumerate(parser_result['para_blocks']):

                para_text = ''
                bbox = para_block['bbox']
                para_type = para_block['type']
                page_size = para_block['page_size']

                h_scale = page_width / int(page_size[0])
                v_scale = page_height / int(page_size[1])
                bbox = [int(bbox[0] * h_scale), int(bbox[1] * v_scale),
                        int(bbox[2] * h_scale), int(bbox[3] * v_scale)]

                meta_data = {
                    'page': page_id,
                    'bbox': [bbox[0], bbox[2], bbox[1], bbox[3]]
                }
                img_cropped = pdf_page.crop((bbox[0], bbox[1], bbox[2], bbox[3]))
                # im_path = 'output/img_%02d_%02d_%s.jpg'%(block_id, page_id, para_type)
                # img_cropped.save(im_path)
                # print(page_id, block_id, bbox)
                data_file_path = self._save_extra_file(img_cropped, doc_id)

                if para_type in ['text', 'list', 'index', 'interline_equation']:
                    para_text = merge_para_with_text(para_block)
                    doc_elem = DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.TEXT,
                        text=para_text,
                        meta_data=meta_data)

                elif para_type == 'title':
                    para_text = merge_para_with_text(para_block)
                    title_level = get_title_level(para_block)
                    meta_data['title_level'] = title_level
                    doc_elem = DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.TITLE,
                        text=para_text,
                        meta_data=meta_data)

                elif para_type == 'image':
                    for block in para_block['blocks']:  # 1st.拼image_body
                        if block['type'] == 'image_body':
                            for line in block['lines']:
                                for span in line['spans']:
                                    if span['type'] == 'image':
                                        if span.get('image_path', ''):
                                            para_text += f"\n![]({span['image_path']})  \n"
                    for block in para_block['blocks']:  # 2nd.拼image_caption
                        if block['type'] == 'image_caption':
                            para_text += merge_para_with_text(block) + '  \n'
                    for block in para_block['blocks']:  # 3rd.拼image_footnote
                        if block['type'] == 'image_footnote':
                            para_text += merge_para_with_text(block) + '  \n'

                    doc_elem = DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.FIGURE,
                        image_caption=para_text,
                        meta_data=meta_data,
                        data_file_path=data_file_path)

                elif para_type == 'table':
                    table_caption = ''
                    for block in para_block['blocks']:  # 1st.拼table_caption
                        if block['type'] == 'table_caption':
                            table_caption += merge_para_with_text(block) + '  \n'

                    for block in para_block['blocks']:  # 2nd.拼table_body
                        if block['type'] == 'table_body':
                            for line in block['lines']:
                                for span in line['spans']:
                                    if span['type'] == 'table':
                                        # if processed by table model
                                        if span.get('latex', ''):
                                            para_text += f"\n\n$\n {span['latex']}\n$\n\n"
                                        elif span.get('html', ''):
                                            para_text += f"\n\n{span['html']}\n\n"
                                        elif span.get('image_path', ''):
                                            para_text += f"\n![]({span['image_path']})  \n"

                    table_footnote = ''
                    for block in para_block['blocks']:  # 3rd.拼table_footnote
                        if block['type'] == 'table_footnote':
                            table_footnote += merge_para_with_text(block) + '  \n'

                    doc_elem = DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.TABLE,
                        table=Table.from_html(para_text, caption=table_caption),
                        text=table_footnote,
                        meta_data=meta_data,
                        data_file_path=data_file_path)
                doc.doc_elements.append(doc_elem)

                if para_text.strip() == '':
                    continue
        return doc
