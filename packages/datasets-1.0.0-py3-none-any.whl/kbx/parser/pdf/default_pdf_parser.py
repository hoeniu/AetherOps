import os
from typing import List

import pypdfium2

from kbx.common.utils import generate_new_id
from kbx.common.types import DocData, DocElement
from kbx.parser.base_parser import BaseParser


class DefaultPdfParser(BaseParser):
    """
    PDF文档默认解析器，继承自BaseParser，用于解析PDF文件。

    该解析器是PDF文档解析的默认实现，基于pypdfium2库进行本地解析。

    支持解析PDF文档中的以下内容：

    - 文本内容提取
    - 分页信息保留
    - 基本文档元数据

    不支持的功能：

    - 图片内容提取
    - 表格结构识别
    - 复杂排版保留
    - 加密PDF解析
    """
    @staticmethod
    def file_extensions() -> List[str]:
        return ['.pdf']

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        """Parse pdf data into document objects."""
        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)

        with self.open(file_path, 'rb') as f:
            pdf_reader = pypdfium2.PdfDocument(f, autoclose=True)
            try:
                for page_number, page in enumerate(pdf_reader):
                    text_page = page.get_textpage()
                    content = text_page.get_text_range(force_this=True)
                    text_page.close()
                    page.close()
                    metadata = {"file_type": "pdf", "page": page_number}
                    doc.doc_elements.append(
                        DocElement(doc_element_id=generate_new_id(), text=content, meta_data=metadata))
            finally:
                pdf_reader.close()
        return doc
