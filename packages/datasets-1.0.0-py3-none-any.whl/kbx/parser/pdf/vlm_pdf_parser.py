import os
import base64
from typing import List
from PIL import Image
from io import BytesIO

from kbx.kbx import KBX
from kbx.datastore.file.file_base import BaseFileDS
from kbx.common.prompts.parser import VLM_PDF_to_HTML_prompt, VLM_PDF_to_HTML_prompt_contextual
from kbx.parser.types import DocParseConfig
from kbx.parser.base_parser import BaseParser
from kbx.common.types import DocData, DocElementType
from kbx.parser.pdf.dataset import PymuDocDataset
from kbx.parser.html.default_html_parser import DefaultHTMLParser


class VLMPdfParser(BaseParser):
    """
    PDF文档解析器，继承自BaseParser，用于解析PDF文件。

    该解析器是PDF文档解析的VLM实现，基于多模态大模型库进行在线解析。

    """
    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None):
        super().__init__(config, file_ds)

        self._config = config
        self._file_ds = file_ds
        self.contextual_parse = config.pdf_ocr_strategy.use_consecutive_pages

        self.client_config, self.client = KBX.get_ai_model_config_and_client(
            config.pdf_ocr_strategy.vlm_model,
            user_id=config.user_ctx.user_id
        )
        self.html_parser = DefaultHTMLParser(config, file_ds)
        self.html_parser._call_by_VLM_parser = True

    @staticmethod
    def file_extensions() -> List[str]:
        return ['.pdf']

    def _parse(self, file_path: str, doc_id: str = None):
        with self.open(file_path, 'rb') as f:
            pdf_bytes = f.read()
        dataset = PymuDocDataset(pdf_bytes)

        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)

        if self.contextual_parse and len(dataset) > 1:
            doc = self.parse_contextual_page(dataset, doc)
        else:
            doc = self.parse_per_page(dataset, doc)
        return doc

    def parse_per_page(self, dataset, doc):
        for index in range(len(dataset)):
            page_data = dataset.get_page(index)
            img_dict = page_data.get_image()

            img = img_dict['img']
            img = Image.fromarray(img)

            res = self.call_llm_single(img)
            res = self.extract_html(res)

            self.html_parser._parse_from_str(res, doc)
            self.add_meta_data(doc, img, index, img_dict)
        return doc

    def parse_contextual_page(self, dataset, doc):
        for index in range(len(dataset) - 1):
            page_data = dataset.get_page(index)
            img_dict = page_data.get_image()

            img1 = dataset.get_page(index).get_image()['img']
            img2 = dataset.get_page(index + 1).get_image()['img']
            img1 = Image.fromarray(img1)
            img2 = Image.fromarray(img2)

            res = self.call_llm_contextual(img1, img2)
            res = self.extract_html(res)
            self.html_parser._parse_from_str(res, doc)
            self.add_meta_data(doc, img1, index, img_dict)

        page_data = dataset.get_page(len(dataset) - 1)
        img_dict = page_data.get_image()
        img = page_data.get_image()['img']
        img = Image.fromarray(img)
        res = self.call_llm_single(img)
        res = self.extract_html(res)
        self.html_parser._parse_from_str(res, doc)
        self.add_meta_data(doc, img, len(dataset) - 1, img_dict)
        return doc

    def add_meta_data(self, doc, img, page_id, img_dict):
        for element in doc.doc_elements:
            if 'page' not in element.meta_data.keys():
                # print('\nelement', element)
                element.meta_data.update(
                    dict(page=page_id))

                if element.type == DocElementType.FIGURE and 'bbox' in element.meta_data.keys():
                    bbox = element.meta_data['bbox']
                    img_cropped = img.crop((bbox[0], bbox[1], bbox[2], bbox[3]))
                    data_file_path = self._save_extra_file(img_cropped, doc.doc_id)
                    element.data_file_path = data_file_path

    def image_to_base64(self, img: Image = None, target_format: str = 'JPEG'):
        img_buffer = BytesIO()
        img.save(img_buffer, format=target_format)
        byte_data = img_buffer.getvalue()
        base64_str = base64.b64encode(byte_data).decode('utf-8')
        return base64_str

    def call_llm_single(self, img: Image = None):
        base64_image = self.image_to_base64(img, target_format='webp')

        response = self.client.chat(
            self.client_config,
            messages=[
                {"role": "system", "content": VLM_PDF_to_HTML_prompt},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/jpeg;base64,{base64_image}", }
                        }, ],
                }
            ],
            temperature=0
        )
        content = response.choices[0].message.content
        return content

    def call_llm_contextual(self, img1, img2):
        base64_image = [
            self.image_to_base64(img1, target_format='webp'),
            self.image_to_base64(img2, target_format='webp')]

        response = self.client.chat(
            self.client_config,
            messages=[
                {"role": "system", "content": VLM_PDF_to_HTML_prompt_contextual},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "QwenVL HTML."},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{base64_image[0]}",
                            }
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{base64_image[1]}",
                            }
                        }, ],
                }
            ],
            temperature=0
        )
        content = response.choices[0].message.content
        return content

    def extract_html(self, res):
        start = res.find('<html>')
        end = res.find('</html>') + 7
        if start != -1 and end != -1:
            res = res[start:end]
        else:
            res = '<html></html>'
        return res
