import os
import filetype
import base64
from io import TextIOWrapper, BufferedReader, BytesIO
from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Union, Optional
from PIL import Image

from kbx.common.types import DocData, DocElementType
from kbx.common.utils import detect_file_encoding, generate_new_id
from kbx.common.toc_builder import TOCBuilder
from kbx.datastore.file.file_base import BaseFileDS
from kbx.datastore.types import FileType
from kbx.parser.types import DocParseConfig
from kbx.parser.utils import postprocess_table_data
from concurrent.futures import ThreadPoolExecutor


class BaseParser(ABC):
    """文档解析器基类，定义了解析器的通用接口和行为。

    该类是所有具体文档解析器的基类，提供了以下核心功能：

    - 文档解析
    - 文件格式校验
    - 文件打开（兼容本地文件和系统FileSystem文件）

    主要接口方法：

    - parse(): 解析文档并返回DocData对象
    - file_extensions(): 返回支持的文件扩展名列表
    - open(): 打开文件并返回文件对象
    - validate_file(): 验证文件是否符合解析要求

    典型使用样例：

    ```python
    class MyParser(BaseParser):
        @staticmethod
        def file_extensions() -> List[str]:
            return ['.txt']

        def parse(self, file_path: str, doc_id: str) -> DocData:
            with self.open(file_path) as f:
                content = f.read()
            return DocData(doc_id=doc_id, content=content)

    parser = MyParser(config)
    doc_data = parser.parse('example.txt', 'doc_id_xxxxx')
    ```

    注意事项：

    - 子类必须实现file_extensions()和parse()方法
    - 文件打开支持本地文件和远程存储
    - 自动编码检测仅对文本文件有效
    """
    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None) -> None:
        self._config = config if config is not None else DocParseConfig()
        self._file_ds = file_ds
        self._image_processor = None
        self._audio_processor = None
        self._video_processor = None
        self._code_processor = None

        # 初始化raw_path_prefix
        if self._file_ds:
            with self._file_ds:
                # 获取raw_path前缀，两边的斜杠去掉，方便拼接
                self._raw_path_prefix = self._file_ds.get_raw_path('').strip('/')
        else:
            self._raw_path_prefix = ''

        # 初始化file_service_prefix
        from kbx.kbx import KBX
        self._file_service_prefix = KBX.config.file_service_prefix.rstrip('/')

    @staticmethod
    def file_extensions() -> List[str]:
        """此Parser可以处理文档格式的文件后缀

        Returns:
            List[str]: 文件格式后缀列表
        """
        raise NotImplementedError

    @staticmethod
    def postprocess_steps() -> List[str]:
        """此Parser可以进行的后处理步骤
        Returns:
            List[str]: 后处理步骤列表
        """
        return []

    def open(self, file_path: str, mode: str = 'r', encoding: str = None, **kwargs) \
            -> Union[TextIOWrapper, BufferedReader]:
        """打开一个文档文件，用于后续读取和解析

        Args:
            file_path (str): 文档文件路径
            mode (str): 打开模式
            encoding (str): 编码方式
            kwargs (Any): 其他可选的kw参数，比如newline

        Returns:
            Union[TextIOWrapper, BufferedReader]: 打开的文件对象
        """
        if self._file_ds is not None:
            with self._file_ds:
                return self._file_ds.open(file_path, mode, encoding, **kwargs)
        else:
            if 'w' in mode:
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
            if 'b' in mode:
                return open(file_path, mode, **kwargs)
            else:
                try:
                    return open(file_path, 'r', encoding=encoding)
                except UnicodeDecodeError as e:
                    detected_encoding = detect_file_encoding(file_path)
                    if detected_encoding:
                        return open(file_path, 'r', encoding=detected_encoding)
                    else:
                        # 抛出新异常，同时携带原始异常的信息
                        raise RuntimeError(f"Error loading {file_path}") from e

    def isfile(self, file_path: str) -> bool:
        """
        检查某个路径是否是一个存在的文件（类似os.path.isfile）

        Args:
            file_path (str): 文件路径

        Returns:
            bool: 是否是一个存在的文件
        """
        if self._file_ds is not None:
            with self._file_ds:
                return self._file_ds.isfile(file_path)
        else:
            return os.path.exists(file_path)

    def _save_extra_file(self, data: Union[bytes, Image.Image], doc_id: str,
                         save_name: Optional[str] = None, limit_size: int = 5) -> str:
        """保存文档解析过程中的图片、音频、视频文件到FileDatastore

        Args:
            data (Union[bytes, Image.Image]): 图片、音频、视频文件数据
            doc_id (str): 文档id
            save_name (str): 保存文件名(不带路径及后缀名)，如不提供则自动生成随机id
            limit_size (int): 图片文件大小限制，单位为MB
        Returns:
            str: 在FileDatastore中的相对文件路径

        Raises:
            RuntimeError: 当文件类型未知或文件大小超过5MB时抛出异常
        """
        if isinstance(data, Image.Image):
            with BytesIO() as bytes_io:
                data.save(bytes_io, format="JPEG")
                data = bytes_io.getvalue()

        # save bytes数据到datastore
        kind = filetype.guess(data)
        if kind is None:
            raise RuntimeError(f"Unknown file type: {save_name}")

        # 限制存储图片大小
        if kind.extension in ['jpg', 'png', 'webp']:
            if len(data) > limit_size * 1024 * 1024:
                raise RuntimeError(
                    f"Image size exceeds maximum limit of {limit_size}MB: {len(data) / (1024 * 1024):.2f}MB.")

        guess_ext = kind.extension
        if save_name:
            save_name = generate_new_id() + '_' + save_name + '.' + guess_ext
        else:
            save_name = generate_new_id() + '.' + guess_ext
        data_file_path = os.path.join(FileType.EXTRA_DOC_ELEMENTS, doc_id, save_name)
        with self.open(data_file_path, 'wb') as f:
            f.write(data)

        return data_file_path

    def _load_image_as_base64(self, file_path: str) -> str:
        """打开图片文件并返回base64编码的字符串

        Args:
            file_path (str): 图片文件路径

        Returns:
            str: base64编码的字符串
        """
        with self.open(file_path, 'rb') as f:
            data = f.read()
        return base64.b64encode(data).decode('utf-8')

    @abstractmethod
    def _parse(self, file_path: str, doc_id: str) -> DocData:
        """读取并解析一个文档文件，然后转换成DocData格式

        Args:
            file_path (str): 文档文件路径
            doc_id (str): 文档id，用于记录文档来源

        Returns:
            DocData: 解析完成后的DocData数据
        """
        raise NotImplementedError

    def parse(self, file_path: str, doc_id: str) -> DocData:
        """读取并解析一个文档文件，以DocData格式输出，然后进行后处理

        Args:
            file_path (str): 文档文件路径
            doc_id (str): 文档id，用于记录文档来源

        Returns:
            DocData: 解析完成后的DocData数据
        """
        self.validate_file(file_path)
        doc_data = self._parse(file_path, doc_id)

        # 先执行一些可配置的后处理
        steps = self.__class__.postprocess_steps()
        self.post_process(doc_data, steps)

        # 再执行一些固定流程
        # 1. 构建目录树
        toc_builder = TOCBuilder(self._config)
        doc_data = toc_builder.build_toc(doc_data)

        # 2. 设置data_file_raw_path和data_file_url
        self._post_process_file_url(doc_data)

        return doc_data

    def validate_file(self, file_path: str) -> None:
        """用于检查某文件是否符合本解析器能够处理的文档格式，如果存在问题会抛出异常

        Args:
            file_path (str): 文档路径
        """
        path = Path(file_path)

        if path.suffix not in self.file_extensions():
            raise RuntimeError(
                f'{__class__.__name__} expect file extension to be one of'
                f' {self.file_extensions()}, given {file_path}'
            )

        if self._file_ds is None:
            if not path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")

            if not path.is_file():
                raise ValueError(f"Path is not a file: {file_path}")

    def post_process(self, doc_data: DocData, steps: list[str]):
        """对解析完成的文档数据进行后处理
        Args:
            doc_data (DocData): 解析完成的文档数据
            steps (list[str]): 后处理步骤列表
        """
        post_process_map = {
            "table": self._post_process_table,
            "audio": self._post_process_audio,
            "video": self._post_process_video,
            "image": self._post_process_image,
            "code": self._post_process_code,
        }

        for step in steps:
            if step in post_process_map:
                post_process_map[step](doc_data)
            else:
                raise ValueError(f"Unknown post processing step: {step}")

    def _post_process_file_url(self, doc_data: DocData) -> None:
        """对解析完成的文档数据进行后处理，设置data_file_raw_path和data_file_url
        Args:
            doc_data (DocData): 解析完成的文档数据
        """

        # 设置文档文件的原始路径和url
        if self._raw_path_prefix:
            doc_data.file_raw_path = os.path.join(
                self._raw_path_prefix,
                doc_data.file_path
            ).lstrip('/')
            if self._file_service_prefix:
                doc_data.file_url = f"{self._file_service_prefix}/{doc_data.file_raw_path}"

        # 设置文档内容中每个内容单元的原始路径和url
        for elem in doc_data.doc_elements:
            if not elem.data_file_path:
                # 如果data_file_path为空，则不设置data_file_raw_path和data_file_url
                continue
            if self._raw_path_prefix:
                elem.data_file_raw_path = os.path.join(
                    self._raw_path_prefix,
                    elem.data_file_path
                ).lstrip('/')
                if self._file_service_prefix:
                    elem.data_file_url = f"{self._file_service_prefix}/{elem.data_file_raw_path}"

    def _post_process_table(self, doc_data: DocData) -> None:
        """对解析完成的表格数据进行后处理
        Args:
            doc_data (DocData): 解析完成的文档数据
        """
        for elem in doc_data.doc_elements:
            if elem.type == DocElementType.TABLE and elem.table.is_standard:
                # TODO: 是否需要对非标表格处理？
                # TODO: postprocess_table_data的输入直接改为Table？
                elem.table.data_2d = postprocess_table_data(elem.table.data_2d)

    def _post_process_audio(self, doc_data: DocData) -> None:
        """对解析完成的音频数据进行后处理
        Args:
            doc_data (DocData): 解析完成的文档数据
        """
        if self._config.audio_strategy is None:
            return
        if self._audio_processor is None:
            from kbx.parser.multimodal.multimodal_processor import AudioProcessor
            self._audio_processor = AudioProcessor(self._config)

        # 旧版串行调用
        [self._audio_processor.process_doc_element(elem, fn_open=self.open)
            for elem in doc_data.doc_elements]

        # TODO: 音频因为需要调用CPU密集型的解码分割，暂时不启用并行
        # from kbx.kbx import KBX
        # with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as executor:
        #     executor.map(self._audio_processor.process_doc_element, doc_data.doc_elements)

    def _post_process_video(self, doc_data: DocData) -> None:
        """对解析完成的视频数据进行后处理
        Args:
            doc_data (DocData): 解析完成的文档数据
        """
        if self._config.video_strategy is None:
            return
        if self._video_processor is None:
            from kbx.parser.multimodal.multimodal_processor import VideoProcessor
            self._video_processor = VideoProcessor(self._config)

        # 旧版串行调用
        [self._video_processor.process_doc_element(elem, fn_open=self.open)
            for elem in doc_data.doc_elements]

        # TODO: 视频因为需要调用CPU密集型的解码分割，暂时不启用并行
        # from kbx.kbx import KBX
        # with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as executor:
        #     executor.map(self._video_processor.process_doc_element, doc_data.doc_elements)

    def _post_process_image(self, doc_data: DocData) -> None:
        """对解析完成的图像数据进行后处理
        Args:
            doc_data (DocData): 解析完成的文档数据
        """
        if self._config.image_strategy is None:
            return
        if self._image_processor is None:
            from kbx.parser.multimodal.multimodal_processor import ImageProcessor
            self._image_processor = ImageProcessor(self._config)

        # 旧版串行调用
        # [self._image_processor.process_doc_element(elem)
        #     for elem in doc_data.doc_elements]

        # NOTE: 统一并行优化
        from kbx.kbx import KBX
        with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as executor:
            def process_with_loader(elem):
                return self._image_processor.process_doc_element(
                    elem,
                    image_loader=self._load_image_as_base64
                )

            executor.map(process_with_loader, doc_data.doc_elements)

    def _post_process_code(self, doc_data: DocData) -> None:
        """对解析完成的代码数据进行后处理

        Args:
            doc_data (DocData): 解析完成的文档数据
        """
        if self._config.code_strategy is None or \
                self._config.code_strategy.code_summarizer == '':
            return
        if self._code_processor is None:
            from kbx.parser.multimodal.multimodal_processor import CodeProcessor
            self._code_processor = CodeProcessor(self._config)

        # NOTE: 统一并行优化
        from kbx.kbx import KBX
        with ThreadPoolExecutor(max_workers=KBX.config.num_threads) as executor:
            executor.map(self._code_processor.process_doc_element, doc_data.doc_elements)
