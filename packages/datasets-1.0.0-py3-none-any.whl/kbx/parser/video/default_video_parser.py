import os
from typing import List, Tuple
from pathlib import Path
from kbx.datastore.file.file_base import BaseFileDS
from kbx.datastore.types import FileType
from kbx.parser.base_parser import BaseParser
from kbx.parser.types import DocParseConfig
from kbx.common.types import DocData, DocElement, DocElementType
from kbx.common.utils import generate_new_id
from scenedetect.frame_timecode import FrameTimecode


class DefaultVideoParser(BaseParser):
    """
    默认视频解析器，继承自BaseParser，用于解析视频文件并提取视频Summary。

    该解析器是视频文件解析的默认实现，支持mp4/mov等格式，基于ffmpeg和scenedetect进行视频处理和场景分割，然后抽帧进行VLM内容分析。

    支持解析视频文件中的以下内容：

    - 视频场景分割
    - 视频片段提取
    - 视频转文本描述

    不支持的功能：

    - 复杂视频处理（如目标检测、行为识别）
    - 视频水印处理
    """
    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None):
        super().__init__(config, file_ds)
        from kbx.kbx import KBX
        self._cache_dir = KBX.config.cache_dir

    @staticmethod
    def file_extensions() -> List[str]:
        """此解析器支持的文件扩展名。

        Returns:
            List[str]: 文件拓展名列表
        """
        return ['.mp4']

    @staticmethod
    def postprocess_steps() -> List[str]:
        return ['video']

    def _merge_short_scenes(
        self,
        scene_list: List[Tuple[FrameTimecode, FrameTimecode]],
        min_duration: int
    ) -> List[Tuple[FrameTimecode, FrameTimecode]]:
        """根据最小片段时长合并较短片段

        Args:
            scene_list (List[Tuple[FrameTimecode, FrameTimecode]]): 场景时间戳列表
            min_duration (int): 最小片段时长，以秒为单位

        Returns:
            List[Tuple[FrameTimecode, FrameTimecode]]: 合并后的时间戳列表
        """
        merged_timestamps = []
        current_start, current_end = scene_list[0]
        for i, (start_time, end_time) in enumerate(scene_list[1:]):
            if (current_end - current_start).get_seconds() < min_duration:
                current_end = end_time
            else:
                merged_timestamps.append((current_start, current_end))
                current_start, current_end = start_time, end_time
        merged_timestamps.append((current_start, current_end))

        return merged_timestamps

    def _detect_and_split_scenes(self, file_path: str, doc_id: str) -> List[DocElement]:
        """检测视频场景变化并分割为多个场景，并返回分割后的DocData对象。

        Args:
            file_path (str): 文件路径
            doc_id (str): 文档id

        Returns:
            List[DocElement]: 已分割视频构建的DocElement列表
        """
        from scenedetect import open_video, SceneManager
        from scenedetect.detectors import ContentDetector

        output_dir = os.path.join(self._cache_dir, 'video_cache')
        os.makedirs(output_dir, exist_ok=True)

        self._file_ds.connect()
        self._file_ds.download_files([file_path], save_dir=self._cache_dir)
        file_name = Path(file_path)
        ext = file_name.suffix
        video = open_video(os.path.join(self._cache_dir, file_name.name))
        scene_manager = SceneManager()
        scene_manager.add_detector(ContentDetector(threshold=5))
        scene_manager.detect_scenes(video=video)
        scene_list = scene_manager.get_scene_list()
        if not scene_list:
            return [DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.VIDEO,
                data_file_path=file_path)]

        merged_scene_list = self._merge_short_scenes(scene_list, min_duration=self._config.video_strategy.num_frames)

        if len(merged_scene_list) == 1:
            return [DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.VIDEO,
                data_file_path=file_path)]

        doc_eles = []
        for i, (start_time, end_time) in enumerate(merged_scene_list):
            duration = end_time - start_time
            output_file_name = os.path.join(output_dir, f'{file_name.stem}_part{i}{ext}')
            os.system(
                f'ffmpeg -nostdin -y -ss {str(start_time.get_seconds())} '
                f'-i {os.path.join(self._cache_dir, file_name.name)} '
                f'-t {str(duration.get_seconds())} {output_file_name}')

            self._file_ds.upload_files([output_file_name], save_dir=os.path.join(FileType.EXTRA_DOC_ELEMENTS, doc_id))
            os.remove(output_file_name)
            doc_ele = DocElement(
                doc_element_id=generate_new_id(),
                type=DocElementType.VIDEO,
                data_file_path=os.path.join(FileType.EXTRA_DOC_ELEMENTS, doc_id, os.path.basename(output_file_name))
            )

            doc_eles.append(doc_ele)

        self._file_ds.close()

        return doc_eles

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        """解析视频文件，统一转换为DocData格式。

        Args:
            file_path (str): 文件路径
            doc_id (str): 文件doc_id

        Returns:
            DocData: 解析后的DocData对象
        """
        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)

        if self._config.video_strategy.enable_scene_split:
            doc.doc_elements = self._detect_and_split_scenes(file_path, doc_id)
        else:
            doc.doc_elements = [DocElement(doc_element_id=generate_new_id(),
                                           type=DocElementType.VIDEO,
                                           data_file_path=file_path)]

        return doc
