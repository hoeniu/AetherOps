import os
from typing import List

from kbx.common.utils import generate_new_id
from kbx.parser.base_parser import BaseParser
from kbx.common.types import DocData, DocElement


class DefaultTxtParser(BaseParser):
    @staticmethod
    def file_extensions() -> List[str]:
        return ['.txt']

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        """Load from file path."""
        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)

        text = ""
        with self.open(file_path, 'r', 'utf-8') as f:
            # TODO: 讨论f.read() or f.readlines()的选择
            text = f.read()

        doc_elem = DocElement(doc_element_id=generate_new_id(), text=text)

        doc.doc_elements.append(doc_elem)
        return doc
