from typing import Dict, Literal, Optional, ClassVar, Set
from pydantic import Field
from kbx.common.types import DocFileType, ImageEmbeddingStrategy, \
    AudioEmbeddingStrategy, VideoEmbeddingStrategy, UserContext, KBXBaseModel
from kbx.common.types import TokenCounterConfig
from kbx.ai_model.types import AIModelBundle


class ImageStrategyConfig(KBXBaseModel):
    """图像嵌入提取策略及相关参数配置"""
    type: ImageEmbeddingStrategy = Field(
        default=ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING,
        description="文档中图像数据的Embedding提取策略"
    )
    vision_model: str = Field(
        default='',
        description="用于视觉理解的模型名称。可选用Pro/Qwen/Qwen2-VL-7B-Instruct等视觉理解大模型。"
    )


class VideoStrategyConfig(KBXBaseModel):
    """视频嵌入提取策略及相关参数配置"""
    type: VideoEmbeddingStrategy = Field(
        default=VideoEmbeddingStrategy.VIDEO2TEXT_TEXT_EMBEDDING,
        description="文档中视频数据的Embedding提取策略"
    )
    vision_model: str = Field(
        default='',
        description="用于视觉理解的模型名称。可选用Pro/Qwen/Qwen2-VL-7B-Instruct等视觉理解大模型。"
    )
    num_frames: int = Field(
        default=6,
        description="在生成视频描述过程中需要提取的图像帧数。该参数决定了从视频中提取多少帧用于分析和描述。"
    )
    frame_type: str = Field(
        default='jpg',
        description="视频帧的编码格式，可选值为 'jpg' 和 'png'。选择不同的编码格式会影响文件大小和图像质量。"
    )
    quality_level: int = Field(
        default=85,
        description="图像质量参数。对于jpg格式，取值范围0-100，默认85(值越高质量越好)；对于png格式，取值范围0-9，表示压缩级别，默认3(值越低质量越好)"
    )
    enable_scene_split: bool = Field(
        default=True,
        description="是否启用视频场景切分。当启用时，系统将根据视频内容自动识别并切分为不同的场景片段，以提高视频处理的准确性。"
    )


class AudioStrategyConfig(KBXBaseModel):
    """音频嵌入提取策略及相关参数配置"""
    type: AudioEmbeddingStrategy = Field(
        default=AudioEmbeddingStrategy.SPEECH2TEXT_TEXT_EMBEDDING,
        description="文档中音频数据的Embedding提取策略"
    )
    split_mode: Literal["intelligent", "size", "time"] = Field(
        default="size",
        description="音频分割模式。可选值包括'intelligent'（智能划分）、'size'（按固定尺寸划分）和'time'（按固定时长划分）。"
    )
    voice_model: str = Field(
        default='',
        description="用于语音识别的模型名称。可选用FunAudioLLM/SenseVoiceSmall等语音识别模型。"
    )
    refinement_model: str = Field(
        default='',
        description="用于对语音识别结果进行精炼和纠错的大模型名称。该模型可以提高识别结果的准确性和流畅性。可选用Qwen/Qwen2.5-32B-Instruct等文本大模型。"
    )


class CodeStrategyConfig(KBXBaseModel):
    """代码处理策略的参数配置"""
    code_summarizer: str = Field(
        default='',
        description="用于代码理解和summary生成的模型名称。可选用Qwen/Doubao/DeepSeek等可对代码进行理解的LLM大模型。",
    )


class PdfOcrStrategyConfig(KBXBaseModel):
    parser_type: str = Field(default="MinerU", description="使用哪个parser，基于OCR的pdf parser目前可选[MinerU, Deepdoc, VLM]")

    # For vlm pdf parser
    vlm_model: Optional[str] = Field(default=None, description="【可选】对PDF进行视觉解析的VLM模型名称，仅在parser_type为VLM时有效")
    use_consecutive_pages: Optional[bool] = Field(default=False, description="【可选】是否使用连续页进行辅助判断，仅在parser_type为VLM时有效")


class DocParseConfig(KBXBaseModel):
    """文档解析相关参数"""

    file_parsers: Dict[DocFileType, str] = Field(
        default_factory=dict,
        description="不同格式文件需要手动配置解析器的字典，如{DocFileType.PDF: 'MyPdfParser', DocFileType.DOCX: 'MyDocxParser'}。" \
                    "除非有特殊需求，否则不需要配置，会根据文件类型自动选择相应的文件解析器"
    )
    save_external_data: bool = Field(default=False, description="是否保存解析过程中提取到的外链数据，如图片、音频、视频url等")

    token_counter: Optional[TokenCounterConfig] = Field(
        default=None,
        description="文档解析过程中，用于统计token数量的配置，不设置则使用知识库统一配置"
    )
    summary_model: str = Field(default='', description="用于生成文档摘要的模型名称")

    # 高级功能
    enable_layout_recognition: bool = Field(default=True, description="文档解析时是否启用版面识别")
    image_strategy: Optional[ImageStrategyConfig] = Field(
        # default_factory=ImageStrategyConfig,
        default=None,
        description="图像嵌入提取策略及相关参数配置"
    )
    video_strategy: Optional[VideoStrategyConfig] = Field(
        # default_factory=VideoStrategyConfig,
        default=None,
        description="视频嵌入提取策略及相关参数配置"
    )
    audio_strategy: Optional[AudioStrategyConfig] = Field(
        # default_factory=AudioStrategyConfig,
        default=None,
        description="音频嵌入提取策略及相关参数配置"
    )

    pdf_ocr_strategy: Optional[PdfOcrStrategyConfig] = Field(
        # default_factory=DeepDocOcrStrategyConfig,
        default=None,
        description="基于ocr的pdf提取策略及相关参数配置"
    )

    code_strategy: Optional[CodeStrategyConfig] = Field(
        default=None,
        description="代码Summary生成器的参数配置"
    )

    user_ctx: Optional[UserContext] = Field(
        default=None, init=False, repr=False,
        exclude=True, description="🔒【内部使用】用户上下文"
    )

    # 此类已废弃的字段
    deprecated_fields: ClassVar[Set[str]] = {
        'encoding',
        'autodetect_encoding',
    }

    def update_with_model_bundle(self, model_bundle: AIModelBundle) -> 'DocParseConfig':
        """使用模型配置更新当前配置

        Args:
            model_bundle (AIModelBundle): 模型配置

        Returns:
            DocParseConfig: 更新后的配置
        """
        if self.image_strategy and (not self.image_strategy.vision_model):
            if self.image_strategy.type == ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING:
                self.image_strategy.vision_model = model_bundle.vlm
            elif self.image_strategy.type == ImageEmbeddingStrategy.VISION_EMBEDDING:
                self.image_strategy.vision_model = model_bundle.vision_embedding
        if self.audio_strategy and (not self.audio_strategy.voice_model):
            if self.audio_strategy.type == AudioEmbeddingStrategy.SPEECH2TEXT_TEXT_EMBEDDING:
                self.audio_strategy.voice_model = model_bundle.speech2text
        if self.audio_strategy and (not self.audio_strategy.refinement_model):
            if self.audio_strategy.type == AudioEmbeddingStrategy.SPEECH2TEXT_TEXT_EMBEDDING:
                self.audio_strategy.refinement_model = model_bundle.llm
        if self.video_strategy and (not self.video_strategy.vision_model):
            if self.video_strategy.type == VideoEmbeddingStrategy.VIDEO2TEXT_TEXT_EMBEDDING:
                self.video_strategy.vision_model = model_bundle.vlm
        if self.code_strategy and (not self.code_strategy.code_summarizer):
            self.code_strategy.code_summarizer = model_bundle.llm
        if self.pdf_ocr_strategy and self.pdf_ocr_strategy.parser_type == 'VLM' and \
                not self.pdf_ocr_strategy.vlm_model:
            self.pdf_ocr_strategy.vlm_model = model_bundle.vlm

        return self
