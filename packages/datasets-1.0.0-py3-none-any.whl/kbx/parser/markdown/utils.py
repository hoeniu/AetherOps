from typing import List, Optional, Tuple
from kbx.common.logging import logger


def table_2d_list_to_md(data: List[List[str]], has_header: Optional[bool] = None, caption: Optional[str] = None) -> str:
    """将标准二维List格式表格转换为markdown格式

    Args:
        data (List[List[str]]): 二维List格式数据
        has_header (Optional[bool], optional): 是否有表头. None表示未知. Defaults to None.
        caption (Optional[str], optional): 表注. Defaults to None.

    Returns:
        str: markdown格式表格数据
    """
    if not data or len(data) == 0:
        return ""

    md = ""
    if caption:
        md += f"{caption}\n\n"

    # 处理单元格内容，替换换行符为空格
    sanitized_data = [[cell.replace('\n', ' ').strip() for cell in row] for row in data]
    # 确保每行列数一致
    if not all(len(row) == len(sanitized_data[0]) for row in sanitized_data):
        return ""

    # 根据是否有表头决定表头行内容
    if has_header:
        # 使用第一行作为表头
        header_row = sanitized_data[0]
        data_rows = sanitized_data[1:]
    else:
        # 使用通用列名作为表头
        header_row = [f"col{i + 1}" for i in range(len(sanitized_data[0]))]
        data_rows = sanitized_data

    # 添加表头行
    md += "|" + "|".join(header_row) + "|\n"
    # 添加分隔行
    md += "|" + "|".join(["---"] * len(header_row)) + "|\n"

    # 添加数据行
    for row in data_rows:
        md += "|" + "|".join(row) + "|\n"

    md += '\n'
    return md


def parse_md_table(md: str) -> Tuple[bool, List[List[str]]]:
    """解析一个markdown表格，返回表格是否有表头和数据

    注意，如果输入的md存在语法错误或是非法表格，会抛出ValueError异常

    Args:
        md (str): markdown格式数据

    Returns:
        Tuple[bool, List[List[str]]]: 是否有表头、表数据
    """
    md = md.strip()
    if not md:
        raise ValueError("Empty markdown data")

    # 从markdown格式数据提取表格对象
    data_2d = []
    lines = list(filter(lambda x: x.strip(), md.split('\n')))
    if len(lines) < 1:
        # 行数不足1行，无法构成表格
        raise ValueError(f"Invalid markdown data: less than 1 line\n{md}")

    # 处理表格数据
    has_header = False
    for k, line in enumerate(lines):
        if not line.startswith('|') or not line.endswith('|'):
            # 非法格式
            raise ValueError(f"Invalid markdown data:\n{md}")
        if k == 1:
            # 判断第二行是否是分割线
            if line.startswith('|') and line.endswith('|') and '---' in line:
                has_header = True
        row = line.split('|')[1:-1]
        row = [x.strip() for x in row]
        data_2d.append(row)

    row_cols = [len(row) for row in data_2d]
    if len(set(row_cols)) != 1:
        # 表格列数不一致，无法构成表格
        raise ValueError(f"Different column number in markdown data:\n{md}")

    if not data_2d:
        # 如果没有表数据，不管有没有表头，都是非法的
        logger.warning(f"Empty table data in markdown data:\n{md}")
        return False, []

    return has_header, data_2d
