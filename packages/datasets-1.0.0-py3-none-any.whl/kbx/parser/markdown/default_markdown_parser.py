import os
import re
from typing import List, Optional
from urllib.parse import urlparse

from kbx.common.logging import logger
from kbx.common.types import DocData, DocElement, DocElementType
from kbx.common.utils import generate_new_id
from kbx.parser.base_parser import BaseParser
from kbx.parser.utils import download_image_as_bytes


class DefaultMarkdownParser(BaseParser):
    """
    Markdown文档默认解析器，继承自BaseParser，用于解析Markdown (.md, .markdown)文件。

    该解析器是Markdown文档解析的默认实现，不依赖外部服务，完全基于本地解析。

    支持解析Markdown文档中的以下内容：

    - 标题（支持1-6级标题）
    - 段落文本
    - 代码块（保留原始格式）
    - 图片（支持本地和远程图片）
    - 超链接（转换为标准格式）

    不支持的功能：

    - 复杂表格（仅支持简单表格）
    - 数学公式
    - 自定义HTML标签
    - 高级Markdown扩展语法
    """
    @staticmethod
    def file_extensions() -> List[str]:
        return ['.md', '.markdown']

    @staticmethod
    def postprocess_steps() -> List[str]:
        # TODO: image, audio and video postprocess
        return ['table']

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        """Load from file path."""
        self.validate_file(file_path)

        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)

        tups, image_elems = self._parse_markdown(file_path, doc_id)

        for header_info, value in tups:
            value = value.strip()
            if header_info is None:
                doc_elem = DocElement(doc_element_id=generate_new_id(),
                                      text=value)
                doc.doc_elements.append(doc_elem)
            else:
                doc_elem = DocElement(doc_element_id=generate_new_id(),
                                      text=header_info[1],
                                      type=DocElementType.TITLE,
                                      meta_data={'title_level': header_info[0]}
                                      )
                doc.doc_elements.append(doc_elem)
                doc_elem = DocElement(doc_element_id=generate_new_id(),
                                      text=value,
                                      )
                doc.doc_elements.append(doc_elem)
        doc.doc_elements.extend(image_elems)

        return doc

    def _markdown_to_tups(self, markdown_text: str) -> list[tuple[Optional[tuple[int, str]], str]]:
        """Convert a markdown file to a list of tuples.

        Each tuple contains header and the text under each header.

        """
        markdown_tups: list[tuple[Optional[tuple[int, str]], str]] = []
        lines = markdown_text.split("\n")

        current_header = None    # 格式变为(level, title)
        current_text = ""
        code_block_flag = False

        for line in lines:
            # parse code block
            if line.startswith("```"):
                code_block_flag = not code_block_flag
                current_text += line + "\n"
                continue
            if code_block_flag:
                current_text += line + "\n"
                continue

            # parse markdown header(start with "#")
            header_match = re.match(r"^(#+)\s+(.+)$", line)
            if header_match:
                # 如果有任何在第一个标题之前的内容，确保它们被添加到结果中
                if current_header is not None:
                    markdown_tups.append((current_header, current_text))
                elif current_text.strip():  # 如果有标题前内容，且不全是空白
                    markdown_tups.append((None, current_text))

                level = len(header_match.group(1))
                title = header_match.group(2).strip()
                current_header = (level, title)
                current_text = ""
            else:
                current_text += line + "\n"
        markdown_tups.append((current_header, current_text))

        return markdown_tups

    def _remove_images(self, content: str) -> str:
        """Remove all image links from markown file content."""
        pattern = r"!{1}\[\[(.*)\]\]"
        content = re.sub(pattern, "", content)
        return content

    def _extract_images(self, content: str, base_path: str, doc_id: str) -> list[str]:
        """Extract images from markdown content."""
        image_pattern = r'!\[([^\]]*)\]\((.*?)\)'
        images = re.findall(image_pattern, content)
        image_elems = []

        for _, image_path in images:
            # 判断是否是外部链接还是相对路径
            if not urlparse(image_path).netloc:  # 相对路径
                image_path = os.path.join(base_path, image_path)
                if os.path.exists(image_path):
                    with open(image_path, "rb") as img_file:
                        bytes_data = img_file.read()
                    data_file_path = self._save_extra_file(bytes_data, doc_id)
                    if data_file_path:
                        image_elem = DocElement(doc_element_id=generate_new_id(),
                                                type=DocElementType.FIGURE,
                                                data_file_path=data_file_path)
                        image_elems.append(image_elem)
                else:
                    logger.warning(f"Image file not found: {image_path}")

            # 如果是外部链接（URL），根据需要可以下载并保存图片
            if self._config.save_external_data and urlparse(image_path).netloc:
                bytes_data = download_image_as_bytes(image_path)
                if bytes_data:
                    data_file_path = self._save_extra_file(bytes_data, doc_id)
                    if data_file_path:
                        image_elem = DocElement(doc_element_id=generate_new_id(),
                                                type=DocElementType.FIGURE,
                                                data_file_path=data_file_path)
                        image_elems.append(image_elem)

        return content, image_elems

    def _parse_markdown(self, file_path: str, doc_id) -> tuple[list[tuple[Optional[tuple[int, str]], str]], list]:
        """Parse markdown file into tuples and extract images in markdown file."""
        content = ""
        with self.open(file_path, 'r', 'utf-8') as f:
            content = f.read()

        # 提取并处理图片
        content, image_elems = self._extract_images(content, os.path.dirname(file_path), doc_id)

        return self._markdown_to_tups(content), image_elems
