import os
from typing import List
from markdown_it import MarkdownIt
from markdown_it.tree import SyntaxTreeNode
from kbx.common.logging import logger
from kbx.common.types import DocData, DocElement, DocElementType, Table
from kbx.common.utils import generate_new_id
from kbx.parser.base_parser import BaseParser
from kbx.parser.utils import download_image_as_bytes


def get_syntax_node_original_text(node: SyntaxTreeNode, md_content: str) -> str:
    """
    从markdown的token树中获取指定节点的原始文本内容。

    Args:
        node (SyntaxTreeNode): 要获取原始文本的节点。
        md_content (str): 完整的markdown内容。

    Returns:
        str: 节点的原始文本内容。
    """
    if node.map:
        # 如果有行号范围，从原文获取
        range_start, range_end = node.map
        original_str = md_content.split('\n')[range_start:range_end]
        original_str = '\n'.join(original_str).strip()
        return original_str
    else:
        # 否则直接获取子节点的文本
        return ''.join(child.content for child in node.walk())


class MarkdownItPyParser(BaseParser):
    """
    基于markdown-it-py的Markdown解析器，继承自BaseParser，用于解析Markdown (.md,.markdown)文件。
    原则上可以对markdown的所有语法进行解析。

    支持解析的 Markdown 元素：

    - 标题（Heading）：如 # 一级标题、## 二级标题等，支持标题级别识别。
    - 段落（Paragraph）：普通的文本段落，支持行内图片。
    - 列表项（List Item）：有序列表（如 1. ）和无序列表（如 - ）、嵌套列表、task列表。
    - 代码块（Code Block）：包括缩进式代码块和围栏式代码块（使用 ``` 或 ~~~ 包裹）。
    - 图片（Image）：支持本地图片和外部链接图片，可将外部图片保存为本地文件。
    - 表格（Table）：支持简单的表格结构，可提取表头和内容。
    - HTML 块（HTML Block）：目前将其作为普通文本处理，未来可考虑进一步解析。
    - 数学公式（Math Formula）：如行间 LaTeX 公式 $$E=mc^2$$。

    不支持解析的 Markdown 元素：

    - 脚注（Footnote）：Markdown 中的脚注语法暂不支持。
    - 链接（Link）：Markdown 中的链接语法暂不做特殊处理，当成普通文本。
    """

    BLOCK_TYPES = {
        "heading",
        "paragraph",
        "bullet_list",
        "ordered_list",
        "list_item",
        "code_block",
        "fence",
        "blockquote",
        "hr",
        "table",
        "html_block",
    }
    INLINE_TYPES = {
        "inline",
        "text",
        "em",
        "strong",
        "link",
        "code_inline",
        "image",
        "hardbreak",
        "softbreak",
    }

    @staticmethod
    def file_extensions() -> List[str]:
        return ['.md', '.markdown']

    @staticmethod
    def _is_math_block(text: str) -> bool:
        """判断是否是行间公式"""
        return text.strip().startswith('$$') and text.strip().endswith('$$')

    @staticmethod
    def postprocess_steps() -> List[str]:
        return ['image', 'code']
        # return []

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        doc_data = DocData(
            doc_id=doc_id,
            file_name=os.path.basename(file_path),
            file_path=file_path
        )

        md_content = ''
        with self.open(file_path, 'r') as f:
            # 一次性读取整个文件内容
            md_content = f.read()

        # 使用markdown-it-py解析markdown内容，生成token列表
        md_parser = MarkdownIt("commonmark").enable('table').enable('image')
        tokens = md_parser.parse(md_content)
        # 建立AST树
        md_tree = SyntaxTreeNode(tokens)

        # 获取节点的行号范围
        def get_line_range(node):
            if node.map:
                return node.map

            # 尝试从所有子节点获取行号范围
            start_lines = []
            end_lines = []
            for child in node.children:
                if child.map:
                    start_lines.append(child.map[0])
                    end_lines.append(child.map[1])

            # 如果找到了子节点的行号范围，返回整体的起始和终止行
            if start_lines and end_lines:
                return [min(start_lines), max(end_lines)]

            # 如果所有子节点都没有map，则提供默认值[0, 0]，表示无法确定具体行号
            return [0, 0]

        # md_renderer = MDRenderer()
        def _parse_paragraph_and_children_node(node: SyntaxTreeNode):
            """paragraph节点因为可能嵌套image等特殊节点，需要特殊递归解析"""
            all_children_types = set(child.type for child in node.walk())
            # 添加行号范围到meta_data
            line_range = get_line_range(node)
            if 'image' not in all_children_types:
                # 当前node没有image子节点，直接获取整段文本
                text = get_syntax_node_original_text(node, md_content)
                if text == '':
                    return

                if self._is_math_block(text):
                    # 检查是否是行间公式
                    # 不需要去除公式的$$标记
                    formula = text.strip()
                    doc_data.doc_elements.append(DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.EQUATION,
                        text=formula,
                        meta_data={
                            'line_range': line_range
                        }
                    ))
                else:
                    # 纯文本段落
                    doc_data.doc_elements.append(DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.TEXT,
                        text=text,
                        meta_data={
                            'line_range': line_range
                        }
                    ))
            elif node.type == 'image':
                # 已经遍历到一个图片节点，直接处理，且子节点不用继续递归处理
                data_file_path = self._handle_image_node(
                    node,
                    if_download_image_url=self._config.save_external_data,
                    base_dir=os.path.dirname(file_path),
                    doc_id=doc_id
                )
                if data_file_path:
                    doc_data.doc_elements.append(DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.FIGURE,
                        data_file_path=data_file_path,
                        image_caption=node.attrs.get('alt', ''),
                        meta_data={'line_range': line_range}
                    ))
            else:
                # 有子节点包含图片，需要递归解析
                for child in node.children:
                    _parse_paragraph_and_children_node(child)

        # 按阅读顺序遍历整个markdown树，抽取其中的内容单元，然后转换成DocElement并插入doc_data
        for node in md_tree.children:
            # 添加行号范围到meta_data
            line_range = get_line_range(node)
            if node.type == 'heading':
                # 处理标题
                text = ''.join(child.content for child in node.children)
                if text == '':
                    continue
                doc_data.doc_elements.append(DocElement(
                    doc_element_id=generate_new_id(),
                    type=DocElementType.TITLE,
                    text=text,
                    meta_data={
                        'line_range': line_range,
                        'title_level': int(node.tag[1:]),
                    }
                ))
            elif node.type in ('paragraph', 'blockquote'):
                _parse_paragraph_and_children_node(node)
            elif node.type in ['bullet_list', 'ordered_list']:
                # 处理列表项
                # 根据node.map获取原始markdown文本的起始、终止行号，然后从原始markdown文本中提取列表项内容
                list_str = get_syntax_node_original_text(node, md_content)
                if list_str == '':
                    continue
                doc_data.doc_elements.append(DocElement(
                    doc_element_id=generate_new_id(),
                    type=DocElementType.TEXT,
                    text=list_str,
                    meta_data={
                        'line_range': line_range
                    }
                ))
            elif node.type == 'code_block':
                # 处理代码块（非```包围，而是使用缩进实现）
                doc_data.doc_elements.append(DocElement(
                    doc_element_id=generate_new_id(),
                    type=DocElementType.CODE_BLOCK,
                    text=node.content,
                    meta_data=(
                        {
                            'language': node.info,
                            'line_range': line_range
                        }
                        if node.info
                        else {
                            'line_range': line_range
                        }
                    )
                ))
            elif node.type == 'image':
                # 处理图片
                data_file_path = self._handle_image_node(
                    node,
                    if_download_image_url=self._config.save_external_data,
                    base_dir=os.path.dirname(file_path),
                    doc_id=doc_id
                )
                if data_file_path:
                    doc_data.doc_elements.append(DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.FIGURE,
                        data_file_path=data_file_path,
                        image_caption=node.attrs.get('alt', ''),
                        meta_data={
                            'line_range': line_range
                        }
                    ))
            elif node.type == 'fence':
                # 处理围栏代码块
                if node.content.strip() == '':
                    continue
                # NOTE: 不需要删除围栏代码块的```标记，保留下来可以辅助后续LLM理解
                if node.map:
                    # 如果有行号范围，从原文获取
                    range_start, range_end = node.map
                    original_str = md_content.split('\n')[range_start:range_end]
                    original_str = '\n'.join(original_str).strip()
                    code_content = original_str
                else:
                    code_content = node.content
                doc_data.doc_elements.append(DocElement(
                    doc_element_id=generate_new_id(),
                    type=DocElementType.CODE_BLOCK,
                    text=code_content,
                    meta_data=(
                        {
                            'language': node.info,
                            'line_range': line_range
                        }
                        if node.info
                        else {
                            'line_range': line_range
                        }
                    )
                ))
            elif node.type == 'table':
                # 处理表格
                table_data = []
                has_header = False

                # 处理表头
                thead = next((child for child in node.children if child.type == 'thead'), None)
                if thead:
                    for tr in thead.children:
                        if tr.type == 'tr':
                            headers = []
                            for th in tr.children:
                                if th.type == 'th':
                                    headers.append(''.join(child.content for child in th.children))
                            if headers:
                                table_data.append(headers)
                                has_header = True
                # 处理表格内容
                tbody = next((child for child in node.children if child.type == 'tbody'), None)
                if tbody:
                    for tr in tbody.children:
                        if tr.type == 'tr':
                            row = []
                            for td in tr.children:
                                if td.type == 'td':
                                    row.append(''.join(child.content for child in td.children))
                            if row:
                                table_data.append(row)

                # NOTE: md表格可以非常准确的提取表头和内容，但是这里直接合并了存在信息丢失
                # NOTE: Markdown表格应该没有填写表注的地方，所以这里直接忽略表注

                if table_data:
                    try:
                        doc_data.doc_elements.append(DocElement(
                            doc_element_id=generate_new_id(),
                            type=DocElementType.TABLE,
                            table=Table.from_2d_list(table_data, has_header=has_header, caption=''),
                            meta_data={
                                'line_range': line_range
                            }
                        ))
                    except ValueError as e:
                        # 打印错误信息和traceback
                        import traceback
                        logger.error(f"Error parsing table:\n {traceback.format_exc()}\n {e}")
                        continue
            elif node.type == 'html_block':
                # 处理HTML块
                # TODO: 暂时不做进一步处理，直接当成text对待，未来可以考虑进一步对html做解析
                if node.content.strip() == '':
                    continue
                doc_data.doc_elements.append(DocElement(
                    doc_element_id=generate_new_id(),
                    type=DocElementType.TEXT,
                    text=node.content,
                    meta_data={
                        'line_range': line_range
                    }
                ))
            elif node.type == 'hr':
                # 忽略分隔线
                pass
            else:
                # 其他类型的节点，暂时不做处理
                logger.error(f"Unsupported node type for MarkdownItPy: {node.type}")

        return doc_data

    def _handle_image_node(self, node: SyntaxTreeNode, if_download_image_url: bool, base_dir: str, doc_id: str) -> str:
        """
        尝试从image节点获取具体的图片数据（例如从image url下载，或从资源文件中读取）。

        Args:
            node (SyntaxTreeNode): 要保存为图片文件的图片节点。
            if_download_image_url (bool): 是否下载图片。
            base_dir (str): 当前解析文件所在目录，用于进行相对路径拼接。
            doc_id (str): 当前解析文件的doc_id，用于保存图片文件。

        Returns:
            str: 图片在file_store中存储的路径，如果获取或保存失败则返回None。
        """
        if node.type != 'image':
            return None
        image_url = node.attrs['src']
        if image_url.startswith('http'):
            if if_download_image_url:
                try:
                    bytes_data = download_image_as_bytes(image_url)
                    # 只有从外部下载的图片需要额外保存
                    data_file_path = self._save_extra_file(bytes_data, doc_id)
                    return data_file_path
                except Exception as e:
                    logger.warning(f"Failed to download image: {image_url}, error: {e}")
                    return None
            else:
                return None
        else:
            image_path = image_url
            if not os.path.isabs(image_path):
                # 如果image_path不是绝对路径，则需要使用当前文件所在文件夹路径作为基准进行拼接
                image_path = os.path.normpath(os.path.join(base_dir, image_path))

            if self.isfile(image_path):
                # 已经存在的图片资源文件，直接返回路径即可
                return image_path
            else:
                logger.warning(f"Can not find image file: {image_path}")
                return None
