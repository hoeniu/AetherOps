import base64
from typing import List, Union, Callable
import av
import numpy as np
from io import BytesIO
from abc import ABC, abstractmethod
from kbx.common.types import AudioEmbeddingStrategy, DocElement, DocElementType, \
    ImageEmbeddingStrategy, VideoEmbeddingStrategy
from kbx.parser.types import DocParseConfig
from kbx.common.prompt import get_category_prompts
from kbx.common.logging import logger


class BaseModalityProcessor(ABC):
    """多模态处理器的基类"""

    def __init__(self, processor_config: DocParseConfig):
        self.prompts = get_category_prompts(category='parser')
        self.config = processor_config
        if processor_config.user_ctx is None:
            raise RuntimeError('"user_ctx" is not specified in DocParseConfig. '\
                               'Must provide for multimodal processor.')

    @abstractmethod
    def process_doc_element(self, doc_element: DocElement, **kwargs) -> None:
        """使用大模型将包含图像/音频/视频的DocElement的多模态数据转换为文本描述

        Args:
            doc_element (DocElement): 包含图像/音频/视频数据的DocElement
        """

        pass

    @abstractmethod
    def convert_to_text(self, multimodal_data: Union[str, BytesIO], **kwargs) -> str:
        """将不同模态数据（图像、视频、语音）转换为自然语言描述

        Args:
            multimodal_data (Union[str, BytesIO]): 包含图像数据的base64，或者包含视频/音频数据的BytesIO对象

        Returns:
            str: 由多模态数据（图像、视频、语音）转换而成的自然语言描述。
                 对于图像和视频数据，返回的文本应当作为DocElement的content_description属性；
                 而对于语音数据，返回的文本应当作为DocElement的text属性。
        """
        pass

    def _get_image_type(self, base64_str: str) -> str:
        """根据base64字符串判断图像类型

        Args:
            base64_str (str): base64编码的字符串
        Returns:
            str: 图像类型，如'png', 'jpg', 'jpeg'等
        """
        header = base64_str[:8]
        signatures = {
            b'\xFF\xD8\xFF': 'jpeg',
            b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A': 'png',
        }
        bytes_data = base64.b64decode(base64_str)
        for header, img_type in signatures.items():
            if bytes_data.startswith(header):
                return img_type
        return 'png'


class ImageProcessor(BaseModalityProcessor):
    """图像处理器"""

    def __init__(self, processor_config: DocParseConfig):
        if processor_config.image_strategy is None:
            raise RuntimeError('Image strategy is not specified in DocParseConfig.')
        super().__init__(processor_config)
        from kbx.kbx import KBX
        self.client_config, self.client = KBX.get_ai_model_config_and_client(
            processor_config.image_strategy.vision_model,
            user_id=self.config.user_ctx.user_id
        )
        self.prompts_mapping = {
            '统计图表': self.prompts['statistical_chart_description'].text,
            '流程图': self.prompts['flowchart_description'].text,
            '系统架构图': self.prompts['system_architecture_description'].text
        }

    def image_classification(self, image_b64: str) -> str:
        classification_prompt = self.prompts['image_classification'].text
        img_type = self._get_image_type(image_b64)
        content = [
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/{img_type};base64,{image_b64}"
                }
            },
            {
                "type": "text",
                "text": classification_prompt
            }
        ]
        classification_res = self.client.chat(
            self.client_config,
            messages=[
                {"role": "system", "content": "你是一个多模态大模型，任务是帮助用户分析图像属于某个类别，请仔细辨别图像并作出准确回答。"},
                {"role": "user", "content": content}
            ],
        ).choices[0].message.content
        return classification_res

    def process_doc_element(self, elem: DocElement, image_loader: Callable[[str], str]):
        if elem.type != DocElementType.FIGURE or not elem.data_file_path:
            return

        if self.config.image_strategy.type == ImageEmbeddingStrategy.VLM_TEXT_EMBEDDING:
            image_b64 = image_loader(elem.data_file_path)
            file_type = elem.meta_data.get('file_type', '')
            ppt_img = True if file_type in ['ppt', 'pptx', 'slides'] else False
            if ppt_img:
                description_prompt = self.prompts['PPT_description'].text
            else:
                image_type = self.image_classification(image_b64)
                logger.debug(f"待解析图像类型为{image_type}")
                description_prompt = self.prompts_mapping.get(
                    image_type,
                    self.prompts['general_img_description'].text).format(elem.image_caption)

            response_text = self.convert_to_text(image_b64, image_prompt=description_prompt)
            elem.content_description = response_text

    def convert_to_text(self, image_b64: str, **kwargs) -> str:
        """使用大模型将图像内容转换为文本描述
        Args:
            image_b64 (str): base64编码的图像数据
        Returns:
            str: 转换后的文本
        """
        image_prompt = kwargs.get('image_prompt', '')
        img_type = self._get_image_type(image_b64)
        content = [
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/{img_type};base64,{image_b64}"
                }
            },
            {
                "type": "text",
                "text": image_prompt
            }
        ]
        response_text = self.client.chat(
            self.client_config,
            messages=[
                {"role": "system", "content": "你是一个多模态大模型，任务是将图像中的关键信息转化为自然语言描述，请仔细观察图像并作出准确回答。"},
                {"role": "user", "content": content}
            ],
        ).choices[0].message.content
        return response_text


class VideoProcessor(BaseModalityProcessor):
    """视频处理器"""

    def __init__(self, processor_config: DocParseConfig):
        if processor_config.video_strategy is None:
            raise RuntimeError('Video strategy is not specified in DocParseConfig.')
        super().__init__(processor_config)
        from kbx.kbx import KBX
        self.client_config, self.client = KBX.get_ai_model_config_and_client(
            processor_config.video_strategy.vision_model,
            user_id=self.config.user_ctx.user_id
        )
        self.format_mapping = {
            'png': {
                'format': 'PNG',
                'quality_range': (0, 9),
                'default_quality': 3
            },
            'jpg': {
                'format': 'JPEG',
                'quality_range': (0, 100),
                'default_quality': 85
            },
        }
        format_config = self.format_mapping[self.config.video_strategy.frame_type]
        self.__dict__.update(format_config)
        if not self.quality_range[0] <= self.config.video_strategy.quality_level <= self.quality_range[1]:
            logger.error(f'检测到无效的PNG质量级别{self.config.video_strategy.quality_level}，有效范围为{self.quality_range}，\
                          系统将使用默认质量级别{self.default_quality}继续处理。')
            self.config.video_strategy.quality_level = self.default_quality

    def extract_frames(self, vdata: BytesIO, num_frames: int) -> List[str]:
        with av.open(vdata) as vid_container:
            stream = vid_container.streams.video[0]
            fps = stream.base_rate
            total_time_in_second = stream.duration * 1.0 * stream.time_base
            frame_count = int(total_time_in_second * fps)

            if fps == 0 or frame_count == 0:
                logger.error(f'视频文件{vdata.name}无法正常读取')
                return []
            if frame_count < num_frames:
                logger.error(f"无法从视频文件中采样足够的帧数，文件名称:{vdata.name}，需要采样帧数:{num_frames}，文件总帧数:{frame_count}")
                return []

            images = []
            frame_indices = np.linspace(0, frame_count - 1, num_frames, dtype=int)

            for idx, frame in enumerate(vid_container.decode(video=0)):
                if idx in frame_indices:
                    with BytesIO() as output:
                        frame.to_image().save(
                            output,
                            format=self.format,
                            quality=self.config.video_strategy.quality_level)
                        images.append(base64.b64encode(output.getvalue()).decode('utf-8'))

        return images

    def process_doc_element(self, elem: DocElement, **kwargs):
        if elem.type != DocElementType.VIDEO:
            return

        if self.config.video_strategy.type == VideoEmbeddingStrategy.VIDEO2TEXT_TEXT_EMBEDDING:
            fn_open = kwargs.get('fn_open', None)
            if fn_open is None:
                raise RuntimeError('未提供fn_open参数，请提供fn_open参数用于读取文件！')

            with fn_open(elem.data_file_path, 'rb', encoding=None) as video_data:
                video_file_name = elem.data_file_path.split('/')[1]
                response_text = self.convert_to_text(video_data, video_file_name=video_file_name)

                elem.content_description = response_text

    def convert_to_text(self, video_data: BytesIO, **kwargs) -> str:
        video_file_name = kwargs.get('video_file_name', None)
        request_content = []
        images_base64 = self.extract_frames(video_data, self.config.video_strategy.num_frames)
        if not images_base64:
            return ''

        for img_base64 in images_base64:
            request_content.append(
                {
                    "type": "image_url",
                            "image_url": {
                                "url": f"data:image/{self.format.lower()};base64,{img_base64}"
                            }
                },
            )
        caption_prompt = self.prompts['video_caption'].text.format(video_file_name)
        request_content.append(
            {
                "type": "text",
                "text": caption_prompt
            }
        )
        response_text = self.client.chat(
            self.client_config,
            messages=[
                {"role": "user", "content": request_content},
            ],
        ).choices[0].message.content
        return response_text


class AudioProcessor(BaseModalityProcessor):
    """音频处理器"""

    def __init__(self, processor_config: DocParseConfig):
        if processor_config.audio_strategy is None:
            raise RuntimeError('Audio strategy is not specified in DocParseConfig.')
        super().__init__(processor_config)
        from kbx.kbx import KBX
        self.audio_config, self.audio_client = KBX.get_ai_model_config_and_client(
            processor_config.audio_strategy.voice_model,
            user_id=self.config.user_ctx.user_id
        )
        self.refinement_config, self.refinement_client = KBX.get_ai_model_config_and_client(
            processor_config.audio_strategy.refinement_model,
            user_id=self.config.user_ctx.user_id
        )

    def process_doc_element(self, elem: DocElement, **kwargs):
        if elem.type != DocElementType.AUDIO:
            return

        if self.config.audio_strategy.type == AudioEmbeddingStrategy.SPEECH2TEXT_TEXT_EMBEDDING:
            fn_open = kwargs.get('fn_open', None)
            if fn_open is None:
                raise RuntimeError('未提供fn_open参数，请提供fn_open参数用于读取文件！')

            with fn_open(elem.data_file_path, mode='rb', encoding=None) as audio_data:
                response_text = self.convert_to_text(audio_data)

                elem.text = response_text

    def convert_to_text(self, audio_data: BytesIO, **kwargs) -> str:
        response_text = self.audio_client.speech2text(self.audio_config, audio_file=audio_data, language='zh')
        if self.config.audio_strategy.refinement_model:
            response_text = self.refinement_client.chat(
                self.refinement_config,
                messages=[
                    {"role": "system", "content": self.prompts['asr_optimization'].text},
                    {"role": "user", "content": response_text}
                ],
            ).choices[0].message.content

        return response_text


class CodeProcessor(BaseModalityProcessor):
    """代码处理器"""
    def __init__(self, processor_config: DocParseConfig):
        if processor_config.code_strategy is None:
            raise RuntimeError(f'Invalid code strategy in DocParseConfig: {processor_config.code_strategy}')
        super().__init__(processor_config)
        from kbx.kbx import KBX
        self.code_config, self.code_client = KBX.get_ai_model_config_and_client(
            name=processor_config.code_strategy.code_summarizer,
            user_id=self.config.user_ctx.user_id,
        )

    def process_doc_element(self, doc_element: DocElement, **kwargs) -> None:
        if doc_element.type != DocElementType.CODE_BLOCK:
            return

        system_prompt = self.prompts['code_summary'].text
        prompt = doc_element.text
        summary = self.code_client.chat(
            self.code_config,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
        ).choices[0].message.content

        doc_element.content_description = summary

    def convert_to_text(self, multimodal_data: Union[str, BytesIO], **kwargs) -> str:
        pass
