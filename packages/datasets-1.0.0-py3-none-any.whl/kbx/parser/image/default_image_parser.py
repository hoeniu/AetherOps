import os
from typing import List
from kbx.datastore.file.file_base import BaseFileDS
from kbx.parser.base_parser import BaseParser
from kbx.parser.types import DocParseConfig
from kbx.common.types import DocData, DocElement, DocElementType
from kbx.common.utils import generate_new_id


class DefaultImageParser(BaseParser):
    """
    默认图像解析器，继承自BaseParser，用于解析常见图像格式并提取视觉语言模型(VLM)特征。

    该解析器是图像文件解析的默认实现，支持png、jpg、jpeg和webp格式，基于图像处理进行解析，一般需要搭配VLM，否则只是单纯的提取图片数据。

    支持解析图像文件中的以下内容：

    - 常见图像格式读取
    - 视觉语言模型(VLM)特征提取
    - 自动生成图像描述
    - 图像元数据提取

    不支持的功能：

    - 复杂图像处理（如目标检测、分割）
    - 图像质量评估
    - 图像格式转换
    - 大尺寸图像分块处理
    - 图像水印处理
    """
    def __init__(self, config: DocParseConfig, file_ds: BaseFileDS = None):
        super().__init__(config, file_ds)

    @staticmethod
    def file_extensions() -> List[str]:
        return ['.png', '.jpg', '.jpeg', 'webp']

    @staticmethod
    def postprocess_steps() -> List[str]:
        return ['image']

    def _parse(self, file_path: str, doc_id: str) -> DocData:
        doc = DocData(doc_id=doc_id,
                      file_name=os.path.basename(file_path),
                      file_path=file_path)
        doc.doc_elements = [DocElement(
            doc_element_id=generate_new_id(),
            type=DocElementType.FIGURE,
            data_file_path=file_path,
            image_caption=os.path.splitext(os.path.basename(file_path))[0])]
        return doc
