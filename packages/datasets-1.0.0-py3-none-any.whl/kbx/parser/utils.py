"""
Proxy requests
"""
import time

import httpx
import pandas as pd

from kbx.common.logging import logger


DEFAULT_MAX_RETRIES = 3

BACKOFF_FACTOR = 0.5
STATUS_FORCELIST = [429, 500, 502, 503, 504]


def make_request(method, url, max_retries=DEFAULT_MAX_RETRIES, **kwargs):
    if "allow_redirects" in kwargs:
        allow_redirects = kwargs.pop("allow_redirects")
        if "follow_redirects" not in kwargs:
            kwargs["follow_redirects"] = allow_redirects

    if "timeout" not in kwargs:
        kwargs["timeout"] = httpx.Timeout(
            timeout=5,
            connect=5,
            read=5,
            write=5,
        )

    retries = 0
    while retries <= max_retries:
        try:
            with httpx.Client() as client:
                response = client.request(method=method, url=url, **kwargs)

            if response.status_code not in STATUS_FORCELIST:
                return response
            else:
                logger.warning(f"Received status code {response.status_code} for URL {url} which is in the force list")

        except httpx.RequestError as e:
            logger.warning(f"Request to URL {url} failed on attempt {retries + 1}: {e}")

        retries += 1
        if retries <= max_retries:
            time.sleep(BACKOFF_FACTOR * (2 ** (retries - 1)))

    raise Exception(f"Reached maximum retries ({max_retries}) for URL {url}")


def httpx_get(url, max_retries=DEFAULT_MAX_RETRIES, **kwargs):
    return make_request("GET", url, max_retries=max_retries, **kwargs)


def httpx_post(url, max_retries=DEFAULT_MAX_RETRIES, **kwargs):
    return make_request("POST", url, max_retries=max_retries, **kwargs)


def httpx_put(url, max_retries=DEFAULT_MAX_RETRIES, **kwargs):
    return make_request("PUT", url, max_retries=max_retries, **kwargs)


def httpx_patch(url, max_retries=DEFAULT_MAX_RETRIES, **kwargs):
    return make_request("PATCH", url, max_retries=max_retries, **kwargs)


def httpx_delete(url, max_retries=DEFAULT_MAX_RETRIES, **kwargs):
    return make_request("DELETE", url, max_retries=max_retries, **kwargs)


def httpx_head(url, max_retries=DEFAULT_MAX_RETRIES, **kwargs):
    return make_request("HEAD", url, max_retries=max_retries, **kwargs)


def download_image_as_bytes(url: str) -> bytes:
    """
    Helper function to download image and return bytes.
    """
    try:
        response = httpx_get(url)
        if response.status_code == 200:
            return response.content
        else:
            logger.warning(f"Failed to download image from {url}. Status code: {response.status_code}")
            return None
    except Exception as e:
        logger.warning(f"Error downloading image from {url}: {e}")
        return None


def postprocess_table_data(table_data: list[list[str]]) -> list[list[str]]:
    """
    Postprocess table data
    Args:
        table_data (list[list[str]]): table data

    Returns:
        list[list[str]]: proprocessed table data
    """
    data = pd.DataFrame(table_data)

    # Drop empty rows and columns
    data = data.dropna(how='all')
    data.dropna(axis=1, how='all', inplace=True)

    # 将 None 替换为空字符串
    data.fillna("", inplace=True)

    # Remove duplicate rows and columns
    data = data.drop_duplicates()
    data = data.T.drop_duplicates().T

    data = remove_title_rows(data)

    data = data.astype(str)

    return data.values.tolist()


def remove_title_rows(data):
    """
    去除表格标题行（通过合并单元格占用整行，导致某一行所有列的值相同或全为空，
    或者只有某一列有值，其余列的内容为空字符串）。
    """
    # 如果数据为空，或者只有一列，则直接返回
    if data is None or len(data) == 0 or len(data.columns) == 1:
        return data

    # 找到所有可能是标题行的索引
    title_rows = []
    for index, row in data.iterrows():
        # 检查是否所有单元格的值相同、全为空，或者只有一个单元格有值，其余为空字符串
        non_empty_cells = row[row != '']
        unique_values = non_empty_cells.dropna().unique()

        # 条件 1: 全为空的行
        if len(non_empty_cells) == 0:
            title_rows.append(index)
            continue

        # 条件 2: 所有非空单元格的值都相同
        if len(unique_values) == 1 and len(non_empty_cells) > 1:
            title_rows.append(index)
            continue

        # 条件 3: 只有一个单元格有值，其余为空字符串
        if len(non_empty_cells) == 1:
            title_rows.append(index)
            continue

        # 如果以上条件都不满足，则认为遇到了数据行，停止搜索标题行
        break

    # 删除标题行
    data = data.drop(index=title_rows)

    # 重置索引
    data.reset_index(drop=True, inplace=True)

    return data
