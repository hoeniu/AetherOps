import os
import json
from typing import List, Dict, Literal

from pydantic import Field
from jinja2 import Template, meta, Environment
from kbx.common.types import KBXBaseModel


class Prompt(KBXBaseModel):
    """prompt当前支持的字段"""
    text: str = Field(..., description="prompt模板内容")
    stops: List[str] = Field(default_factory=list, description="停止符列表")

    def __call__(self, template_type: Literal['text', 'jinja2'],
                 **kwargs: Dict[str, str]) -> str:
        render_methods = {
            "text": lambda: self.text.format(**kwargs),
            "jinja2": lambda: Template(self.text).render(**kwargs)
        }
        if template_type.lower() not in render_methods:
            raise ValueError(
                f"Unsupported template type: {template_type}. Available types: {', '.join(render_methods.keys())}"
            )
        if template_type.lower() == "jinja2":
            # 校验jinja2模板必要参数是否传递
            env = Environment()
            template_vars = meta.find_undeclared_variables(env.parse(
                self.text))
            missing_vars = list(template_vars - kwargs.keys())
            if missing_vars:
                raise ValueError(
                    f"Missing required template variables: {', '.join(missing_vars)}. "
                    f"Ensure all required variables are provided in 'kwargs'.")
        return render_methods[template_type.lower()]()


def get_category_prompts_old(
    category: str,
    encoding: str = "utf-8"
) -> Dict[str, Prompt]:
    """读取并校验prompt配置

    Args:
        category (str): prompt种类, 当前可选为: graph/parser/structured/dynamic_doc/evaluator/select_docs
        encoding (str, optional): json读取时的编码. 默认为: utf-8.

    Returns:
        Dict[str, Prompt]: prompt的内容信息
    """
    import warnings
    warnings.warn(
        "get_category_prompts_old is deprecated and will be removed in a future version. "
        "Please use get_category_prompts instead.",
        DeprecationWarning,
        stacklevel=2
    )

    prompts_root_dir = os.path.join(os.path.dirname(__file__), "prompts")
    category_to_file = {}
    for prompts_file in os.listdir(prompts_root_dir):
        category_to_file[prompts_file.split('.')[0]] = os.path.join(
            prompts_root_dir, prompts_file)

    if category not in category_to_file:
        raise ValueError(
            f"Unknown prompt category: '{category}'. Valid options are: {', '.join(category_to_file.keys())}"
        )

    prompts_file = category_to_file[category]

    prompts = {}
    with open(prompts_file, "r", encoding=encoding) as file:
        raw_prompts = json.load(file)

        for key, value in raw_prompts.items():
            prompts[key] = Prompt(**value)

    return prompts


def get_category_prompts(category: str) -> Dict[str, Prompt]:
    """从py文件读取并校验prompt配置

    Args:
        category (str): prompt种类, 当前可选为: graph/parser/structured/dynamic_doc/evaluator/select_docs

    Returns:
        Dict[str, Prompt]: prompt的内容信息
    """
    # 根据category动态进行prompt文件导入，并把里面定义的所有prompt模板以字典格式返回
    import importlib
    module_name = f'kbx.common.prompts.{category}'
    try:
        mod = importlib.import_module(module_name)
    except ImportError:
        raise ValueError(f"Unknown prompt category: '{category}'.")
    prompts = {}
    for name, value in mod.__dict__.items():
        if name.startswith('_'):
            continue
        if isinstance(value, Prompt):
            prompts[name] = value
        elif isinstance(value, str):
            prompts[name] = Prompt(text=value)
        else:
            raise RuntimeError(f'Invalid prompt in {module_name}, prompt {name}: "{value}"')
    return prompts
