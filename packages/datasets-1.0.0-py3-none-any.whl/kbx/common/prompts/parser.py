image_classification = """
请对提供的图片进行分类，具体的图像类别及各自特征如下：
1. 统计图表：主要用于展示数据之间的关系、趋势或分布情况，包括饼状图、柱状图、折线图、散点图等。
2. 流程图：一种图形化的表示方法，主要用于展示过程的步骤、决策点以及各个步骤之间的逻辑关系。
3. 系统架构图：一种高层次的图表，用于展示系统的整体结构、主要组件及其之间的关系和交互方式。
要求：返回文本中应仅包含['统计图表'、'流程图'、'系统架构图']几个选项中的一个，不要输出多余文本。
"""

statistical_chart_description = """
请根据提供的图像及其图注"{}"，将其转换为自然语言描述。我期望的描述应该包括但不限于：主要的数据趋势、重要的数据点以及任何值得注意的模式或异常。
要求：
1. 仔细观察图像，不要遗漏任何关键信息
2. 确保描述清晰易懂
"""

flowchart_description = """
请根据提供的图像及其图注"{}"，将其转换为自然语言描述。我的目的是帮助用户在没有查看流程图的情况下也能理解整个过程。描述应包括流程的起点和终点、每个主要步骤、决策节点以及任何循环或分支。
要求：
1. 仔细观察图像，明确流程图中每个环节的关键
2. 确保描述逻辑清晰，易于理解
"""

system_architecture_description = """
请根据提供的图像及其图注"{}"，将其转换为自然语言描述。该描述旨在为非技术人员提供对系统工作方式的基本理解，同时也为技术团队提供详细的参考。
要求：
1. 确保描述中包含系统的主要组件、组件间的交互方式、使用的技术和协议、安全措施以及系统的设计特点。
2. 不要遗漏系统架构中的任何模块
"""

general_img_description = """
请根据提供的图像及其图注"{}"，将其转换为自然语言描述。该描述将被用作RAG系统知识库的一部分，此描述旨在提高基于文本的检索效率，并增强模型对图像内容的理解。
要求：
1. 仔细观察图像，确保描述中包含图像的主要内容和特征。
2. 如果适用，请使用有助于机器理解的技术术语或者专业概念对图像进行描述
"""

asr_optimization = """
以下这段文字是通过语音识别方法得到的转录结果，其中可能包含一些错字或者病句的地方，帮我重新整理一下。
要求：
1. 维持原有信息量
2. 尽量减少口语化表达
3. 根据上下文语义改正其中的错字或病句
4. 不要改变原始文本的表达逻辑
5. 不需要额外添加总结文字
"""

video_caption = """
请根据提供的视频帧，为我生成一段针对该视频片段的详细自然语言描述，用于建立RAG系统中的知识库。
请注意：这个视频片段来源于名为"{}"的视频文件。
要求：
1. 全面捕捉细节：不要忽略视频画面中的任何细节。
2. 文字与字符说明：如果视频画面中有任何文字或字符，请结合这些文字或字符进行描述。
3. 利用文件名信息：如果判断视频文件名称中存在有关视频主体的关键信息，在生成描述时要进行结合。
4. 考虑上下文关联：处理每个视频片段时，考虑前后帧的关联关系，生成更完整符合逻辑的描述。
"""

PPT_description = """
请根据提供的PPT页面图像，为我生成一段详细的自然语言描述，用于建立RAG系统中的知识库。
这段描述需要满足以下要求：

1. **全面性**：涵盖PPT页面上的所有信息，包括但不限于标题、副标题、正文文本、列表项、图表、图片说明以及任何注释或补充信息。
2. **准确性**：忠实于原始PPT内容，不添加或遗漏任何关键信息。
3. **逻辑性**：按照合理的顺序组织信息，使描述符合逻辑流程，易于理解。
4. **细节性**：对于图表和图形，请详细描述其类型（如柱状图、饼图）、所表示的数据趋势或关系，以及重要数据点。
5. **可读性**：使用流畅、易懂的语言表达，适当分段以增强阅读体验。
"""

code_summary = """
你是一位专业的文档语义理解专家，尤其擅长从各种类型的文本块中提取核心语义信息，并生成简洁、信息丰富的摘要，**目的是为了最大化后续基于向量 embedding 的检索准确率**。 你的任务是分析以下文本块（可能包含代码、JSON、YAML 或其他结构化/非结构化内容），并提
  其最核心的语义信息，生成高质量的摘要。

请按照以下步骤操作，并**始终以提升检索准确率为最高目标**：

1. **内容类型识别 (Content Type Detection):**  首先判断文本块的内容类型。可能的类型包括：
    * `function` (函数代码)
    * `class` (类代码)
    * `json` (JSON 数据)
    * `yaml` (YAML 数据)
    * `code_snippet` (通用代码片段，无法明确归类为函数或类)
    * `data_snippet` (通用数据片段，无法明确归类为 JSON 或 YAML，例如 CSV 片段、纯文本数据等)
    * `unknown` (无法识别类型)

2. **核心信息提取与摘要生成 (Core Information Extraction & Summary Generation):**  根据识别的内容类型，采取不同的策略提取核心信息并生成摘要。**摘要应该侧重于表达文本块的核心语义和主题，以便在向量空间中能够准确地与其他相关内容聚类。**

    * **`function`, `class`, `code_snippet` (代码类型):**
        * **名称 (Name):** 提取函数名、类名或尝试为代码片段赋予一个描述性名称。
        * **核心功能 (Core Functionality):**  用简洁的语言概括代码块的核心功能和作用。  **重点描述其解决的问题、实现的目标，以及关键的操作或算法。 避免过于细节的输入输出描述，除非它们对于理解核心功能至关重要。**
        * **关键词/标签 (Keywords/Tags):**  提取或生成 3-5 个最能代表这段代码核心主题的关键词或标签，例如 "PDF解析", "数据清洗", "机器学习模型训练", "API 调用", "权限验证" 等。 **关键词应着重于语义层面，而非具体的语法或实现细节。**

    * **`json`, `yaml`, `data_snippet` (数据类型):**
        * **数据主题 (Data Theme):** 确定这段数据描述或代表的核心主题或领域。 例如 "用户配置信息", "API 请求参数", "产品目录数据", "地理位置信息" 等。
        * **关键数据元素 (Key Data Elements):**  识别并列举数据中最重要的几个字段或属性，以及它们的含义或作用。 **关注那些能够体现数据核心内容和用途的字段。**
        * **数据结构特点 (Data Structure Characteristics):**  简要描述数据的结构特点，例如 "键值对结构", "嵌套列表", "树形结构", "表格数据" 等。
        * **关键词/标签 (Keywords/Tags):**  提取或生成 3-5 个最能代表这段数据核心主题的关键词或标签，例如 "用户数据", "配置管理", "API", "地理信息", "产品数据" 等。 **关键词应着重于数据所代表的领域和用途。**

    * **`unknown` (未知类型):**  如果无法识别类型，则尝试进行一般性的语义理解，提取文本块的主题和关键词。  摘要可以更偏向于概括文本内容，并标注类型为 `unknown`。

3. **JSON 输出格式:**  将提取的信息组织成 JSON 格式的数组。

```json
[
  {
    "type": "[内容类型: function, class, json, yaml, code_snippet, data_snippet, unknown]",
    "name": "[名称，代码类型适用]",
    "summary": "[根据内容类型生成的摘要]",
    "keywords": ["[关键词1]", "[关键词2]", "[关键词3]", "..."]
  },
  // ... 更多文本块摘要
]
```

**请分析以下文本块，并严格按照上述步骤和 JSON 格式生成摘要，务必以提升检索准确率为最高目标:**

```text
[此处粘贴你需要摘要的文本块，可能是代码、JSON、YAML 等]
```
"""

doc_summary = """
你是一个专业的内容摘要生成助手，目标是从输入的文档中提取关键信息，生成一个**简短但全面**的摘要，用于支持基于检索增强生成（RAG）系统的过滤和检索任务。

文档可能包含有效的目录信息：
{}

请按照以下步骤操作，并**始终以提升检索准确率为最高目标**：

1. 如果文档目录信息有效，先通过目录了解文档的主要结构和主题，这将帮助你确定哪些部分是最重要的，以及如何构建一个涵盖全文核心观点的摘要。
2. 全面阅读文档，理解文档的整体结构和内容。
3. 提取文档中的核心信息和关键知识点。
4. 用不超过5句话总结文档的核心内容，确保语言简洁、清晰。
"""

VLM_PDF_to_HTML_base = '''You are an AI specialized in recognizing and extracting text from images. Your mission is to analyze the image document and generate a complete HTML document that accurately represents all content while maintaining user privacy and data integrity.

Requirements:
1. Document Structure:
   - Must include complete HTML structure with <html>, <head>, <body> tags
   - Use appropriate heading tags (h1-h6) for document hierarchy
   - Wrap paragraphs in <p> tags
   - Use <ul>, <ol>, <li> for lists
   - Use <table>, <tr>, <td> for tables

2. Content Processing:
   - Extract and include ALL visible text content
   - Merge sentences in the same paragraph
   - Preserve original formatting and structure
   - For tables, merge cells with identical content
   - Retain figure and table captions
   - Include bounding box coordinates for images and tables

3. Formatting:
   - Each HTML tag should occupy one line
   - No extra line breaks or symbols
   - No extra commas
   - Preserve special characters using proper HTML entities

4. Quality Assurance:
   - Double-check for any missed content
   - Ensure all text is properly enclosed in appropriate tags
   - Verify document structure is complete and valid'''

VLM_PDF_to_HTML_prompt = VLM_PDF_to_HTML_base

VLM_PDF_to_HTML_prompt_contextual = VLM_PDF_to_HTML_base + '''

Additional Requirements for Multi-page Documents:
1. Content Focus:
   - Focus primarily on the first page
   - Only include content from subsequent pages that is directly relevant to the first page
   - Ensure logical flow and continuity between pages

2. Quality Checks:
   - Verify that only relevant content from subsequent pages is included
   - Maintain context and coherence across pages
   - Ensure no important cross-page references are missed'''
