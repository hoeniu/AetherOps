import os
import time
from functools import wraps
from opentelemetry import metrics, trace, context
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader, MetricExporter, MetricExportResult
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SpanExporter, SpanExportResult
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter


class NoOpSpanExporter(SpanExporter):

    def export(self, spans) -> SpanExportResult:
        return SpanExportResult.SUCCESS

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True

    def shutdown(self) -> None:
        pass


class NoOpMetricExporter(MetricExporter):

    def export(self, metrics, timeout_millis: float = 10_000, **kwargs) -> MetricExportResult:
        return MetricExportResult.SUCCESS

    def force_flush(self, timeout_millis: float = 10_000) -> bool:
        return True

    def shutdown(self, timeout_millis: float = 30_000, **kwargs) -> None:
        pass


# 从环境变量中获取
# SERVICE_NAME == service.name
attributes_str = os.getenv("OTEL_RESOURCE_ATTRIBUTES", "service.name=kbx-restful-svc")
atrributes_dict = {key: value for pair in attributes_str.split() for key, value in [pair.split("=")]}
resource = Resource(attributes={
    SERVICE_NAME: atrributes_dict[SERVICE_NAME]
})
endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "")  # 获取环境变量值
if endpoint == "":
    otlp_span_exporter = NoOpSpanExporter()
    otlp_metric_exporter = NoOpMetricExporter()
else:
    # Configure OTLP Span Exporter to send traces to OpenTelemetry Collector
    otlp_span_exporter = OTLPSpanExporter(endpoint=endpoint, insecure=True)
    otlp_metric_exporter = OTLPMetricExporter(endpoint=endpoint, insecure=True)

# Configure TracerProvider for traces
tracer_provider = TracerProvider(resource=resource)
trace.set_tracer_provider(tracer_provider)
batch_span_processor = BatchSpanProcessor(otlp_span_exporter)
trace.get_tracer_provider().add_span_processor(batch_span_processor)

# Configure MeterProvider for metrics
metric_reader = PeriodicExportingMetricReader(
    exporter=otlp_metric_exporter, export_interval_millis=1000)
meter_provider = MeterProvider(resource=resource, metric_readers=[metric_reader])
metrics.set_meter_provider(meter_provider)


# 定义 __all__，指定公共接口
__all__ = ['context_wrapper', 'get_tracer', 'get_meter', 'call_counter', 'duration_histogram', 'record_func_metrics']


# 方便传递otel所需的上下文信息
def context_wrapper(current_context, func, *args, **kwargs):
    token = context.attach(current_context)
    res = func(*args, **kwargs)
    context.detach(token)
    return res


def get_tracer(module_name: str):
    return trace.get_tracer(module_name)


def get_meter(module_name: str):
    return metrics.get_meter(module_name)


meter = get_meter(__name__)
# 创建 Counter 用于记录方法调用次数
call_counter = meter.create_counter(
    name="call_counter",
    description="Number of times retrieve was called",
)
# 创建 Histogram 用于记录方法的耗时
duration_histogram = meter.create_histogram(
    name="duration_histogram",
    description="Duration of method calls in milliseconds",
    unit="ms"
)


def record_func_metrics(func):
    """装饰器：记录方法的执行时间并上报到 Histogram"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        duration_ms = (time.time() - start_time) * 1000  # 转换为毫秒
        duration_histogram.record(duration_ms, {"method": func.__name__})
        return result
    return wrapper


def add_trace_if_necessary(func):
    """装饰器：如果需要，就添加一个trace的上下文"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        current_span = trace.get_current_span()
        if current_span is None or isinstance(current_span, trace.NonRecordingSpan):
            tracer = get_tracer(__name__)
            with tracer.start_as_current_span(""):
                result = func(*args, **kwargs)
                return result
        else:
            result = func(*args, **kwargs)
            return result
    return wrapper


def get_context():
    """用于获取跨线程追踪时传递的上下文, 配合context_wrapper使用"""
    return context.get_current()


def try_get_trace_id() -> str:
    current_span = trace.get_current_span()
    if current_span is None or isinstance(current_span, trace.NonRecordingSpan):
        return ""
    else:
        span_context = current_span.get_span_context()
        # 通常情况，不会有返回0. 即使出现也可以通过0值作出warning.
        trace_id: int = span_context.trace_id if span_context.is_valid else 0
        return f"{trace_id:032x}"
