DEFAULT_TENANT_NAME: str = 'admin'
"""默认租户名称"""

DEFAULT_TENANT_ID: str = 'xeMEKp2p'
"""默认租户ID"""

DEFAULT_USER_NAME: str = 'admin'
"""默认用户名称"""

DEFAULT_USER_ID: str = '5YZsMzEB'
"""默认用户ID"""

DEFAULT_NAMESPACE: str = "default"
"""默认namespace"""

DEFAULT_INDEX_TYPE: str = "default"
"""默认使用者的index_type"""

DEFAULT_SECRET_KEY: str = "sk-9f73s3ljTXVcMT3Blb3ljTqtsKiGHXVcMT3BlbkFJLK7U"
"""默认密钥"""
