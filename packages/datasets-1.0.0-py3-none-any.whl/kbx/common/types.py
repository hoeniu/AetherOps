from __future__ import annotations
import os
import enum
from typing import Optional, Dict, Any, List, Literal, Union, Iterable, Set, ClassVar
from kbx.parser.html.utils import parse_html_table, table_2d_list_to_html
from kbx.parser.markdown.utils import parse_md_table, table_2d_list_to_md
from pydantic import BaseModel, Field, field_validator, model_validator, field_serializer, ConfigDict, SerializationInfo
from datetime import datetime
import json


class KBXBaseModel(BaseModel):
    """KBX所有数据模型类的基类"""

    # NOTE：这里必须使用ClassVar，否则在子类中会报错
    # 已知的历史废弃字段名，可以在子类中覆盖或扩展，初始化实例时会自动移除这些字段
    deprecated_fields: ClassVar[Set[str]] = set()

    # 禁止在实例化对象时传入额外（未定义）字段
    model_config = ConfigDict(extra='forbid')

    @model_validator(mode='before')
    @classmethod
    def _remove_deprecated_fields(cls, data: Any) -> Any:
        """
        在验证前移除已知的历史字段，以兼容旧数据。
        """
        if isinstance(data, dict):
            # 如果没有已知的历史字段，直接返回
            if not cls.deprecated_fields:
                return data

            keys_to_remove = set(data.keys()).intersection(cls.deprecated_fields)
            for key in keys_to_remove:
                data.pop(key)

            return data
        # 如果输入不是字典，直接返回
        return data


class DocFileType(enum.Enum):
    """文档文件格式类型"""
    TXT = 'txt'
    MARKDOWN = 'markdown'
    DOCX = "docx"
    PDF = "pdf"
    PPTX = "pptx"
    CSV = "csv"
    EXCEL = "excel"
    HTML = "html"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"

    UNKNOWN = 'unknown'

    @staticmethod
    def get_file_type_by_file_name(file_path: str) -> DocFileType:
        ext = os.path.splitext(file_path)[-1].lower()

        # NOTE: 根据需要可以增删文件后缀选项
        if ext in ['.txt']:
            return DocFileType.TXT
        elif ext in ['.md', '.markdown']:
            return DocFileType.MARKDOWN
        elif ext in ['.docx']:
            return DocFileType.DOCX
        elif ext in ['.pdf']:
            return DocFileType.PDF
        elif ext in ['.pptx']:
            return DocFileType.PPTX
        elif ext in ['.csv']:
            return DocFileType.CSV
        elif ext in ['.xlsx', '.xls']:
            return DocFileType.EXCEL
        elif ext in ['.html', '.htm', '.xhtml']:
            return DocFileType.HTML
        elif ext in ['.jpg', '.png', '.jpeg', '.bmp', '.webp']:
            return DocFileType.IMAGE
        elif ext in ['.mp3', '.flv', '.wav']:
            return DocFileType.AUDIO
        elif ext in ['.mov', '.mp4']:
            return DocFileType.VIDEO
        else:
            return DocFileType.UNKNOWN


class DocElementType(enum.Enum):
    """一般场景下，用于表示文档中一个内容元素类型，对应版面识别中的各种类型
    或者在多模态RAG概念下，可能再包含更加多元的数据类型，如音频、视频等
    """
    TITLE = "title"
    TEXT = "text"
    FIGURE = "figure"
    # FIGURE_NAME = "figure_name"
    TABLE = "table"
    # TABLE_NAME = "table_name"
    # HEADER = "header"
    # FOOTER = "footer"
    # REFERENCE = "reference"
    EQUATION = "equation"
    # PAGE_NUMBER = "page_number"
    CODE_BLOCK = "code_block"

    # 兼容之后的多模态RAG
    AUDIO = "audio"
    VIDEO = "video"


class Table(KBXBaseModel):
    """表格数据类型，支持标准m*n的表格，以及包含单元格合并的非标准表格数据表示。

    此数据结构为KBX知识库特殊设计，主要面向以下使用场景：

    1. 结构化数据库索引（Text2SQL）：
       - 需要将表格数据插入SQL数据库，因此必须支持二维List格式

    2. 作为LLM、Embedding等文本模型输入：
       - 支持多种文本格式（HTML/Markdown/2D List）
       - 格式转换灵活，可根据需求选择合适的表示方式，保持语义完整性，确保模型理解

    3. 作为检索结果输出：
       - 支持多种展示格式，适应不同场景需求
       - Markdown格式适合简单表格展示， HTML格式支持复杂表格（如单元格合并）

    核心特性：

    1. 多格式支持：
       - data_2d：二维列表格式，适合数据处理和SQL操作
       - md：Markdown格式，适合简单表格展示
       - html：HTML格式，支持复杂表格结构

    2. 序列化与反序列化：
       - 序列化选项（通过context参数传递）：
         * fill_all_formats：是否填充所有格式数据，内部使用选择False，外部使用选择True
       - 反序列化自动填充：
         * 从2d_list反序列化时自动填充md和html格式
         * 从html反序列化时自动填充data_2d和md格式
         * 从md反序列化时自动填充data_2d和html格式

    3. 构造方法：
       - from_2d_list：从二维列表创建
       - from_html：从HTML创建，支持解析表头和caption
       - from_md：从Markdown创建，自动处理分隔符

    4. 辅助功能：
       - 表头检测和处理（has_header），表格标题支持（caption）
       - 格式转换和验证
       - 标准化的数据访问接口

    使用建议：

    1. 创建表格：
       - 优先使用 from_xxx 类方法创建实例并指定原始格式（original_format）
       - 明确指定 has_header 和 caption

    2. 数据访问：
       - 序列化时指定 fill_all_formats 以获取所需格式
       - 注意处理可能的格式转换异常

    3. 格式选择：
       - 简单表格优先使用 Markdown
       - 复杂布局（合并单元格）使用 HTML
       - 数据处理场景使用 data_2d

    注意事项：
    - 所有数据均以字符串形式存储，忽略具体数据类型
    - 非标准表格（有单元格合并）可能无法转换为 data_2d 或 md 格式
    - 序列化时注意处理 None 值和格式转换异常
    - 创建实例时必须提供至少一种格式的数据
    - 格式转换可能因表格结构复杂性而失败
    """

    data_2d: Optional[List[List[str]]] = Field(default=None, description="表格的二维数据，如果has_header为True，则第一行为表头")
    md: Optional[str] = Field(default=None, description="markdown格式表格")
    html: Optional[str] = Field(default=None, description="html格式表格")

    # 辅助字段
    has_header: Optional[bool] = Field(default=None, description="表格是否有表头，如果有，则data_2d的第一行为表头。None表示未知")
    caption: Optional[str] = Field(default=None, description="表格的标题")
    original_format: Literal["2d_list", "html", "md"] = Field(
        default="2d_list",
        description="原始表格数据的格式"
    )

    @model_validator(mode='after')
    def fill_missing_formats(self) -> 'Table':
        """如果只提供了部分格式的数据，尝试填充其他格式

        Returns:
            Table: 填充后的表格对象

        Raises:
            ValueError: 当original_format为空或与提供的数据不匹配时抛出异常
        """
        if self.original_format is None:
            raise ValueError("original_format is required!")

        if self.original_format == "2d_list":
            if self.data_2d is None:
                raise ValueError(
                    f"'original_format' is '2d_list', must set 'data_2d' field! "
                    f"Full data: {self.model_dump()}"
                )
            try:
                if self.md is None:
                    self.md = table_2d_list_to_md(self.data_2d, self.has_header)
                if self.html is None:
                    self.html = table_2d_list_to_html(self.data_2d, self.has_header)
            except Exception:
                # 格式转换失败不是致命错误,忽略异常继续执行
                pass
        elif self.original_format == "html":
            if self.html is None:
                raise ValueError(
                    f"'original_format' is 'html', must set 'html' field! "
                    f"Full data: {self.model_dump()}"
                )
            try:
                if self.data_2d is None:
                    caption, has_header, data_2d = parse_html_table(self.html)
                    self.data_2d = data_2d
                    if self.has_header is None:
                        self.has_header = has_header
                    if self.caption is None:
                        self.caption = caption
                if self.md is None:
                    self.md = table_2d_list_to_md(self.data_2d, self.has_header)
                # 如果html中包含合并单元格，无法正常转换为md格式，则直接使用html
                if self.md == '':
                    self.md = self.html
            except Exception:
                pass
        elif self.original_format == "md":
            if self.md is None:
                raise ValueError(
                    f"'original_format' is 'md', must set 'md' field! "
                    f"Full data: {self.model_dump()}"
                )
            try:
                if self.data_2d is None:
                    has_header, data_2d = parse_md_table(self.md)
                    self.data_2d = data_2d
                    if self.has_header is None:
                        self.has_header = has_header
                if self.html is None:
                    self.html = table_2d_list_to_html(self.data_2d, self.has_header)
            except Exception:
                pass
        else:
            raise ValueError(
                f"Invalid 'original_format': {self.original_format}! "
                f"Full data: {self.model_dump()}"
            )
        return self

    @field_serializer('data_2d')
    def serialize_data_2d(
        self,
        value: Optional[List[List[str]]],
        info: SerializationInfo
    ) -> Optional[List[List[str]]]:
        """序列化 data_2d 字段

        Args:
            value: 字段值
            info: 序列化信息，包含 context 等

        Returns:
            Optional[List[List[str]]]: 序列化后的值
        """
        # 从 context 中获取是否需要填充所有格式
        context = info.context or {}
        fill_formats = context.get('fill_all_formats', False)

        # 如果不需要填充所有格式,且原始格式不是2d_list,则返回None
        if not fill_formats and self.original_format != '2d_list':
            return None

        # 如果值不为None,直接返回
        if value is not None:
            return value

        # 需要填充格式且值为None时,尝试从其他格式转换
        if fill_formats:
            try:
                if self.original_format == "html" and self.html:
                    _, _, data_2d = parse_html_table(self.html)
                    return data_2d
                elif self.original_format == "md" and self.md:
                    _, data_2d = parse_md_table(self.md)
                    return data_2d
            except ValueError:
                # 转换失败时返回None
                return None

        return None

    @field_serializer('md')
    def serialize_md(
        self,
        value: Optional[str],
        info: SerializationInfo
    ) -> Optional[str]:
        """序列化 md 字段

        Args:
            value: 字段值
            info: 序列化信息，包含 context 等

        Returns:
            Optional[str]: 序列化后的值
        """
        # 从 context 中获取是否需要填充所有格式
        context = info.context or {}
        fill_formats = context.get('fill_all_formats', False)

        # 如果不需要填充所有格式,且原始格式不是md,则返回None
        if not fill_formats and self.original_format != 'md':
            return None

        # 如果值不为None,直接返回
        if value is not None:
            return value

        # 需要填充格式且值为None时,尝试从其他格式转换
        if fill_formats:
            try:
                if self.original_format == "2d_list" and self.data_2d:
                    return table_2d_list_to_md(self.data_2d, self.has_header, self.caption)
                elif self.original_format == "html" and self.html:
                    _, _, data_2d = parse_html_table(self.html)
                    if data_2d:
                        return table_2d_list_to_md(data_2d, self.has_header, self.caption)
            except ValueError:
                # 转换失败时返回None
                return None
        return None

    @field_serializer('html')
    def serialize_html(
        self,
        value: Optional[str],
        info: SerializationInfo
    ) -> Optional[str]:
        """序列化 html 字段

        Args:
            value: 字段值
            info: 序列化信息，包含 context 等

        Returns:
            Optional[str]: 序列化后的值
        """
        # 从 context 中获取是否需要填充所有格式
        context = info.context or {}
        fill_formats = context.get('fill_all_formats', False)

        # 如果不需要填充所有格式,且原始格式不是html,则返回None
        if not fill_formats and self.original_format != 'html':
            return None

        # 如果值不为None,直接返回
        if value is not None:
            return value

        # 需要填充格式且值为None时,尝试从其他格式转换
        if fill_formats:
            try:
                if self.original_format == "2d_list" and self.data_2d:
                    return table_2d_list_to_html(self.data_2d, self.has_header, self.caption)
                elif self.original_format == "md" and self.md:
                    _, data_2d = parse_md_table(self.md)
                    if data_2d:
                        return table_2d_list_to_html(data_2d, self.has_header, self.caption)
            except ValueError:
                # 转换失败时返回None
                return None

        return None

    @property
    def is_standard(self) -> bool:
        """判断表格是否为标准m*n格式，也就是不存在单元格合并的情况，可以使用二维List方式进行访问

        Returns:
            bool: 是否为标准格式
        """
        return self.data_2d is not None

    @property
    def header(self) -> Optional[List[str]]:
        """如果此表格确定包含表头，则返回表头列表，如果表头不确定是否存在，则返回None

        Returns:
            Optional[List[str]]: 表格表头，如果has_header为False或None则返回None
        """
        if not self.has_header or not self.data_2d or len(self.data_2d) == 0:
            return None
        return self.data_2d[0]

    @property
    def body(self) -> Optional[List[List[str]]]:
        """获取表格主体数据（不含表头）

        Returns:
            Optional[List[List[str]]]: 表格主体数据，如果data_2d为None则返回None
        """
        if not self.data_2d:
            return None
        if self.has_header and len(self.data_2d) > 1:
            return self.data_2d[1:]
        return self.data_2d

    def as_2d_list(self, with_header: bool = True) -> Optional[List[List[str]]]:
        """以二维List格式返回表格数据
        注意，如果原始表格是html格式，且存在单元格合并情况，则可能返回None

        Args:
            with_header (bool, optional): 是否包含表头. Defaults to True.

        Returns:
            Optional[List[List[str]]]: 二维List格式表格数据，如果表格不是标准格式，则返回None
        """
        if not self.is_standard:
            return None
        if with_header:
            return self.data_2d
        else:
            return self.body

    def as_html(self) -> str:
        """以html格式返回表格数据
        此函数一定成功，即使原始表格数据不是html格式

        Returns:
            str: html格式表格数据
        """
        return self.html

    def as_md(self) -> Optional[str]:
        """以markdown格式返回表格数据
        注意，如果原始表格是html格式，且存在单元格合并情况，则可能返回None

        Returns:
            Optional[str]: markdown格式表格数据
        """
        # 只有标准表格才有md格式支持
        return self.md

    def as_str(self, prefer: Literal["md", "html"] = "md") -> Optional[str]:
        """以字符串格式返回表格数据

        Args:
            prefer (Literal[&quot;md&quot;, &quot;html&quot;], optional): 优先返回的表格字符串格式，默认为"md"。

        Returns:
            Optional[str]: 表格字符串数据，如果表格不是标准格式，则返回None
        """
        if prefer == "md":
            # MD格式只有标准表格才有
            return self.md if self.is_standard else self.html
        elif prefer == "html":
            # 所有表格都可以转换为html
            return self.html
        else:
            raise ValueError(f"Invalid prefer value: {prefer}")

    @classmethod
    def from_2d_list(
        cls,
        data: List[List[str]],
        has_header: bool = False,
        caption: Optional[str] = None
    ) -> "Table":
        """从二维List格式数据创建表格对象
        如果输入数据无效，会抛出ValueError异常

        Args:
            data (List[List[str]]): 二维List格式数据
            has_header (bool, optional): 是否有表头. Defaults to False.
            caption (Optional[str], optional): 表格标题. Defaults to None.

        Returns:
            Table: 表格对象

        Raises:
            ValueError: 当输入数据无效时抛出
        """
        # 验证输入数据
        if not data:
            raise ValueError("Empty table data")

        # 检查所有行的列数是否一致
        row_cols = [len(row) for row in data]
        if len(set(row_cols)) != 1:
            raise ValueError("Different column number in table data")

        # 此处仅设置data_2d，其他格式数据由fill_missing_formats方法统一设置
        return cls(
            data_2d=data,
            has_header=has_header,
            caption=caption,
            original_format="2d_list",
        )

    @classmethod
    def from_html(cls, html: str, caption: Optional[str] = None) -> "Table":
        """从html格式数据创建表格对象
        如果输入的html存在语法错误或是非法表格，会抛出ValueError异常

        Args:
            html (str): html格式数据
            caption (Optional[str], optional): 从外部指定一个表格标题，默认为None

        Returns:
            Table: 表格对象

        Raises:
            ValueError: 当输入的html存在语法错误或是非法表格时抛出

        """
        # 基本验证
        if not html:
            raise ValueError("Empty HTML table data")

        # 检查是否包含基本的HTML表格标签
        if "<table" not in html or "</table>" not in html:
            raise ValueError("Invalid HTML table format: missing table tags")

        # 检查是否包含数据行
        if "<tr" not in html or "</tr>" not in html:
            raise ValueError("Invalid HTML table format: missing row tags")

        # 检查是否包含单元格
        if ("<td" not in html and "<th" not in html) or ("</td>" not in html and "</th>" not in html):
            raise ValueError("Invalid HTML table format: missing cell tags")

        # 此处仅设置html，其他格式数据由fill_missing_formats方法统一设置
        return cls(
            original_format="html",
            html=html,
            caption=caption,
        )

    @classmethod
    def from_md(cls, md: str, caption: Optional[str] = None) -> "Table":
        """从markdown格式数据创建表格对象
        如果输入的md存在语法错误或是非法表格，会抛出ValueError异常

        Args:
            md (str): markdown格式数据
            caption (Optional[str], optional): 表格标题. Defaults to None.

        Returns:
            Table: 表格对象

        Raises:
            ValueError: 当输入的md存在语法错误或是非法表格时抛出
        """
        # 基本验证
        if not md:
            raise ValueError("Empty markdown table data")

        # 检查是否包含基本的markdown表格语法
        if "|" not in md:
            raise ValueError("Invalid markdown table format: missing '|' separator")

        # 检查是否至少有一行数据
        lines = [line.strip() for line in md.split("\n") if line.strip()]
        if len(lines) < 1:
            raise ValueError("Invalid markdown table format: no data rows")

        # 此处仅设置md，其他格式数据由fill_missing_formats方法统一设置
        return cls(
            original_format="md",
            md=md,
            caption=caption,
        )


class DocElement(KBXBaseModel):
    """用于表示文档布局中的一个最小单元，可以是标题、正文、表格、图片甚至音频、视频等

    Attributes:

    doc_element_id (str): 该元素的唯一id（该文档内唯一）

    type (DocElementType): 该元素的类型

    text (str): 文本内容（通常对应正文、标题、图注、表注等直接、明确包含的文本，或从图片中OCR识别出的文本）

    content_description (str): 对图片、音频、视频等非文本数据，通过其他方式对其进行理解然后得到的内容描述

    table (Optional[Table]): 表格数据

    image_caption (Optional[str]): 图片的标题

    data_file_path (str): 数据文件路径，例如音频、视频等较大的数据，不适合直接提取到内存或存入数据库中，可以转存到文件存储中，然后在此处记录对应文件路径

    meta_data (Dict[str, Any]): 其他元信息，例如标题级别(title_level: int)、页码(page: int)等
    """
    doc_element_id: str = Field(default='', description="该元素的唯一id（该文档内唯一）")

    type: DocElementType = Field(default=DocElementType.TEXT, description="该元素的类型")

    text: str = Field(default='', description="文本内容（通常对应正文、标题、图注、表注等直接、明确包含的文本，或从图片中OCR识别出的文本）")
    content_description: str = Field(default='', description="对图片、音频、视频等非文本数据，通过其他方式对其进行理解然后得到的内容描述")

    table: Optional[Table] = Field(default=None, description="表格数据")

    image_caption: Optional[str] = Field(default=None, description="图注（image caption）")

    data_file_path: str = Field(
        default='',
        description="图片、音频、视频统一转存到文件存储中，然后在此处记录对应文件路径"
    )
    data_file_raw_path: str = Field(
        default='',
        description="原始文件路径，在文件存储中包含tenant_id/user_id/kb_id前缀的原始路径，主要为url拼接使用，一般由parser的后处理进行统一填写"
    )
    data_file_url: str = Field(
        default='',
        description="文件访问url，原则上通过安全认证的用户可以直接使用此url访问对应文件，一般由parser的后处理进行统一填写"
    )

    meta_data: Dict[str, Any] = Field(default_factory=dict, description="其他元信息，例如标题级别(title_level: int)、页码(page: int)等")
    toctree_node_path: str = Field(default='', description="所在目录树的层级路径，格式为0.1.2.3，第一个0表示根节点")

    # 此类已废弃的字段
    deprecated_fields: ClassVar[Set[str]] = {
        'table_html',
        'table_caption',
    }

    @field_serializer('type')
    def serialize_type(self, type: DocElementType, _info):
        return type.value  # 始终输出 Enum 的值作为字符串

    # 所有类型都需要的公共字段
    _common_fields: ClassVar[Set[str]] = {
        'doc_element_id',
        'type',
        'meta_data',
        'toctree_node_path'
    }

    # 媒体文件相关字段
    _media_fields: ClassVar[Set[str]] = {
        'content_description',
        'data_file_path',
        'data_file_raw_path',
        'data_file_url'
    }

    # 定义每种类型需要输出的字段
    _type_fields_map: ClassVar[Dict[DocElementType, Set[str]]] = {
        DocElementType.TITLE: {'text'},
        DocElementType.TEXT: {'text'},
        DocElementType.TABLE: {'table'},
        DocElementType.EQUATION: {'text'},
        DocElementType.CODE_BLOCK: {'text'},
        DocElementType.FIGURE: {'text', 'content_description', 'image_caption'} | _media_fields,
        DocElementType.AUDIO: {'text', 'content_description'} | _media_fields,
        DocElementType.VIDEO: {'text', 'content_description'} | _media_fields,
    }

    def model_dump(self, **kwargs) -> Dict[str, Any]:
        """重写model_dump方法，根据type选择需要输出的字段"""
        # 获取基础序列化结果
        data = super().model_dump(**kwargs)

        # 获取当前类型需要输出的字段（公共字段 + 类型特定字段）
        fields_to_keep = self._common_fields | self._type_fields_map.get(self.type, set())

        # 只保留需要的字段
        return {k: v for k, v in data.items() if (k in fields_to_keep or v)}

    def model_dump_json(self, **kwargs) -> str:
        """重写model_dump_json方法，确保使用我们的字段过滤逻辑"""
        json_str = super().model_dump_json(**kwargs)
        data = json.loads(json_str)
        # 过滤字段
        fields_to_keep = self._common_fields | self._type_fields_map.get(self.type, set())
        filtered_data = {k: v for k, v in data.items() if (k in fields_to_keep or v)}
        return json.dumps(filtered_data, ensure_ascii=False, indent=kwargs.get('indent', None))


class DocElementCollection(KBXBaseModel):
    """自定义集合类，支持顺序访问和ID查询"""
    elements: List[DocElement] = Field(default_factory=list, description="元素列表")
    id_map: Dict[str, int] = Field(default_factory=dict, description="id_str到index的映射")

    def append(self, element: DocElement) -> None:
        if element.doc_element_id in self.id_map:
            raise ValueError(f"Duplicate doc_element_id: {element.doc_element_id}")
        self.elements.append(element)
        self.id_map[element.doc_element_id] = len(self.elements) - 1

    def extend(self, elements: Iterable[DocElement]) -> None:
        for element in elements:
            self.append(element)

    def insert(self, index: int, element: DocElement) -> None:
        """在指定位置插入元素

        Args:
            index (int): 插入位置
            element (DocElement): 插入元素
        """
        if element.doc_element_id in self.id_map:
            raise ValueError(f"Duplicate doc_element_id: {element.doc_element_id}")
        self.elements.insert(index, element)
        self.id_map[element.doc_element_id] = index
        # 更新插入位置之后所有元素的索引
        for i in range(index + 1, len(self.elements)):
            self.id_map[self.elements[i].doc_element_id] = i

    def __getitem__(self, key: Union[int, str]) -> DocElement:
        if isinstance(key, int):
            return self.elements[key]
        elif isinstance(key, str):
            return self.elements[self.id_map[key]]
        else:
            raise TypeError(f"Expect int or str key for DocElementCollection, given {key} (type: {type(key)})")

    def __iter__(self):
        return iter(self.elements)

    def __len__(self):
        return len(self.elements)

    def __repr__(self):
        return f"DocElementCollection(elements={self.elements})"


class TOCNode(KBXBaseModel):
    """目录树节点（同时表示整棵树）"""
    children: List['TOCNode'] = Field(default_factory=list, description="子节点列表")

    # 核心属性字段
    title: str = Field(default="", description="节点标题，通常指章节标题")
    level_str: str = Field(default="0", description="节点所在的层级，如0.1.2.3")
    self_doc_element_ids: Optional[List[str]] = Field(
        default_factory=list, description="节点本身包含的DocElements列表，包括标题以及非子节点DocElements")
    children_doc_element_ids: Optional[List[str]] = Field(
        default_factory=list, description="子节点包含的DocElements列表")
    # 辅助属性字段
    num_tokens: int = Field(default=0, description="该节点及其所有子节点包含的token总数")
    summary: str = Field(default='', description="节点摘要信息")

    @property
    def doc_element_ids(self):
        return self.self_doc_element_ids + self.children_doc_element_ids


class DocData(KBXBaseModel):
    """所有文档在内存中的标准化数据表示"""
    doc_id: str = Field(default='', description="唯一id（知识库内唯一）")
    file_name: str = Field(default='', description="文件名（包含后缀）")
    file_path: str = Field(default='', description="文档路径")
    file_raw_path: str = Field(
        default='',
        description="原始文件路径，在文件存储中包含tenant_id/user_id/kb_id前缀的原始路径，一般由parser的后处理进行统一填写"
    )
    file_url: str = Field(
        default='',
        description="文件访问url，原则上通过安全认证的用户可以直接使用此url访问对应文件，一般由parser的后处理进行统一填写"
    )
    doc_elements: DocElementCollection = Field(
        default_factory=DocElementCollection,
        description="文档内容数据，支持顺序访问和按doc_element_id查询，"
        "一般为该文档按正常阅读顺序依次遍历的所有内容单元，每个单元可以是标题、正文、表格、图片等"
    )
    doc_toc: TOCNode = Field(
        default_factory=lambda: TOCNode(title="ROOT"),  # 创建虚拟根节点
        description="文档目录树结构（虚拟根节点，实际子节点在children中）"
    )

    def __setattr__(self, name, value):
        if name == "doc_elements" and isinstance(value, list):
            # 如果是给doc_elements赋值一个列表，将其自动转换为DocElementCollection
            collection = DocElementCollection()
            for element in value:
                collection.append(element)
            super().__setattr__(name, collection)
        else:
            super().__setattr__(name, value)

    @model_validator(mode='before')
    @classmethod
    def validate_doc_elements(cls, data):
        if isinstance(data, dict) and "doc_elements" in data and isinstance(data["doc_elements"], list):
            elements_list = data["doc_elements"]
            collection = DocElementCollection()

            for element in elements_list:
                if not isinstance(element, DocElement):
                    raise TypeError(f"列表中的元素 {element} 不是DocElement类型")
                collection.append(element)

            data["doc_elements"] = collection
        return data


class Chunk(KBXBaseModel):
    """对某个文档进行分块后的一个文本块，可能来源于一个或多个普通正文段落、表格md格式、图片ocr结果等
    """
    text: str = Field(default='', description="此文本块的文本数据，后续可能会直接进行embedding提取")
    chunk_id: str = Field(default='', description="chunk唯一id")
    doc_id: str = Field(default='', description="来源文档id")
    doc_element_ids: List[str] = Field(default_factory=list, description="来源DocElement的唯一id")
    meta_data: Dict[str, Any] = Field(default_factory=dict, description="用于记录更加详细的来源信息，如页码、bbx位置等")
    doc_elements: Optional[List[DocElement]] = Field(default=None,
                                                     description="当chunk包含非纯文本数据（如图片、表格、音频、视频等）时，存储对应的原始DocElement对象列表")


class IndexType(str, enum.Enum):
    """索引类型"""
    VECTOR_KEYWORD = "vector_keyword"
    KNOWLEDGE_GRAPH = "knowledge_graph"
    STRUCTURED = "structured"
    DYNAMIC_DOC = "dynamic_doc"


class FileEncoding(KBXBaseModel):
    """A file encoding as the NamedTuple."""

    encoding: Optional[str]
    """The encoding of the file."""
    confidence: float
    """The confidence of the encoding."""
    language: Optional[str]
    """The language of the file."""


class ImageEmbeddingStrategy(enum.Enum):
    NONE = 'None'  # 忽略图片数据，不做特征提取
    OCR_TEXT_EMBEDDING = 'OCRTextEmbedding'  # 图像数据先使用OCR提取文字，然后生成文本Embedding
    VLM_TEXT_EMBEDDING = 'VLMTextEmbedding'  # 图像数据先用VLM生成文字格式的描述，然后生成文本Embedding
    VISION_EMBEDDING = 'VisionEmbedding'  # 图像数据直接使用Vision-Embedding模型进行特征提取，例如Colpali等方案


class AudioEmbeddingStrategy(enum.Enum):
    NONE = 'None'  # 忽略Audio数据，不做特征提取
    SPEECH2TEXT_TEXT_EMBEDDING = 'Speech2TextTextEmbedding'  # 音频数据先使用speech2text提取文字，然后生成文本Embedding


class VideoEmbeddingStrategy(enum.Enum):
    NONE = 'None'  # 忽略Video数据，不做特征提取
    VIDEO2TEXT_TEXT_EMBEDDING = 'Video2TextTextEmbedding'  # 视频数据先使用video2text提取文字，然后生成文本Embedding


class BaseDSConfig(KBXBaseModel):
    type: str = Field(default="", description="")
    # url, username, password.
    connection_kwargs: Dict[str, Any] = Field(default_factory=dict, description="")


class TaskIQConfig(BaseDSConfig):
    num_workers: int = Field(default=1, description="任务执行的worker数量")


class FileDSConfig(BaseDSConfig):
    # TODO: default方案待设计、实现
    type: str = Field(default="nano_filesystem", description="文件存储类型")
    connection_kwargs: Dict[str, Any] = Field(default_factory=dict, description="用于连接文件存储服务的初始化参数字典")


class DocDSConfig(BaseDSConfig):
    # TODO: default方案待设计、实现
    type: str = Field(default="nano_docsystem", description="Doc和Chunk存储服务类型")
    connection_kwargs: Dict[str, Any] = Field(default_factory=dict, description="用于连接Doc和Chunk存储服务的参数字典")


class KeywordDSConfig(BaseDSConfig):
    # TODO: default方案待设计、实现
    type: str = Field(default="nano", description="Keyword搜索存储类型")
    connection_kwargs: Dict[str, Any] = Field(default_factory=dict, description="用于连接Keyword全文搜索存储服务的初始化参数字典")


class VectorDSConfig(BaseDSConfig):
    # TODO: default方案待设计、实现
    type: str = Field(default="chroma", description="向量搜索存储类型")
    connection_kwargs: Dict[str, Any] = Field(default_factory=dict, description="用于连接向量搜索存储服务的初始化参数字典")


class StructuredDSConfig(BaseDSConfig):
    # TODO: default方案待设计、实现
    type: str = Field(default="sqlite", description="结构化数据库存储类型")
    connection_kwargs: Dict[str, Any] = Field(default_factory=dict, description="用于连接结构化数据库的初始化参数字典")


class GraphDSConfig(BaseDSConfig):
    type: str = Field(default="networkx", description="图数据库类型")
    connection_kwargs: Dict[str, Any] = Field(default_factory=dict, description="用于连接图数据库的初始化参数字典")


class CeleryConfig(BaseDSConfig):
    type: str = Field(default="sqlite", description="Celery默认broker和backend配置")
    broker_url: str = Field(default="sqla+sqlite:///celery.sqlite", description="Celery broker url")
    result_backend: str = Field(default="db+sqlite:///celery.sqlite", description="Celery result backend url")


class KBXGlobalConfig(KBXBaseModel):
    '''用于KBX系统初始化时的相关全局配置参数'''

    work_dir: str = Field(
        default='volumes',
        description="启动KBX的工作目录，所有日志、数据库均会持久化在此文件夹内"
    )
    cache_dir: str = Field(
        default='/tmp/kbx',
        description="KBX项目的缓存目录，所有临时文件均统一暂存在此目录下"
    )

    port: int = Field(default=30018, description="KBX后端服务端口")
    host: str = Field('127.0.0.1', description="KBX后端服务监听地址")

    # 日志
    # TODO: 目前整个项目共用一个日志文件，未来视情况评估是否需要按模块、用途拆分
    log_file: str = Field(default='kbx.log', description="KBX程序运行日志文件保存路径，如果是相对路径，默认会与work_dir进行拼接")
    log_level: Literal['INFO', 'ERROR', 'WARNING', 'DEBUG', 'FATAL'] = Field(
        default='INFO', description="日志等级，如INFO/ERROR/WARNING/FATAL等")

    # 系统业务数据库
    system_db: Optional[StructuredDSConfig] = Field(default=None, description="系统业务数据存储的DB")
    # redis 配置
    redis: Optional[Dict[str, Any]] = Field(default=None, description="全局公用Redis服务配置参数")

    # celery配置
    celery: Optional[CeleryConfig] = Field(default=None, description="Celery配置")

    # taskiq配置
    taskiq: Optional[TaskIQConfig] = Field(default=None, description="TaskIQ配置")

    # 文件服务配置
    file_service_prefix: str = Field(
        default="http://localhost:30018/kb_files",
        description="文件服务前缀地址，用于生成文件访问URL，生成模式建议使用Nginx等方案，开发模式可以使用KBX自带restful的文件服务"
    )

    # KBX内部各个知识库使用的Datastore配置
    file_ds: Optional[FileDSConfig] = Field(default=None, description="文件存储配置参数")
    doc_ds: Optional[DocDSConfig] = Field(default=None, description="DocData/Chunk存储配置参数")
    keyword_ds: Optional[KeywordDSConfig] = Field(default=None, description="关键词搜索datastore配置参数")
    vector_ds: Optional[VectorDSConfig] = Field(default=None, description="向量数据库配置参数")
    structured_ds: Optional[StructuredDSConfig] = Field(default=None, description="结构化数据库配置参数")
    graph_ds: Optional[GraphDSConfig] = Field(default=None, description="图数据库配置参数")
    # 其他参数
    # TODO: 暂时整个项目设置一个公共的线程数量，未来可能对num_threads进行细分
    num_threads: int = Field(default=-1, description="KBX系统内部使用的线程数，默认值-1将按照CPU核心数量乘以2得到")
    user_kb_num_limit: int = Field(default=100, description="每个用户允许创建的最大知识库数量")
    kb_docs_num_limit: int = Field(default=1000, description="每个知识库允许的最大文档数量")
    upload_file_batch_limit: int = Field(default=100, description="每次批量添加的最大文档数量")
    upload_file_size_limit: Union[int, str] = Field(
        default="512MB",
        description="每个用户上传文件（文档、图片、音频、视频）允许的最大size，如果为字符串，必须以B/KB/MB/GB这几种单位之一结尾，如果是不带单位的数字，则默认单位为B"
    )

    '''一些校验函数'''
    @field_validator("work_dir", mode='before')
    def validate_work_dir(cls, v: str) -> str:
        if v is None or v == '':
            raise ValueError('work_dir can not be empty.')

        if not os.path.isabs(v):
            from kbx.common.utils import get_default_base_dir
            v = os.path.join(get_default_base_dir(), v)

        return v


class KBXError(KBXBaseModel):
    """KBX项目内部通用错误信息类"""

    class Code(enum.Enum):
        """错误类型码"""

        SUCCESS = 0

        INTERNAL_ERROR = 10
        RUNTIME_ERROR = 11
        TIMEOUT = 12
        INVALID_VALUE = 13
        NOT_FOUND_ERROR = 14  # 专门用于传入参数合法，但是没有找到预期结果的情形

        UNKNOWN_ERROR = 50

    code: Code = Field(default=Code.SUCCESS, description="错误类型码")
    msg: Optional[str] = Field(default=None, description="错误信息")


class FileInfo(KBXBaseModel):
    """文件存储中文件的相关信息"""

    # 一些基本属性
    file_name: Optional[str] = Field(default=None, description="文件名（包含后缀）")
    file_path: Optional[str] = Field(default=None, description="原始文件在存储服务下的相对路径")
    file_raw_path: Optional[str] = Field(
        default=None,
        description="原始文件在存储服务下的原始路径，路径格式为tenant_id/user_id/kb_id/file_path"
    )
    file_url: Optional[str] = Field(
        default=None,
        description="原始文件在存储服务下的url，格式为http://xx.xx.xx.xx:123456/kb_files/file_raw_path"
    )

    # NOTE: 可拓展添加一些重要事件时间记录或其他状态属性
    upload_date: Optional[datetime] = Field(default_factory=datetime.now, description="文件上传（成功）的时间")
    file_size: Optional[int] = Field(default=None, description="文件大小，单位字节（B）")


class TenantInfo(KBXBaseModel):
    """租户信息"""

    id: str = Field(description="租户id")
    name: str = Field(description="租户名称")


class UserInfo(KBXBaseModel):
    """用户信息"""

    id: str = Field(description="用户id")
    name: str = Field(description="用户名称")

    tenant_id: str = Field(description="用户所属租户id")


class UserContext(KBXBaseModel):
    """🔒【内部使用】用户上下文信息，在各内部模块间提供用户级的一些上下文资源信息"""
    user_id: str = Field(default='', description="用户id")
    tenant_id: str = Field(default='', description="租户id")

    extra_kwargs: Dict[str, Any] = Field(default_factory=dict, description="其他额外的上下文信息")


class TokenCounterConfig(KBXBaseModel):
    """用于计算token数量的配置参数"""
    counter: Literal['estimated', 'accurate'] = Field(
        default='estimated',
        description="token计数器名称，当前仅支持 'estimated' 和 'accurate' 两种配置"
    )
    kwargs: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "token计数器的自定义配置参数，具体参数取决于counter类型：\n"
            "- 当counter为 'estimated' 时，支持以下参数：\n"
            "  * chinese_factor: float, 中文token估算系数\n"
            "  * english_factor: float, 英文token估算系数\n\n"
            "- 当counter为 'accurate' 时，支持以下参数：\n"
            "  * tokenizer_type: str, tokenizer类型，支持 'tiktoken' 或 'transformers'\n"
            "    - 当tokenizer_type为 'tiktoken' 时，需要指定：\n"
            "      * encoding_name: str, 编码名称，如 'cl100k_base'\n"
            "    - 当tokenizer_type为 'transformers' 时，需要指定：\n"
            "      * model_name: str, 模型名称，如 'bert-base-uncased'\n"
        )
    )
