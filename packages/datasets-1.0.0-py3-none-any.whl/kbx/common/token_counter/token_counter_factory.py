from typing import Optional
from kbx.common.token_counter.base_token_counter import BaseTokenCounter
from kbx.common.types import TokenCounterConfig


def get_token_counter(config: Optional[TokenCounterConfig]) -> BaseTokenCounter:
    """给定一个TokenCounter的配置，获取对应的TokenCounter实例
    Args:
        config (Optional[TokenCounterConfig]): TokenCounter的配置
    Returns:
        BaseTokenCounter: 对应的TokenCounter实例
    """
    if config is None:
        config = TokenCounterConfig()

    if config.counter == 'estimated':
        from kbx.common.token_counter.estimated_token_counter import EstimatedTokenCounter
        return EstimatedTokenCounter(config)
    elif config.counter == 'accurate':
        from kbx.common.token_counter.accurate_token_counter import AccurateTokenCounter
        return AccurateTokenCounter(config)
    else:
        raise ValueError(f"Unsupported token counter type: {config.counter}")
