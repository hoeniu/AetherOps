from abc import ABC, abstractmethod
from kbx.common.types import TokenCounterConfig


class BaseTokenCounter(ABC):
    """Token计数器基类"""

    def __init__(self, config: TokenCounterConfig):
        super().__init__()
        self._config = config

    @property
    def config(self) -> TokenCounterConfig:
        return self._config

    @abstractmethod
    def __call__(self, text: str) -> int:
        """计算指定文本的token数量（与count_tokens相同）

        Args:
            text (str): 待计算token数量的文本

        Returns:
            int: 文本的token数量
        """
        raise NotImplementedError
