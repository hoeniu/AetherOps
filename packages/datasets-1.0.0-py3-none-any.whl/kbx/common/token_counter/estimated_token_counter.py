from kbx.common.token_counter.base_token_counter import BaseTokenCounter
from kbx.common.types import TokenCounterConfig
import re


class EstimatedTokenCounter(BaseTokenCounter):
    """基于经验系数进行估算token计数的实现类"""

    def __init__(self, config: TokenCounterConfig):
        super().__init__(config)
        self._chinese_factor = self.config.kwargs.get('chinese_factor', 1.2)
        self._english_factor = self.config.kwargs.get('english_factor', 3.0)
        if self._chinese_factor <= 0 or self._english_factor <= 0:
            raise ValueError(
                "chinese_factor and english_factor must be positive, "
                f"given {self._chinese_factor} and {self._english_factor}"
            )

    def _count_chinese_chars(self, text: str) -> int:
        """统计中文字符数量"""
        return len(re.findall(r'[\u4e00-\u9fff]', text))

    def _count_english_chars(self, text: str) -> int:
        """统计英文字符数量"""
        return len(re.findall(r'[a-zA-Z]', text))

    def __call__(self, text: str) -> int:
        """基于经验系数进行估算token计数

        Args:
            text (str): 待计算token数量的文本

        Returns:
            int: 文本的token数量
        """
        chinese_count = self._count_chinese_chars(text)
        english_count = self._count_english_chars(text)
        other_count = len(text) - chinese_count - english_count

        return int(
            chinese_count / self._chinese_factor + \
            english_count / self._english_factor + \
            other_count
        )
