from kbx.common.token_counter.base_token_counter import BaseTokenCounter
from kbx.common.types import TokenCounterConfig


class AccurateTokenCounter(BaseTokenCounter):
    """使用具体tokenizer进行精确token计数的实现类"""

    def __init__(self, config: TokenCounterConfig):
        super().__init__(config)
        self._tokenizer = self._load_tokenizer()

    def _load_tokenizer(self):
        """根据配置加载tokenizer"""
        kwargs = self.config.kwargs
        tokenizer_type = kwargs.get('tokenizer_type')

        if tokenizer_type == 'tiktoken':
            import tiktoken
            encoding_name = kwargs.get('encoding_name', 'cl100k_base')
            return tiktoken.get_encoding(encoding_name)
        elif tokenizer_type == 'transformers':
            from transformers import AutoTokenizer
            model_name = kwargs.get('model_name', 'bert-base-uncased')
            return AutoTokenizer.from_pretrained(model_name)
        else:
            raise ValueError(f"Unsupported tokenizer type: {tokenizer_type}")

    def __call__(self, text: str) -> int:
        """使用加载的tokenizer进行精确token计数

        注意：对于transformers tokenizer，即使输入为空字符串，也会返回至少2个token，
        因为会添加[CLS]和[SEP]特殊token。

        Args:
            text (str): 待计算token数量的文本

        Returns:
            int: 文本的token数量
        """
        return len(self._tokenizer.encode(text))
