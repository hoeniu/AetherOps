import os
import json
import time
import yaml
import re
from fastapi import HTTPException, Security
from typing import Any, Dict

import jwt
from pydantic import BaseModel
from typing import Dict, Any, Optional, TypeVar, Union, List, Literal
from pathlib import Path

from kbx.common.types import DocElement, DocElementType, DocElementCollection, DocData, FileEncoding, UserContext
from kbx.knowledge_base.types import QueryConfig
from kbx.common.prompt import get_category_prompts
from kbx.common.types import TOCNode
from kbx.common.constants import DEFAULT_SECRET_KEY, DEFAULT_USER_ID
from fastapi.security import APIKeyHeader


ConfigType = TypeVar('ConfigType', bound=BaseModel)

API_KEY_HEADER = APIKeyHeader(name="Authorization")


def generate_new_id() -> str:
    """生成一个新id，本项目中tenant_id/user_id/kb_id/doc_id/doc_element_id/chunk_id均可使用"""
    return generate_new_id_v2()


def generate_new_id_v0() -> str:
    """生成一个新的随机id"""
    import uuid
    return str(uuid.uuid4())


def generate_new_id_v1() -> str:
    """生成一个新的随机id"""
    import shortuuid
    return shortuuid.uuid()


def generate_new_id_v2() -> str:
    """生成一个新的随机id"""
    import nanoid
    return nanoid.generate(
        alphabet='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
        size=8
    )


def doc_element_to_markdown(doc_element: DocElement, mode: Literal['summary', 'original']) -> str:
    """把DocElement转换成markdown

    Args:
        doc_element (DocElement): 文档中的一个DocElement
        mode (Literal['summary', 'original']): 转换模式，
            summary表示摘要模式，对code/image/video等多模态数据会尽可能使用content_description字段，
            original表示原文模式，尽可能使用原文

    Returns:
        str: 转换出的markdown字符串
    """
    md = ''

    if doc_element.type == DocElementType.TITLE:
        # 标题
        md += '#' * (doc_element.meta_data['title_level'] if 'title_level' in doc_element.meta_data else 1) + \
            ' ' + doc_element.text
    elif doc_element.type == DocElementType.CODE_BLOCK:
        # 代码块
        if mode == 'summary':
            if doc_element.content_description:
                # 如果content_description不为空，则使用content_description作为代码块的描述信息
                md += doc_element.content_description
            else:
                # 否则使用text作为代码块的描述信息
                md += doc_element.text
        else:
            # 原文模式
            md += doc_element.text
    elif doc_element.type == DocElementType.FIGURE:
        # 图片
        if doc_element.data_file_url:
            image_url = doc_element.data_file_url
            caption = doc_element.image_caption if doc_element.image_caption else ''

            # 生成标准Markdown图片格式 类似于"![图1-2：北京市2024GDP季度变化曲线图](image_url)\n图片内容：content_description\n\n"
            md += f'![{caption}]({image_url})'
            # 如果有内容描述，添加到图片下方
            if doc_element.content_description:
                md += f'\n图片内容：{doc_element.content_description}\n\n'
    elif doc_element.type == DocElementType.TABLE:
        # 表格
        md += doc_element.table.as_md()
    elif doc_element.type == DocElementType.VIDEO:
        # 视频
        # NOTE: md不支持视频预览，所以这里采用内嵌html的方式构造
        md += '<video controls width="100%">\n'
        mime_type = get_video_media_mime_type(doc_element.data_file_path)
        if doc_element.data_file_url:
            md += f'  <source src="{doc_element.data_file_url}" type="{mime_type}">\n'
        else:
            md += f'  <source src="{doc_element.data_file_path}" type="{mime_type}">\n'
        md += '</video>'
        if doc_element.content_description:
            md += f'\n\n<p>视频内容：{doc_element.content_description}</p>'
    elif doc_element.type == DocElementType.AUDIO:
        # 音频
        content = doc_element.text if doc_element.text else doc_element.content_description
        mime_type = get_audio_media_mime_type(content)
        md += '<audio controls>\n'
        md += f'  <source src="{doc_element.data_file_url}" type="{mime_type}">\n'
        md += '</audio>'
        if content:
            md += f'\n\n<p>音频内容：{content}</p>'
    elif doc_element.type in (DocElementType.TEXT, DocElementType.EQUATION):
        # 正文段
        md += doc_element.text

    return md


def doc_elements_to_markdown(doc_elements: List[DocElement], mode: Literal['summary', 'original']) -> str:
    """把一个文档内容转换成markdown

    Args:
        doc_elements (List[DocElement]): 文档内容
        mode (Literal['summary', 'original']): 转换模式，
            summary表示摘要模式，对code/image/video等多模态数据会尽可能使用content_description字段，
            original表示原文模式，尽可能使用原文

    Returns:
        str: 转换出的markdown字符串
    """
    return "\n\n".join(
        filter(
            lambda x: x is not None,
            [doc_element_to_markdown(doc_element, mode=mode) for doc_element in doc_elements]
        )
    )


def doc_data_to_markdown(doc: DocData, mode: Literal['summary', 'original'], prepend_file_name: bool = True) -> str:
    """把一个文档内容转换成markdown

    Args:
        doc (Document): 文档内容
        mode (Literal['summary', 'original']): 转换模式，
            summary表示摘要模式，对code/image/video等多模态数据会尽可能使用content_description字段，
            original表示原文模式，尽可能使用原文
        prepend_file_name (bool, optional): 是否在markdown中添加文件名。默认为True.

    Returns:
        str: 转换出的markdown字符串
    """
    content_md = doc_elements_to_markdown(doc.doc_elements, mode=mode)

    if prepend_file_name:
        content_md = "<file_name = \"" + doc.file_name + "\">\n\n" + content_md

    return content_md


def detect_file_encoding(file_path: str) -> FileEncoding:
    """Try to detect the file encoding.

    Returns a list of `FileEncoding` tuples with the detected encodings ordered
    by confidence.

    Args:
        file_path: The path to the file to detect the encoding for.
    """
    import chardet

    path = Path(file_path)
    detector = chardet.universaldetector.UniversalDetector()

    # 只读取部分字节，避免文件过大导致检测时间过长
    # 注意：只读取部分字节，可能影响检测的准确性
    with path.open("rb") as f:
        while True:
            chunk = f.read(128)
            if not chunk:
                break
            detector.feed(chunk)
            if detector.done:
                break
        detector.close()

    encoding = detector.result

    return FileEncoding(**encoding) if encoding else None


def get_pydantic_config_changes(
    old_config: BaseModel,
    new_config: BaseModel,
    recursive: bool = False
) -> Dict[str, Any]:
    """比较两个pydantic模型的配置差异，并返回新配置相比旧配置发生变化字段的字典（也就是只返回发生变化的新配置属性字段）

    Args:
        old_config (BaseModel): 旧配置
        new_config (BaseModel): 新配置
        recursive (bool): 是否递归比较，如果为False，则只会比较第一层属性字段，否则会递归比较所有BaseModel类型属性的成员变量字段

    Returns:
        Dict[str, Any]: 新配置相比旧配置发生变化字段的字典
    """

    if old_config.__class__ != new_config.__class__:
        raise ValueError(
            "old_config and new_config must be the same type, "
            f"given {old_config.__class__} and {new_config.__class__}"
        )
    if not isinstance(old_config, BaseModel):
        raise ValueError(f"old_config must be a pydantic model, given {type(old_config)}")

    diff = {}
    for field_name, field in old_config.model_fields.items():
        if field.exclude:
            continue
        old_field_val = getattr(old_config, field_name)
        new_field_val = getattr(new_config, field_name)

        if old_field_val == new_field_val:
            continue
        if recursive and isinstance(new_field_val, BaseModel):
            field_diff = get_pydantic_config_changes(old_field_val, new_field_val, recursive)
            if field_diff:
                diff[field_name] = field_diff
        else:
            diff[field_name] = new_field_val

    return diff


def inject_user_ctx(config: ConfigType, user_ctx: UserContext, recursive: bool) -> ConfigType:
    """为一个自定义配置注入指定的用户上下文信息，注意，该函数会修改传入的config对象，
    调用完之后输入config和返回值其实是同一个对象

    Args:
        config (ConfigType): 待注入用户上下文的配置，必须是BaseModel的子类对象
        user_ctx (UserContext): 用户上下文
        recursive (bool): 是否递归处理

    Returns:
        ConfigType: 处理后的配置
    """

    # 遍历config所有field，检查是否有名字为user_ctx、类型为UserContext的field
    # 如果有，则赋值为输入的user_ctx，如果没有，则什么也不做
    # 根据recursive参数决定是否递归处理所有BaseModel类型的field
    for field_name, field in config.model_fields.items():
        field_annotation = field.annotation
        if hasattr(field.annotation, '__args__') and len(field.annotation.__args__) == 2 \
                and field.annotation.__args__[1] is type(None):
            # 特殊处理Optional[XXX]类型
            field_annotation = field.annotation.__args__[0]

        if field_name == "user_ctx" and field.annotation in [UserContext, Optional[UserContext]]:
            setattr(config, field_name, user_ctx)
        elif recursive and isinstance(field_annotation, type) and issubclass(field_annotation, BaseModel):
            nested_config = getattr(config, field_name)
            if nested_config is not None and isinstance(nested_config, BaseModel):
                inject_user_ctx(nested_config, user_ctx, recursive)

    return config


def locate_kbx_settings_yaml(desired_path: Union[str, List[str]] = '') -> str:
    """尝试获取KBX的配置文件路径，如果找不到则抛出异常，具体搜索规则如下

    1. 如果desired_path是非空字符串，且路径存在，则直接返回desired_path
    2. 如果desired_path是列表，则在其后面额外添加几个备选项，然后挨个判断是否存在
    3. 备选项包括
        3.1 KBX_CONFIG_FILE环境变量
        3.2 ${KBX_BASE_DIR}/conf/kbx_settings.yaml
        3.3 ${KBX_BASE_DIR}/kbx_settings.yaml

    Args:
        desired_path (Union[str, List[str]]): 外部高优搜索的路径，可以是一个路径，也可以是多个路径的列表

    Returns:
        str: 实际找到的配置文件路径
    """
    if isinstance(desired_path, str) and desired_path:
        # 如果指定了路径，则作为唯一的选择
        desired_path = [desired_path]
    else:
        # 否则，添加一些备选路径
        if desired_path == '':
            desired_path = []

        if 'KBX_CONFIG_FILE' in os.environ:
            desired_path.append(os.environ["KBX_CONFIG_FILE"])

        base_dir = get_default_base_dir()
        desired_path.append(os.path.join(base_dir, 'conf/kbx_settings.yaml'))
        desired_path.append(os.path.join(base_dir, 'kbx_settings.yaml'))

    for path in desired_path:
        if not path:
            continue
        if os.path.exists(path) and (path.endswith('.yaml') or path.endswith('.yml') or path.endswith('.json')):
            return path

    raise FileNotFoundError(f"KBX settings file not found in the following paths:\n {desired_path}")


def get_default_base_dir() -> str:
    """获取本项目默认的BASE DIR路径，之后的配置文件、模型文件等，都以该路径为根目录，具体规则如下：

    1. 如果设置了KBX_BASE_DIR环境变量，优先级最高
    2. 如果KBX_BASE_DIR环境变量未设置
        2.1 如果当前处于项目源码目录中（尚未安装），则返回当前源码根目录
        2.2 如果当前不处于安装目录中（且kbx已安装），则返回`~/.kbx`

    Returns:
        str: base dir路径
    """

    if 'KBX_BASE_DIR' in os.environ:
        return os.environ['KBX_BASE_DIR']

    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')
    if os.path.exists(os.path.join(base_dir, 'conf')) and os.path.exists(os.path.join(base_dir, 'tools')):
        # KBX源码文件夹根目录
        return base_dir
    else:
        # 返回~/.kbx
        return os.path.expanduser('~/.kbx')


def convert_table_to_markdown(table_data: list[list[str]]) -> str:
    """将二维列表转换为简化版Markdown表格（无分隔线、不做任何填充）"""
    if not table_data:
        return ""

    # 生成表头行
    header_row = "|".join(str(cell).strip() for cell in table_data[0])
    markdown_str = f"|{header_row}|\n"

    # 直接拼接数据行
    for row in table_data[1:]:
        data_row = "|".join(str(cell).strip() for cell in row)
        markdown_str += f"|{data_row}|\n"

    return markdown_str.strip()


def select_kbs(query: QueryConfig, kb_ids: List[str], user_id: str) -> str:
    """根据query进行初步意图判断，选择需要检索的相关知识库

    Args:
        query (QueryConfig): 用户原始请求
        kb_ids (List[str]): 知识库id列表
        user_id (str): 用户id

    Returns:
        str: 大模型返回的json字符串表示，包含用户意图信息
    """
    from kbx.kbx import KBX
    kb_info_list = []

    for kb_id in kb_ids:
        kb_config = KBX.get_kb_config(kb_id=kb_id, user_id=user_id)
        docs_info = KBX.get_existed_kb(kb_id=kb_id, user_id=user_id).list_docs_info()[0]
        docs_list = [doc.raw_file_info.file_name for doc in docs_info]
        kb_info_list.append(
            {
                'kb_id': kb_id,
                'kb_name': kb_config.name,
                'kb_description': kb_config.description,
                'docs_list': docs_list,
            }
        )
    prompt = get_category_prompts('retrieve')['select_kbs'].text
    kb_prompt = ''
    for kb in kb_info_list:
        kb_prompt += f"kb_id: {kb['kb_id']}, kb_name: {kb['kb_name']}, kb_description:" + \
            f" {kb['kb_description']}, docs_list: {kb['docs_list']}\n"

    system_prompt = prompt.format(kb_prompt=kb_prompt)

    llm_config, llm_client = KBX.get_ai_model_config_and_client(query.deep_think.llm_model, user_id)
    prompt_messages = []
    prompt_messages.append({"role": "system", "content": system_prompt})
    prompt_messages.append({"role": "user", "content": query.text if query.text else json.dumps(
        query.messages, ensure_ascii=False)})
    intent_response = llm_client.chat(
        llm_config,
        prompt_messages
    ).choices[0].message.content.strip().strip('```json').strip('```')

    return intent_response


def get_video_media_mime_type(file_path: str) -> str:
    """根据文件扩展名返回视频文件对应的MIME类型

    Args:
        file_path (str): 文件路径

    Returns:
        str: MIME类型
    """
    ext = os.path.splitext(file_path)[1].lower()

    # 视频MIME类型映射
    video_types = {
        '.mp4': 'video/mp4',
        '.webm': 'video/webm',
        '.ogg': 'video/ogg',
        '.mov': 'video/quicktime',
        '.avi': 'video/x-msvideo',
        '.wmv': 'video/x-ms-wmv',
        '.flv': 'video/x-flv',
        '.mkv': 'video/x-matroska'
    }
    return video_types.get(ext, 'video/mp4')


def get_audio_media_mime_type(file_path: str) -> str:
    """根据文件扩展名返回音频文件对应的MIME类型

    Args:
        file_path (str): 文件路径

    Returns:
        str: MIME类型
    """
    ext = os.path.splitext(file_path)[1].lower()
    audio_types = {
        '.mp3': 'audio/mpeg',
        '.wav': 'audio/wav',
        '.ogg': 'audio/ogg',
        '.aac': 'audio/aac',
        '.flac': 'audio/flac',
        '.m4a': 'audio/mp4',
        '.wma': 'audio/x-ms-wma'
    }
    return audio_types.get(ext, 'audio/mpeg')


def parse_jwt_token(token):
    decode = jwt.decode(token, os.getenv("SECRET_KEY", "sk-9f73s3ljTXVcMT3Blb3ljTqtsKiGHXVcMT3BlbkFJLK7U"),
                        algorithms=["HS256"])
    return decode


def get_user_id(api_key_header: str = Security(API_KEY_HEADER)):
    if not api_key_header or not api_key_header.startswith("Bearer "):
        raise HTTPException(status_code=403, detail="Invalid Authorization token.")
    token = api_key_header.split(" ")[1]
    try:
        claim = parse_jwt_token(token)
        user_id = claim.get("user_id")
        if not user_id:
            raise HTTPException(status_code=403, detail="Invalid token. missing user_id")
        return user_id
    except jwt.exceptions.InvalidSignatureError:
        raise HTTPException(status_code=403, detail="Invalid token signature.")
    except jwt.exceptions.DecodeError:
        raise HTTPException(status_code=403, detail="Invalid token.")
    except jwt.exceptions.ExpiredSignatureError:
        raise HTTPException(status_code=403, detail="Token has expired.")


def get_user_id_from_jwt_header(user_id: str = DEFAULT_USER_ID, expires_in: int = 3600):
    """生成JWT令牌
    :param user_id: 用户ID
    :param expires_in: 令牌有效期（秒），默认3600秒
    """
    now = int(time.time())
    payload = {
        "exp": now + expires_in,
        "iat": now,
        "user_id": user_id
    }

    # 使用与应用程序相同的密钥
    secret_key = os.getenv("SECRET_KEY", DEFAULT_SECRET_KEY)

    # 生成令牌
    token = jwt.encode(payload, secret_key, algorithm="HS256")

    return token


def get_node_by_level_str(root_node: TOCNode, level_str: str) -> TOCNode:
    """根据level_str获取对应的TOCNode

    Args:
        root_node (TOCNode): 目录树根节点
        level_str (str): 目录层级字符串，例如"1.2.3"

    Returns:
        TOCNode: 指定层级的TOCNode
    """
    indices = [int(i) for i in level_str.split('.')]
    node = root_node
    for index in indices[1:]:
        node = node.children[index]
    return node


def get_toc_node_content_str(
    node: TOCNode,
    doc_elements: DocElementCollection,
    mode: Literal['original', 'summary'] = 'summary'
) -> str:
    """获取指定节点的所有文本内容

    Args:
        node: 查询的目标TOCNode
        doc_elements: 文档元素集合
        mode: 内容模式,'original'表示原始内容,'summary'表示摘要内容

    Returns:
        str: 节点内容字符串
    """
    content = []
    for doc_element_id in node.doc_element_ids:
        try:
            md_content = doc_element_to_markdown(doc_elements[doc_element_id], mode=mode)
            if md_content.strip():  # 只添加非空内容
                content.append(md_content)
        except (KeyError, IndexError):
            continue  # 跳过无法访问的元素

    content_str = '\n\n'.join(content)

    return content_str


def toc_tree_to_string(root_node: TOCNode) -> str:
    """将目录树转换为字符串表示

    Args:
        root_node (TOCNode): 目录树根节点

    Returns:
        str: 目录树结构的字符串表示
    """

    def _helper_fun(node: TOCNode, prefix: str = "", is_last: bool = False) -> str:
        connector = "└── " if is_last else "├── "

        result = f"{prefix}{connector}{node.title} ({node.level_str}, {node.num_tokens} tokens)"

        child_prefix = prefix + ("    " if is_last else "│   ")

        for i, child in enumerate(node.children):
            is_last_child = i == len(node.children) - 1
            child_str = _helper_fun(child, child_prefix, is_last_child)
            result += "\n" + child_str
        return result

    return _helper_fun(root_node, '', is_last=False)


def read_yaml_with_env_replace(yaml_file_path: str) -> Dict[str, Any]:
    """
    读取YAML 配置文件, 并替换 ${env:XXX} 格式的字符串为当前运行环境下环境变量的值
    注意 ${env:XXX} 为固定格式, ${env:}为固定写法; XXX为环境变量名称，当前实现暂时不支持默认值

    Args:
        yaml_file_path (str): Yaml文件的路径

    Returns:
        Dict[str, Any]: 根据Yaml文件转换的字典格式.
    """
    with open(yaml_file_path, 'r', encoding='utf-8') as file:
        content = file.read()

    # 定义正则表达式匹配 ${env:XXX}
    pattern: re.Pattern = re.compile(r'\${env:([A-Za-z0-9_]+)}')

    # 正则表达式替换函数
    def replace_with_env(match: re.Match) -> str:
        env_var_name = match.group(1)  # 获取环境变量名称
        env_var_value = os.getenv(env_var_name)  # 获取环境变量值
        if env_var_value is None:
            raise ValueError(f"环境变量 {env_var_name} 未定义")
        return env_var_value

    # 替换所有匹配的 ${env:XXX}
    replaced_content: str = pattern.sub(replace_with_env, content)

    # 加载替换后的 YAML 内容
    return yaml.safe_load(replaced_content)
