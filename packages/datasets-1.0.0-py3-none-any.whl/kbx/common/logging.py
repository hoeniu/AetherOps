import sys
import logging
from kbx.common.otel import try_get_trace_id


logger = logging.getLogger("KBX")


class RequestIDFormatter(logging.Formatter):

    def format(self, record):
        # 获取 request_id
        request_id = try_get_trace_id()
        # 如果有 request_id，添加到日志格式中；如果没有，使用 "-" 代替
        request_id_str = f"[request_id:{request_id or '-'}]"
        # 设置格式
        self._style._fmt = (
            f"[%(asctime)s] {request_id_str} [%(name)s] [%(levelname)s] "
            f"%(filename)s [func:%(funcName)s()] [line:%(lineno)d]: %(message)s"
        )
        return super().format(record)


def set_logger(log_file: str, level: str = 'info'):
    """对本项目的logger进行初始化配置，正常来说将在KBX.init内被调用，其他模块不需要重复调用

    Args:
        log_file (str): 日志保存的文件路径
        level (str, optional): 日志级别，如info/error/warning/fatal/debug等
    """
    global logger

    if isinstance(level, str):
        if level.lower() in ['warning', 'warn']:
            level = logging.WARNING
        elif level.lower() == 'error':
            level = logging.ERROR
        elif level.lower() == 'info':
            level = logging.INFO
        elif level.lower() == 'fatal':
            level = logging.FATAL
        elif level.lower() == 'debug':
            level = logging.DEBUG
        elif level.lower() == 'critical':
            level = logging.CRITICAL
        else:
            raise ValueError(f'Unknown log level: {level}')

    logger.setLevel(level=level)

    if logger.handlers:
        # 如果已经设置过handlers，直接返回
        return

    formatter = RequestIDFormatter()

    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level=level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    stream_handler = logging.StreamHandler(stream=sys.stdout)
    stream_handler.setLevel(level=level)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
