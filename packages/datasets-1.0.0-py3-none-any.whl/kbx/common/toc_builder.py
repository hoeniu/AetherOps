from typing import Tuple, Optional, cast, Iterator
from pydantic import Field
from enum import Enum
from kbx.agent.types import TOCAgentConfig
from kbx.common.types import TOCNode, DocElementCollection, DocElement, DocElementType, DocData, KBXBaseModel
from kbx.parser.types import DocParseConfig
from kbx.common.token_counter.token_counter_factory import get_token_counter
from kbx.common.prompt import get_category_prompts
from kbx.common.utils import generate_new_id, get_toc_node_content_str, get_node_by_level_str, toc_tree_to_string
from kbx.common.logging import logger


class TitleCmd(KBXBaseModel):
    '''标题编辑指令，可被AI Agent或真人用于对指定文档内容DocData进行标题目录树的构造或修正'''

    class TitleCmdCode(Enum):
        '''标题编辑指令码'''
        SET_TITLE = 'SET_TITLE'
        ADD_TITLE_BEFORE = 'ADD_TITLE_BEFORE'
        ADD_TITLE_AFTER = 'ADD_TITLE_AFTER'
        DEMOTE_TO_TEXT = 'DEMOTE_TO_TEXT'

    code: TitleCmdCode = Field(
        default=TitleCmdCode.SET_TITLE,
        description='标题编辑指令码，具体来说有以下几种：\n'
        'SET_TITLE: 将指定文档元素设置为标题类型（不论是因为之前的标题级别出错还是之前错误的把标题识别成了正文等其他类型，都可以用本指令来修正）\n'
        'ADD_TITLE_BEFORE: 在指定文档元素之前添加新标题（例如之前缺少了一个二级标题，此时需要在指定文档元素之前添加一个）\n'
        'ADD_TITLE_AFTER: 在指定文档元素之后添加新标题（例如之前缺少了一个二级标题，此时需要在指定文档元素之后添加一个）\n'
        'DEMOTE_TO_TEXT: 把指定文档元素降级为正文（例如之前识别成了二级标题，此时需要把其降级为正文）\n'
    )
    doc_element_id: str = Field(description='需要进行标题操作的文档元素ID')
    text: Optional[str] = Field(
        default=None,
        description='标题内容，注意，因为已经有了level字段，所以text不需要使用诸如#之类的方法重复标记标题级别'
    )
    level: Optional[int] = Field(
        default=None,
        description='标题等级，例如1、2、3等，如果为None，则表示降级为正文'
    )
    summary: Optional[str] = Field(
        default=None,
        description='标题的摘要，用于描述这个标题所涵盖的内容'
    )


class TOCBuilder:
    def __init__(self,
                 config: DocParseConfig = DocParseConfig()):
        self._config = config
        # 创建token计数器
        self.token_counter = get_token_counter(self._config.token_counter)

    def _add_doc_element(self, root_node: TOCNode, doc_element: DocElement, last_added_node: TOCNode
                         ) -> Tuple[str, TOCNode]:
        """添加一个DocElement到目录树中，并返回该DocElement在目录树中的路径"""
        if doc_element.type == DocElementType.TITLE:
            title_level = doc_element.meta_data.get('title_level', 1)
            current_node = root_node
            current_depth = 1

            while current_depth < title_level:
                if not current_node.children:
                    # NOTE: 文档的目录树结构可能不完整，出现跳跃标题级别的情况
                    current_node.children.append(TOCNode(title='<未命名章节>',
                                                         level_str=current_node.level_str + '.0'))
                current_node = current_node.children[-1]
                current_depth += 1

            path_indices = current_node.level_str.split('.')
            # 添加新节点
            new_index = len(current_node.children)
            new_node = TOCNode(
                title=doc_element.text,
                self_doc_element_ids=[doc_element.doc_element_id],
                level_str='.'.join(map(str, path_indices + [new_index])),
                summary=doc_element.meta_data.get('summary', '')
            )
            current_node.children.append(new_node)

            return new_node.level_str, new_node

        else:
            last_added_node.self_doc_element_ids.append(doc_element.doc_element_id)
            return last_added_node.level_str, last_added_node

    def _update_token_count(self, doc_elements: DocElementCollection, node: TOCNode) -> int:
        """递归更新节点的token总数"""
        num_tokens = 0
        for doc_element_id in node.self_doc_element_ids:
            doc_element = doc_elements[doc_element_id]
            if doc_element.content_description:
                num_tokens += self.token_counter(doc_element.content_description)
            elif doc_element.table:
                # NOTE: 虽然使用md更合适，但有些情况可能没有md/2d_list，只能使用html格式
                # NOTE: html格式可以认为按上界估计
                num_tokens += self.token_counter(doc_element.table.as_html())
            elif doc_element.text:
                num_tokens += self.token_counter(doc_element.text)
        node.num_tokens = num_tokens

        if node.children:
            node.num_tokens += sum(self._update_token_count(doc_elements, child) for child in node.children)
        return node.num_tokens

    def _update_doc_element_ids(self, node: TOCNode):
        """递归更新节点的doc_element_ids"""
        for child in node.children:
            self._update_doc_element_ids(child)

        if node.children:
            node.children_doc_element_ids = [
                elem_id
                for child in node.children
                for elem_id in (child.doc_element_ids)
            ]

    def _check_tree_meaningful(self, root_node: TOCNode, max_num_nodes: int = 50) -> None:
        """检查目录树是否具有实际意义，当前以节点总数判定，后续可加其他判定规则"""
        def _count_nodes(node: TOCNode) -> int:
            count = 1
            for child in node.children:
                count += _count_nodes(child)

            return count

        num_nodes = _count_nodes(root_node)
        if num_nodes > max_num_nodes:
            logger.info(f'[Warning!] The current number of nodes is {num_nodes}, this may indicate an invalid TocTree.')

    def _summary_for_node(self, doc_data: DocData) -> None:
        """为目录树节点生成summary信息"""
        # TODO: 当前仅为ROOT节点做全文总结，后续根据需要为具体章节做总结
        from kbx.kbx import KBX
        doc_content = get_toc_node_content_str(
            get_node_by_level_str(doc_data.doc_toc, '0'),
            doc_data.doc_elements,
            mode='summary')
        prompt = get_category_prompts('parser')['doc_summary'].text.format(toc_tree_to_string(doc_data.doc_toc))
        llm_config, llm_client = KBX.get_ai_model_config_and_client(
            self._config.summary_model,
            self._config.user_ctx.user_id)
        doc_data.doc_toc.summary = llm_client.chat(
            llm_config,
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": doc_content}
            ]
        ).choices[0].message.content

    def build_toc(self, doc_data: DocData) -> DocData:
        """严格根据doc_elements中的标题doc_element构建文档目录树，耗时很短

        Args:
            doc_data (DocData): 文档数据

        Returns:
            DocData: 更新doc_toc后的文档数据
        """
        doc_data.doc_toc.children = []
        doc_data.doc_toc.self_doc_element_ids = []
        doc_data.doc_toc.num_tokens = 0

        last_added_node = doc_data.doc_toc
        for doc_element in doc_data.doc_elements:
            node_path, last_added_node = self._add_doc_element(doc_data.doc_toc, doc_element, last_added_node)
            doc_element.toctree_node_path = node_path

        self._update_doc_element_ids(doc_data.doc_toc)
        self._update_token_count(doc_data.doc_elements, doc_data.doc_toc)
        self._check_tree_meaningful(doc_data.doc_toc)
        if self._config.summary_model:
            self._summary_for_node(doc_data)

        return doc_data

    def apply_title_cmds(
        self,
        doc_data: DocData,
        title_cmds: Iterator[TitleCmd],
        deepcopy: bool = False
    ) -> DocData:
        """根据title_cmds对doc_data的标题目录进行修改，并返回修改后的doc_data
        title_cmds中的指令可以由Agent或人工生成，但需要保证指令的合法性

        Args:
            doc_data (DocData): 文档数据
            title_cmds (Iterator[TitleCmd]): 标题指令序列
            deepcopy (bool): 是否对输入的doc_data进行深拷贝

        Returns:
            DocData: 更新后的文档数据
        """
        if deepcopy:
            doc_data = doc_data.model_copy(deep=True)

        for title_cmd in title_cmds:
            if title_cmd.doc_element_id not in doc_data.doc_elements.id_map:
                logger.error(
                    f'Doc element {title_cmd.doc_element_id} not found in doc_data.doc_elements, '
                    f'title cmd {title_cmd} will be ignored.'
                )
                continue

            try:
                if title_cmd.code == TitleCmd.TitleCmdCode.SET_TITLE:
                    # 修改现有元素
                    doc_element = doc_data.doc_elements[title_cmd.doc_element_id]
                    if doc_element.type != DocElementType.TITLE:
                        doc_element.type = DocElementType.TITLE
                    doc_element.text = title_cmd.text
                    doc_element.meta_data['title_level'] = title_cmd.level
                    # TODO: Summary现在没法使用？
                    doc_element.meta_data['summary'] = title_cmd.summary
                elif title_cmd.code in [
                    TitleCmd.TitleCmdCode.ADD_TITLE_BEFORE,
                    TitleCmd.TitleCmdCode.ADD_TITLE_AFTER
                ]:
                    # 插入新元素
                    new_doc_element = DocElement(
                        doc_element_id=generate_new_id(),
                        type=DocElementType.TITLE,
                        text=title_cmd.text,
                        meta_data={
                            'title_level': title_cmd.level,
                            'summary': title_cmd.summary
                        }
                    )
                    # 计算新元素的插入位置
                    new_doc_element_index = doc_data.doc_elements.id_map[title_cmd.doc_element_id]
                    if title_cmd.code == TitleCmd.TitleCmdCode.ADD_TITLE_AFTER:
                        new_doc_element_index += 1

                    # 在指定index插入新元素
                    doc_data.doc_elements.insert(new_doc_element_index, new_doc_element)
                elif title_cmd.code == TitleCmd.TitleCmdCode.DEMOTE_TO_TEXT:
                    # 把指定元素降级为正文
                    doc_element = doc_data.doc_elements[title_cmd.doc_element_id]
                    if doc_element.type == DocElementType.TITLE:
                        doc_element.type = DocElementType.TEXT
                        doc_element.meta_data.pop('title_level')
                else:
                    raise ValueError(f'Invalid title command code: {title_cmd.code}')
            except Exception as e:
                # 打印错误信息，然后继续
                import traceback
                logger.error(f'Error processing title command {title_cmd}:\n{e}\n{traceback.format_exc()}')

        doc_data = self.build_toc(doc_data)

        return doc_data

    def build_toc_by_ai(self, doc_data: DocData, agent_config: TOCAgentConfig, deepcopy: bool = False) -> DocData:
        """使用AI Agent构建文档目录树，可能会修改输入的doc_data内容，例如

        - 把未识别为标题的正文修正为标题
        - 在特定位置插入新的标题doc_element
        - 把标题级别不正确的标题修正为正确的标题
        - 把标题降级为正文

        注意：此函数会调用LLM对全文内容进行遍历分析，产生较大的耗时和token消耗

        Args:
            doc_data (DocData): 文档数据
            agent_config (TOCAgentConfig): TOC Agent配置
            deepcopy (bool): 是否对输入的doc_data进行深拷贝

        Returns:
            DocData: 更新后的文档数据
        """
        # 先进行doc_data检查，并非所有文档数据都适合进行TOC构建
        if len(doc_data.doc_elements) < 10:
            logger.warning(
                f'Skip ai-based TOC building for "{doc_data.file_path}" (doc_id = {doc_data.doc_id}) '
                f'because the number of doc_elements is too small ({len(doc_data.doc_elements)})'
            )
            return doc_data

        from kbx.agent.toc.base_toc_agent import BaseTOCAgent
        from kbx.agent.agent_factory import get_agent
        toc_agent = get_agent(agent_config)
        if not isinstance(toc_agent, BaseTOCAgent):
            raise ValueError(
                f'Expected instance of BaseTOCAgent, but got {type(toc_agent)} from agent_config: {agent_config}'
            )
        toc_agent = cast(BaseTOCAgent, toc_agent)

        logger.info(f'Try to rebuild TOC with ai agent for "{doc_data.file_path}" (doc_id = {doc_data.doc_id})')

        title_cmds_iter = toc_agent.generate_title_cmds(doc_data)
        return self.apply_title_cmds(doc_data, title_cmds_iter, deepcopy=deepcopy)
