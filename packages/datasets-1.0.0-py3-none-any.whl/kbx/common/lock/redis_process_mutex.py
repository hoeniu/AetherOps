import redis
import time
import uuid
from kbx.common.lock.base_mutex import BaseMutex


class RedisProcessMutex(BaseMutex):
    """
    本实现旨在保护单实例内多个进程访问资源场景下的资源保护.
    """
    def __init__(self, section: str):
        from kbx.kbx import KBX
        host: str = KBX.config.redis_config["host"]
        port: str = KBX.config.redis_config["port"]
        # 锁的持续时间：如果设置为0，则始终生效
        self.expired_time: int = KBX.config.redis_config["expired_time"]
        self.redis_client = redis.StrictRedis(host=host, port=port, decode_responses=True)
        self.section: str = section
        self.lock_value: str = str(uuid.uuid4()())

    def acquire(self, is_write: bool = True) -> None:
        while True:
            # nx: 只有当不存在时才设置; px: 过期的时间ms
            if self.redis_client.set(self.section, self.lock_value, nx=True, px=self.expire_time * 1000):
                break
            time.sleep(0.1)

    def release(self, is_write: bool = True) -> None:
        lock_value = self.redis_client.get(self.section)
        if lock_value is not None and lock_value == self.lock_value:
            self.redis_client.delete(self.section)
