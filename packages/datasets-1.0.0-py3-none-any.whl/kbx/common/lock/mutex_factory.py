from kbx.common.lock.base_mutex import BaseMutex


def get_mutex(key: str, mutex_type: str = "thread_mutex") -> BaseMutex:
    if mutex_type == "none":
        return None
    elif mutex_type == "thread_mutex":
        from kbx.common.lock.shared_thread_mutex import SharedThreadMutex
        return SharedThreadMutex(key)
    elif mutex_type == "redis_process_mutex":
        from kbx.common.lock.redis_process_mutex import RedisProcessMutex
        return RedisProcessMutex(key)
    elif mutex_type == "node_mutex":
        raise NotImplementedError
    else:
        raise RuntimeError("Unsupported Type")
