import threading
from typing import Dict
from kbx.common.lock.base_mutex import BaseMutex


class SharedThreadMutex(BaseMutex):

    locks: Dict[str, threading.Lock] = dict()

    def __init__(self, section: str):
        """
        本实现旨在保护单进程内多线程访问互斥资源场景下的互斥保护
        无论在进程内的任何类实例中，只要section一样，就能够获得同一把锁
        这是有别于直接使用threading.Lock的部分
        """
        super().__init__(section)
        if section not in SharedThreadMutex.locks.keys():
            SharedThreadMutex.locks[section] = threading.Lock()

    def acquire(self, is_write: bool = True) -> None:
        SharedThreadMutex.locks[self.section].acquire()

    def release(self, is_write: bool = True) -> None:
        SharedThreadMutex.locks[self.section].release()
