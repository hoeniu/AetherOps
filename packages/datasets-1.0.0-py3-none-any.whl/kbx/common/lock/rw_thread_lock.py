import threading


class ReadWriteLock:

    def __init__(self):
        self.lock = threading.Lock()
        self.readers = 0
        self.writing = False
        self.read_condition = threading.Condition(self.lock)
        self.write_condition = threading.Condition(self.lock)

    def acquire_read(self):
        """获取读锁"""
        with self.lock:
            while self.writing:
                self.read_condition.wait()  # wait 释放锁并被挂起; 直至被唤醒，重新获取锁
            self.readers += 1

    def release_read(self):
        """释放读锁"""
        with self.lock:
            self.readers -= 1
            if self.readers == 0:
                self.write_condition.notify()

    def acquire_write(self):
        """获取写锁"""
        with self.lock:
            while self.readers > 0 or self.writing is True:
                self.write_condition.wait()
            self.writing = True

    def release_write(self):
        """释放写锁"""
        with self.lock:
            self.writing = False
            self.read_condition.notify_all()
            self.write_condition.notify()
