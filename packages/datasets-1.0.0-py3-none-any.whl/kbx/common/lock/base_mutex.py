from abc import ABC, abstractmethod


class BaseMutex(ABC):

    def __init__(self, section: str):
        """
        互斥锁基类：传入一个key

        Param:
            section (str): 声明要保护的资源名称. 在mutex实现的作用域(多线程，单节点多进程，多节点)下要求唯一性.
        """
        self.section = section

    def __enter__(self):
        self.acquire()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()

    @abstractmethod
    def acquire(self, is_write: bool = True) -> None:
        """
        获得锁, 如果锁被占用无法获得，则进入等待

        Args:
            is_write (bool): True: 写操作; False: 读操作.
                             标识该操作是读操作还是写操作，保证现有逻辑不受影响的前提下，兼容读写锁的设计
                             开发者如果确定设置is_write, 需要保证代码逻辑的正确性.

        Returns:

        """
        raise NotImplementedError

    @abstractmethod
    def release(self, is_write: bool = True) -> None:
        """
        释放锁.

        Args:
            is_write (bool): True: 写操作; False: 读操作.
                             标识该操作是读操作还是写操作，保证现有逻辑不受影响的前提下，兼容读写锁的设计
                             开发者如果确定设置is_write, 需要保证代码逻辑的正确性.

        Returns:

        """
        raise NotImplementedError
