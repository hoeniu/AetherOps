from typing import Dict
from kbx.common.lock.base_mutex import BaseMutex
from kbx.common.lock.rw_thread_lock import ReadWriteLock


class SharedRWThreadLock(BaseMutex):

    locks: Dict[str, ReadWriteLock] = dict()

    def __init__(self, section: str):
        """
        本实现旨在保护单进程内多线程访问互斥资源场景下的互斥保护
        无论在进程内的任何类实例中，只要section一样，就能够获得同一把锁
        这是有别于直接使用threading.Lock的部分
        """
        super().__init__(section)
        if section not in SharedRWThreadLock.locks.keys():
            SharedRWThreadLock.locks[section] = ReadWriteLock()

    def acquire(self, is_write: bool = True) -> None:
        if is_write:
            self.acquire_write()
        else:
            self.acquire_read()

    def release(self, is_write: bool = True) -> None:
        if is_write:
            self.release_write()
        else:
            self.release_read()

    def acquire_read(self) -> None:
        SharedRWThreadLock.locks[self.section].acquire_read()

    def release_read(self) -> None:
        SharedRWThreadLock.locks[self.section].release_read()

    def acquire_write(self) -> None:
        SharedRWThreadLock.locks[self.section].acquire_write()

    def release_write(self) -> None:
        SharedRWThreadLock.locks[self.section].release_write()
