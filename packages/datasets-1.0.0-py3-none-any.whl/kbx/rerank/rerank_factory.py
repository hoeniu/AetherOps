from kbx.rerank.base_rerank import BaseRerank
from kbx.rerank.model_rerank import ModelRerank
from kbx.rerank.types import RerankConfig
from kbx.rerank.weight_rerank import WeightRerank


def get_rerank(config: RerankConfig) -> BaseRerank:
    match config.name:
        case 'ModelRerank':
            return ModelRerank(config)
        case 'WeightRerank':
            return WeightRerank(config)
        case _:
            raise ValueError(f"Unknown rerank type: {config.name}")
