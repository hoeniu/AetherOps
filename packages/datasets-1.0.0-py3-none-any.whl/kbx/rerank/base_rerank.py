from abc import ABC, abstractmethod

from kbx.knowledge_base.types import QueryConfig, QueryResult
from kbx.rerank.types import RerankConfig


class BaseRerank(ABC):
    def __init__(self, config: RerankConfig) -> None:
        self.config = config

    @abstractmethod
    def rerank(
        self,
        query_config: QueryConfig,
        query_results: list[QueryResult]
    ) -> list[QueryResult]:
        """
        Rerank query results
        Args:
            query_config (QueryConfig): search query config
            query_results(QueryResult): list of query result for reranking

        Return:
            list[QueryResult]: Reranked query result
        """
        raise NotImplementedError
