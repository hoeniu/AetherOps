from kbx.knowledge_base.types import QueryConfig, QueryResult
from kbx.rerank.base_rerank import BaseRerank
from kbx.rerank.types import RerankConfig


class ModelRerank(BaseRerank):
    def __init__(self, config: RerankConfig) -> None:
        super().__init__(config)
        if "model" not in config.kwargs:
            raise ValueError("Must provide 'model' for ModelRerank.")
        self.model_name = config.kwargs['model']
        self.user_id = config.user_ctx.user_id if config.user_ctx else None

    def rerank(
        self,
        query_config: QueryConfig,
        query_results: list[QueryResult]
    ) -> list[QueryResult]:
        """
        Rerank query results
        Args:
            query_config (QueryConfig): search query config
            query_results(QueryResult): list of query result for reranking

        Return:
            list[QueryResult]: Reranked query result
        """
        texts = [x.try_get_content_as_str() for x in query_results]

        from kbx.kbx import KBX
        rerank_config, rerank_model = KBX.get_ai_model_config_and_client(
            self.model_name, self.user_id)

        rerank_results = rerank_model.rerank(
            model_config=rerank_config,
            query=query_config.text,
            texts=texts,
            top_n=query_config.top_k,
            score_threshold=query_config.score_threshold
        )

        # rerank result: [(index, text, score), ...]
        rerank_index_and_score_list = [(result[0], result[2]) for result in rerank_results]
        new_results = []
        for index, score in rerank_index_and_score_list:
            result = query_results[index]
            result.score = score
            new_results.append(result)
        query_results = new_results

        sorted_result = sorted(query_results, key=lambda x: x.score, reverse=True)

        if query_config.top_k > 0:
            return sorted_result[:query_config.top_k]
        else:
            return sorted_result
