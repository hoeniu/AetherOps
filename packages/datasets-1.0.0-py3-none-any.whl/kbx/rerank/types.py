from typing import Any, Dict, Literal, Optional
from pydantic import Field
from kbx.common.types import UserContext, KBXBaseModel
from kbx.ai_model.types import AIModelBundle


class RerankWeights(KBXBaseModel):
    """各种index的权重"""
    vector_keyword_weight: float = 1.0
    structured_weight: float = 1.0
    graph_weight: float = 1.0


class RerankConfig(KBXBaseModel):
    """Rerank配置"""
    name: Literal['ModelRerank', 'WeightRerank'] = Field(
        default='ModelRerank',
        description="rerank类型，当前支持 'ModelRerank' 和 'WeightRerank' 两种配置"
    )
    kwargs: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "rerank的自定义配置参数，具体参数取决于rerank类型：\n"
            "- 当name为 'ModelRerank' 时，需要指定：\n"
            "  * model: str, rerank模型名称\n\n"
            "- 当name为 'WeightRerank' 时，需要指定：\n"
            "  * weights: RerankWeights, 不同类型索引的权重分数\n"
        )
    )

    user_ctx: Optional[UserContext] = Field(
        default=None, init=False, repr=False,
        exclude=True, description="🔒【内部使用】用户上下文"
    )

    def update_with_model_bundle(self, model_bundle: AIModelBundle) -> 'RerankConfig':
        """使用模型配置更新当前配置

        Args:
            model_bundle (AIModelBundle): 模型配置

        Returns:
            RerankConfig: 更新后的配置
        """
        if self.name == 'ModelRerank' and 'model' not in self.kwargs:
            self.kwargs['model'] = model_bundle.rerank

        return self
