from kbx.common.types import IndexType
from kbx.knowledge_base.types import QueryConfig, QueryResult
from kbx.rerank.base_rerank import BaseRerank
from kbx.rerank.types import RerankConfig


class WeightRerank(BaseRerank):
    def __init__(self, config: RerankConfig) -> None:
        super().__init__(config)
        if "weights" not in config.kwargs:
            raise ValueError("Must provide 'weights' for WeightRerank.")
        self.weights = self.config.kwargs['weights']

    def rerank(
        self,
        query_config: QueryConfig,
        query_results: list[QueryResult]
    ) -> list[QueryResult]:
        """
        Rerank query results
        Args:
            query_config (QueryConfig): search query config
            query_results(QueryResult): list of query result for reranking

        Return:
            list[QueryResult]: Reranked query result
        """

        for query_result in query_results:
            score = query_result.score
            index_type = query_result.index_type
            # 根据索引类型重新计算权重分数
            if index_type == IndexType.VECTOR_KEYWORD:
                score *= self.weights.vector_keyword_weight
            elif index_type == IndexType.KNOWLEDGE_GRAPH:
                score *= self.weights.graph_weight
            elif index_type == IndexType.STRUCTURED:
                score *= self.weights.structured_weight

            query_result.score = score

        sorted_result = sorted(query_results, key=lambda x: x.score, reverse=True)

        if query_config.top_k > 0:
            return sorted_result[:query_config.top_k]
        else:
            return sorted_result
