from typing import Union
from agno.agent import Agent as AgnoAgent
from typing import Union, overload
from .types import AgentConfig, ReflectionAgentConfig, TOCAgentConfig, SearchAgentConfig, \
    KnowledgeExtractAgentConfig, KnowledgeGraphNavigateAgentConfig, ALL_AGENT_CONFIG_TYPES
from .classic.base_reflection_agent import BaseReflectionAgent
from .toc.base_toc_agent import BaseTOCAgent
from .graph.base_knowledge_extractor import BaseKnowledgeExtractor
from .graph.base_knowledge_graph_navigator import BaseKnowledgeGraphNavigator
from .search.base_searcher import BaseSearcher


# 所有Agent的类型集合
ALL_AGENT_TYPES = Union[
    AgnoAgent,
    BaseReflectionAgent,
    BaseTOCAgent,
    BaseKnowledgeExtractor,
    BaseKnowledgeGraphNavigator,
    BaseSearcher,
]


@overload
def get_agent(config: KnowledgeExtractAgentConfig) -> BaseKnowledgeExtractor:
    ...


@overload
def get_agent(config: KnowledgeGraphNavigateAgentConfig) -> BaseKnowledgeGraphNavigator:
    ...


@overload
def get_agent(config: ReflectionAgentConfig) -> BaseReflectionAgent:
    ...


@overload
def get_agent(config: SearchAgentConfig) -> BaseSearcher:
    ...


@overload
def get_agent(config: TOCAgentConfig) -> BaseTOCAgent:
    ...


@overload
def get_agent(config: AgentConfig) -> AgnoAgent:
    ...


def get_agent(config: ALL_AGENT_CONFIG_TYPES) -> ALL_AGENT_TYPES:
    """
    根据提供的Agent代理配置对象创建并返回相应的Agent代理实例。

    Args:
        config (ALL_AGENT_CONFIG_TYPES): Agent代理配置对象，包含代理名称和其他必要的配置信息。

    Returns:
        ALL_AGENT_TYPES: 一个继承自BaseAgent的具体代理实例。

    Raises:
        ValueError: 如果配置中的Agent代理名称无效，则抛出此异常。
    """
    # 检查配置中的代理名称是否为 'DeepSearcher'
    if isinstance(config, SearchAgentConfig) and config.agent_name == 'DeepSearcher':
        # 如果是 'deep_searcher'，则从当前包的 search 模块导入 DeepSearcher 类
        from .search.deepsearcher import DeepSearcher
        # 创建并返回 DeepSearcher 类的实例
        return DeepSearcher(config)
    elif isinstance(config, KnowledgeExtractAgentConfig) and config.agent_name == 'DefaultKnowledgeExtractor':
        # 如果是 'DefaultKnowledgeExtractor'，则从当前包的 graph 模块导入 KnowledgeExtractor 类
        from .graph.default_knowledge_extractor import DefaultKnowledgeExtractor
        # 创建并返回 KnowledgeExtractor 类的实例
        return DefaultKnowledgeExtractor(config)
    elif isinstance(config, ReflectionAgentConfig) and config.agent_name == 'DefaultReflectionAgent':
        from .classic.default_reflection_agent import DefaultReflectionAgent
        return DefaultReflectionAgent(config)
    elif isinstance(config, KnowledgeGraphNavigateAgentConfig) and  \
            config.agent_name == 'DefaultKnowledgeGraphNavigator':
        from .graph.default_knowledge_graph_navigator import DefaultKnowledgeGraphNavigator
        return DefaultKnowledgeGraphNavigator(config)
    elif isinstance(config, TOCAgentConfig) and config.agent_name == 'IterativeTOCAgent':
        from .toc.iterative_toc_agent import IterativeTOCAgent
        return IterativeTOCAgent(config)
    elif type(config) is AgentConfig and config.agent_name == 'AgnoAgent':
        from kbx.kbx import KBX
        llm_config, _ = KBX.get_ai_model_config_and_client(
            # 配置中的大语言模型名称
            config.llm_model,
            # 用户唯一ID
            user_id=config.user_ctx.user_id
        )
        # 根据聊天配置创建 Agno 模型实例
        agno_model = llm_config.agno_model()
        return AgnoAgent(
            # 使用配置中的Agno模型
            model=agno_model,
            # 是否显示工具调用信息
            show_tool_calls=True,
            # 最大重试次数，从配置中获取
            retries=config.max_iter
        )
    else:
        # 如果代理名称不是以上，则抛出 ValueError 异常
        raise ValueError(f"Invalid agent name: {config.agent_name} or config type: {type(config)}")
