from typing import Optional, Dict, List, Any
from pydantic import Field
from kbx.common.types import UserContext, KBXBaseModel, TokenCounterConfig
from typing import Optional, Dict, List, Any, Union
from kbx.ai_model.types import AIModelBundle


class AgentConfig(KBXBaseModel):
    user_ctx: Optional[UserContext] = Field(
        default=None, init=False, repr=False,
        exclude=True, description="🔒【内部使用】用户上下文"
    )
    agent_name: str = Field(default="AgnoAgent", description="Agent名称")
    max_iter: int = Field(default=3, description="Agent思考的最大迭代次数")
    llm_model: str = Field(default='', description="大语言模型")

    def update_with_model_bundle(self, model_bundle: AIModelBundle) -> 'AgentConfig':
        """使用模型配置更新当前配置

        Args:
            model_bundle (AIModelBundle): 模型配置

        Returns:
            AgentConfig: 更新后的配置
        """
        if not self.llm_model:
            self.llm_model = model_bundle.llm
        return self


class ReflectionAgentConfig(AgentConfig):
    score_threshold: int = Field(default=8, description="0-10分，0分意味着答案完全错误，10分表示答案完全正确。")


class SearchAgentConfig(AgentConfig):
    pass


class TOCAgentConfig(AgentConfig):
    token_counter: TokenCounterConfig = Field(
        default=TokenCounterConfig(counter="estimated"),
        description="token计数器"
    )


class KnowledgeExtractAgentConfig(AgentConfig):
    schema_dict: Dict[str, List[Dict[str, Any]]] = Field(
        default_factory=dict,
        description="schema字典，具体格式规范见说明文档。"
    )


class KnowledgeGraphNavigateAgentConfig(AgentConfig):
    schema_dict: Dict[str, List[Dict[str, Any]]] = Field(
        default_factory=dict,
        description="schema字典，具体格式规范见说明文档。"
    )


# 所有Agent配置类型集合
ALL_AGENT_CONFIG_TYPES = Union[
    AgentConfig,
    ReflectionAgentConfig,
    SearchAgentConfig,
    TOCAgentConfig,
    KnowledgeExtractAgentConfig,
    KnowledgeGraphNavigateAgentConfig,
]
