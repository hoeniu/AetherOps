import traceback
import sys
import ast
# import re
from typing import Any, Union, List, Dict, Iterator, TypeVar, Generic
from agno.run.response import RunResponse
from kbx.agent.types import AgentConfig
from kbx.common.logging import logger


ConfigT = TypeVar('ConfigT', bound=AgentConfig)


class BaseAgent(Generic[ConfigT]):
    def __init__(
            self,
            # 传入的配置对象，类型为RagAgentConfig，包含RAG代理所需的配置信息
            config: ConfigT
    ):
        """
        初始化 BaseAgent 类的实例。

        Args:
            config (AgentConfig): 传入的配置对象，包含RAG代理所需的配置信息。
        """
        # 调用父类RAGAgent的构造函数，将配置对象传递给父类进行初始化
        super().__init__()
        # 保存传入的配置对象到实例属性
        self._config: ConfigT = config
        # 从kbx.kbx模块中导入KBX类
        from kbx.kbx import KBX
        # 调用KBX类的get_ai_model_config_and_client方法，根据配置中的大语言模型名称和用户ID，获取聊天配置和大语言模型实例
        self.llm_config, self.llm_client = KBX.get_ai_model_config_and_client(
            # 配置中的大语言模型名称
            config.llm_model,
            # 用户唯一ID
            user_id=config.user_ctx.user_id
        )
        # 根据聊天配置创建 Agno 模型实例
        self.agno_model = self.llm_config.agno_model()

    def run(self, *args: Any, **kwargs: Any) -> Union[RunResponse, Iterator[RunResponse]]:
        """
        定义一个抽象的运行方法，该方法需要在子类中被实现。

        此方法旨在作为一个占位符，强制子类提供具体的实现逻辑。
        子类应该根据自身的需求重写这个方法，以执行特定的任务。

        Args:
            *args (Any): 可变数量的位置参数。
            **kwargs (Any): 可变数量的关键字参数。

        Returns:
            Any: 子类实现中返回的结果，具体类型取决于子类的实现。

        Raises:
            NotImplementedError: 如果在子类中没有重写此方法，调用时会抛出此异常。
        """
        raise NotImplementedError

    def literal_eval(self, response_content: str) -> Union[str, List, Dict[str, Any]]:
        """
        从大语言模型的响应内容中提取并解析JSON或列表格式的数据。

        Args:
            response_content (str): 大语言模型的响应内容。

        Returns:
            解析后的JSON或列表数据。

        Raises:
            ValueError: 如果响应内容格式不正确，无法解析。
        """
        # 去除响应内容首尾的空白字符
        response_content = response_content.strip()

        # 移除 <think> 和 </think> 标签之间的内容，特别是针对DeepSeek推理模型
        if "<think>" in response_content and "</think>" in response_content:
            end_of_think = response_content.find("</think>") + len("</think>")
            response_content = response_content[end_of_think:]

        try:
            # 检查响应内容是否为代码块格式（以 ``` 开头和结尾）
            if response_content.startswith("```") and response_content.endswith("```"):
                # 根据不同的代码块标识移除前缀和后缀
                if response_content.startswith("```python"):
                    response_content = response_content[9:-3]
                elif response_content.startswith("```json"):
                    response_content = response_content[7:-3]
                elif response_content.startswith("```str"):
                    response_content = response_content[6:-3]
                elif response_content.startswith("```\n"):
                    response_content = response_content[4:-3]
                else:
                    # 若代码块格式无效，抛出异常
                    raise ValueError("Invalid code block format")
            # 尝试使用ast.literal_eval解析内容
            result = ast.literal_eval(response_content.strip())
        except Exception as e:
            # 使用正则表达式查找JSON或列表格式的内容
            logger.warning(e)
            logger.warning(response_content)
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_tb(exc_traceback, limit=None, file=sys.stdout)
            json_pattern = r'\{.*?\}|\[.*?\]'
            import re
            matches = re.findall(json_pattern, response_content, re.DOTALL)
            if matches:
                try:
                    # 尝试解析第一个匹配的 JSON 或列表
                    result = ast.literal_eval(matches[0])
                    return result
                except Exception as e:
                    logger.warning(f"Failed to parse matched JSON/List: {e}")
            return None  # 返回原始内容

        return result
