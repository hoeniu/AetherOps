from typing import Union, Iterator, Optional, List, Callable
from agno.agent import RunResponse
from kbx.knowledge_base.base_index import BaseIndex
from kbx.knowledge_base.types import QueryConfig
from kbx.knowledge_base.types import QueryResults

from ..base_agent import BaseAgent
from ..types import SearchAgentConfig


class BaseSearcher(BaseAgent[SearchAgentConfig]):
    def __init__(
            self,
            # 传入的配置对象，类型为SearchAgentConfig，包含搜索代理所需的配置信息
            config: SearchAgentConfig
    ):
        """
        初始化 DeepSearcher 类的实例。

        Args:
            config (SearchAgentConfig): 传入的配置对象，包含搜索代理所需的配置信息。
        """
        # 调用父类BaseAgent的构造函数，将配置对象传递给父类进行初始化
        super().__init__(config)

    def run(self, retrieve_function: Callable, query: QueryConfig) -> Union[RunResponse, Iterator[RunResponse]]:
        """
        运行搜索操作，调用 `retrieve` 方法从指定索引中检索与查询相关的结果。

        Args:
            retrieve_function (Callable): 用于检索的索引对象。
            query (QueryConfig): 查询配置对象，包含查询文本和其他相关参数。

        Returns:
            QueryResults: 检索到的结果列表，经过去重处理。
        """
        # 调用 retrieve 方法进行实际的检索操作
        return RunResponse(content=self.retrieve(retrieve_function, query).model_dump(), content_type='str')

    def retrieve(
            self, index: BaseIndex, query: QueryConfig, selected_doc_ids: Optional[List[str]] = None
    ) -> QueryResults:
        """
        从指定的索引中检索与查询相关的结果。

        该方法会将原始查询分解为子查询，并通过多次迭代来获取更多相关结果。
        在每次迭代中，它会执行子查询，合并结果，去重，并根据当前结果生成新的差距查询。

        Args:
            index (BaseIndex): 用于检索的索引对象。
            query (QueryConfig): 查询配置对象，包含查询文本和其他相关参数。
            selected_doc_ids (Optional[List[str]]): 文档ID列表，用于在检索时过滤文档。
        Returns:
            QueryResults: 检索到的结果列表，经过去重处理。
        """
        raise NotImplementedError
