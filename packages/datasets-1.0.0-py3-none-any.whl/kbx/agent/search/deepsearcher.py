import copy
import json
from typing import Tuple, List, Union, Iterator, Callable
from kbx.common.logging import logger
from ..types import SearchAgentConfig
from kbx.common.prompt import get_category_prompts
from kbx.knowledge_base.types import QueryResult, QueryResults, QueryConfig, RetrievalStepMessage
from agno.agent import Agent, RunResponse
from .base_searcher import BaseSearcher


class DeepSearcher(BaseSearcher):
    def __init__(
            self,
            # 传入的配置对象，类型为SearchAgentConfig，包含搜索代理所需的配置信息
            config: SearchAgentConfig
    ):
        """
        初始化 DeepSearcher 类的实例。

        Args:
            config (SearchAgentConfig): 传入的配置对象，包含搜索代理所需的配置信息。
        """
        # 调用父类BaseAgent的构造函数，将配置对象传递给父类进行初始化
        super().__init__(config)
        # 调用get_category_prompts函数，获取类型为'deepsearcher'的提示模板
        self.prompt_templates = get_category_prompts('deepsearcher')
        # 创建子查询代理，用于根据用户输入生成子查询
        self.sub_query_agent = Agent(
            # 使用配置中的Agno模型
            model=self.agno_model,
            # 代理的描述信息，告知代理的任务
            description="你是一个专业的搜索助手，会按照用户要求，根据用户的搜索输入，辅助用户完成搜索任务。",
            # 是否显示工具调用信息
            show_tool_calls=True,
            # 最大重试次数，从配置中获取
            retries=self._config.max_iter
        )
        # 创建反思代理，用于根据搜索结果反思并生成差距查询
        self.reflect_agent = Agent(
            # 使用配置中的Agno模型
            model=self.agno_model,
            # 代理的描述信息，告知代理的任务
            description="你是一个专业的搜索助手，会按照用户要求，根据用户的搜索输入，辅助用户完成搜索任务。",
            # 是否显示工具调用信息
            show_tool_calls=True,
            # 最大重试次数，从配置中获取
            retries=self._config.max_iter
        )
        # 创建评估代理，用于对搜索结果进行评估
        self.critic_agent = Agent(
            # 使用配置中的Agno模型
            model=self.agno_model,
            # 代理的描述信息，告知代理的任务
            description="你是一个专业的搜索助手，会按照用户要求，根据用户的搜索输入，辅助用户完成搜索任务。",
            # 是否显示工具调用信息
            show_tool_calls=True,
            # 最大重试次数，从配置中获取
            retries=self._config.max_iter
        )

    def run(self, retrieve_function: Callable, query: QueryConfig) -> Union[RunResponse, Iterator[RunResponse]]:
        """
        运行搜索操作，调用 `retrieve` 方法从指定索引中检索与查询相关的结果。

        Args:
            retrieve_function (Callable): 用于检索的索引函数。
            query (QueryConfig): 查询配置对象，包含查询文本和其他相关参数。

        Returns:
            QueryResults: 检索到的结果列表，经过去重处理。
        """
        # 调用 retrieve 方法进行实际的检索操作
        return RunResponse(content=self.retrieve(retrieve_function, query).model_dump(), content_type='str')

    def generate_sub_queries(self, original_query: str) -> Tuple[List[str], int]:
        """
        根据原始查询生成子查询列表。

        Args:
            original_query (str): 原始查询字符串。

        Returns:
            Tuple[List[str], int]: 一个元组，包含生成的子查询列表和整数（根据上下文推测可能是某种计数或标识）。
        """
        # 调用大语言模型的聊天接口，使用预定义的提示模板格式化原始查询，并限制生成的最大令牌数
        response_content = self.sub_query_agent.run(
            # 使用提示模板中的子查询提示，将原始查询插入到提示中
            message=self.prompt_templates["SUB_QUERY_PROMPT"].text.format(
                original_query=original_query),
            retries=1
        )
        assert isinstance(response_content, RunResponse)
        assert response_content.content_type == 'str'
        # 调用 literal_eval 方法解析大语言模型的响应内容，将其转换为子查询列表和整数的元组
        return self.literal_eval(response_content.content)

    def generate_gap_queries(
            self, original_query: str, all_sub_queries: List[str], query_results: List[QueryResult]
    ) -> List[str]:
        """
        根据原始查询、所有子查询和查询结果生成差距查询。

        Args:
            original_query (str): 原始查询字符串。
            all_sub_queries (List[str]): 所有生成的子查询列表。
            query_results (List[QueryResult]): 查询结果列表。

        Returns:
            List[str]: 查询列表
        """
        # 使用提示模板中的反射提示，将原始查询、子查询和格式化后的查询结果插入到提示中
        reflect_prompt = self.prompt_templates["REFLECT_PROMPT"].text.format(
            # 原始查询
            question=original_query,
            # 所有子查询
            mini_questions=all_sub_queries,
            # 格式化后的查询结果
            mini_chunk_str=self._format_chunk_texts([self.format_query_result(result)
                                                     for result in query_results]),
        )
        # 调用大语言模型的聊天接口，使用反射提示并限制生成的最大令牌数
        response_content = self.reflect_agent.run(message=reflect_prompt)
        assert isinstance(response_content, RunResponse)
        assert response_content.content_type == 'str'
        # 调用 literal_eval 方法解析大语言模型的响应内容，将其转换为差距查询列表和整数的元组
        return self.literal_eval(response_content.content)

    def format_query_result(self, query_result: QueryResult):
        """
        格式化查询结果为一个字符串。

        Args:
            query_result (QueryResult): 需要格式化的查询结果对象。

        Returns:
            str: 格式化后的查询结果字符串。
        """
        # 初始化一个空列表，用于存储不同类型的查询结果文本
        text = []
        # 检查查询结果中是否包含文本块
        if query_result.chunk:
            # 如果包含文本块，将文本块的文本添加到列表中
            text.append(query_result.chunk.text)
        # 检查查询结果中是否包含图三元组
        if query_result.graph_triplets:
            # 如果包含图三元组，调用 _format_triples 方法将其格式化后添加到列表中
            text.append(self._format_triples(query_result.graph_triplets))
        # 检查查询结果中是否包含结构化结果
        if query_result.structured_result:
            # 如果包含结构化结果，调用 _format_structured_data 方法将其数据格式化后添加到列表中
            text.append(self._format_structured_data(query_result.structured_result.data))
        # 将列表中的所有文本用换行符连接成一个字符串并返回
        return "\n".join(text)

    def _format_structured_data(self, data: List[List[str]]) -> str:
        """
        格式化结构化数据为一个代码块字符串，用于展示数据表格列表。

        Args:
            data (List[List[str]]): 结构化数据，是一个二维字符串列表。

        Returns:
            str: 格式化后的代码块字符串，包含数据表格列表。
        """
        # 拼接代码块开头，添加注释说明是数据表格列表
        # 使用json.dumps将数据转换为JSON字符串
        # 拼接代码块结尾
        return "```\n# 数据表格列表如下：\n" + \
               json.dumps(data, ensure_ascii=False) + \
               "\n```"

    def _format_triples(self, triples: List[Tuple[str, str, str]]) -> str:
        """
        格式化三元组

        Args:
            triples (list[tuple[str, str, str]]): 三元组列表，每个三元组由三个字符串组成

        Returns:
            str: 格式化后的三元组字符串，以代码块形式呈现
        """
        # 拼接代码块开头，添加注释说明是三元组列表
        # 使用json.dumps将三元组列表转换为JSON字符串
        # 拼接代码块结尾
        return "```\n# 三元组列表如下：\n" + \
               json.dumps(triples, ensure_ascii=False) + \
               "\n```"

    def _format_chunk_texts(self, chunk_texts: List[str]) -> str:
        """
        将文本块列表格式化为带有编号标签的字符串。

        Args:
            chunk_texts (List[str]): 文本块列表，每个元素是一个字符串。

        Returns:
            str: 格式化后的字符串，每个文本块被包裹在 <chunk_i> 和 </chunk_i> 标签中，i 是文本块的索引。
        """
        # 初始化一个空字符串，用于存储最终格式化后的结果
        chunk_str = ""
        # 遍历文本块列表，同时获取每个文本块的索引和内容
        for i, chunk in enumerate(chunk_texts):
            # 将当前文本块包裹在 <chunk_i> 和 </chunk_i> 标签中，并添加到结果字符串中
            chunk_str += f"""<chunk_{i}>\n{chunk}\n</chunk_{i}>\n"""
        # 返回最终格式化后的字符串
        return chunk_str

    def wrap_query_like(self, query_text: str, query: QueryConfig):
        """
        根据给定的查询文本和查询配置对象，创建一个新的查询配置对象。

        Args:
            query_text (str): 新的查询文本。
            query (QueryConfig): 原始的查询配置对象。

        Returns:
            QueryConfig: 一个新的查询配置对象，其查询文本被更新为传入的查询文本。
        """
        # 深拷贝原始的查询配置对象，避免修改原始对象
        new_query = copy.deepcopy(query)
        # 将新的查询文本赋值给新查询配置对象的 text 属性
        new_query.text = query_text
        # 返回新的查询配置对象
        return new_query

    @classmethod
    def deduplicate_results(cls, results: List[QueryResult]) -> List[QueryResult]:
        """
        对查询结果列表进行去重处理。

        Args:
            results (List[QueryResult]): 待去重的查询结果列表。

        Returns:
            List[QueryResult]: 去重后的查询结果列表。
        """
        # 初始化一个集合，用于存储已经出现过的查询结果的特征元组
        seen_results = set()
        # 初始化一个空列表，用于存储去重后的查询结果
        deduplicated_results = []

        # 遍历查询结果列表
        for result in results:
            # 创建一个特征元组，包含chunk、graph_triplets和structured_result
            result_key = (
                result.chunk.text if result.chunk else None,
                tuple(sorted(result.graph_triplets, key=lambda x: json.dumps(x, ensure_ascii=False)))
                if result.graph_triplets else None,
                json.dumps(result.structured_result.dict(), sort_keys=True) if result.structured_result else None
            )

            # 检查该特征元组是否已经在集合中
            if result_key not in seen_results:
                # 如果不在集合中，将该特征元组添加到集合中
                seen_results.add(result_key)
                # 同时将该查询结果添加到去重后的列表中
                deduplicated_results.append(result)
        return deduplicated_results

    def retrieve(
            self, retrieve_function: Callable, query: QueryConfig
    ) -> Iterator[QueryResults]:
        """
        从指定的索引中检索与查询相关的结果。

        该方法会将原始查询分解为子查询，并通过多次迭代来获取更多相关结果。
        在每次迭代中，它会执行子查询，合并结果，去重，并根据当前结果生成新的差距查询。

        Args:
            retrieve_function (Callable): 用于检索的索引函数。
            query (QueryConfig): 查询配置对象，包含查询文本和其他相关参数。

        Returns:
            Iterator[QueryResults]: 检索到的结果列表，经过去重处理。
        """
        # 记录原始查询文本
        logger.info(f"<query> {query.text} </query>\n")
        # 存储所有检索结果
        all_search_res = QueryResults()
        # 存储所有生成的子查询
        all_sub_queries = []
        # 执行初始检索
        search_results = retrieve_function(query)
        for result in search_results:
            if not result.is_final:
                yield result
            else:
                all_search_res.extend(result.results)
                all_search_res.extend(QueryResults(step_messages=result.step_messages))
        all_sub_queries.append(query.text)

        all_search_res.append(RetrievalStepMessage(
            step_name='执行检索(第1次迭代)',
            content=f"本次检索到{len(all_search_res)}条相关上下文\n\n"
        ))
        if query.stream:
            yield QueryResults(step_messages=all_search_res.step_messages[-1])

        # 进行最大迭代次数的循环
        for iter in range(self._config.max_iter - 1):
            logger.info(f">> Iteration: {iter + 1}\n")

            # 反思检索结果并生成差距查询
            logger.info("**<think> Reflecting on the search results... </think>\n")
            try:
                sub_gap_queries = self.generate_gap_queries(
                    query.text, all_sub_queries, all_search_res
                )
            except Exception as e:
                logger.error(f"生成差距查询时发生错误: {str(e)}")
                break
            # 搜索结果充分, 停止搜索
            if not sub_gap_queries:
                logger.info(
                    "<think> No new search queries were generated. Exiting. </think>\n"
                )
                all_search_res.append(RetrievalStepMessage(
                    step_name='检索结果反思',
                    content="当前查询结果已符合预期，进入下一流程\n\n"
                ))
                if query.stream:
                    yield QueryResults(step_messages=all_search_res.step_messages[-1])
                break
            # 搜索子查询
            logger.info(
                f"<think> "
                f"New search queries for current iteration: {sub_gap_queries} "
                f"</think>\n"
            )
            all_search_res.append(RetrievalStepMessage(
                step_name='检索结果反思',
                content=f"当前查询结果不符合预期，生成新的查询列表：{'、'.join(sub_gap_queries)}\n\n"
            ))
            if query.stream:
                yield QueryResults(step_messages=all_search_res.step_messages[-1])
            search_res_from_index = []
            # 创建所有子查询的检索任务
            for sub_query in sub_gap_queries:
                try:
                    for sub_res in retrieve_function(self.wrap_query_like(sub_query, query)):
                        if not sub_res.is_final:
                            yield sub_res
                        else:
                            search_res_from_index.extend(sub_res)
                            all_search_res.extend(QueryResults(step_messages=sub_res.step_messages))
                except Exception as e:
                    logger.error(f"检索子查询 {sub_query} 时发生错误: {str(e)}")
                    continue

            # 对检索结果进行去重处理
            search_res_from_index = DeepSearcher.deduplicate_results(search_res_from_index)
            step_log = "本次检索到0条相关上下文\n\n"
            if search_res_from_index:
                step_log = f"本次检索到{len(search_res_from_index)}条相关上下文\n\n"
                all_search_res.extend(search_res_from_index)
            all_search_res.append(RetrievalStepMessage(
                step_name=f'执行检索(第{iter + 2}次迭代)',
                content=step_log
            ))
            if query.stream:
                yield QueryResults(step_messages=all_search_res.step_messages[-1])
            all_sub_queries.extend(sub_gap_queries)

        # 对所有检索结果进行最终去重处理
        all_search_res.results = DeepSearcher.deduplicate_results(all_search_res)
        all_search_res.is_final = True
        yield all_search_res
