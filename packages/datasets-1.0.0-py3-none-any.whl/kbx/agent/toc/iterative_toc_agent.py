import re
import json
from textwrap import dedent
from kbx.agent.toc.base_toc_agent import BaseTOCAgent, TitleCmd
from kbx.agent.types import TOCAgentConfig
from kbx.common.types import DocData
from typing import Iterator, List, Dict
from kbx.common.prompt import get_category_prompts
from kbx.common.utils import doc_element_to_markdown
from kbx.common.logging import logger
from agno.agent import Agent


class IterativeTOCAgent(BaseTOCAgent):
    """一个迭代式的TOC Agent，基于LLM Agent实现文档标题目录的自动生成

    调用时，传入一个文档内容DocData，返回一个标题指令序列，然后根据这些指令对文档内容进行标题目录构建
    """
    def __init__(self, config: TOCAgentConfig):
        super().__init__(config)

        self.prompts = get_category_prompts('toc_agent')

        # 按模型max_context_len来设置chunk_size
        MIN_CHUNK_SIZE = 1024 * 4
        MAX_CHUNK_SIZE = 1024 * 16
        self.chunk_size = max(min(self.llm_config.max_context_len - 1024 * 8, MAX_CHUNK_SIZE), MIN_CHUNK_SIZE)
        # for testing
        # self.chunk_size = 2048
        from kbx.common.token_counter.token_counter_factory import get_token_counter
        self.token_counter = get_token_counter(self._config.token_counter)

    def generate_title_cmds(self, doc_data: DocData) -> Iterator[TitleCmd]:
        """对给定的DocData格式文档数据进行内容分析，然后尝试生成一个标题指令序列用于后续为文档构造一套符合逻辑的标题目录

        Args:
            doc_data (DocData): 需要进行标题目录构建的文档数据

        Returns:
            Iterator[TitleCmd]: 返回一个包含标题指令的迭代器
        """
        title_cmd_schema = json.dumps(
            TitleCmd.model_json_schema(),
            indent=2,
            ensure_ascii=False
        )
        current_title_cmds: List[TitleCmd] = []

        # 创建Agent
        agent_intro = self.prompts["ITERATIVE_TOC_AGENT_INTRO"]
        agent_instructions = self.prompts["ITERATIVE_TOC_AGENT_INSTRUCTIONS"](
            template_type='text',
            title_cmd_schema=title_cmd_schema,
        )
        agent = Agent(
            model=self.agno_model,
            debug_mode=True,
            retries=self._config.max_iter,
            introduction=agent_intro.text,
            instructions=agent_instructions,
        )

        for k, batch_data in enumerate(self._split_doc_batches(doc_data)):
            prompt = dedent(
                f"""
                ## current_title_cmds

                {json.dumps([cmd.model_dump(mode='json') for cmd in current_title_cmds], indent=2, ensure_ascii=False)}

                ## batch_doc_elements

                {json.dumps(batch_data, indent=2, ensure_ascii=False)}
                """
            )

            # 每个batch的处理最多重试max_iter次，如果仍然失败，则直接跳过此batch
            for i in range(self._config.max_iter):
                logger.debug(f"IterativeTOCAgent \"{doc_data.file_name}\"，第{k}个batch，第{i}次重试")
                resp = agent.run(
                    messages=[
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                )
                resp = resp.content

                # 从resp中解析出可能存在的json字典，然后更新toc
                try:
                    # 先使用正则提取出json字符串，注意```json可能存在也可能不存在，所以这里直接提取大括号内容
                    # 匹配从第一个{开始到最后一个}结束的内容
                    groups = re.search(r'(\{[\s\S]*\})', resp)
                    if groups:
                        json_str = groups.group(1)
                        data = json.loads(json_str)
                        batch_title_cmd = [TitleCmd(**item) for item in data['cmds']]
                        batch_title_cmd_json = [cmd.model_dump(mode='json') for cmd in batch_title_cmd]
                        logger.debug(
                            f"IterativeTOCAgent \"{doc_data.file_name}\"，第{k}次迭代，batch标题指令序列：\n"
                            f"{json.dumps(batch_title_cmd_json, indent=2, ensure_ascii=False)}"
                        )
                        for cmd in batch_title_cmd:
                            current_title_cmds.append(cmd)
                            yield cmd
                        # 进行下一个batch迭代
                        break
                    else:
                        # 重试
                        continue
                except Exception as e:
                    import traceback
                    traceback = traceback.format_exc()
                    logger.error(f"解析json字符串失败: {e}\n{traceback}\njson_str:\n\"{json_str}\"")

    def _split_doc_batches(self, doc_data: DocData) -> Iterator[List[Dict[str, str]]]:
        """将长文档分割成N个顺序的的batch doc elements，用于后续的遍历处理

        Args:
            doc_data (DocData): 需要分割的文档数据

        Returns:
            Iterator[List[Dict[str, str]]]: 返回一个包含Batch数据的迭代器，每个Batch都是一个列表，
                列表中每个元素是一个字典，字典格式为：
                {
                    "id": str,
                    "type": str,
                    "content": str
                }
        """
        # TODO：暂时使用一个简单的按顺序累积doc elements直到达到chunk size的实现，未来可以考虑进行优化

        chunk_list = []
        chunk_token_count = 0
        # NOTE: 这里需要使用深拷贝，否则外部在收到返回值后立马修改doc_data.doc_elements
        for doc_element in doc_data.doc_elements.model_copy(deep=True):
            md_text = doc_element_to_markdown(doc_element=doc_element, mode='original')
            doc_element_token_count = self.token_counter(md_text)

            if len(chunk_list) > 0 and chunk_token_count + doc_element_token_count > self.chunk_size:
                # 如果当前chunk_list非空，且加上当前doc_element后超过chunk_size，则yield当前chunk_list
                yield chunk_list
                chunk_list = []
                chunk_token_count = 0

            chunk_list.append(
                {
                    'id': doc_element.doc_element_id,
                    'type': doc_element.type.value,
                    'content': md_text
                }
            )
            chunk_token_count += doc_element_token_count

        if chunk_list:
            yield chunk_list
