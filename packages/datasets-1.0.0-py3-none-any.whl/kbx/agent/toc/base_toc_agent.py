import json
from typing import Iterator, Union, List
from kbx.agent.base_agent import BaseAgent
from kbx.agent.types import TOCAgentConfig
from kbx.common.types import DocData
from agno.run.response import RunResponse
from kbx.common.toc_builder import TitleCmd


class BaseTOCAgent(BaseAgent[TOCAgentConfig]):
    """TOC Agent基类，基于LLM Agent实现文档标题的自动推测/生成"""
    def __init__(self, config: TOCAgentConfig):
        if not isinstance(config, TOCAgentConfig):
            raise ValueError(f'Expected instance of TOCAgentConfig, but got {type(config)}: {config}')
        super().__init__(config)

    def run(self, doc_data: DocData, stream: bool = False) -> Union[RunResponse, Iterator[RunResponse]]:
        """对给定的DocData格式文档数据进行仔细分析，然后尝试生成一个TOC树

        Args:
            doc_data (DocData): 需要生成TOC树的文档数据
            stream (bool): 是否流式输出

        Returns:
            Union[RunResponse, Iterator[RunResponse]]: 返回一个推断生成的TOC树
        """
        all_title_cmds: List[TitleCmd] = []
        for batch_title_cmds in self.generate_title_cmds(doc_data):
            all_title_cmds.extend(batch_title_cmds)

            if stream:
                batch_title_cmds_json = [cmd.model_dump_json() for cmd in batch_title_cmds]
                yield RunResponse(
                    content=json.dumps(
                        batch_title_cmds_json,
                        indent=2,
                        ensure_ascii=False
                    ),
                    content_type='str'
                )

        if not stream:
            all_title_cmds_json = [cmd.model_dump_json() for cmd in all_title_cmds]
            return RunResponse(
                content=json.dumps(
                    all_title_cmds_json,
                    indent=2,
                    ensure_ascii=False
                ),
                content_type='str'
            )

    def generate_title_cmds(self, doc_data: DocData) -> Iterator[TitleCmd]:
        """对给定的DocData格式文档数据进行内容分析，然后尝试生成一个标题指令序列用于后续为文档构造一套符合逻辑的标题目录

        Args:
            doc_data (DocData): 需要进行标题目录构建的文档数据

        Returns:
            Iterator[TitleCmd]: 返回一个包含标题指令的迭代器
        """
        raise NotImplementedError("子类必须实现generate_title_cmds方法")
