import json
from typing import Tuple, List, Dict, Iterator, Union

from agno.agent import RunResponse
from kbx.common.prompt import get_category_prompts

from .base_knowledge_extractor import BaseKnowledgeExtractor
from ..types import KnowledgeExtractAgentConfig, ReflectionAgentConfig
from ..classic.default_reflection_agent import DefaultReflectionAgent


class DefaultKnowledgeExtractor(BaseKnowledgeExtractor):
    def __init__(
            self,
            # 传入的配置对象，类型为KnowledgeExtractAgentConfig，包含知识抽取代理所需的配置信息
            config: KnowledgeExtractAgentConfig
    ):
        """
        初始化 KnowledgeExtractor 类的实例。

        Args:
            config (KnowledgeExtractAgentConfig): 传入的配置对象，包含知识抽取代理所需的配置信息。
        """
        # 调用父类BaseAgent的构造函数，将配置对象传递给父类进行初始化
        super().__init__(config)
        # 从配置对象中获取模式字典并保存到实例属性
        self.schema = self._config.schema_dict
        # 调用get_category_prompts函数，获取类型为'graph'的提示模板
        self.prompt_templates = get_category_prompts('graph')
        # 创建实体抽取代理，用于从输入文本中提取实体
        self.entity_extractor = DefaultReflectionAgent(ReflectionAgentConfig(
            user_ctx=self._config.user_ctx,
            agent_name="ReflectionAgent",
            max_iter=3,
            llm_model=self._config.llm_model,
            score_threshold=8
        ))
        # 创建实体对齐代理，用于对输入文本中的实体进行对齐
        self.entity_alignment_mapper = DefaultReflectionAgent(ReflectionAgentConfig(
            user_ctx=self._config.user_ctx,
            agent_name="ReflectionAgent",
            max_iter=3,
            llm_model=self._config.llm_model,
            score_threshold=8
        ))
        # 创建实体属性抽取代理，用于从输入文本中提取实体的属性
        self.entity_property_extractor = DefaultReflectionAgent(ReflectionAgentConfig(
            user_ctx=self._config.user_ctx,
            agent_name="ReflectionAgent",
            max_iter=3,
            llm_model=self._config.llm_model,
            score_threshold=8
        ))
        # 创建实体属性过滤代理，用于过滤无效的实体属性
        self.entity_property_filter = DefaultReflectionAgent(ReflectionAgentConfig(
            user_ctx=self._config.user_ctx,
            agent_name="ReflectionAgent",
            max_iter=3,
            llm_model=self._config.llm_model,
            score_threshold=8
        ))
        # 创建关系抽取代理，用于从输入文本中提取实体之间的关系
        self.relation_extractor = DefaultReflectionAgent(ReflectionAgentConfig(
            user_ctx=self._config.user_ctx,
            agent_name="ReflectionAgent",
            max_iter=3,
            llm_model=self._config.llm_model,
            score_threshold=8
        ))

    def run(self, text: str) -> Union[RunResponse, Iterator[RunResponse]]:
        """
        执行文本的知识抽取任务。

        该方法调用 `extract` 方法对输入的文本进行知识抽取，返回抽取到的实体和关系。

        Args:
            text (str): 需要进行知识抽取的文本。

        Returns:
            Tuple[List[Dict[str, str]], List[List[Dict[str, str]]]]: 一个元组，包含两个元素：
                - 第一个元素是一个字典列表，每个字典表示一个抽取到的实体。
                - 第二个元素是一个嵌套的字典列表，每个子列表表示两个实体之间的关系。
        """
        return RunResponse(content=json.dumps(list(self.extract(text)), ensure_ascii=False), content_type='str')

    def gen_instructions_from_template(self, task: str, text: str,
                                       entities: List[Dict] = None,
                                       entity_properties: List[List[str]] = None) -> str:
        """
        获得大模型的instructions
        Args:
            task (str): 任务: NER, NER_PROPERTY, RE
            text (str): 输入text
            entities (List[Dict]): 输入text中的实体, 在NER_PROPERTY, RE任务中使用
            entity_properties List[List[str]]: 实体属性列表，PROPERTY_FILTER任务中使用
        Returns:
            str: instruction
        """
        templates = get_category_prompts('graph')
        if task == "NER":
            entity_types = list(map(lambda e: e['类型'], self.schema['实体']))
            return templates['NER'].text % (json.dumps(entity_types, ensure_ascii=False), text)
        if task == "ENTITY_ALIGNMENT":
            return templates['ENTITY_ALIGNMENT'].text % (text, json.dumps(list(map(lambda ent: ent['名称'], entities)),
                                                         ensure_ascii=False))
        if task == "NER_PROPERTY":
            property_types = list(map(lambda e: e['类型'], self.schema['属性']))
            return templates['NER_PROPERTY'].text % (
                json.dumps(property_types, ensure_ascii=False),
                json.dumps(list(map(lambda ent: ent['名称'], entities)), ensure_ascii=False),
                json.dumps(property_types, ensure_ascii=False),
                text)
        if task == "PROPERTY_FILTER":
            return templates['PROPERTY_FILTER'].text % (
                text, json.dumps(entity_properties, ensure_ascii=False))
        if task == "RE":
            relation_types = list(map(lambda e: e['类型'], self.schema['关系']))
            relation_explain = list(map(lambda e: "- {0}: {1}".format(e['类型'], e['说明']), self.schema['关系']))
            return templates['RE'].text % (json.dumps(relation_types, ensure_ascii=False),
                                           "\n".join(relation_explain),
                                           json.dumps(list(map(lambda ent: ent['名称'], entities)), ensure_ascii=False),
                                           json.dumps(relation_types, ensure_ascii=False),
                                           text)
        if task == "RELATED_NER_FILTER":
            return templates['RELATED_NER_FILTER'].text % (text,
                                                           json.dumps(list(map(lambda ent: ent['名称'], entities)),
                                                                      ensure_ascii=False))
        raise ValueError("Task {} not supported.".format(task))

    def _extract_entities(self, text) -> List[Dict[str, str]]:
        """
        从输入文本中提取实体。

        Args:
            text (str): 需要进行实体提取的文本。

        Returns:
            List[Dict[str, str]]: 提取到的实体列表，每个实体用一个字典表示。
        """
        # 调用 gen_instructions_from_template 方法，生成用于命名实体识别（NER）任务的提示信息
        prompt = self.gen_instructions_from_template("NER", text)
        # 使用实体抽取代理运行生成的提示信息，得到响应内容
        response_content = self.entity_extractor.run(text=prompt)
        # 断言响应内容是 RunResponse 类型的对象
        assert isinstance(response_content, RunResponse)
        # 断言响应内容的类型是字符串
        assert response_content.content_type == 'str'
        # 调用 literal_eval 方法解析大语言模型的响应内容，将其转换为实体列表
        entities = self.literal_eval(response_content.content)
        if not entities:
            return []
        return entities

    def _align_entities(self, text, entities) -> List[Dict[str, str]]:
        """
        对输入文本中的实体进行对齐操作。

        该方法通过生成特定的提示信息，调用实体对齐代理来获取对齐后的实体列表，
        并根据对齐结果过滤原始实体列表。

        Args:
            text (str): 输入的文本。
            entities (List[Dict[str, str]]): 输入文本中提取到的实体列表，每个实体用一个字典表示。

        Returns:
            List[Dict[str, str]]: 对齐后的实体列表，每个实体用一个字典表示。
        """
        # 调用 gen_instructions_from_template 方法，生成用于实体对齐任务的提示信息
        prompt = self.gen_instructions_from_template("ENTITY_ALIGNMENT", text, entities)
        # 使用实体对齐代理运行生成的提示信息，得到响应内容
        response_content = self.entity_alignment_mapper.run(text=prompt)
        # 断言响应内容是 RunResponse 类型的对象
        assert isinstance(response_content, RunResponse)
        # 断言响应内容的类型是字符串
        assert response_content.content_type == 'str'
        # 调用 literal_eval 方法解析大语言模型的响应内容，将其转换为对齐后的实体列表
        aligned_entities = self.literal_eval(response_content.content)
        # 如果对齐后的实体列表不为空，则过滤原始实体列表，只保留在对齐列表中的实体
        if aligned_entities and isinstance(aligned_entities, list):
            entities = list(filter(lambda ent: ent['名称'] in aligned_entities, entities))
        return entities

    def _extract_relations(self, text, entities) -> List[List[Dict[str, str]]]:
        """
        从输入文本中提取实体之间的关系。

        Args:
            text (str): 需要进行关系提取的文本。
            entities (List[Dict[str, str]]): 输入文本中提取到的实体列表，每个实体用一个字典表示。

        Returns:
            List[List[Dict[str, str]]]: 提取到的关系列表，每个关系用一个包含三个元素的列表表示，
                                        分别是起始实体、关系类型和结束实体。
        """
        # 调用 gen_instructions_from_template 方法，生成用于关系抽取（RE）任务的提示信息
        prompt = self.gen_instructions_from_template("RE", text, entities)
        # 使用关系抽取代理运行生成的提示信息，得到响应内容
        response_content = self.relation_extractor.run(text=prompt)
        # 断言响应内容是 RunResponse 类型的对象
        assert isinstance(response_content, RunResponse)
        # 断言响应内容的类型是字符串
        assert response_content.content_type == 'str'
        # 调用 literal_eval 方法解析大语言模型的响应内容，将其转换为关系列表
        relations = self.literal_eval(response_content.content)
        if not relations:
            return []
        # 初始化边列表，用于存储提取到的关系
        edges = []
        # 从配置的模式字典中获取所有关系类型
        relation_types = list(map(lambda e: e['类型'], self.schema['关系']))
        # 遍历每个关系
        for relation in relations:
            if len(relation) != 3:
                continue
            if not isinstance(relation, List) and not isinstance(relation, Tuple):
                continue
            # 初始化一个边，包含起始实体、关系类型和结束实体
            edge = [None, {"类型": relation[1]}, None]
            # 遍历每个实体，找到关系的起始实体和结束实体
            for entity in entities:
                if relation[0] == entity['名称']:
                    edge[0] = entity
                if relation[2] == entity['名称']:
                    edge[2] = entity
            # 如果边的起始实体、关系类型和结束实体都存在，并且关系类型合法，则将边添加到边列表中
            if edge[0] and edge[1] and edge[2] and relation[1] in relation_types:
                edges.append(edge)
        return edges

    def _extract_properties(self, text, entities, entities_per_group=5) -> List[Dict[str, str]]:
        """
        从输入文本中提取实体的属性，并将这些属性添加到实体字典中。

        Args:
            text (str): 输入的文本。
            entities (List[Dict[str, str]]): 输入文本中提取到的实体列表，每个实体用一个字典表示。

        Returns:
            entities (List[Dict[str, str]]): 更新后的实体列表，包含了提取到的属性。
        """
        start = 0
        while start < len(entities):
            entity_group = entities[start:start + entities_per_group]
            start = start + entities_per_group
            # 调用 gen_instructions_from_template 方法，生成用于实体属性抽取（NER_PROPERTY）任务的提示信息
            prompt = self.gen_instructions_from_template("NER_PROPERTY", text, entity_group)
            # 使用实体属性抽取代理运行生成的提示信息，得到响应内容
            response_content = self.entity_property_extractor.run(text=prompt)
            # 断言响应内容是 RunResponse 类型的对象
            assert isinstance(response_content, RunResponse)
            # 断言响应内容的类型是字符串
            assert response_content.content_type == 'str'
            # 调用 literal_eval 方法解析大语言模型的响应内容，将其转换为实体属性列表
            entity_properties = self.literal_eval(response_content.content)
            if not entity_properties:
                continue
            # 调用 gen_instructions_from_template 方法，生成用于实体属性过滤（PROPERTY_FILTER）任务的提示信息
            prompt = self.gen_instructions_from_template("PROPERTY_FILTER", text, entity_properties=entity_properties)
            # 使用实体属性过滤代理运行生成的提示信息，得到响应内容
            response_content = self.entity_property_filter.run(text=prompt)
            # 断言响应内容是 RunResponse 类型的对象
            assert isinstance(response_content, RunResponse)
            # 断言响应内容的类型是字符串
            assert response_content.content_type == 'str'
            # 调用 literal_eval 方法解析大语言模型的响应内容，将其转换为实体属性列表
            entity_properties = self.literal_eval(response_content.content)
            if not entity_properties:
                continue
            # 从配置的模式字典中获取所有属性类型，并存储在集合中
            property_types = set(prop['类型'] for prop in self.schema['属性'])
            # 遍历每个实体
            for entity in entity_group:
                # 遍历每个实体属性
                for property in entity_properties:
                    # 检查属性是否为列表，长度是否为3，实体名称是否匹配，属性类型是否合法，实体中是否已存在该属性，以及属性值是否不为空
                    if isinstance(property, list) and len(property) == 3 and entity['名称'] == property[0] and \
                            property[1] in property_types and property[1] not in entity and property[2]:
                        # 如果满足条件，则将属性添加到实体字典中
                        entity[property[1]] = property[2]
        return entities

    def _is_legal_entity(self, entity: dict) -> bool:
        """
        简化实体,只保留名称和类型
        Args:
            entity (dict): 实体字典

        Returns:
            bool: 是合法实体返回True, 否则返回False
        """
        necessary_properties = [
            '类型',
            '名称',
        ]
        for p in necessary_properties:
            if p not in entity or not entity[p]:
                return False
        property_types = set(prop['类型'] for prop in self.schema['属性'])
        entity_types = set(ent['类型'] for ent in self.schema['实体'])
        for k, v in entity.items():
            if not isinstance(k, str) or not isinstance(v, str) or k not in property_types:
                return False
        if '类型' in entity and entity['类型'] not in entity_types:
            return False
        return True

    def extract(self, text: str) -> Tuple[List[Dict[str, str]], List[List[Dict[str, str]]]]:
        """
        从输入文本中提取知识，包括实体和实体之间的关系。

        Args:
            text (str): 需要进行知识抽取的文本。

        Returns:
            Tuple[List[Dict[str, str]], List[List[Dict[str, str]]]]: 一个元组，包含两个元素：
                - 第一个元素是一个字典列表，每个字典表示一个抽取到的实体。
                - 第二个元素是一个嵌套的字典列表，每个子列表表示两个实体之间的关系。
        """
        # 调用 _extract_entities 方法从输入文本中提取实体
        entities = self._extract_entities(text)
        # 使用 _is_legal_entity 方法过滤出合法的实体
        entities = list(filter(lambda ent: self._is_legal_entity(ent), entities))
        # 如果没有合法的实体，则返回空列表
        if not entities:
            return [], []
        # 调用 _align_entities 方法对实体进行对齐操作
        entities = self._align_entities(text, entities)
        # 如果对齐后没有实体，则返回空列表
        if not entities:
            return [], []
        # 调用 _extract_properties 方法从输入文本中提取实体的属性
        entities = self._extract_properties(text, entities)
        # 调用 _extract_relations 方法从输入文本中提取实体之间的关系
        edges = self._extract_relations(text, entities)
        # 返回提取到的实体和关系
        return entities, edges
