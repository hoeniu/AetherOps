import json
from typing import Tuple, List, Dict, Iterator, Union
from agno.agent import RunResponse
from ..base_agent import BaseAgent
from ..types import KnowledgeExtractAgentConfig


class BaseKnowledgeExtractor(BaseAgent[KnowledgeExtractAgentConfig]):
    def __init__(
            self,
            # 传入的配置对象，类型为KnowledgeExtractAgentConfig，包含知识抽取代理所需的配置信息
            config: KnowledgeExtractAgentConfig
    ):
        """
        初始化 KnowledgeExtractor 类的实例。

        Args:
            config (KnowledgeExtractAgentConfig): 传入的配置对象，包含知识抽取代理所需的配置信息。
        """
        # 调用父类BaseAgent的构造函数，将配置对象传递给父类进行初始化
        super().__init__(config)
        # 从配置对象中获取模式字典并保存到实例属性
        self.schema = self._config.schema_dict

    def run(self, text: str) -> Union[RunResponse, Iterator[RunResponse]]:
        """
        执行文本的知识抽取任务。

        该方法调用 `extract` 方法对输入的文本进行知识抽取，返回抽取到的实体和关系。

        Args:
            text (str): 需要进行知识抽取的文本。

        Returns:
            Tuple[List[Dict[str, str]], List[List[Dict[str, str]]]]: 一个元组，包含两个元素：
                - 第一个元素是一个字典列表，每个字典表示一个抽取到的实体。
                - 第二个元素是一个嵌套的字典列表，每个子列表表示两个实体之间的关系。
        """
        return RunResponse(content=json.dumps(list(self.extract(text)), ensure_ascii=False), content_type='str')

    def extract(self, text: str) -> Tuple[List[Dict[str, str]], List[List[Dict[str, str]]]]:
        """
        从输入文本中提取知识，包括实体和实体之间的关系。

        Args:
            text (str): 需要进行知识抽取的文本。

        Returns:
            Tuple[List[Dict[str, str]], List[List[Dict[str, str]]]]: 一个元组，包含两个元素：
                - 第一个元素是一个字典列表，每个字典表示一个抽取到的实体。
                - 第二个元素是一个嵌套的字典列表，每个子列表表示两个实体之间的关系。
        """
        raise NotImplementedError
