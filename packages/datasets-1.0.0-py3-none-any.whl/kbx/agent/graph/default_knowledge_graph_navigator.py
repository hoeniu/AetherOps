import json
from typing import List, Iterator, Union, Dict, Any, Tuple
from kbx.common.logging import logger
import networkx as nx
from agno.agent import RunResponse

from .base_knowledge_graph_navigator import BaseKnowledgeGraphNavigator
from ..classic.default_reflection_agent import DefaultReflectionAgent
from ..types import KnowledgeGraphNavigateAgentConfig, ReflectionAgentConfig
from ...common.prompt import get_category_prompts
from ...datastore.graph.graph_base import BaseGraphDS
from ...knowledge_base.types import QueryConfig


class DefaultKnowledgeGraphNavigator(BaseKnowledgeGraphNavigator):
    def __init__(
            self,
            # 传入的配置对象，类型为KnowledgeExtractAgentConfig，包含知识抽取代理所需的配置信息
            config: KnowledgeGraphNavigateAgentConfig
    ):
        """
        初始化 DefaultKnowledgeGraphNavigator 类的实例。

        Args:
            config (KnowledgeGraphNavigateAgentConfig): 知识图谱导航代理的配置对象，
                包含了代理运行所需的各种配置信息。
        """
        # 调用父类BaseAgent的构造函数，将配置对象传递给父类进行初始化
        super().__init__(config)
        # 创建一个 DefaultReflectionAgent 实例，用于实体抽取
        # 传入的配置对象包含用户上下文、代理名称、最大迭代次数、大语言模型和分数阈值
        self.entity_extractor = DefaultReflectionAgent(ReflectionAgentConfig(
            # 用户上下文，从传入的配置对象中获取
            user_ctx=self._config.user_ctx,
            # 代理名称，设置为 "ReflectionAgent"
            agent_name="ReflectionAgent",
            # 最大迭代次数，设置为 3
            max_iter=3,
            # 大语言模型，从传入的配置对象中获取
            llm_model=self._config.llm_model,
            # 分数阈值，设置为 8
            score_threshold=8
        ))
        self.entity_navigator = DefaultReflectionAgent(ReflectionAgentConfig(
            # 用户上下文，从传入的配置对象中获取
            user_ctx=self._config.user_ctx,
            # 代理名称，设置为 "ReflectionAgent"
            agent_name="ReflectionAgent",
            # 最大迭代次数，设置为 3
            max_iter=3,
            # 大语言模型，从传入的配置对象中获取
            llm_model=self._config.llm_model,
            # 分数阈值，设置为 8
            score_threshold=8
        ))

    def run(self, datastore: BaseGraphDS, query: QueryConfig) -> Union[RunResponse, Iterator[RunResponse]]:
        """
        运行知识图谱导航任务，并将结果转换为 JSON 字符串返回。

        Args:
            datastore (BaseGraphDS): 图数据存储对象，用于存储和管理图数据。
            query (QueryConfig): 查询配置对象，包含了查询的相关配置信息。

        Returns:
            Union[RunResponse, Iterator[RunResponse]]: 运行结果，可以是一个 RunResponse 对象，
            也可以是一个 RunResponse 对象的迭代器。
        """
        # 调用 navigate 方法进行图导航，得到导航结果的图对象
        navigation_result = self.navigate(datastore, query)
        # 调用 graph_to_json 方法将图对象转换为 JSON 字符串
        json_content = self.graph_to_json(navigation_result)
        # 创建一个 RunResponse 对象，将 JSON 字符串作为内容，并指定内容类型为字符串
        return RunResponse(content=json_content, content_type='str')

    def _format_triplets(self, graph: nx.Graph) -> List[Tuple[str, str, str]]:
        """
        将图对象转换为三元组列表。
        Args:
            graph (nx.Graph): 图对象。
        Returns:
            List[Tuple[str, str, str]]: 三元组列表。
        """
        # 创建一个空列表，用于存储三元组
        triplets = []
        if graph is None:
            return triplets
        # 遍历图的所有边
        for u, v, data in graph.edges(data=True):
            # 从边的属性中获取关系类型
            relation_type = data.get('类型', '')
            # 将三元组添加到列表中
            triplets.append((graph.nodes[u]['名称'], relation_type, graph.nodes[v]['名称']))
        for node, data in graph.nodes(data=True):
            for p, v in data.items():
                if p != '名称':
                    triplets.append((data['名称'], p, v))
        # 返回三元组列表
        return triplets

    def gen_instructions_from_template(self, task: str, text: str, graph: nx.Graph = None) -> str:
        """
        获得大模型的instructions
        Args:
            task (str): 任务: NER, NER_PROPERTY, RE
            text (str): 输入text
            entities (List[Dict]): 输入text中的实体, 在NER_PROPERTY, RE任务中使用
            entity_properties List[List[str]]: 实体属性列表，PROPERTY_FILTER任务中使用
        Returns:
            str: instruction
        """
        templates = get_category_prompts('graph')
        if task == "NER":
            entity_types = list(map(lambda e: e['类型'], self.schema['实体']))
            return templates['NER'].text % (json.dumps(entity_types, ensure_ascii=False), text)
        if task == "GRAPH_NAVIGATE":
            # TODO： 返回GRAPH_NAVIGATE的prompts
            relation_types = list(map(lambda e: e['类型'], self.schema['关系']))
            return templates['GRAPH_NAVIGATE'].text % (text,
                                                       self._format_triplets(graph),
                                                       json.dumps([data['名称'] for node, data in graph.nodes(data=True)],
                                                                  ensure_ascii=False),
                                                       json.dumps(relation_types, ensure_ascii=False))
        raise ValueError("Task {} not supported.".format(task))

    def _extract_entities(self, text) -> List[Dict[str, str]]:
        """
        从输入文本中提取实体。

        Args:
            text (str): 需要进行实体提取的文本。

        Returns:
            List[Dict[str, str]]: 提取到的实体列表，每个实体用一个字典表示。
        """
        # 调用 gen_instructions_from_template 方法，生成用于命名实体识别（NER）任务的提示信息
        prompt = self.gen_instructions_from_template("NER", text)
        # 使用实体抽取代理运行生成的提示信息，得到响应内容
        response_content = self.entity_extractor.run(text=prompt)
        # 断言响应内容是 RunResponse 类型的对象
        assert isinstance(response_content, RunResponse)
        # 断言响应内容的类型是字符串
        assert response_content.content_type == 'str'
        # 调用 literal_eval 方法解析大语言模型的响应内容，将其转换为实体列表
        entities = self.literal_eval(response_content.content)
        if not entities:
            return []
        return entities

    def _search_query_nodes(self, datastore: BaseGraphDS, entities: List[Dict[str, str]]) -> Dict[int, Dict[str, Any]]:
        """
        根据给定的实体列表，在图数据存储中搜索对应的节点。

        Args:
            datastore (BaseGraphDS): 图数据存储对象，用于存储和管理图数据。
            entities (List[Dict[str, str]]): 实体列表，每个实体是一个字典，包含实体的类型和名称。

        Returns:
            Dict[int, Dict[str, Any]]: 搜索到的节点字典，键为节点 ID，值为节点的属性字典。
        """
        # 从 schema 中筛选出所有标记为 '是否标识' 为 '是' 的属性，并提取其 '类型' 作为名称属性列表
        name_properties = list(map(lambda p: p['类型'],
                                   filter(lambda x: x.get('是否标识', '否') == '是',
                                          self.schema['属性'])))
        # 如果没有找到标记为 '是否标识' 为 '是' 的属性，则默认使用 '名称' 作为名称属性
        if not name_properties:
            name_properties = ['名称']
        # 初始化一个空列表，用于存储查询到的节点 ID
        query_node_ids = []
        # 遍历实体列表
        for entity in entities:
            # 检查实体字典中是否包含 '类型' 和 '名称' 键，如果不包含则跳过该实体
            if '类型' not in entity or '名称' not in entity:
                continue
            # 遍历名称属性列表
            for name_property in name_properties:
                # 构建一个包含实体类型和名称属性的字典，用于查询节点
                entity_property = {'类型': entity['类型'], name_property: entity['名称']}
                # 调用 datastore 的 search_node_by_property 方法，根据实体属性查询节点 ID
                node_ids = datastore.search_node_by_property(entity_property)
                # 将查询到的节点 ID 添加到 query_node_ids 列表中
                query_node_ids.extend(node_ids)
        # 调用 datastore 的 search_node_by_ids 方法，根据节点 ID 列表查询节点信息
        query_nodes = datastore.search_node_by_ids(query_node_ids)
        # 返回查询到的节点信息
        return query_nodes

    def _generate_gap_queries(self, query: QueryConfig, graph: nx.Graph) -> Tuple[str, str]:
        # TODO: 获得图谱下一步探索的实体和关系类型
        prompt = self.gen_instructions_from_template("GRAPH_NAVIGATE", query.text, graph)
        logger.info(prompt)
        response_content = self.entity_navigator.run(text=prompt)
        assert isinstance(response_content, RunResponse)
        assert response_content.content_type == 'str'
        # TODO: 解析大语言模型的响应内容，将其转换为实体列表和关系类型列表
        entitiy_relation_types = self.literal_eval(response_content.content)
        return entitiy_relation_types

    def _expand_graph(self, datastore: BaseGraphDS, graph: nx.Graph, entity_relation: Tuple[str, str]) -> nx.Graph:
        """
        根据实体关系扩展图

        Args:
            datastore (BaseGraphDS): 图数据存储
            graph (nx.Graph): 当前子图
            entity_relation (Tuple[str, str]): (实体名称, 关系类型)

        Returns:
            nx.Graph: 扩展后的子图
        """
        entity_name, relation_type = entity_relation

        # 查找当前图中匹配的节点
        matching_nodes = [node for node, data in graph.nodes(data=True)
                          if data['名称'] == entity_name]
        logger.info(f'Finding {matching_nodes} for edge type {relation_type}')
        if not matching_nodes:
            logger.info(f"No matching nodes found for entity: {entity_name}")
            return graph
        relation_types = list(map(lambda e: e['类型'], self.schema['关系']))
        if relation_type not in relation_types:
            logger.info(f"Relation type {relation_type} not supported.")
            return graph

        # 对于每个匹配节点，查找指定类型的关系
        for node_id in matching_nodes:
            pred_edges = datastore.pred(node_id, {'类型': relation_type})
            logger.info(f"Pred edges: {pred_edges}")
            for pred_edge in pred_edges.items():
                pred_node_id, edge_data = pred_edge
                if pred_node_id not in graph.nodes():
                    pred_node = datastore.search_node_by_id(pred_node_id)
                    graph.add_node(pred_node_id, **pred_node)
                    logger.info(f"Add node: {pred_node_id}, {pred_node}")
                for rank, edge in edge_data.items():
                    graph.add_edge(pred_node_id, node_id, **edge)
                    logger.info(f"Add edge: {pred_node_id}, {node_id}, {edge}")

            succ_edges = datastore.succ(node_id, {'类型': relation_type})
            logger.info(f"Succ edges: {succ_edges}")
            for succ_edge in succ_edges.items():
                succ_node_id, edge_data = succ_edge
                if succ_node_id not in graph.nodes():
                    succ_node = datastore.search_node_by_id(succ_node_id)
                    graph.add_node(succ_node_id, **succ_node)
                    logger.info(f"Add node: {succ_node_id}, {succ_node}")
                for rank, edge in edge_data.items():
                    graph.add_edge(node_id, succ_node_id, **edge)
                    logger.info(f"Add edge: {node_id}, {succ_node_id}, {edge}")
        return graph

    def navigate(self, datastore: BaseGraphDS, query: QueryConfig, start_nodes: List[int] = None) -> nx.Graph:
        """
        根据给定的数据存储和查询配置进行图导航。

        Args:
            datastore (BaseGraphDS): 图数据存储对象，用于存储和管理图数据。
            query (QueryConfig): 查询配置对象，包含查询的相关信息。
            start_nodes (List[int], optional): 起始节点列表，用于指定导航的起始节点。
                如果不提供，则使用默认的起始节点。 默认为 None。
        Returns:
            nx.Graph: 导航生成的图对象。
        """
        # 创建一个空的有向多重图对象
        graph = nx.MultiDiGraph()
        if not start_nodes:
            # 生成用于命名实体识别（NER）任务的提示信息
            prompt = self.gen_instructions_from_template("NER", query.text)
            # 从提示信息中提取实体
            entities = self._extract_entities(prompt)
            # 根据提取的实体在数据存储中搜索对应的节点
            query_nodes = self._search_query_nodes(datastore, entities)
            logger.info(f"Query nodes: {query_nodes}")
        else:
            query_nodes = datastore.search_node_by_ids(start_nodes)
        if not query_nodes:
            return graph
        # 遍历查询到的节点，将节点添加到图中
        for node_id, node in query_nodes.items():
            graph.add_node(node_id, **node)
        # 进行最大迭代次数的循环，尝试发现更多的实体关系
        for iter in range(self._config.max_iter):
            # 生成用于查询间隙实体关系的查询
            gap_entity_relations = self._generate_gap_queries(query, graph)
            # 如果没有找到间隙实体关系，则跳出循环
            if not gap_entity_relations:
                break
            # 遍历间隙实体关系，这里暂时未实现具体逻辑
            for entity_relation in gap_entity_relations:
                try:
                    if len(entity_relation) != 2:
                        continue
                    graph = self._expand_graph(datastore, graph, entity_relation)
                except Exception as e:
                    logger.info(e)
                    pass
        # 返回生成的图对象
        return graph
