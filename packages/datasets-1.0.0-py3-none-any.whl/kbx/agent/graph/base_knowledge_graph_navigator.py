import json
import networkx as nx
from typing import List, Iterator, Union
from agno.agent import RunResponse
from ..base_agent import BaseAgent
from ..types import KnowledgeGraphNavigateAgentConfig
from ...datastore.graph.graph_base import BaseGraphDS
from ...knowledge_base.types import QueryConfig


class BaseKnowledgeGraphNavigator(BaseAgent[KnowledgeGraphNavigateAgentConfig]):
    def __init__(
            self,
            # 传入的配置对象，类型为KnowledgeExtractAgentConfig，包含知识抽取代理所需的配置信息
            config: KnowledgeGraphNavigateAgentConfig
    ):
        """
        初始化 BaseKnowledgeGraphNavigator 类的实例。

        Args:
            config (KnowledgeGraphNavigateAgentConfig): 知识图谱导航代理的配置对象，
                包含了代理运行所需的各种配置信息。
        """
        # 调用父类BaseAgent的构造函数，将配置对象传递给父类进行初始化
        super().__init__(config)
        # 从配置对象中获取模式字典并保存到实例属性
        self.schema = self._config.schema_dict

    def run(self, datastore: BaseGraphDS, query: QueryConfig) -> Union[RunResponse, Iterator[RunResponse]]:
        """
        运行知识图谱导航任务，并返回运行结果。

        Args:
            datastore (BaseGraphDS): 图数据存储对象，用于存储和管理图数据。
            query (QueryConfig): 查询配置对象，包含了查询的相关配置信息。

        Returns:
            Union[RunResponse, Iterator[RunResponse]]: 运行结果，可以是一个 RunResponse 对象，
            也可以是一个 RunResponse 对象的迭代器。
        """
        # 调用 navigate 方法进行导航，得到图对象，再将图对象转换为 JSON 字符串
        return RunResponse(content=self.graph_to_json(self.navigate(datastore, query)), content_type='str')

    def navigate(self, datastore: BaseGraphDS, query: QueryConfig, start_nodes: List[int] = None) -> nx.Graph:
        """
        根据给定的数据存储和查询配置进行图导航。

        该方法是一个抽象方法，需要在子类中实现具体的导航逻辑。

        Args:
            datastore (BaseGraphDS): 图数据存储对象，包含了图的结构和数据。
            query (QueryConfig): 查询配置对象，定义了导航的规则和条件。
            start_nodes (List[int], optional): 起始节点的列表，用于指定导航的起始点。
                如果未提供，则使用默认的起始节点。默认为 None。

        Returns:
            nx.Graph: 导航结果的图对象。

        Raises:
            NotImplementedError: 如果子类没有实现该方法，将抛出此异常。
        """
        raise NotImplementedError

    @classmethod
    def graph_to_json(cls, graph: nx.Graph) -> str:
        """
        将 NetworkX 图对象转换为 JSON 格式的字符串。

        Args:
            graph (nx.Graph): 要转换的 NetworkX 图对象。

        Returns:
            str: 包含图数据的 JSON 字符串。
        """
        # 将图转换为节点和边的字典
        data = {
            # 遍历图的所有节点，将节点的 ID 和属性组合成字典添加到 nodes 列表中
            "nodes": [{"id": node, **graph.nodes[node]} for node in graph.nodes()],
            # 遍历图的所有边，将边的源节点、目标节点和属性组合成字典添加到 edges 列表中
            "edges": [{"source": u, "target": v, **graph.edges[u, v]} for u, v in graph.edges()]
        }
        # 使用 json.dumps 方法将字典转换为 JSON 字符串，设置缩进为 4 个空格，不进行 ASCII 编码
        return json.dumps(data, indent=4, ensure_ascii=False)

    @classmethod
    def json_to_graph(cls, json_data: str) -> nx.Graph:
        """
        将 JSON 格式的图数据转换为 NetworkX 图对象。

        Args:
            json_data (str): 包含图数据的 JSON 字符串。

        Returns:
            nx.Graph: 转换后的 NetworkX 图对象。
        """
        # 解析 JSON 数据
        data = json.loads(json_data)
        # 创建一个空的无向图对象
        G = nx.Graph()
        # 遍历 JSON 数据中的节点列表
        for node in data["nodes"]:
            # 从节点数据中提取节点 ID
            node_id = node.pop("id")
            # 将节点添加到图中，并设置节点的属性
            G.add_node(node_id, **node)
        # 遍历 JSON 数据中的边列表
        for edge in data["edges"]:
            # 从边数据中提取源节点
            source = edge.pop("source")
            # 从边数据中提取目标节点
            target = edge.pop("target")
            # 将边添加到图中，并设置边的属性
            G.add_edge(source, target, **edge)
        # 返回构建好的图对象
        return G
