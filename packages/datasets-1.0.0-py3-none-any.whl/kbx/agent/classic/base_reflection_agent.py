from typing import Union, Iterator
from agno.run.response import RunResponse
from kbx.agent.base_agent import BaseAgent
from kbx.agent.types import ReflectionAgentConfig


class BaseReflectionAgent(BaseAgent[ReflectionAgentConfig]):
    def __init__(
            self,
            # 传入的配置对象，ReflectionAgentConfig，包含RAG代理所需的配置信息
            config: ReflectionAgentConfig
    ):
        """
        初始化 ReflectionAgent 类的实例。

        Args:
            config (ReflectionAgentConfig): 传入的配置对象，包含RAG代理所需的配置信息。
        """
        # ReflectionAgent，将配置对象传递给父类进行初始化
        super().__init__(config)

    def run(self, text: str) -> Union[RunResponse, Iterator[RunResponse]]:
        raise NotImplementedError
