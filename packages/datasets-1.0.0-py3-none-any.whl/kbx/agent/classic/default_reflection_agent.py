import traceback
import sys
from typing import Union, Iterator

from agno.agent.agent import Agent
from agno.run.response import RunResponse
from .base_reflection_agent import BaseReflectionAgent
from ..types import ReflectionAgentConfig
from pydantic import BaseModel, Field
from kbx.common.logging import logger


class Feedback(BaseModel):
    feedback: str = Field(description="评审者给的反馈")
    score: int = Field(description="得分，从0到10分")


class DefaultReflectionAgent(BaseReflectionAgent):
    def __init__(
            self,
            # 传入的配置对象，ReflectionAgentConfig，包含RAG代理所需的配置信息
            config: ReflectionAgentConfig
    ):
        """
        初始化 ReflectionAgent 类的实例。

        Args:
            config (ReflectionAgentConfig): 传入的配置对象，包含RAG代理所需的配置信息。
        """
        # ReflectionAgent，将配置对象传递给父类进行初始化
        super().__init__(config)
        self.description: str = "Reflection Agent"
        self.executor: Agent = Agent(
            name="任务执行者",
            description="任务执行智能体",
            instructions=[
                "你是一个专业的任务执行智能体。",
                "给定一个任务，以及执行该任务的要求，你会严格按照要求执行任务，给出答案。",
                "你每次的执行结果会被审核者阅读，审核者会给出评价和建议，你需要根据评价和建议改进答案。",
            ],
            model=self.agno_model,
            add_history_to_messages=True,
            num_history_responses=1,
            retries=self._config.max_iter
        )

        self.reviewer: Agent = Agent(
            name="结果评审员",
            description="内容审核智能体",
            instructions=[
                "你是一个高级审核员，具有各个领域的专业知识，你会审核各类任务的执行结果，以及各种问题的答案。",
                "给你一个任务，以及任务执行者给出的答案，你会从正确性、全面性、条理性、准确性等方面给出评价。",
                "你会确保答案没有错误！",
                "你会确保答案没有遗漏！",
                "你会确保答案没有冗余！",
                "你会确保答案符合要求！",
                "你会确保答案格式正确！",
                "你会确保答案没有无效信息！",
                "你会给出一个0-10分的评分，0分意味着答案完全错误，10分表示答案完全正确。",
            ],
            response_model=Feedback,
            model=self.agno_model,
        )

    def run(self, text: str) -> Union[RunResponse, Iterator[RunResponse]]:
        content_response = self.executor.run(text)
        max_tries = self._config.max_iter
        for _ in range(max_tries):
            try:
                task_result = (f"# 用户输入的任务：\n\n{text}\n\n# 执行者给出的答案：\n\n{content_response.content}\n\n"
                               "请对执行者的答案给出评审意见和评分。\n")
                feedback = self.reviewer.run(task_result)
                logger.info(f"{content_response.content}")
                logger.info(f"审核结果{feedback.content.score}-{feedback.content.feedback}")
                if feedback.content and feedback.content.score >= self._config.score_threshold:
                    break
                content_feedback_input = (f"对于你的答案，评审者反馈：\n{feedback.content.feedback if feedback.content else ''}\n"
                                          f"评审者评分：\n{feedback.content.score if feedback.content else ''}\n"
                                          "请根据评审反馈结果优化你的答案。")
                content_response = self.executor.run(content_feedback_input)
            except Exception as e:
                logger.warning(e)
                exc_type, exc_value, exc_traceback = sys.exc_info()
                traceback.print_tb(exc_traceback, limit=None, file=sys.stdout)
        return content_response
